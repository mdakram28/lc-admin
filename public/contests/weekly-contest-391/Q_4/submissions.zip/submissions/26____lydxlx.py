import bisect
from functools import cache
from typing import *
from collections import namedtuple
from sortedcontainers import SortedList, SortedDict
from collections import Counter
from math import inf
from math import gcd
import string
import random
import itertools

print("Start")


class Solution:
    def getDistance(self, p1, p2):
        return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])

    def helper(self, points, ignore):
        plus = []
        minus = []
        n = len(points)
        for i in range(n):
            if i == ignore:
                continue
            plus.append((points[i][0] + points[i][1], i))
            minus.append((points[i][0] - points[i][1], i))
        plus.sort()
        minus.sort()
        plus_distance = self.getDistance(points[plus[0][1]], points[plus[-1][1]])
        minus_distance = self.getDistance(points[minus[0][1]], points[minus[-1][1]])
        if plus_distance > minus_distance:
            return plus_distance, plus[0][1], plus[-1][1]
        return minus_distance, minus[0][1], minus[-1][1]

    def minimumDistance(self, points):
        ignore, index1, index2 = self.helper(points, -1)
        distance1, ignore1, ignore2 = self.helper(points, index1)
        distance2, ignore1, ignore2 = self.helper(points, index2)
        return min(distance1, distance2)


solution = Solution()
print(solution.minimumDistance([[3, 10], [5, 15], [10, 2], [4, 4]]))
print(solution.minimumDistance([[1, 1], [1, 1], [1, 1]]))
