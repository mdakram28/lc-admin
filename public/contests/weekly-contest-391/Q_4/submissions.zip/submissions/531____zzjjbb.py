class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        p = sorted((x + y, i) for i, (x, y) in enumerate(points))
        n = sorted((x - y, i) for i, (x, y) in enumerate(points))
        # print(p, n)
        pall = p[-1][0] - p[0][0]
        pl = p[-2][0] - p[0][0]
        pr = p[-1][0] - p[1][0]
        nall = n[-1][0] - n[0][0]
        nl = n[-2][0] - n[0][0]
        nr = n[-1][0] - n[1][0]
        ans = max(pall, nall)

        if pall <= nall:
            pl, pr, pall, nl, nr, nall, p, n = nl, nr, nall, pl, pr, pall, n, p
        # print(pl, pr, pall, nl, nr, nall)
        # print(p, n)
            
        if p[-1][1] == n[0][1] :
            ans = min(ans, max(pl, nr))
            # print("nr")
        if p[-1][1] == n[-1][1]:
            ans = min(ans, max(pl, nl))
            # print("nl")
        ans = min(ans, max(pl, nall))

        if p[0][1] == n[0][1] :
            ans = min(ans, max(pr, nr))
        if p[0][1] == n[-1][1]:
            ans = min(ans, max(pr, nl))
        ans = min(ans, max(pr, nall))
        return ans

                
        