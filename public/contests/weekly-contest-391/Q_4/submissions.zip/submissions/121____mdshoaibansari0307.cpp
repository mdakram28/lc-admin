class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {

        int n = points.size();

        map<int, int> sum;
        map<int, int> diff;

        for(int i = 0; i < n; i++)
        {
            int x = points[i][0];
            int y = points[i][1];
            sum[x + y]++;
            diff[x - y]++;
        }

        int ans = INT_MAX;
        for(int i = 0; i < n; i++)
        {
            int x = points[i][0];
            int y = points[i][1];

            int s = x + y;
            int d = x - y;

            sum[s]--;
            if(sum[s] == 0)
                sum.erase(s);
            diff[d]--;
            if(diff[d] == 0)
                diff.erase(d);

            ans = min(ans, max(sum.rbegin()->first - sum.begin()->first, diff.rbegin()->first - diff.begin()->first));

            sum[s]++;
            diff[d]++;
        }

        return ans;
    }
};