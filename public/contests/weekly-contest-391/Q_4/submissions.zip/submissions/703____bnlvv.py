class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        total = []
        diff = []
        for i, (x, y) in enumerate(points): 
            total.append((x+y, i))
            diff.append((x-y, i))
        total.sort()
        diff.sort()
        
        if total[-1][0] - total[0][0] > diff[-1][0] - diff[0][0]: 
            cand = total[0][1], total[-1][1]
        else: 
            cand = diff[0][1], diff[-1][1]
        ans = inf 
        for x in cand: 
            val = 0 
            lo = 0
            hi = len(points)-1
            if total[0][1] == x: lo += 1
            elif total[-1][1] == x: hi -= 1
            val = max(val, total[hi][0] - total[lo][0])
            lo = 0
            hi = len(points)-1
            if diff[0][1] == x: lo += 1
            elif diff[-1][1] == x: hi -= 1
            val = max(val, diff[hi][0] - diff[lo][0])
            ans = min(ans, val)
        return ans 