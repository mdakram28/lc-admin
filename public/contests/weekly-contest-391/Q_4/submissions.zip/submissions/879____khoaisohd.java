class Solution {
    /**
        1D -> sort
        2D
        Calculate Manhattan max dis
            Sort by x?
            
        given distance d
        [3 10] [..]
        
        [[3,10],[5,15],[10,2],[4,4]]
        [3,10] [4,4] [5,15] [10,2]
        
        move between 2 points
            dx change by delta 1
            
        max (|x1 - x2| + |y1 - y2|)
            = x1 - x2 + y1 - y2 = (x1 + y1) - (x2 + y2)
            = x2 - x1 + y1 - y2 = (y1 - x1) - (y2 - x2)
                                = (x1 - y1) - (x2 - y2)
                                =
                                
            max (sums diff) (diffs diff)
        
        1D: sort, x1 x5
            x1 x2 x3 x4 x5
        
        sudo
            sort by sum candiate is min or max
            sort by diff candiate is min or max
            
            [3,10] [10 2]
            x2 - x1 + y1 - y2
            = y1 - x1 - (y2 -x2)
            
    **/
    public int minimumDistance(int[][] points) {
        int n = points.length;
        
        int minSumId = 0;
        int maxSumId = 0;
        int minDiffId = 0;
        int maxDiffId = 0;
        
        for (int i = 1; i < n; i++) {
            int sum = points[i][0] + points[i][1];
            
            if (points[minSumId][0] + points[minSumId][1] > sum) {
                minSumId = i;
            }
            
            if (points[maxSumId][0] + points[maxSumId][1] < sum) {
                maxSumId = i;
            }
            
            int diff = points[i][0] - points[i][1];
            if (points[minDiffId][0] - points[minDiffId][1] > diff) {
                minDiffId = i;
            }
            
            if (points[maxDiffId][0] - points[maxDiffId][1] < diff) {
                maxDiffId = i;
            }
        }
        
        return Math.min(
            Math.min(minimumDistance(points, minSumId), minimumDistance(points, maxSumId)),
            Math.min(minimumDistance(points, minDiffId), minimumDistance(points, maxDiffId)));
    }
    
    public int minimumDistance(int[][] points, int skip) {
        int n = points.length;
        int minSum = Integer.MAX_VALUE;
        int maxSum = Integer.MIN_VALUE;
        int minDiff = Integer.MAX_VALUE;
        int maxDiff = Integer.MIN_VALUE;
        
        for (int i = 0; i < n; i++) {
            if (i == skip) continue;
            int sum = points[i][0] + points[i][1];
            minSum = Math.min(minSum, sum);
            maxSum = Math.max(maxSum, sum);
            
            int diff = points[i][0] - points[i][1];
            minDiff = Math.min(minDiff, diff);
            maxDiff = Math.max(maxDiff, diff);
        }
        
        
        return Math.max(maxSum - minSum, maxDiff - minDiff);
    }
}