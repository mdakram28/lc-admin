class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int N=points.size();
        vector<pair<int,int>> V(N), V1(N);

        for (int i = 0; i < N; i++) {
            V[i] = {points[i][0] + points[i][1], i};
            V1[i] = {points[i][0] - points[i][1], i};
        }

        // Sorting both the vectors
        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());

        int first=V[N-1].first-V[1].first;
        if(V1[N-1].second != V[0].second && V1[0].second != V[0].second)
            first=max(first, V1[N-1].first-V1[0].first);
        else if(V1[N-1].second == V[0].second)
            first=max(first, V1[N-2].first-V1[0].first);
        else if(V1[0].second == V[0].second)
            first=max(first, V1[N-1].first-V1[1].first);
        
        int second=V[N-2].first-V[0].first;
        if(V1[N-1].second != V[N-1].second && V1[0].second != V[N-1].second)
            second=max(second, V1[N-1].first-V1[0].first);
        else if(V1[N-1].second == V[N-1].second)
            second=max(second, V1[N-2].first-V1[0].first);
        else if(V1[0].second == V[N-1].second)
            second=max(second, V1[N-1].first-V1[1].first);
        
        int third=V1[N-1].first-V1[1].first;
        if(V[N-1].second != V1[0].second && V[0].second != V1[0].second)
            third=max(third, V[N-1].first-V[0].first);
        else if(V[N-1].second == V1[0].second)
            third=max(third, V[N-2].first-V[0].first);
        else if(V[0].second == V1[0].second)
            third=max(third, V[N-1].first-V[1].first);
        
        int fourth=V1[N-2].first-V1[0].first;
        if(V[N-1].second != V1[N-1].second && V[0].second != V1[N-1].second)
            fourth=max(fourth, V[N-1].first-V[0].first);
        else if(V[N-1].second == V1[N-1].second)
            fourth=max(fourth, V[N-2].first-V[0].first);
        else if(V[0].second == V1[N-1].second)
            fourth=max(fourth, V[N-1].first-V[1].first);
        
        int ans=min(min(first, second), min(third, fourth));
        return ans;
    }
};