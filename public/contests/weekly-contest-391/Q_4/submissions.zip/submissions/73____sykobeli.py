class Solution:
    
    def MaxDist(self, A, skip):
        # List to store maximum and
        # minimum of all the four forms
        V = []
        V1 = []

        for i in range(len(A)):
            if i == skip:
                continue
            V.append((A[i][0] + A[i][1], i))
            V1.append((A[i][0] - A[i][1], i))

        # Sorting both the vectors
        V.sort()
        V1.sort()
        
        if V[-1][0] - V[0][0] > V1[-1][0] - V1[0][0]:
            return V[-1][0] - V[0][0], V[-1][1], V[0][1]
        return V1[-1][0] - V1[0][0], V1[-1][1], V1[0][1]

    def minimumDistance(self, points: List[List[int]]) -> int:
        dist, p1, p2 = self.MaxDist(points, -1)
        d1, p3, p4 = self.MaxDist(points, p1)
        d2, p5, p6 = self.MaxDist(points, p2)
        return min(d1, d2)