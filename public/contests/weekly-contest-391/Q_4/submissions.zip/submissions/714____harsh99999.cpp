class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        
        set<int> sumPoints;
        set<int> diffPoints;
        
        unordered_map<int,int> sumP,diffP;
        
        for(int i=0;i<n;i++){
            int x=points[i][0];
            int y=points[i][1];
            
            sumP[x+y]++;
            diffP[x-y]++;
            sumPoints.insert(x+y);
            diffPoints.insert(x-y);
        }
        
        int minDis=INT_MAX;
        
        for(int i=0;i<n;i++){
            
            int x=points[i][0];
            int y=points[i][1];
            
            int sum=x+y,diff=x-y;
            
            if(sumP[sum]==1)
            sumPoints.erase(sum);
            if(diffP[diff]==1)
            diffPoints.erase(diff);
            
            int curMaxDis=0;
            
            if(sumPoints.size())curMaxDis=max( *sumPoints.rbegin()- *sumPoints.begin() , *diffPoints.rbegin()- *diffPoints.begin());
            
            // cout<<curMaxDis<<endl;
            
            minDis=min(minDis,curMaxDis);
            
            if(sumP[sum]==1)
            sumPoints.insert(sum);
            if(diffP[diff]==1)
            diffPoints.insert(diff);
        }
        
        return minDis;
    }
};


/*

// 1,1 -9,2 3,3



*/

