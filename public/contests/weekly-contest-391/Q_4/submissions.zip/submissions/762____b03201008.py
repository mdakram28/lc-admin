class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        a = []
        xma = yma = xma2 = yma2 = -10 ** 9
        xmi = ymi = xmi2 = ymi2 = 10 ** 9
        xma_idx = yma_idx = xma2_idx = yma2_idx = xmi_idx = ymi_idx = xmi2_idx = ymi2_idx = -1
        for i, (x, y) in enumerate(points):
            a.append((x - y, x + y))
            if x - y > xma:
                xma2 = xma
                xma2_idx = xma_idx
                xma = x - y
                xma_idx = i
            elif x - y > xma2:
                xma2 = x - y
                xma2_idx = i
            if x - y < xmi:
                xmi2 = xmi
                xmi2_idx = xmi_idx
                xmi = x - y
                xmi_idx = i
            elif x - y < xmi2:
                xmi2 = x - y
                xmi2_idx = i
            if x + y > yma:
                yma2 = yma
                yma2_idx = yma_idx
                yma = x + y
                yma_idx = i
            elif x + y > yma2:
                yma2 = x + y
                yma2_idx = i
            if x + y < ymi:
                ymi2 = ymi
                ymi2_idx = ymi_idx
                ymi = x + y
                ymi_idx = i
            elif x + y < ymi2:
                ymi2 = x + y
                ymi2_idx = i
        ans = 10 ** 9
        h = []
        for i, (x, y) in enumerate(a):
            heappush(h, (-abs(x - xma), i, xma_idx))
            heappush(h, (-abs(x - xma2), i, xma2_idx))
            heappush(h, (-abs(x - xmi), i, xmi_idx))
            heappush(h, (-abs(x - xmi2), i, xmi2_idx))
            heappush(h, (-abs(y - yma), i, yma_idx))
            heappush(h, (-abs(y - yma2), i, yma2_idx))
            heappush(h, (-abs(y - ymi), i, ymi_idx))
            heappush(h, (-abs(y - ymi2), i, ymi2_idx))
        _, i, j = heappop(h)
        g = h[:]
        while g[0][1] == i or g[0][2] == i:
            heappop(g)
        ans = min(ans, -g[0][0])
        while h[0][1] == j or h[0][2] == j:
            heappop(h)
        ans = min(ans, -h[0][0])
        return ans