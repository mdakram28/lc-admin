class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def f(points: List[List[int]], rem: int):
            s = [-(10**18)] * 4
            res = 0
            n = len(points)
            for i in range(n):
                if rem != i:
                    for j in range(2):
                        for k in range(2):
                            id = j * 2 + k
                            v = (points[i][0] if j else -points[i][0]) + (
                                points[i][1] if k else -points[i][1]
                            )
                            s[id] = max(s[id], -v)
                            res = max(res, s[id] + v)
            return res

        ans = 10**18
        for j in [-1, 1]:
            for k in [-1, 1]:
                ans = min(
                    ans,
                    f(
                        points,
                        max([(y * j + z * k, x) for x, (y, z) in enumerate(points)])[1],
                    ),
                )
        return ans
