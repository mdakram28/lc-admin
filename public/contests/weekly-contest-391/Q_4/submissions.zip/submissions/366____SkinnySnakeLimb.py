class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        points.sort(key = lambda x: x[0])
        
        def dist(a, b):
            return abs(a[0] - b[0]) + abs(a[1] - b[1])
        
        def maxDist(points):
            n = len(points)
            v = [0 for i in range(n)]
            v1 = [0 for i in range(n)]

            for i in range(n):
                v[i] = (points[i][0] + points[i][1], i)
                v1[i] = (points[i][0] - points[i][1], i)
                
                
            v.sort(key = lambda x: x[0])
            v1.sort(key = lambda x: x[0])

            if v[-1][0] - v[0][0] > v1[-1][0] - v1[0][0]:
                return (v[-1][1], v[0][1])
            else:
                return (v1[-1][1], v1[0][1])
            
        thePs = maxDist(points)
        points1 = [p for i, p in enumerate(points) if i != thePs[0]]
        points2 = [p for i, p in enumerate(points) if i != thePs[1]]
        p1 = maxDist(points1)
        p2 = maxDist(points2)
        
        return min(dist(points1[p1[0]], points1[p1[1]]), dist(points2[p2[0]], points2[p2[1]]))