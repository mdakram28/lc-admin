class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        xs = []
        ys = []
        for x, y in points:
            xs.append(x + y)
            ys.append(x - y)
        if max(xs) - min(xs) >= max(ys) - min(ys):
            o = sorted(range(n), key=lambda i: (xs[i], ys[i]))
            return min(
                max(xs[o[-1]] - xs[o[1]], max(ys[o[i]] for i in range(1, n)) - min(ys[o[i]] for i in range(1, n))),
                max(xs[o[-2]] - xs[o[0]], max(ys[o[i]] for i in range(n - 1)) - min(ys[o[i]] for i in range(n - 1))))
        else:
            xs, ys = ys, xs
            o = sorted(range(n), key=lambda i: (xs[i], ys[i]))
            return min(
                max(xs[o[-1]] - xs[o[1]], max(ys[o[i]] for i in range(1, n)) - min(ys[o[i]] for i in range(1, n))),
                max(xs[o[-2]] - xs[o[0]], max(ys[o[i]] for i in range(n - 1)) - min(ys[o[i]] for i in range(n - 1))))
