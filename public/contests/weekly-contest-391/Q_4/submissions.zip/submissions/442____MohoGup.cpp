#define ll long long

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<ll> sum, diff;
        int n = points.size();
        int mini = INT_MAX;
        
        for(auto point: points)
        {
            sum.insert(point[0]+point[1]);
            diff.insert(point[0]-point[1]);
        }
        
        for(int i=0;i<n;i++)
        {
            int s = points[i][0]+points[i][1];
            int d =  points[i][0]-points[i][1];
            sum.extract(s);
            diff.extract(d);
            
            int a = 0, b = 0;
            
            if (!sum.empty())
                a = (*sum.rbegin())-(*sum.begin());
            
            if (!diff.empty())
                b = (*diff.rbegin())-(*diff.begin());
            
            mini = min(mini, max(a, b));
            
            sum.insert(s);
            diff.insert(d);
        }
        
        return mini;
    }
};