from sortedcontainers import SortedList

class Solution:
    def minimumDistance(self, a: List[List[int]]) -> int:
        # def solve(b):
        #     values = defaultdict(lambda: SortedList())
        #     for x, y in b: 
        #         values[x].add(y)
        #     ans = 0
        #     mx = SortedList()
        #     mn = SortedList()
        #     for x, v in values.items():
        #         if mn: 
        #             ans = max(ans, v[-1] + x - mn[0])
        #         if mx: 
        #             ans = max(ans, mx[-1] - (v[0] + x))
        #         mx.add(v[-1] + x)
        #         mn.add(v[0] + x)
        #     return ans 
        if len(a) == 1: return 0
        p = [SortedList() for _ in range(4)]
        for x, y in a:
            p[0].add(x + y)
            p[1].add(-x + y)
            p[2].add(x - y)
            p[3].add(-x - y)
        ans = []
        for x, y in a: 
            ans.append(0)
            p[0].remove(x + y)
            ans[-1] = max(ans[-1], p[0][-1] - p[0][0])
            p[0].add(x + y)
            
            p[1].remove(- x + y)
            ans[-1] = max(ans[-1], p[1][-1] - p[1][0])
            p[1].add(- x + y)
            
            p[2].remove(x - y)
            ans[-1] = max(ans[-1], p[2][-1] - p[2][0])
            p[2].add(x - y)
            
            p[3].remove(- x - y)
            ans[-1] = max(ans[-1], p[3][-1] - p[3][0])
            p[3].add(- x - y)
        
        return min(ans)
            