class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        sort(points.begin(), points.end());
        multiset<int> sp, sm;
        int res = INT_MAX;
        
        for(auto it : points) {
            int p = it[0] + it[1], m = it[0] - it[1];
            sp.insert(p);   sm.insert(m);
        }
        for(auto it : points) {
            int p = it[0] + it[1], m = it[0] - it[1];
            sp.erase(sp.find(p));   sm.erase(sm.find(m));
            
            int ans = -1;
            if(sp.size() >= 2)      ans = max(ans, *sp.rbegin() - *sp.begin());
            if(sm.size() >= 2)      ans = max(ans, *sm.rbegin() - *sm.begin());
            if(ans != -1)   res = min(res, ans);
            
            sp.insert(p);   sm.insert(m);
        }
        return res;
    }
};