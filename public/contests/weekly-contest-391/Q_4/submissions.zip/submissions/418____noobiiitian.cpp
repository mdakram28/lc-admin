class Solution {
public:

#define ll long long
vector<pair<int, int>> MaxDist(vector<pair<int, int>> &A, int N)
{
    int minsum, maxsum, mindiff, maxdiff;
    minsum = maxsum = A[0].first + A[0].second;
    mindiff = maxdiff = A[0].first - A[0].second;

    pair<int, int> a = A[0], b = A[0];
    pair<int, int> c = A[0], d = A[0];

    for (int i = 1; i < N; i++)
    {
        int sum = A[i].first + A[i].second;
        int diff = A[i].first - A[i].second;
        if (sum < minsum)
        {
            a = A[i];
            minsum = sum;
        }
        else if (sum > maxsum)
        {
            b = A[i];
            maxsum = sum;
        }
        if (diff < mindiff)
        {
            c = A[i];
            mindiff = diff;
        }
        else if (diff > maxdiff)
        {
            d = A[i];
            maxdiff = diff;
        }
    }
    if (maxsum - minsum > maxdiff - mindiff)
    {
        return {a, b};
    }
    else
    {
        return {c, d};
    }
}

int minimumDistance(vector<vector<int>> &points)
{
    vector<pair<int, int>> A;
    int ans = INT_MAX;
    for (int i = 0; i < points.size(); i++)
    {
        A.push_back({points[i][0], points[i][1]});
    }
    vector<pair<int, int>> v = MaxDist(A, A.size());
    // cout<<v[0].first<<" "<<v[0].second<<endl;
    for (int i = 0; i < A.size(); i++)
    {
        if (A[i].first == v[0].first && A[i].second == v[0].second)
        {
            vector<pair<int, int>> B;
            for (int j = 0; j < A.size(); j++)
            {
                if (i != j)
                {
                    B.push_back(A[j]);
                }
            }
            vector<pair<int, int>> temp = MaxDist(B, B.size());
            ans = min(ans, abs(temp[0].first - temp[1].first) + abs(temp[0].second - temp[1].second));
            break;
        }
    }
    for (int i = 0; i < A.size(); i++)
    {
        if (A[i].first == v[1].first && A[i].second == v[1].second)
        {
            vector<pair<int, int>> B;
            for (int j = 0; j < A.size(); j++)
            {
                if (i != j)
                {
                    B.push_back(A[j]);
                }
            }
            vector<pair<int, int>> temp = MaxDist(B, B.size());
            ans = min(ans, abs(temp[0].first - temp[1].first) + abs(temp[0].second - temp[1].second));
            break;
        }
    }
    return ans;
}
};