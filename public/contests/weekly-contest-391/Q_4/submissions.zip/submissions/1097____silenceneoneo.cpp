class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> m1, m2, m3, m4;
        int n = points.size(), ans = INT_MAX;
        for (int i = 0; i < n; ++i) {
            m1.insert(points[i][0] + points[i][1]);
            m2.insert(-points[i][0] - points[i][1]);
            m3.insert(points[i][0] - points[i][1]);
            m4.insert(-points[i][0] + points[i][1]);
        }
        for (int i = 0; i < n; ++i) {
            m1.erase(m1.find(points[i][0] + points[i][1]));
            m2.erase(m2.find(-points[i][0] - points[i][1]));
            m3.erase(m3.find(points[i][0] - points[i][1]));
            m4.erase(m4.find(-points[i][0] + points[i][1]));
            ans = min(ans, max({(*m1.rbegin()) + (*m2.rbegin()), (*m3.rbegin()) + (*m4.rbegin()), (*m4.rbegin()) + (*m3.rbegin()), (*m2.rbegin()) + (*m1.rbegin())}));
            m1.insert(points[i][0] + points[i][1]);
            m2.insert(-points[i][0] - points[i][1]);
            m3.insert(points[i][0] - points[i][1]);
            m4.insert(-points[i][0] + points[i][1]);
        }
        return ans;
    }
};