class Solution {
    public int minimumDistance(int[][] points) {
        int n = points.length, d[] = new int[n], p[] = new int[n];
        for(int i = 0; i < n; i++) {
            p[i] = points[i][0] + points[i][1];
            d[i] = points[i][0] - points[i][1];
        }
        Arrays.sort(p);
        Arrays.sort(d);
        int res = 1_000_000_000;
        for(int i = 0; i < n; i++) {
            int pp = points[i][0] + points[i][1], dd = points[i][0] - points[i][1];
            int max = -1_000_000_000;
            max = (pp == p[0]) ? Math.max(max, p[n - 1] - p[1]) : (pp == p[n - 1]) ? Math.max(max, p[n - 2] - p[0]) : Math.max(max, p[n - 1] - p[0]);
            max = (dd == d[0]) ? Math.max(max, d[n - 1] - d[1]) : (dd == d[n - 1]) ? Math.max(max, d[n - 2] - d[0]) : Math.max(max, d[n - 1] - d[0]);
            res = Math.min(res, max);
        }
        return res;
    }
}