class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        vector<array<int,4>> arr(n),left(n),right(n);
        for (int i=0;i<n;i++) {
            int x=points[i][0],y=points[i][1];
            arr[i][0]=x+y;
            arr[i][1]=x-y;
            arr[i][2]=-x-y;
            arr[i][3]=-x+y;
        }
        left=right=arr;
        for (int i=1;i<n;i++)
            for (int k=0;k<4;k++) left[i][k]=max(left[i][k],left[i-1][k]);
        for (int i=n-2;i>0;i--)
            for (int k=0;k<4;k++) right[i][k]=max(right[i][k],right[i+1][k]);
        int inf=1e9+7;
        int res=inf;
        for (int i=0;i<n;i++) {
            array<int,4> cur={-inf,-inf,-inf,-inf};
            if (i>0) for (int k=0;k<4;k++) cur[k]=max(cur[k],left[i-1][k]);
            if (i<n-1) for (int k=0;k<4;k++) cur[k]=max(cur[k],right[i+1][k]);
            int val=0;
            val=max(val,cur[0]+cur[2]);
            val=max(val,cur[1]+cur[3]);
            // printf("val=%d\n",val);
            res=min(res,val);
        }
        return res;
    }
};