class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        if n == 2:
            return 0
        lookup1 = [0 for i in range(n)]
        lookup2 = [0 for i in range(n)]
 
        for j in range(n):
            lookup1[j] = (points[j][0] + points[j][1], j)
            lookup2[j] = (points[j][0] - points[j][1], j)

        lookup1.sort()
        lookup2.sort()

        t1, index1 = lookup1[0]
        t2, index2 = lookup1[-1]
        t3, index3 = lookup2[0]
        t4, index4 = lookup2[-1]

        def helper(points):
            n = len(points)
            l1, l2 = [0] * n, [0] * n
            for j in range(n):
                l1[j] = points[j][0] + points[j][1]
                l2[j] = points[j][0] - points[j][1]
 
            l1.sort()
            l2.sort()
            return max(l1[-1] - l1[0], l2[-1] - l2[0])
        
        res = float('inf')
        for index in [index1, index2, index3, index4]:
            res = min(res, helper(points[:index] + points[index+1:]))
        return res
            