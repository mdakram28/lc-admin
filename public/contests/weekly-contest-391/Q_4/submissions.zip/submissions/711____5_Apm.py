import heapq
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        vi1, vi2, vi3, vi4 = self.get_vertex(points)
        # print(points[vi1], points[vi2], points[vi3], points[vi4])
        dis = self.get_max_dis(points, vi1, vi2, vi3, vi4)
        for vi in (vi1, vi2, vi3, vi4):
            p = points.pop(vi)
            _vi1, _vi2, _vi3, _vi4 = self.get_vertex(points)
            dis = min(dis, self.get_max_dis(points, _vi1, _vi2, _vi3, _vi4))
            # print(points)
            # print(vi, points[_vi1], points[_vi2], points[_vi3], points[_vi4], self.get_max_dis(points, _vi1, _vi2, _vi3, _vi4))
            points.insert(vi, p)
        return dis


    def get_vertex(self, points):
        q1, q2, q3, q4 = [], [], [], []
        for i, (x, y) in enumerate(points):
            heapq.heappush(q1, (- (x + y), i))
            heapq.heappush(q2, (- (-x + y), i))
            heapq.heappush(q3, (- (x - y), i))
            heapq.heappush(q4, (- (-x - y), i))
        _, i1 = q1[0]
        _, i2 = q2[0]
        _, i3 = q3[0]
        _, i4 = q4[0]
        return i1, i2, i3, i4

    def get_max_dis(self, points, i1, i2, i3, i4):
        ps = [points[i1], points[i2], points[i3], points[i4]]
        dis = 0
        for i in range(4):
            for j in range(i + 1, 4):
                dis = max(dis, abs(ps[i][0] - ps[j][0]) + abs(ps[i][1] - ps[j][1]))
        return dis