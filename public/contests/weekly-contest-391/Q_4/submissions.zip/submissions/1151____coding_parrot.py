class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        N = len(points)
        su = [0 for i in range(N)]
        diff = [0 for i in range(N)]

        for i in range(N):
            su[i] = (points[i][0] + points[i][1], i)
            diff[i] = (points[i][0] - points[i][1], i)

        su.sort(key=lambda x: x[0])
        diff.sort(key = lambda x: x[0])

        ans = float("inf")
        mapping = [[0, 0] for i in range(len(points))]
        
        for i in range(len(points)):
            curr = i
            if curr == 0:
                d1 = su[-1][0] - su[i + 1][0]
                mapping[su[i][1]][0] = d1
                d2 = diff[-1][0] - diff[i + 1][0]
                mapping[diff[i][1]][1] = d2
            elif curr == len(points) - 1:
                d1 = su[-2][0] - su[0][0]
                mapping[su[-1][1]][0] = d1
                d2 = diff[-2][0] - diff[0][0]
                mapping[diff[-1][1]][1] = d2
            else:
                d1 = su[-1][0] - su[0][0]
                mapping[su[i][1]][0] = d1
                d2 = diff[-1][0] - diff[0][0]
                mapping[diff[i][1]][1] = d2
                
        for i in range(len(points)):
            ans = min(ans, max(mapping[i][0], mapping[i][1]))
        
        return ans
                
                
                
