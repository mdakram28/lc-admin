class Solution {
public:
    int chk(vector<int> &p,int x){
        int res=0,n=p.size();
        if(x==p.back()){
            return p[n-2]-p[0];
        }
        if(x==p[0]){
            return p[n-1]-p[1];
        }
        return p.back()-p[0];
    }
    int minimumDistance(vector<vector<int>>& ps) {
        int n=ps.size(),ans=1000000000;
        vector<vector<int> >p(4);
        for(int i=0;i<n;i++){
            p[0].push_back(ps[i][0]+ps[i][1]);
            p[1].push_back(-ps[i][0]+ps[i][1]);
            p[2].push_back(ps[i][0]-ps[i][1]);
            p[3].push_back(-ps[i][0]-ps[i][1]);
        }
        for(int i=0;i<4;i++)sort(p[i].begin(),p[i].end());
        for(int i=0;i<n;i++){
            vector<int> q={ps[i][0]+ps[i][1],-ps[i][0]+ps[i][1],ps[i][0]-ps[i][1],-ps[i][0]-ps[i][1]};
            int pans=0;
            for(int j=0;j<4;j++){
                pans=max(pans,chk(p[j],q[j]));
            }
            ans=min(ans,pans);
        }
        return ans;
    }
};