class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
       int n = points.size();

	vector<int>p, q;
	for (auto &i : points)
	{
		p.push_back(i[0] + i[1]);
		q.push_back((i[0] - i[1]));
	}
	auto X = [&](vector<int>a)
	{
		vector<int>suff_max(n, 0);
		vector<int>suff_min(n, 0);
		vector<int>pref_min(n, 0);
		vector<int>pref_max(n, 0);
		pref_min[0] = a[0];
		pref_max[0] = a[0];
		suff_min[n - 1] = a[n - 1];
		suff_max[n - 1] = a[n - 1];
		for (int i = 1; i < n; i++)
		{
			pref_min[i] = min(a[i], pref_min[i - 1]);
			pref_max[i] = max(a[i], pref_max[i - 1]);
		}
		for (int i = n - 2; i >= 0; i--)
		{
			suff_min[i] = min(a[i], suff_min[i + 1]);
			suff_max[i] = max(a[i], suff_max[i + 1]);
		}
		// print(pref_min);
		// print(pref_max);
		// print(suff_min);
		// print(suff_max);
		vector<int>aa;
		for (int i = 0; i < n; i++)
		{
			int ma1 = -1e9, mi2 = 1e9;
			if (i + 1 < n)
			{
				ma1 = suff_max[i + 1];
				mi2 = suff_min[i + 1];
				// v1 = suff_max[i + 1] - suff_min[i + 1];
			}
			if (i - 1 >= 0)
			{
				ma1 = max(ma1, pref_max[i - 1]);
				mi2 = min(mi2, pref_min[i - 1]);
				// v2 = pref_max[i - 1] - pref_min[i - 1];
			}
			aa.push_back(abs(ma1 - mi2));
		}
		return aa;
	};

	vector<int>x = X(p);
	vector<int>y = X(q);

	for (int i = 0; i < n; i++)
	{
		x[i] = max(x[i], y[i]);
	}
	sort(x.begin(), x.end());
	return x[0];

        
        
        
        
    }
};