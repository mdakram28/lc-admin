class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        int f[4][n];
        multiset<int> s1,s2,s3,s4;
        for (int i = 0; i < n; ++i) {
            s1.insert(points[i][0] + points[i][1]);
            s2.insert(points[i][0] - points[i][1]);
            s3.insert(-points[i][0] + points[i][1]);
            s4.insert(-points[i][0] - points[i][1]);
        }

        int res = INT_MAX;
        for (int i = 0; i < n; ++i) {
            s1.erase(s1.find(points[i][0] + points[i][1]));
            s2.erase(s2.find(points[i][0] - points[i][1]));
            s3.erase(s3.find(-points[i][0] + points[i][1]));
            s4.erase(s4.find(-points[i][0] - points[i][1]));
            res = min(res, max(*s1.rbegin() - *s1.begin(), max(*s2.rbegin() - *s2.begin(), max(*s3.rbegin() - *s3.begin(), *s4.rbegin() - *s4.begin()))));
            s1.insert(points[i][0] + points[i][1]);
            s2.insert(points[i][0] - points[i][1]);
            s3.insert(-points[i][0] + points[i][1]);
            s4.insert(-points[i][0] - points[i][1]);
        }

        return res;
    }
};