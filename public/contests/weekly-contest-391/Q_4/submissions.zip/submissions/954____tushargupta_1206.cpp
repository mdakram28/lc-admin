class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        set<pair<int,int>> a,b;
        for(int i=0;i<points.size();i++){
            auto x=points[i];
            a.insert({x[0]+x[1],i});
            b.insert({x[0]-x[1],i});
        }
        int ans=INT_MAX;
        for(int i=0;i<points.size();i++){
            auto x=points[i];
            pair<int,int> t1={x[0]+x[1],i};
            pair<int,int> t2={x[0]-x[1],i};
            a.erase(t1);
            b.erase(t2);
            auto lt1 = a.end();
            --lt1;
            auto z=*lt1;
            int l1 = z.first;
            auto lt2=b.end();
            --lt2;
            auto cz=*lt2;
            int l2=cz.first;
            auto ft1=a.begin();
            auto cvz=*ft1;
            int f1=cvz.first;
            auto ft2=b.begin();
            auto cvbz=*ft2;
            int f2=cvbz.first;
            int t=max(l1-f1,l2-f2);
            ans=min(ans,t);
            a.insert(t1);
            b.insert(t2);
        }
        return ans;
    }
};