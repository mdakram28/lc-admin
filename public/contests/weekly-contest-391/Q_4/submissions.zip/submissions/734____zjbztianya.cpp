class Solution {
public:
    int minimumDistance(vector<vector<int>> &points) {
        int i, j, k, n;
        multiset<int> s[2];    //定义多重集合
        multiset<int>::iterator it1, it2;
        map<int, int> m[2];    //式子对点
        int a[2];

        n = points.size();
        for (int i = 0; i < n; ++i) {
            a[0] = points[i][0];
            a[1] = points[i][1];
            for (j = 0; j < (1 << (2 - 1)); j++) {    //用二进制形式遍历所有可能的运算情况
                int sum = 0;
                for (k = 0; k < 2; k++) {    //因为是五维的，所以有4个运算符
                    //提取当前运算符
                    int t = j & 1 << k;    //1为+，0为-
                    if (t) sum += a[k];
                    else sum -= a[k];
                }
                s[j].insert(sum);
                m[j][i] = sum;
            }
        }

        int ans;
        ans = 1e9;
        for (i = 0; i < n; i++) {
            for (j = 0; j < (1 << (2 - 1)); j++) {
                if (m[j].size() > 0) {
                    s[j].erase(s[j].find(m[j][i]));
                    m[j].erase(i);
                }
            }

            int Max = 0;
            for (j = 0; j < (1 << (2 - 1)); j++) {
                if (s[j].size() > 0) {
                    it1 = s[j].begin();
                    it2 = s[j].end();
                    it2--;
                    Max = *it2 - *it1 > Max ? *it2 - *it1 : Max;
                }
            }
            ans = min(ans, Max);

            a[0] = points[i][0];
            a[1] = points[i][1];
            for (j = 0; j < (1 << (2 - 1)); j++) {    //用二进制形式遍历所有可能的运算情况
                int sum = 0;
                for (k = 0; k < 2; k++) {    //因为是五维的，所以有4个运算符
                    //提取当前运算符
                    int t = j & 1 << k;    //1为+，0为-
                    if (t) sum += a[k];
                    else sum -= a[k];
                }
                s[j].insert(sum);
                m[j][i] = sum;
            }
        }
        return ans;
    }
};