void add(map<int, int>& mmap, int k) {
    if (mmap.contains(k)) {
        mmap[k]++;
    } else {
        mmap[k] = 1;
    }
}

void del(map<int, int>& mmap, int k) {
    mmap[k]--;
    if (mmap[k] == 0) {
        mmap.erase(k);
    }
}

int mx(map<int, int>& mmap) {
    return mmap.rbegin()->first - mmap.begin()->first;
}

class Solution {
public:
    int minimumDistance(vector<vector<int>>& ps) {
        int n = (int)ps.size();
        map<int, int> a, b, c, d;
        for (int i = 0; i < n; i++) {
            auto& p = ps[i];
            add(a, p[0] + p[1]);
            add(b, p[0] - p[1]);
            add(c, -p[0] + p[1]);
            add(d, -p[0] - p[1]);
        }
        int answer = 2e8 + 100;
        for (int i = 0; i < n; i++) {
            int cur = 0;
            auto& p = ps[i];
            del(a, p[0] + p[1]);
            del(b, p[0] - p[1]);
            del(c, -p[0] + p[1]);
            del(d, -p[0] - p[1]);
            cur = max(cur, mx(a));
            cur = max(cur, mx(b));
            cur = max(cur, mx(c));
            cur = max(cur, mx(d));
            answer = min(answer, cur);
            add(a, p[0] + p[1]);
            add(b, p[0] - p[1]);
            add(c, -p[0] + p[1]);
            add(d, -p[0] - p[1]);
        }
        return answer;
    }
};