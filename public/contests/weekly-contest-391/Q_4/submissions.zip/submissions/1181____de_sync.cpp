class Solution 
{
public:
    int minimumDistance(vector<vector<int>>& points) 
    {   
        multiset<int> first, second;
        for (auto i : points)
        {
            first.insert(i[0] + i[1]);
            second.insert(i[0] - i[1]);
        }
        int minMax = INT_MAX, n = points.size();
        for (int i = 0; i < n; i++)
        {
            first.erase(first.find(points[i][0] + points[i][1]));
            second.erase(second.find(points[i][0] - points[i][1]));
            minMax = min(minMax, max(*(first.rbegin()) - *(first.begin()), *(second.rbegin()) - *(second.begin())));
            first.insert(points[i][0] + points[i][1]);
            second.insert(points[i][0] - points[i][1]);
        }

        return minMax;    
    }
};