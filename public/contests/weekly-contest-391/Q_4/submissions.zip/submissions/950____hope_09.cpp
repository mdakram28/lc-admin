class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        set<pair<int,int>> v, v1;
 
        for (int i = 0; i < n; i++) {
            pair<int,int>temp;
            temp={points[i][0] + points[i][1],i};
            v.insert(temp);
            temp.first= points[i][0] - points[i][1];
            v1.insert(temp);
        }
        set<int>res;
        for(int i=0;i<n;i++){
            pair<int,int>temp,temp2;
            temp={points[i][0] + points[i][1],i};
            v.erase(temp);
            temp2.first= points[i][0] - points[i][1];
            temp2.second=i;
            v1.erase(temp2);
            // cout<<points[v.rbegin()->second][0]<<" "<<points[v.rbegin()->second][1]<<endl;
            // cout<<points[v.begin()->second][0]<<" "<<points[v.begin()->second][1]<<endl;
            // cout<<points[v1.rbegin()->second][0]<<" "<<points[v1.rbegin()->second][1]<<endl;
            // cout<<points[v1.begin()->second][0]<<" "<<points[v1.begin()->second][1]<<endl<<endl;;
            res.insert(max(v.rbegin()->first - v.begin()->first, v1.rbegin()->first - v1.begin()->first));
            v.insert(temp);
            v1.insert(temp2);
        }
        // cout<<endl;
        return *res.begin();
    }
};