class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        set<vector<int>>st1,st2;
        for(int i = 0 ; i < n ; i++){
            int a = points[i][0] + points[i][1];
            int b = points[i][0] - points[i][1];
            st1.insert({a,b,i});
            st2.insert({b,a,i});
        }
        int ans = INT_MAX;
        for(int i = 0 ; i < n ; i++){
            int curr = 0;
            int a = points[i][0] + points[i][1];
            int b = points[i][0] - points[i][1];
            auto it1 = st1.find({a,b,i});
            auto it2 = st2.find({b,a,i});
            st1.erase(it1);
            st2.erase(it2);
            auto x = *st1.begin() , y = *st1.rbegin();
            curr = max(curr,y[0]-x[0]);
            x = *st2.begin() , y = *st2.rbegin();
            curr = max(curr,y[0]-x[0]);
            ans = min(ans,curr);
            st1.insert({a,b,i});
            st2.insert({b,a,i});
        }
        return ans;
    }
};