class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> xs;
        multiset<int> ys;
        for (auto &p : points) {
            int x = p[0], y = p[1];
            p[0] = x + y;
            p[1] = y - x;
            xs.insert(p[0]);
            ys.insert(p[1]);
        }
        
        int ans = INT_MAX;
        for (auto &p : points) {
            int x = p[0], y = p[1];
            xs.erase(xs.find(x));
            ys.erase(ys.find(y));
            
            ans = min(ans, max(*xs.rbegin() - *xs.begin(), *ys.rbegin() - *ys.begin()));
            
            xs.insert(x);
            ys.insert(y);
        }
        
        return ans;
    }
};