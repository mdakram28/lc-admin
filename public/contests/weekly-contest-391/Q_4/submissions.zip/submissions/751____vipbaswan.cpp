class Solution {
public:
    
    int findDis(pair<int, int> p1, pair<int, int> p2) {
        return abs(p1.first - p2.first) + abs(p1.second - p2.second);
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> st1, st2;
        
        int n = points.size();
        
        for(int i=0; i<n; i++) {
            int x = points[i][0], y = points[i][1];
            st1.insert(x+y);
            st2.insert(x-y);
        }
        
        int ans = INT_MAX;
        
        for(int i=0; i<n; i++) {
            // remove this point
            int x = points[i][0], y = points[i][1];
            st1.erase(st1.find(x+y));
            st2.erase(st2.find(x-y));
            
            // Find dis1
            int dis = max(*(st1.rbegin()) - *(st1.begin()), *(st2.rbegin()) - *(st2.begin()));
            
            ans = min(ans, dis);
            
            st1.insert(x+y);
            st2.insert(x-y);
        }
        
        return ans;
    }
};