class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        pointsCop=points[:]
        def maxMan(arr):
            n=len(arr)
            v=[0 for i in range(n)]
            v1=[0 for i in range(n)]
            for i in range(n):
                v[i]=(arr[i][0]+arr[i][1],arr[i])
                v1[i]=(arr[i][0]-arr[i][1],arr[i])
            v.sort(key=lambda x:x[0])
            v1.sort(key=lambda x:x[0])
            points=[]
            vsum=v[-1][0]-v[0][0]
            v1sum=v1[-1][0]-v1[0][0]
            if(vsum>v1sum):
                points=[v[-1][1],v[0][1]]
            else:
                points=[v1[-1][1],v1[0][1]]
            
            return (max(vsum,v1sum),points)
        
        def removePoint(sing):
            points=pointsCop[:]
            # print("pointscop ",pointsCop)
            for i in range(len(points)):
                if(sing[0]==points[i][0] and sing[1]==points[i][1]):
                    # print("sing ",sing)
                    points.pop(i)
                    # print("point ",points)
                    break
            return points
                    
        sum1=0
        sum2=0
        sum3=0
        maximan=maxMan(points)
        sum1=maximan[0]
        
        points=removePoint(maximan[1][0])
        # print("out ",points)
        maximan1=maxMan(points)
        sum2=maximan1[0]
        
        points=removePoint(maximan[1][1])
        maximan1=maxMan(points)
        sum3=maximan1[0]
        # print(sum1,sum2,sum3)
        return min(sum1,sum2,sum3)