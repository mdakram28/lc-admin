class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        
        
        int n=points.size(), i, mn=INT_MAX;
        multiset<int>a, b;
        
        
        
        for(i=0;i<n;i++){
            int x=points[i][0]+points[i][1];
            int y=points[i][0]-points[i][1];
            a.insert(x);
            b.insert(y);
        }
        
        for(i=0;i<n;i++){
            int x=points[i][0]+points[i][1];
            int y=points[i][0]-points[i][1];
            
            a.erase(a.find(x));
            b.erase(b.find(y));
            
            //cout<<a.size()<<" "<<b.size()<<endl;
            //int p=*(a.rbegin());
            int z=max(*a.rbegin()-*a.begin(), *b.rbegin()-*b.begin());
            if(z<mn)
                mn=z;
            a.insert(x);
            b.insert(y);
        }
        
        return mn;
        
        
    }
};