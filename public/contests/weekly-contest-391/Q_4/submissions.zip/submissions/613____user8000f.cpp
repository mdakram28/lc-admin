class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        
        
        multiset<int> xpy;
        for (auto point: points) xpy.insert(point[0]+point[1]);
        
        multiset<int> xmy;
        for (auto point: points) xmy.insert(point[0]-point[1]);
        
        int res = INT_MAX;
        
        for (auto &point: points) {
            
            int p = point[0] + point[1];
            
            xpy.erase(xpy.find(p));
            
            auto lit = xpy.begin();
            auto rit = xpy.rbegin();
            
            int pd = (*rit - *lit);
            
            xpy.insert(p);
            
            
            int m = point[0] - point[1];
            
            xmy.erase(xmy.find(m));
            
            auto mlit = xmy.begin();
            auto mrit = xmy.rbegin();
            
            int md = (*mrit - *mlit);
            
            xmy.insert(m);
            
            
            res = min(res, max(pd, md));
            
        }
        
        
        return res;
    }
};