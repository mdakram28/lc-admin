package main

import (
	"sort"
)

const MX = int64(2e18)

func minimumDistance(nums [][]int) int {
	length := len(nums)
	type point struct {
		v int64
		i int
	}
	p := make([][]point, 4)
	for i := 0; i < 4; i++ {
		p[i] = make([]point, length)
	}
	for i := 0; i < length; i++ {
		x := int64(nums[i][0])
		y := int64(nums[i][1])
		p[0][i] = point{x + y, i}
		p[1][i] = point{-x + y, i}
		p[2][i] = point{x - y, i}
		p[3][i] = point{-x - y, i}
	}
	for i := 0; i < 4; i++ {sort.Slice(p[i], func(x, y int) bool { return p[i][x].v < p[i][y].v })}
	mx := int64(0)
	ij1 := 0
	ij2 := 0
	for i := 0; i < 4; i++ {
		d := p[i][length-1].v - p[i][0].v
		if d > mx {
			mx = d
			ij1 = p[i][length-1].i
			ij2 = p[i][0].i
		}
	}
	getResult := func(qq int) int64 {
		p := make([][]point, 4)
		for i := 0; i < length; i++ {
			if i == qq {
				continue
			}
			x := int64(nums[i][0])
			y := int64(nums[i][1])
			p[0] = append(p[0], point{x + y, i})
			p[1] = append(p[1], point{-x + y, i})
			p[2] = append(p[2], point{x - y, i})
			p[3] = append(p[3], point{-x - y, i})
		}
		for i := 0; i < 4; i++ {
			sort.Slice(p[i], func(x, y int) bool { return p[i][x].v < p[i][y].v })
		}
		mx := int64(0)
		for i := 0; i < 4; i++ {
			d := p[i][len(p[i])-1].v - p[i][0].v
			mx = max(mx, d)
		}
		return mx
	}
	result := MX
	result = min(result, getResult(ij1))
	result = min(result, getResult(ij2))
	return int(result)
}
