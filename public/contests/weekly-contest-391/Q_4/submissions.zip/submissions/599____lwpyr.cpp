using ll = long long;
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        map<ll, vector<int>> as;
        map<ll, vector<int>> ms;
        int idx = 0;
        for(auto&p: points) {
            as[p[0]+p[1]].push_back(idx);
            ms[p[0]-p[1]].push_back(idx);
            idx += 1;
        }
        auto asb = as.begin();
        auto ase = --as.end();
        auto msb = ms.begin();
        auto mse = --ms.end();
        ll res = ase->first - asb->first;
        res = max(res, mse->first - msb->first);
        if (asb->second.size() == 1) {
            auto new_asb = next(asb);
            auto new_ase = ase;
            auto new_msb = msb;
            auto new_mse = mse;
            if (new_ase->second.size() == 1 && new_ase->second[0] == asb->second[0]) {
                --new_ase;
            }
            if (new_msb->second.size() == 1 && new_msb->second[0] == asb->second[0]) {
                ++new_msb;
            }
            if (new_mse->second.size() == 1 && new_mse->second[0] == asb->second[0]) {
                --new_mse;
            }
            ll cur_res = new_ase->first - new_asb->first;
            cur_res = max(cur_res, new_mse->first - new_msb->first);
            res = min(res, cur_res);
        }
        if (ase->second.size() == 1) {
            auto new_asb = asb;
            auto new_ase = prev(ase);
            auto new_msb = msb;
            auto new_mse = mse;
            if (new_asb->second.size() == 1 && new_asb->second[0] == ase->second[0]) {
                ++new_asb;
            }
            if (new_msb->second.size() == 1 && new_msb->second[0] == ase->second[0]) {
                ++new_msb;
            }
            if (new_mse->second.size() == 1 && new_mse->second[0] == ase->second[0]) {
                --new_mse;
            }
            ll cur_res = new_ase->first - new_asb->first;
            cur_res = max(cur_res, new_mse->first - new_msb->first);
            res = min(res, cur_res);
        }
        if (msb->second.size() == 1) {
            auto new_asb = asb;
            auto new_ase = ase;
            auto new_msb = next(msb);
            auto new_mse = mse;
            if (new_asb->second.size() == 1 && new_asb->second[0] == msb->second[0]) {
                ++new_asb;
            }
            if (new_ase->second.size() == 1 && new_ase->second[0] == msb->second[0]) {
                --new_ase;
            }
            if (new_mse->second.size() == 1 && new_mse->second[0] == msb->second[0]) {
                --new_mse;
            }
            ll cur_res = new_ase->first - new_asb->first;
            cur_res = max(cur_res, new_mse->first - new_msb->first);
            res = min(res, cur_res);
        }
        if (mse->second.size() == 1) {
            auto new_asb = asb;
            auto new_ase = ase;
            auto new_msb = msb;
            auto new_mse = prev(mse);
            if (new_asb->second.size() == 1 && new_asb->second[0] == mse->second[0]) {
                ++new_asb;
            }
            if (new_ase->second.size() == 1 && new_ase->second[0] == mse->second[0]) {
                --new_ase;
            }
            if (new_msb->second.size() == 1 && new_msb->second[0] == mse->second[0]) {
                ++new_msb;
            }
            ll cur_res = new_ase->first - new_asb->first;
            cur_res = max(cur_res, new_mse->first - new_msb->first);
            res = min(res, cur_res);
        }
        return res;
    }
};