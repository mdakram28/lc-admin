class Solution {
    public int minimumDistance(int[][] points) {
        // 移除一个点后，剩下的点的两两最大曼哈顿距离最小值
        // 最长的距离必须去掉一个点，不然没戏
        // 最长距离大于等于两个，则直接返回答案
        // 最长距离为一个，直接暴力计算2次
        int[] ints = doMinimumDistance(points);
        // 删除3
        int[][] newPoints1 = new int[points.length - 1][2];
        int[][] newPoints2 = new int[points.length - 1][2];
        int pos1 = 0;
        int pos2 = 0;
        for (int i = 0; i < points.length; i++) {
            if (i != ints[1]) {
                newPoints1[pos1] = points[i];
                pos1++;
            }
            if (i != ints[2]) {
                newPoints2[pos2] = points[i];
                pos2++;
            }
        }
        int[] ints1 = doMinimumDistance(newPoints1);
        int[] ints2 = doMinimumDistance(newPoints2);
        return Math.min(ints1[0], ints2[0]);
    }

    public int[] doMinimumDistance(int[][] points) {
        // 移除一个点后，剩下的点的两两最大曼哈顿距离最小值
        // 最长的距离必须去掉一个点，不然没戏
        // 最长距离大于等于两个，则直接返回答案
        // 最长距离为一个，直接暴力计算2次
        int[][][] p = new int[4][points.length][2];
        for (int i = 0; i < points.length; i++) {
            p[0][i][0] = points[i][0] + points[i][1];
            p[1][i][0] = -points[i][0] + points[i][1];
            p[2][i][0] = points[i][0] - points[i][1];
            p[3][i][0] = -points[i][0] - points[i][1];
            p[0][i][1] = i;
            p[1][i][1] = i;
            p[2][i][1] = i;
            p[3][i][1] = i;
        }
        for (int i = 0; i < 4; i++) {
            Arrays.sort(p[i], (a, b) -> a[0] - b[0]);
        }
        int[] ans = new int[] {Integer.MIN_VALUE, -1, -1};
        for (int i = 0; i < 4; i++) {
            if (p[i][points.length - 1][0] - p[i][0][0] > ans[0]) {
                ans[0] = p[i][points.length - 1][0] - p[i][0][0];
                ans[1] = p[i][0][1];
                ans[2] = p[i][points.length - 1][1];
            }
        }
        return ans;
    }
}