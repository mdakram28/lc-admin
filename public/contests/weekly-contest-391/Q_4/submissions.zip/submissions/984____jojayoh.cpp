class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        
        int n = points.size();
        int tl = 0, tr = 0, bl = 0, br = 0;
        int ans = INT_MAX;
        for(int i = 0; i < n; i++)
        {
            if(points[i][0]+points[i][1] > points[tr][0]+points[tr][1]) tr = i;
            if(points[i][0]-points[i][1] > points[br][0]-points[br][1]) br = i;
            if(-points[i][0]+points[i][1] > -points[tl][0]+points[tl][1]) tl = i;
            if(-points[i][0]-points[i][1] > -points[bl][0]-points[bl][1]) bl = i;
        }
        //cout << tl << ", " << tr << ", " << bl << ", " << br << endl;

        ans = min(ans,help(points,tl));
        ans = min(ans,help(points,tr));
        ans = min(ans,help(points,bl));
        ans = min(ans,help(points,br));
        
        return ans;
        
    }
    
    int help(vector<vector<int>>& points, int ignore)
    {
        int n = points.size();
        int first = (ignore==0);
        int tl = first, tr = first, bl = first, br = first;
        for(int i = 0; i < n; i++)
        {
            if(i == ignore) continue;
            if(points[i][0]+points[i][1] > points[tr][0]+points[tr][1]) tr = i;
            if(points[i][0]-points[i][1] > points[br][0]-points[br][1]) br = i;
            if(-points[i][0]+points[i][1] > -points[tl][0]+points[tl][1]) tl = i;
            if(-points[i][0]-points[i][1] > -points[bl][0]-points[bl][1]) bl = i;
        }

        int ans = max(points[tl][1]-points[br][1]+points[br][0]-points[tl][0],points[tr][1]-points[bl][1]+points[tr][0]-points[bl][0]);
        
        /*
        print_coord(points[tl]);
        print_coord(points[tr]);
        print_coord(points[bl]);
        print_coord(points[br]);
        cout << " : " << ans << endl;
        */
        
        return ans;
    }
    
    void print_coord(vector<int> x)
    {
        cout << x[0] << ", " << x[1] << " ; ";
    }
};