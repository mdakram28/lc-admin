class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        cnt = [Counter() for _ in range(4)]
        for x, y in points:
            cnt[0][x + y] += 1
            cnt[1][x + y] += 1
            cnt[2][x - y] += 1
            cnt[3][x - y] += 1
        
        h_mn = [[] for _ in range(4)]
        h_mx = [[] for _ in range(4)]
        for i in range(4):
            h_mn[i] = list(cnt[i].keys())
            heapify(h_mn[i])
            h_mx[i] = list(-k for k in cnt[i].keys())
            heapify(h_mx[i])
        
        ans = math.inf
        for x, y in points:
            cnt[0][x + y] -= 1
            cnt[1][x + y] -= 1
            cnt[2][x - y] -= 1
            cnt[3][x - y] -= 1
            d = 0
            for i in range(4):
                mn = mx = None
                if cnt[i][h_mn[i][0]] == 0:
                    mn = heappop(h_mn[i])
                if cnt[i][-h_mx[i][0]] == 0:
                    mx = heappop(h_mx[i])
                d = max(d, -h_mx[i][0] - h_mn[i][0])
                if mn is not None:
                    heappush(h_mn[i], mn)
                if mx is not None:
                    heappush(h_mx[i], mx)
            ans = min(ans, d)
            cnt[0][x + y] += 1
            cnt[1][x + y] += 1
            cnt[2][x - y] += 1
            cnt[3][x - y] += 1
        return ans