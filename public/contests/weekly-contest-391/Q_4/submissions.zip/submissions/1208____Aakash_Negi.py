class Solution:
    def minimumDistance(self, A) -> int:
        N = len(A)
        V = [0 for i in range(N)]
        V1 = [0 for i in range(N)]

        for i in range(N):
            V[i] = (A[i][0] + A[i][1],i)
            V1[i] = (A[i][0] - A[i][1],i)

        V.sort(key = lambda x:x[0])
        V1.sort(key = lambda x:x[0])
        a = V[-1][0] - V[0][0]
        b = V1[-1][0] - V1[0][0]
        if a > b:
            i = self.getMax(A[0:V[-1][1]]+A[V[-1][1]+1 :])
            j = self.getMax(A[0:V[0][1]]+A[V[0][1]+1 :])
            return min(i,j)
        i = self.getMax(A[0:V1[-1][1]]+A[V1[-1][1]+1 :])
        j = self.getMax(A[0:V1[0][1]]+A[V1[0][1]+1 :])
        return min(i,j)
    
    def getMax(self,A):
        N = len(A)
        V = [0 for i in range(N)]
        V1 = [0 for i in range(N)]
        for i in range(N):
            V[i] = A[i][0] + A[i][1]
            V1[i] = A[i][0] - A[i][1]

        V.sort()
        V1.sort()

        maximum = max(V[-1] - V[0],
                      V1[-1] - V1[0])

        return maximum
            