/**
 * @param {number[][]} points
 * @return {number}
 */

class SegmentNode {
    constructor(a, b) {
        this.start = a;
        this.end = b;
        this.info = -Number.MAX_VALUE;
        this.info2 = Number.MAX_VALUE
        this.left = null;
        this.right = null;
    }
}

class SegmentTree {
    constructor(root) {
        this.root = root;
    }

    constructTree(node, a, b) {
        if (a === b) {
            return;
        }
        let mid = a + Math.floor((b - a) / 2);
        node.left = new SegmentNode(a, mid);
        node.right = new SegmentNode(mid + 1, b);
        this.constructTree(node.left, a, mid);
        this.constructTree(node.right, mid + 1, b);
        node.info = Math.max(node.left.info, node.right.info);
        node.info2 = Math.min(node.left.info2, node.right.info2);
    }

    update(node, index, info1, info2) {
		if (!node) return;
        if (node.start > index || node.end < index) return;
        if (node.start === index && node.end === index) {
            node.info = info1;
            node.info2 = info2;
            return;
        }
        this.update(node.left, index, info1, info2);
        this.update(node.right, index, info1, info2);
        node.info = Math.max(node.left.info === null ? -Number.MAX_VALUE : node.left.info, node.right.info === null ?  -Number.MAX_VALUE : node.right.info);
        node.info2 = Math.min(node.left.info2 === null ? Number.MAX_VALUE :node.left.info2, node.right.info2 === null ? Number.MAX_VALUE : node.right.info2);
        
    }


    queryInfo(node, a, b) {
		if (!node) return -Number.MAX_VALUE;
        if (a > node.end || b < node.start) {
            return -Number.MAX_VALUE;
        }
        if (a <= node.start && b >= node.end) {
            return node.info !== null ? node.info: -Number.MAX_VALUE;
        }
        return Math.max(this.query(node.left, a, b), this.query(node.right, a, b));
    }
    
    queryInfo2(node, a, b) {
		if (!node) return Number.MAX_VALUE;
        if (a > node.end || b < node.start) {
            return Number.MAX_VALUE;
        }
        if (a <= node.start && b >= node.end) {
            return node.info2 !== null ? node.info2 : Number.MAX_VALUE;
        }
        return Math.min(this.query(node.left, a, b), this.query(node.right, a, b));
    }
}





var minimumDistance = function(points) {
    let n = points.length;
    let root1 = new SegmentNode(0, n - 1);
    let tree1 = new SegmentTree(root1);
    tree1.constructTree(root1, 0, n - 1);
    
    let root2 = new SegmentNode(0, n - 1);
    let tree2 = new SegmentTree(root2);
    tree2.constructTree(root2, 0, n - 1);
    for (let i = 0; i < n; i++) {
        let cur = points[i];
        let info1 = cur[0] + cur[1];
        let info2 = cur[0] - cur[1];
        tree1.update(root1, i, info1, info1);
        tree2.update(root2, i, info2, info2);
    }
    let res = Number.MAX_VALUE;
    for (let i = 0; i < n; i++) {
        let cur = points[i];
        tree1.update(root1, i, null, null);
        tree2.update(root2, i, null, null);
        let temp = Math.max(tree1.queryInfo(root1, 0, n - 1) - tree1.queryInfo2(root1, 0, n - 1), tree2.queryInfo(root2, 0, n - 1) - tree2.queryInfo2(root2, 0, n - 1));
        // console.log(i, temp)
        let info1 = cur[0] + cur[1];
        let info2 = cur[0] - cur[1];
        tree1.update(root1, i, info1, info1);
        tree2.update(root2, i, info2, info2);
        res = Math.min(res, temp);
    }
    return res;
};
//[[10,7],[5,5],[2,7],[2,6]]
//5