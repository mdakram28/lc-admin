;

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        
        vector<int> sum(n), diff(n);
        for (int i = 0; i < n; ++i) {
            sum[i] = points[i][0] + points[i][1];
            diff[i] = points[i][0] - points[i][1];
        }
        
        int minSum = *min_element(sum.begin(), sum.end());
        int maxSum = *max_element(sum.begin(), sum.end());
        int minDiff = *min_element(diff.begin(), diff.end());
        int maxDiff = *max_element(diff.begin(), diff.end());
        
      
        int globalMax = max(maxSum - minSum, maxDiff - minDiff);
        
        int result = globalMax;
        for (int i = 0; i < n; ++i) {
            
            int localMinSum = minSum, localMaxSum = maxSum, localMinDiff = minDiff, localMaxDiff = maxDiff;
           
            if (sum[i] == minSum || sum[i] == maxSum || diff[i] == minDiff || diff[i] == maxDiff) {
                vector<int> sumTemp = sum, diffTemp = diff;
                sumTemp.erase(sumTemp.begin() + i);
                diffTemp.erase(diffTemp.begin() + i);
               
                localMinSum = *min_element(sumTemp.begin(), sumTemp.end());
                localMaxSum = *max_element(sumTemp.begin(), sumTemp.end());
                localMinDiff = *min_element(diffTemp.begin(), diffTemp.end());
                localMaxDiff = *max_element(diffTemp.begin(), diffTemp.end());
            }
            
            int localMax = max(localMaxSum - localMinSum, localMaxDiff - localMinDiff);
            
            result = min(result, localMax);
        }
        
        return result;
    }
};
