class Solution {
public:
    int minimumDistance(vector<vector<int>>& a) {
        int n = a.size();
        int ans = INT_MAX;
        vector<int> ids(n); iota(ids.begin(), ids.end(), 0);
        sort(ids.begin(), ids.end(), [&](int x, int y) {
            return (a[x][0]-a[x][1]) < (a[y][0]-a[y][1]);
        });

        vector<int> ids2(n); iota(ids2.begin(), ids2.end(), 0);
        sort(ids2.begin(), ids2.end(), [&](int x, int y) {
            return (a[x][0]+a[x][1]) < (a[y][0]+a[y][1]);
        });

        for (int i = 0; i < n; i++) {
            int st = ids[0], ed = ids[n-1];
            if (st == i) st = ids[1];
            if (ed == i) ed = ids[n-2];
            int c1 = (a[ed][0] - a[ed][1]) - (a[st][0] - a[st][1]);

            st = ids2[0], ed = ids2[n-1];
            if (st == i) st = ids2[1];
            if (ed == i) ed = ids2[n-2];
            int c2 = (a[ed][0] + a[ed][1]) - (a[st][0] + a[st][1]);

            
            int c = max(c1, c2);
            // cout << c1 << " " << c2 << " " << c << endl;
            ans = min(ans, c);
        }
        return ans;
    }
};