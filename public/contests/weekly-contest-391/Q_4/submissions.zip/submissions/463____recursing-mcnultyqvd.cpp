const int INF=1e9;
const int N=1e5+10;
// int t[N];
class Solution {
public:
    // vector<vector<int>> p;
//     int dis(int i,int j){
//         return abs(p[i][0]-p[j][0])+abs(p[i][1]-p[j][1]);
//     }
//     int solve(int l,int r){
//         if(l==r) return INF;
// 	    if(l+1==r) return dis(l,r);
//         int mid=(l+r)/2;
// 	    int d1=solve(l,mid);
// 	    int d2=solve(mid+1,r);
// 	    int d=min(d1,d2);
        
//         int tot=0;
//         while(l<=mid &&(p[mid][0]-p[l][0])>d) l++;

//         int j=mid+1;
//         while(j<=r && (p[j][0]-p[mid][0])<=d) t[tot++]=j++;
//         // 找不到右侧的枚举点 
//         if(!tot) return d;

//         for(int i=l;i<=mid;i++) t[tot++]=i;
//         sort(t,t+tot,[&](const int& a,const int& b){
//             return p[a][1]<p[b][1];
//         }); 
//         for(int i=0;i<tot;i++){
//             for(int j=i+1;j<tot && abs(p[t[j]][1]-p[t[i]][1])<=d;j++){
//                 d=min(d,dis(t[i],t[j]));
//             }
//         }
//         return d;
//     }
    // 找出最大距离的两点 移除其中一个
    
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        // sort(points.begin(),points.end());
        // this->p=points;
        int a=-1,b=-1;
        int mxd=-1;
        for(int i=0;i<4;i++){
            map<int,int> mp;
            for(int j=0;j<n;j++){
                int x=points[j][0],y=points[j][1];
                int d;
                if(i==0) d=x+y;
                else if(i==1) d=x-y;
                else if(i==2) d=-x+y;
                else d=-x-y;
                mp[d]=j;
            }
            int v1=mp.begin()->first,v2=mp.rbegin()->first;
            if(v2-v1>mxd){
                mxd=v2-v1;
                a=mp.begin()->second,b=mp.rbegin()->second;
            }
        }
        // 删除a或者删除b
        vector<vector<int>> p1,p2;
        p1=points,p2=points;
        p1.erase(p1.begin()+a);
        p2.erase(p2.begin()+b);
        
        int mx1=-1,mx2=-1;
        for(int i=0;i<4;i++){
            map<int,int> mp;
            for(int j=0;j<n-1;j++){
                int x=p1[j][0],y=p1[j][1];
                int d;
                if(i==0) d=x+y;
                else if(i==1) d=x-y;
                else if(i==2) d=-x+y;
                else d=-x-y;
                mp[d]=j;
            }
            int v1=mp.begin()->first,v2=mp.rbegin()->first;
            if(v2-v1>mx1){
                mx1=v2-v1;
            }
        }
        for(int i=0;i<4;i++){
            map<int,int> mp;
            for(int j=0;j<n-1;j++){
                int x=p2[j][0],y=p2[j][1];
                int d;
                if(i==0) d=x+y;
                else if(i==1) d=x-y;
                else if(i==2) d=-x+y;
                else d=-x-y;
                mp[d]=j;
            }
            int v1=mp.begin()->first,v2=mp.rbegin()->first;
            if(v2-v1>mx2){
                mx2=v2-v1;
            }
        }
        return min(mx1,mx2);
    }
};