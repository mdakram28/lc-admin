class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        xl, yl = [], []
        for i in range(n):
            x, y = points[i]
            points[i] = [x + y, x - y]
            xl.append((x + y, i))
            yl.append((x - y, i))
        xl.sort()
        yl.sort()
        ans = max(yl[-1][0] - yl[0][0], xl[-1][0] - xl[0][0])
        def getA(cur):
            l, r = 0, n - 1
            if xl[l][1] == cur:
                l += 1
            if xl[r][1] == cur:
                r -= 1
            ly, ry = 0, n - 1
            if yl[ly][1] == cur:
                ly += 1
            if yl[ry][1] == cur:
                ry -= 1
            #print(ly, ry)
            #print(yl[ry][0] - yl[ly][0],  xl[r][0] - xl[l][0], cur)
            return max(yl[ry][0] - yl[ly][0], xl[r][0] - xl[l][0])
        ll = [xl[0][1], xl[-1][1], yl[0][1], yl[-1][1]]
        #print(xl, yl, ll)
        for k in ll:
            ans = min(ans, getA(k))
        return ans
        