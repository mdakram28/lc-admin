class Solution {
public:
    
    vector<vector<pair<int,int>>> fun(vector<vector<int>> arr){
        int n = arr.size();
        vector<vector<pair<int,int>>> ans(n, vector<pair<int,int>>(2));
        for(int i = 0; i < n ; i++){
            ans[i][0] = {arr[i][0], arr[i][0]};
            ans[i][1] = {arr[i][1], arr[i][1]};
            if(i){
                ans[i][0].first = max(ans[i][0].first, ans[i-1][0].first);
                ans[i][0].second = min(ans[i][0].second, ans[i-1][0].second);
                ans[i][1].first = max(ans[i][1].first, ans[i-1][1].first);
                ans[i][1].second = min(ans[i][1].second, ans[i-1][1].second);
                
            }
        }
        return ans;
    }
    
    
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        vector<vector<int>> arr(n, vector<int>(2));
        for(int i = 0; i < n; i++){
            arr[i][0] = p[i][0] + p[i][1];
            arr[i][1] = p[i][0] - p[i][1];
            // arr[i][2] = -p[i][0] + p[i][1];
            // arr[i][3] = -p[i][0] - p[i][1];
        }
        auto pref = fun(arr);
        reverse(arr.begin(), arr.end());
        // for(auto v: pref){
        //     for(auto p: v){
        //         cout << p.first <<" "<< p.second<< endl;
        //     }
        //     cout << endl;
        // }
        auto suffi = fun(arr);
        reverse(suffi.begin(), suffi.end());
        long long ans = INT_MAX;
        for(int i = 0; i < n; i++){
            long long tempAns = LONG_MIN;
            for(int j = 0; j < 2; j++){
                pair<int,int> pre = {INT_MIN, INT_MAX};
                pair<int,int> suff = pre;
                if(i){
                    pre = pref[i-1][j];
                }
                if(i + 1 < n){
                    suff = suffi[i + 1][j];
                }
                long long comMax = max(pre.first, suff.first);
                long long comMin = min(pre.second, suff.second);
                // cout << comMin <<" ,  " << comMax <<endl;
                tempAns = max(tempAns, comMax- comMin);
            }
            if(tempAns != LONG_MIN)ans = min(ans, tempAns);
        }
        return ans;
    }
};