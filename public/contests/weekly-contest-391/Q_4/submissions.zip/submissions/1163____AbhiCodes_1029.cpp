class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
          int n = points.size();
          multiset<int> sum, diff;

        for (int i = 0; i < n; i++) {
            sum.insert(points[i][0] + points[i][1]);
            diff.insert(points[i][0] - points[i][1]);
        }

        int ans = INT_MAX;
        for (int i = 0; i < n; i++) {
            sum.erase(sum.find(points[i][0] + points[i][1]));
            diff.erase(diff.find(points[i][0] - points[i][1]));

            int mx = max(*sum.rbegin() - *sum.begin(), *diff.rbegin() - *diff.begin());
            ans = min(ans, mx);

            sum.insert(points[i][0] + points[i][1]);
            diff.insert(points[i][0] - points[i][1]);
        }

        return ans;
    }
};