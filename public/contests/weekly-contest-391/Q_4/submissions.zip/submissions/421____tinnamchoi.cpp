#define all(x) (x).begin(), (x).end()

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        // cout << endl << "new" << endl;
        int n = points.size();
        vector<vector<int>> sum(n), diff(n);
        for (int i = 0; i < n; ++i) {
            sum[i] = {points[i][0] + points[i][1], i};
            diff[i] = {points[i][0] - points[i][1], i};
        }
        sort(all(sum));
        sort(all(diff));
        // cout << "sum: " << endl;
        // for (auto & v : sum) cout << v[0] << " " << v[1] << endl;
        // cout << "diff: " << endl;
        // for (auto & v : diff) cout << v[0] << " " << v[1] << endl;
        vector<int> candidates = {sum.front()[1], sum.back()[1], diff.front()[1], diff.back()[1]};
        int ans = 2e9;
        for (int cand : candidates) {
            int curr1 = 0, curr2 = 0;
            // if (sum.back()[1] == cand) curr += sum.back()[0]; else 
            curr1 += sum.back()[1] == cand ? sum[n - 2][0] : sum.back()[0];
            curr1 -= sum.front()[1] == cand ? sum[1][0] : sum.front()[0];
            curr2 += diff.back()[1] == cand ? diff[n - 2][0] : diff.back()[0];
            curr2 -= diff.front()[1] == cand ? diff[1][0] : diff.front()[0];
            ans = min(ans, max(curr1, curr2));
        }
        return ans;
    }
};