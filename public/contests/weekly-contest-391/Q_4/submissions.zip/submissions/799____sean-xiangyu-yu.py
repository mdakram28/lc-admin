class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        xy_sum = [point[0]+point[1] for point in points]
        xy_diff = [point[0]-point[1] for point in points]
        sort_sum = sorted(xy_sum)
        sort_diff = sorted(xy_diff)
        max_sum = sort_sum[-1]
        min_sum = sort_sum[0]
        max_diff = sort_diff[-1]
        min_diff = sort_diff[0]
        idx_max_sum = [i for i in range(len(points)) if points[i][0]+points[i][1]==max_sum]
        idx_min_sum = [i for i in range(len(points)) if points[i][0]+points[i][1]==min_sum]
        idx_max_diff = [i for i in range(len(points)) if points[i][0]-points[i][1]==max_diff]
        idx_min_diff = [i for i in range(len(points)) if points[i][0]-points[i][1]==min_diff]
        
        ans = max(max_sum-min_sum, max_diff-min_diff)
        for i in idx_max_sum:
            if i in idx_max_diff:
                ans = min(ans, max(sort_sum[-2]-min_sum, sort_diff[-2]-min_diff))
            elif i in idx_min_diff:
                ans = min(ans, max(sort_sum[-2]-min_sum, max_diff-sort_diff[1]))
            else:
                ans = min(ans, max(sort_sum[-2]-min_sum, max_diff-min_diff))
        for i in idx_min_sum:
            if i in idx_max_diff:
                ans = min(ans, max(max_sum-sort_sum[1], sort_diff[-2]-min_diff))
            elif i in idx_min_diff:
                ans = min(ans, max(max_sum-sort_sum[1], max_diff-sort_diff[1]))
            else:
                ans = min(ans, max(max_sum-sort_sum[1], max_diff-min_diff))
        for i in idx_max_diff:
            if i in idx_max_sum:
                ans = min(ans, max(sort_sum[-2]-min_sum, sort_diff[-2]-min_diff))
            elif i in idx_min_sum:
                ans = min(ans, max(max_sum-sort_sum[1], sort_diff[-2]-min_diff))
            else:
                ans = min(ans, max(max_sum-min_sum, sort_diff[-2]-min_diff))
        for i in idx_min_diff:
            if i in idx_max_sum:
                ans = min(ans, max(sort_sum[-2]-min_sum, max_diff-sort_diff[1]))
            elif i in idx_min_sum:
                ans = min(ans, max(max_sum-sort_sum[1], max_diff-sort_diff[1]))
            else:
                ans = min(ans, max(max_sum-min_sum, max_diff-sort_diff[1]))
        return ans