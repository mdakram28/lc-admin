def dist(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def max_distance_points(points):
    transformed_plus = [(x+y, x, y) for x, y in points]
    transformed_minus = [(x-y, x, y) for x, y in points]
    max_plus = max(transformed_plus)
    min_plus = min(transformed_plus)
    max_minus = max(transformed_minus)
    min_minus = min(transformed_minus)
    distance_plus = abs(max_plus[0] - min_plus[0])
    distance_minus = abs(max_minus[0] - min_minus[0])
    if distance_plus > distance_minus:
        return max_plus[1:], min_plus[1:], distance_plus
    else:
        return max_minus[1:], min_minus[1:], distance_minus

def without(l, x):
    l = l[:]
    l.remove(x)
    return l

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        points = list(map(tuple, points))
        a, b, max_distance = max_distance_points(points)
        fa, fb, fd = max_distance_points(without(points, a))
        sa, sb, sd = max_distance_points(without(points, b))
        
        return min([max_distance, fd, sd])
        
    
    

        