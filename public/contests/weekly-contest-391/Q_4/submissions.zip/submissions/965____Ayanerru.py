class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        from sortedcontainers import SortedList
        
        
        S = SortedList()
        diff = SortedList()
        pos = collections.defaultdict()
        for x, y in points:
            S.add(x+y)
            diff.add(x-y)
        
        ans = 10 ** 18
        for x, y in points:
            p1 = x+y
            p2 = x-y
            S.remove(p1)
            diff.remove(p2)
            
            cur_max = max(S[-1] - S[0], diff[-1] - diff[0])
            ans = min(ans, cur_max)
            
            S.add(p1)
            diff.add(p2)
        return ans
            
