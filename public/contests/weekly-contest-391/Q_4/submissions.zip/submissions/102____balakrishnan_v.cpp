#define ll long long
class Solution {
public:

    void Insert(int val, map<ll,int>& H) {
        H[val]++;
    }
    void Erase(int val, map<ll,int>& H) {
        H[val]--;
        if (H[val]==0) H.erase(val);
    }
    
    int GetMax(const map<ll,int>& H) {
        auto it = H.begin();
        auto rit = H.rbegin();
        return rit->first-it->first;
    }
    
    
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        
        map<ll,int> A,B,C,D;
        
        for(int i=0;i<n;i++) {
            int x=points[i][0];
            int y=points[i][1];
            Insert(x-y,A);
            Insert(-x+y,B);
            Insert(-x-y,C);
            Insert(x+y,D);
        }
        
        int ans=max(GetMax(A),max(GetMax(B),max(GetMax(C),GetMax(D))));
        for(int i=0;i<n;i++) {
            int x=points[i][0];
            int y=points[i][1];
            Erase(x-y,A);
            Erase(-x+y,B);
            Erase(-x-y,C);
            Erase(x+y,D);
            ans=min(ans,max(GetMax(A),max(GetMax(B),max(GetMax(C),GetMax(D)))));
            Insert(x-y,A);
            Insert(-x+y,B);
            Insert(-x-y,C);
            Insert(x+y,D);
        }
        return ans;
    }
};