""" === Method 1. coordinate rotation
(1) u = x + y, v = x - y
(2) For the new coordinates, we check at most 4 points of the max distances.
    Then we try to remove each of them, and get the min of max distance remaining.
"""
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        newPoints = self.getNewPoints(points)
        maxPointIdxs = self.getMaxPointIdxs(newPoints)
        # print(newPoints)
        # print(maxPointIdxs)
        minDistance = float("inf")
        for maxIdx in maxPointIdxs:
            remainingDistance = self.getRemainingDistance(newPoints, maxIdx)
            minDistance = min(minDistance, remainingDistance)
            # print(remainingDistance, minDistance)
        return minDistance
    
    def getNewPoints(self, points):
        newPoints = []
        for x, y in points:
            newPoints.append((x + y, x - y))
        return newPoints
    
    def getMaxPointIdxs(self, points):
        idxs = []
        idxs.append(self.getMaxIdx(0, points))
        idxs.append(self.getMaxIdx(1, points))
        idxs.append(self.getMinIdx(0, points))
        idxs.append(self.getMinIdx(1, points))
        return idxs
    
    def getMaxIdx(self, axisIdx, points, removedIdx = -1):
        maxValue = float("-inf")
        maxIdx = -1
        for idx, point in enumerate(points):
            if idx == removedIdx:
                continue
            if point[axisIdx] >= maxValue:
                maxValue = point[axisIdx]
                maxIdx = idx
        return maxIdx
    
    def getMinIdx(self, axisIdx, points, removedIdx = -1):
        minValue = float("inf")
        minIdx = -1
        for idx, point in enumerate(points):
            if idx == removedIdx:
                continue
            if point[axisIdx] <= minValue:
                minValue = point[axisIdx]
                minIdx = idx
        return minIdx
        
    def getRemainingDistance(self, points, removedIdx):
        return max(self.getRemainingDistanceInAxis(0, points, removedIdx),
                  self.getRemainingDistanceInAxis(1, points, removedIdx))
    
    def getRemainingDistanceInAxis(self, axisIdx, points, removedIdx):
        minIdx = self.getMinIdx(axisIdx, points, removedIdx)
        maxIdx = self.getMaxIdx(axisIdx, points, removedIdx)
        return abs(points[maxIdx][axisIdx] - points[minIdx][axisIdx])
        
        
        
        
        
            
        