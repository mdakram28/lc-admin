class Solution
{
 public:
	int minimumDistance(vector<vector<int>>& points)
	{
		int n = points.size();
		vector<vector<pair<int, int>>> a(4, vector<pair<int, int>>(n));
		for (int i = 0; i < n; ++i)
		{
			int x = points[i][0];
			int y = points[i][1];
			a[0][i] = { x + y, i };
			a[1][i] = { -x + y, i };
			a[2][i] = { x - y, i };
			a[3][i] = { -x - y, i };
		}
		for (int i = 0; i < 4; ++i)
			sort(a[i].begin(), a[i].end());
		int mxi, mxj, mx = 0;
		for (int i = 0; i < 4; ++i)
		{
			if (a[i][n - 1].first - a[i][0].first > mx)
			{
				mx = a[i][n - 1].first - a[i][0].first;
				mxi = min(a[i][n - 1].second, a[i][0].second);
				mxj = max(a[i][n - 1].second, a[i][0].second);
			}
		}
		int mx1 = 0, mx2 = 0;
		for (int i = 0; i < 4; ++i)
		{
			int l = 0, r = n - 1;
			if (a[i][l].second == mxi)
				++l;
			if (a[i][r].second == mxi)
				--r;
			mx1 = max(mx1, a[i][r].first - a[i][l].first);
		}
		for (int i = 0; i < 4; ++i)
		{
			int l = 0, r = n - 1;
			if (a[i][l].second == mxj)
				++l;
			if (a[i][r].second == mxj)
				--r;
			mx2 = max(mx2, a[i][r].first - a[i][l].first);
		}
		return min(mx1, mx2);
	}
};