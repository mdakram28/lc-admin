class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        sum_ = [(x + y, i) for i, (x, y) in enumerate(points)]
        diff = [(y - x, i) for i, (x, y) in enumerate(points)]
        sum_.sort()
        diff.sort()
        sum_max = sum_[-1][0] - sum_[0][0]
        diff_max = diff[-1][0] - diff[0][0]
        if sum_max > diff_max:
            return self.resolve_sum(sum_, diff)
        elif sum_max < diff_max:
            return self.resolve_diff(sum_, diff)
        return max(self.resolve_sum(sum_, diff), self.resolve_diff(sum_, diff))
    
    def resolve_sum(self, sum_, diff):
        sum_max = sum_[-1][0] - sum_[0][0]
        start_points = [sum_[0][1]]
        end_points = [sum_[-1][1]]
        for i in range(1, len(sum_)):
            if sum_[i][0] == sum_[0][0]:
                start_points.append(i)
            else:
                break
        for i in range(len(sum_) - 2, -1, -1):
            if sum_[i][0] == sum_[-1][0]:
                end_points.append(i)
            else:
                break
        if len(start_points) == 1 and len(end_points) == 1:
            start_id = sum_[0][1]
            end_id = sum_[-1][1]
            return min(self.try_remove(start_id, sum_, diff), self.try_remove(end_id, sum_, diff))
        elif len(start_points) == 1:
            start_id = sum_[0][1]
            return self.try_remove(start_id, sum_, diff)
        elif len(end_points) == 1:
            end_id = sum_[-1][1]
            return self.try_remove(end_id, sum_, diff)
        return sum_max

    def resolve_diff(self, sum_, diff):
        diff_max = diff[-1][0] - diff[0][0]
        start_points = [diff[0][1]]
        end_points = [diff[-1][1]]
        for i in range(1, len(diff)):
            if diff[i][0] == diff[0][0]:
                start_points.append(i)
            else:
                break
        for i in range(len(diff) - 2, -1, -1):
            if diff[i][0] == diff[-1][0]:
                end_points.append(i)
            else:
                break
        if len(start_points) == 1 and len(end_points) == 1:
            start_id = diff[0][1]
            end_id = diff[-1][1]
            return min(self.try_remove(start_id, sum_, diff), self.try_remove(end_id, sum_, diff))
        elif len(start_points) == 1:
            start_id = diff[0][1]
            return self.try_remove(start_id, sum_, diff)
        elif len(end_points) == 1:
            end_id = diff[-1][1]
            return self.try_remove(end_id, sum_, diff)
        return diff_max
    
    @staticmethod
    def try_remove(id_, sum_, diff):
        print('try remove', id_, sum_, diff)
        sum_max, max_id = sum_[-1]
        if max_id == id_:
            sum_max, max_id = sum_[-2]
        
        sum_min, min_id = sum_[0]
        if min_id == id_:
            sum_min, min_id = sum_[1]
        
        diff_max, max_id = diff[-1]
        if max_id == id_:
            diff_max, max_id = diff[-2]
        
        diff_min, min_id = diff[0]
        if min_id == id_:
            diff_min, min_id = diff[1]
        
        return max(sum_max - sum_min, diff_max - diff_min)
        