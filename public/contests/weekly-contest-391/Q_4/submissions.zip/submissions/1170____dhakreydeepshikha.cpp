class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n=p.size();
        vector<pair<int,int>>sum;
        vector<pair<int,int>>diff;
        for(int i=0;i<n;i++)
        {
        sum.push_back({(p[i][0]+p[i][1]),i});
             diff.push_back({(p[i][0]-p[i][1]),i});
        }
        int ans=INT_MAX;
        sort(sum.begin(),sum.end());
        sort(diff.begin(),diff.end());
         int a=0,b=n-1,c=0,d=n-1;
        for(int i=0;i<n;i++)
        {
        if(i==sum[a].second)
            a++;
            if(i==sum[b].second)
                b--;
            if(i==diff[c].second)
                c++;
            if(i==diff[d].second)
                d--;
        int temp=max(abs(sum[a].first-sum[b].first),abs(diff[c].first-diff[d].first));
        ans=min(ans,temp);
            a=0,b=n-1,c=0,d=n-1;
        }
        return ans;
    }
};