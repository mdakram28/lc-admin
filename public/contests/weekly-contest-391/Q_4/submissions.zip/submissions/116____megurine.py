class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        i1 = i2 = -1
        v1, v2 = inf, -inf
        for i, (x, y) in enumerate(points):
            xy = x + y
            if xy < v1: i1, v1 = i, xy
            if xy > v2: i2, v2 = i, xy
        idx = {i1, i2}
        i1 = i2 = -1
        v1, v2 = inf, -inf
        for i, (x, y) in enumerate(points):
            xy = x - y
            if xy < v1: i1, v1 = i, xy
            if xy > v2: i2, v2 = i, xy
        idx |= {i1, i2}
        print(idx)
        def f(d):
            i1 = i2 = -1
            v1, v2 = inf, -inf
            for i, (x, y) in enumerate(points):
                if i == d: continue
                xy = x + y
                if xy < v1: i1, v1 = i, xy
                if xy > v2: i2, v2 = i, xy
            cur = v2 - v1 
            i1 = i2 = -1
            v1, v2 = inf, -inf
            for i, (x, y) in enumerate(points):
                if i == d: continue
                xy = x - y
                if xy < v1: i1, v1 = i, xy
                if xy > v2: i2, v2 = i, xy
            cur = max(cur, v2 - v1)
            return cur
        return min(f(i) for i in idx)