class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def computeMaxDistance(points):
            min_sum, max_sum = float('inf'), float('-inf')
            min_diff, max_diff = float('inf'), float('-inf')

            for x, y in points:
                sum_ = x + y
                diff = x - y

                min_sum = min(min_sum, sum_)
                max_sum = max(max_sum, sum_)
                min_diff = min(min_diff, diff)
                max_diff = max(max_diff, diff)

            # The maximum Manhattan distance is the larger of the two extreme differences
            maximum_distance = max(max_sum - min_sum, max_diff - min_diff)
            return maximum_distance
        N = len(points)
    
        # Initial setup: assume first point contributes to all extremes
        min_sum, max_sum, min_diff, max_diff = points[0][0] + points[0][1], points[0][0] + points[0][1], points[0][0] - points[0][1], points[0][0] - points[0][1]
        indices_min_sum, indices_max_sum, indices_min_diff, indices_max_diff = [0], [0], [0], [0]

        # Compute extremes and track contributing point indices
        for i in range(1, N):
            sum_ = points[i][0] + points[i][1]
            diff = points[i][0] - points[i][1]

            if sum_ < min_sum:
                min_sum, indices_min_sum = sum_, [i]
            elif sum_ == min_sum:
                indices_min_sum.append(i)

            if sum_ > max_sum:
                max_sum, indices_max_sum = sum_, [i]
            elif sum_ == max_sum:
                indices_max_sum.append(i)

            if diff < min_diff:
                min_diff, indices_min_diff = diff, [i]
            elif diff == min_diff:
                indices_min_diff.append(i)

            if diff > max_diff:
                max_diff, indices_max_diff = diff, [i]
            elif diff == max_diff:
                indices_max_diff.append(i)

        # Initial maximum distance
        maximum = max(max_sum - min_sum, max_diff - min_diff)

        # To store the minimum of the recalculated maximum distances
        min_max_distance_after_removal = float('inf')

        # Set of unique indices to consider for removal
        unique_indices = set(indices_min_sum + indices_max_sum + indices_min_diff + indices_max_diff)

        # Evaluate removal of each contributing point
        for index in unique_indices:
            new_points = points[:index] + points[index+1:]

            # Recompute maximum distance without this point
            new_max_distance = computeMaxDistance(new_points) # Assume computeMaxDistance is implemented

            min_max_distance_after_removal = min(min_max_distance_after_removal, new_max_distance)

        return min_max_distance_after_removal

	
            