class Solution {
public:
    unordered_map<int,int> f;
    int g[2][400001];
    int y[2][400001];
    void init(int x,int l,int r) {
        if (l==r) {
            g[0][x]=0;
            g[1][x]=-1e8;
        } else {
            int m=(l+r)/2;
            init(2*x,l,m);
            init(2*x+1,m+1,r);
            g[0][x]=0;
            g[1][x]=-1e8;
        }
    }
    void insert(int x,int l,int r,int p,int h,int w,int yy) {
        if (l==r) {
            if (h+w>g[0][x]) {
                g[0][x]=h+w;
                y[0][x]=yy;
            }
            if (h-w>g[1][x]) {
                g[1][x]=h-w;
                y[1][x]=yy;
            }
        } else {
            int m=(l+r)/2;
            if (p<=m) insert(2*x,l,m,p,h,w,yy);
            else insert(2*x+1,m+1,r,p,h,w,yy);
            if (g[0][2*x]>=g[0][2*x+1]) {
                g[0][x]=g[0][2*x];
                y[0][x]=y[0][2*x];
            } else {
                g[0][x]=g[0][2*x+1];
                y[0][x]=y[0][2*x+1];
            }
            if (g[1][2*x]>=g[1][2*x+1]) {
                g[1][x]=g[1][2*x];
                y[1][x]=y[1][2*x];
            } else {
                g[1][x]=g[1][2*x+1];
                y[1][x]=y[1][2*x+1];
            }
        }
    }
    
    pair<int,int> query0(int x,int l,int r,int p) {
        if (l==r) return make_pair(g[0][x],y[0][x]);
        else {
            int m=(l+r)/2;
            if (p<=m) {
                pair<int,int> ret=query0(2*x,l,m,p);
                if (ret.first<g[0][2*x+1]) return make_pair(g[0][2*x+1],y[0][2*x+1]);
                else return ret;
            } else {
                return query0(2*x+1,m+1,r,p);
            }
        }
    }
    
    pair<int,int> query1(int x,int l,int r,int p) {
        if (l==r) return make_pair(g[1][x],y[1][x]);
        else {
            int m=(l+r)/2;
            if (p<=m) {
                return query1(2*x,l,m,p);
            } else {
                pair<int,int> ret=query1(2*x+1,m+1,r,p);
                if (ret.first<g[1][2*x]) return make_pair(g[1][2*x],y[1][2*x]);
                else return ret;
            }
        }
    }

    int minimumDistance(vector<vector<int>>& p) {
       sort(p.begin(),p.end());
        int n=p.size();
        vector<int> b(n);
        for (int i=0;i<n;i++)
            b[i]=p[i][1];
        sort(b.begin(),b.end());
        for (int i=0;i<n;i++)
            f[b[i]]=i;
        
        init(1,0,n-1);
        int mm=0;
        int xx=0;
        int yy=1;
        int j=n-1;
        for (int i=n-1;i>=0;i--) {
            while (j>=0&&p[i][0]==p[j][0]) {
                insert(1,0,n-1,f[p[j][1]],p[j][0],p[j][1],j);
                j--;
            }
            pair<int,int> r1=query0(1,0,n-1,f[p[i][1]]);
            int dis=r1.first-p[i][0]-p[i][1];
            if (mm<dis) {
                mm=dis;
                xx=r1.second;
                yy=i;
            }
            r1=query1(1,0,n-1,f[p[i][1]]);
            dis=r1.first-p[i][0]+p[i][1];
            if (mm<dis) {
                mm=dis;
                xx=r1.second;
                yy=i;
            }
        }
        //printf("%d %d %d\n",mm,xx,yy);
        
        init(1,0,n-1);
        int mm1=0;
        j=n-1;
        for (int i=n-1;i>=0;i--) {
            while (j>=0&&p[i][0]==p[j][0]) {
                if (j!=xx) insert(1,0,n-1,f[p[j][1]],p[j][0],p[j][1],j);
                j--;
            }
            if (i==xx) continue;
            pair<int,int> r1=query0(1,0,n-1,f[p[i][1]]);
            int dis=r1.first-p[i][0]-p[i][1];
            if (mm1<dis) {
                mm1=dis;
            }
            r1=query1(1,0,n-1,f[p[i][1]]);
            dis=r1.first-p[i][0]+p[i][1];
            if (mm1<dis) {
                mm1=dis;
            }
        }
        
        init(1,0,n-1);
        int mm2=0;
        j=n-1;
        for (int i=n-1;i>=0;i--) {
            while (j>=0&&p[i][0]==p[j][0]) {
                if (j!=yy) insert(1,0,n-1,f[p[j][1]],p[j][0],p[j][1],j);
                j--;
            }
            //printf("g0 %d %d %d\n",g[0][1],g[0][2],g[0][4]);
            //printf("g1 %d %d %d\n",g[1][1],g[1][2],g[1][4]);
            if (i==yy) continue;
            pair<int,int> r1=query0(1,0,n-1,f[p[i][1]]);
            int dis=r1.first-p[i][0]-p[i][1];
            //printf("rig %d %d %d\n",i,r1.second,dis);
            if (mm2<dis) {
                mm2=dis;
            }
            r1=query1(1,0,n-1,f[p[i][1]]);
            dis=r1.first-p[i][0]+p[i][1];
            //printf("lef %d %d %d\n",i,r1.second,dis);
            if (mm2<dis) {
                mm2=dis;
            }
        }
        
        //printf("%d %d\n",mm1,mm2);
        return min(mm1,mm2);
    }
};