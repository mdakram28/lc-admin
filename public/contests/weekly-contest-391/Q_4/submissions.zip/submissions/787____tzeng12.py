class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        p = points.copy()
        for i in range(len(p)):
            a = p[i][0] + p[i][1]
            b = p[i][0] - p[i][1]
            p[i] = [a, b]
            
        p1 = p.copy()
        p2 = p.copy()
        p1.sort(key = lambda x:(x[0], x[1]))
        p2.sort(key = lambda x:(x[1], x[0]))
        
        #print(p1, p2)
        
        xdiff = p1[-1][0] - p1[0][0]
        ydiff = p2[-1][1] - p2[0][1]
        
        #print(xdiff, ydiff)
        
        extremes = [p1[0], p1[-1], p2[0], p2[-1]]
        
        best = 10**10
        
        for point in extremes:
            p3 = p1.copy()
            p4 = p2.copy()
            p3.remove(point)
            p4.remove(point)
            #print("p3p4", p3, p4)
            best = min(best, max(p3[-1][0] - p3[0][0], p4[-1][1] - p4[0][1]))
            #print(best)
        
        return best
        
        
        """if ydiff > xdiff:
            return min(max(xdiff, p2[-1][1] - p2[1][1]), max(xdiff, p2[-2][1] - p2[0][1]))
        else:
            return min(max(ydiff, p1[-1][0] - p1[1][0]), max(ydiff, p1[-2][0] - p1[0][0]))"""