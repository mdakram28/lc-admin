class Solution {
public:
    int calc(vector<int>&a,vector<vector<int>>&v){
        int n=a.size();
        int ans=0;
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                ans=max(ans,abs(v[a[i]][0]-v[a[j]][0])+abs(v[a[i]][1]-v[a[j]][1]));
            }
        }
        return ans;
    }
    int minimumDistance(vector<vector<int>>& v) {
        int n=v.size();
        vector<pair<int,int>>mi(n),mx(n);
        for(int i=0;i<n;i++){
            mi[i]={v[i][0]-v[i][1],i};
            mx[i]={v[i][0]+v[i][1],i};
        }
        sort(mi.begin(),mi.end());
        sort(mx.begin(),mx.end());
        int ans=1e9;
        vector<int>a;
        auto pusher=[&](int idx){
            a.clear();
            int l=(idx==mi[0].second);
            a.push_back(mi[l].second);
            l=(idx==mi.back().second);
            a.push_back(mi[n-1-l].second);
            l=(idx==mx[0].second);
            a.push_back(mx[l].second);
            l=(idx==mx.back().second);
            a.push_back(mx[n-1-l].second);
        };
        pusher(mi[0].second);
        ans=min(ans,calc(a,v));
        
        pusher(mi.back().second);
        ans=min(ans,calc(a,v));
        
        pusher(mx[0].second);
        ans=min(ans,calc(a,v));
        
        pusher(mx.back().second);
        ans=min(ans,calc(a,v));
        return ans;
    }
};