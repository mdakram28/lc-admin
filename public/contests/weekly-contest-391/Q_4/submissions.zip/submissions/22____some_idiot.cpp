class Solution {
public:
    int minimumDistance(vector<vector<int>> &points) {
        int n = points.size();
        multiset<int> s1, s2;
        for (int i = 0; i < n; i++) {
            int x = points[i][0], y = points[i][1];
            s1.insert(x + y);
            s2.insert(x - y);
        }
        int ans = 0x3f3f3f3f;
        for (int i = 0; i < n; i++) {
            int x = points[i][0], y = points[i][1];
            s1.extract(x + y);
            s2.extract(x - y);
            ans = min(ans, max(*s1.rbegin() - *s1.begin(), *s2.rbegin() - *s2.begin()));
            s1.insert(x + y);
            s2.insert(x - y);
        }
        return ans;
    }
};