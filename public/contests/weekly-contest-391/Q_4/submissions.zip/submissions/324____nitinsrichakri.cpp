class Solution {
public:
    int minimumDistance(vector<vector<int>>& a) {
        int n=a.size();
        vector<pair<int,int>> s(n), d(n);
        for (int i = 0; i < n; i++) 
        {
            s[i].first = a[i][0] + a[i][1];
            d[i].first = a[i][0] - a[i][1];
            s[i].second = i;
            d[i].second = i;
        }
        sort(s.begin(), s.end());
        sort(d.begin(), d.end());
        vector<int> ans(n);
        for(int i=0;i<n;i++)
        {
            int ls=0,rs=n-1;
            if(i==s[ls].second)ls=1;
            if(i==s[rs].second)rs=n-2;
            int ld=0,rd=n-1;
            if(i==d[ld].second)ld=1;
            if(i==d[rd].second)rd=n-2;
            ans[i]=max(s[rs].first-s[ls].first,d[rd].first-d[ld].first);
        }
        sort(ans.begin(),ans.end());
        return ans[0];
    }
};