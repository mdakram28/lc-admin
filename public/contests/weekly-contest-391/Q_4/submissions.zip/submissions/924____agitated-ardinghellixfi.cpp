class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        vector<vector<pair<int,int> >>p(4);
        for(int i=0;i<n;i++)
        {
            int x=points[i][0],y=points[i][1];
            p[0].push_back({x+y,i+1});
            p[1].push_back({x-y,i+1});
            p[2].push_back({-x+y,i+1});
            p[3].push_back({-x-y,i+1});
        }
        for(int i=0;i<4;i++) sort(p[i].begin(),p[i].end());
        vector<array<int,3>>v;
        for(int i=0;i<4;i++)
        {
            for(int j=1;j<n;j++)
            {
                int h=p[i][0].second;
                int id=p[i][j].second;
                int val=p[i][j].first-p[i][0].first;
                v.push_back({val,h,id});
            }
        }
        sort(v.begin(),v.end(),[&](auto x,auto y){
            return x[0]>y[0];
        });
        int ans=1e9;
        int mx=0,id=0;
        vector<int>cnt(n+1);
        for(int i=1;i<=v.size();i++)
        {
            auto [val,x,y]=v[i-1];
            if(mx==i-1) ans=min(ans,val);
            cnt[x]++,cnt[y]++;
            if(cnt[x]>mx) mx=cnt[x];
            if(cnt[y]>mx) mx=cnt[y];
        }
        return ans;
    }
};