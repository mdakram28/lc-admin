class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        vector<vector<int>> a(n,vector<int>(2)),b(n,vector<int>(2));
        for(int i=0;i<n;i++){
            a[i][0]=points[i][0]-points[i][1];
            b[i][0]=points[i][0]+points[i][1];
            a[i][1]=i;
            b[i][1]=i;
        }
        sort(a.begin(),a.end());
        sort(b.begin(),b.end());
        auto cal=[&n,&points](int x){
            vector<vector<int>> a(n-1,vector<int>(2)),b(n-1,vector<int>(2));
            int index=0;
            for(int i=0;i<n;i++){
                if(i==x)
                    continue;
                a[index][0]=points[i][0]-points[i][1];
                b[index][0]=points[i][0]+points[i][1];
                a[index][1]=i;
                b[index][1]=i;
                index++;
            }  
            sort(a.begin(),a.end());
        sort(b.begin(),b.end());
            return max(a[n-2][0]-a[0][0],b[n-2][0]-b[0][0]);
        };
        int ans=INT_MAX;
        // cout<<max(a[n-1][0]-a[0][0],b[n-1][0]-b[0][0])<<endl;
        // cout<<a[0][1]<<" "<<b[0][1]<<" "<<a[n-1][1]<<" "<<b[n-1][1]<<endl;
        ans=min(ans,cal(a[0][1]));
        // cout<<ans<<endl;
        ans=min(ans,cal(b[0][1]));
        // cout<<ans<<endl;
        ans=min(ans,cal(a[n-1][1]));
        // cout<<ans<<endl;
        ans=min(ans,cal(b[n-1][1]));
        // cout<<ans<<endl;
        return ans;
    }
};