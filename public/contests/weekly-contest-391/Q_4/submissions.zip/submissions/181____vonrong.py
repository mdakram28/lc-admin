class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        INF = 10000000000
        a = (INF, INF)
        b = (-INF, INF)
        c = (INF, -INF)
        d = (-INF, -INF)
        i1, i2, i3, i4 = -1, -1, -1, -1
        for i in range(len(points)):
            x, y = points[i]
            if -x-y > -a[0]-a[1]:
                a = (x, y)
                i1 = i
            if x-y > b[0]-b[1]:
                b = (x, y)
                i2 = i
            if -x+y > -c[0]+c[1]:
                c = (x, y)
                i3 = i
            if x+y > d[0]+d[1]:
                d = (x, y)
                i4 = i
        ans = INF
        
        #cand1
        points1 = points[:i1]+points[i1+1:]
        tans = 0
        a = (INF, INF)
        b = (-INF, INF)
        c = (INF, -INF)
        d = (-INF, -INF)
        for i in range(len(points1)):
            x, y = points1[i]
            if -x-y > -a[0]-a[1]:
                a = (x, y)
            if x-y > b[0]-b[1]:
                b = (x, y)
            if -x+y > -c[0]+c[1]:
                c = (x, y)
            if x+y > d[0]+d[1]:
                d = (x, y)
        for x, y in points1:
            tans = max(tans, abs(x-a[0])+abs(y-a[1]), abs(x-b[0])+abs(y-b[1]), abs(x-c[0])+abs(y-c[1]), abs(x-d[0])+abs(y-d[1]))
        ans = min(ans, tans)
        
        #cand2
        points2 = points[:i2]+points[i2+1:]
        tans = 0
        a = (INF, INF)
        b = (-INF, INF)
        c = (INF, -INF)
        d = (-INF, -INF)
        for i in range(len(points2)):
            x, y = points2[i]
            if -x-y > -a[0]-a[1]:
                a = (x, y)
            if x-y > b[0]-b[1]:
                b = (x, y)
            if -x+y > -c[0]+c[1]:
                c = (x, y)
            if x+y > d[0]+d[1]:
                d = (x, y)
        for x, y in points2:
            tans = max(tans, abs(x-a[0])+abs(y-a[1]), abs(x-b[0])+abs(y-b[1]), abs(x-c[0])+abs(y-c[1]), abs(x-d[0])+abs(y-d[1]))
        ans = min(ans, tans)
        
        #cand3
        points3 = points[:i3]+points[i3+1:]
        tans = 0
        a = (INF, INF)
        b = (-INF, INF)
        c = (INF, -INF)
        d = (-INF, -INF)
        for i in range(len(points3)):
            x, y = points3[i]
            if -x-y > -a[0]-a[1]:
                a = (x, y)
            if x-y > b[0]-b[1]:
                b = (x, y)
            if -x+y > -c[0]+c[1]:
                c = (x, y)
            if x+y > d[0]+d[1]:
                d = (x, y)
        for x, y in points3:
            tans = max(tans, abs(x-a[0])+abs(y-a[1]), abs(x-b[0])+abs(y-b[1]), abs(x-c[0])+abs(y-c[1]), abs(x-d[0])+abs(y-d[1]))
            
        ans = min(ans, tans)
        
        #cand4
        points4 = points[:i4]+points[i4+1:]
        tans = 0
        a = (INF, INF)
        b = (-INF, INF)
        c = (INF, -INF)
        d = (-INF, -INF)
        for i in range(len(points4)):
            x, y = points4[i]
            if -x-y > -a[0]-a[1]:
                a = (x, y)
            if x-y > b[0]-b[1]:
                b = (x, y)
            if -x+y > -c[0]+c[1]:
                c = (x, y)
            if x+y > d[0]+d[1]:
                d = (x, y)
        for x, y in points4:
            tans = max(tans, abs(x-a[0])+abs(y-a[1]), abs(x-b[0])+abs(y-b[1]), abs(x-c[0])+abs(y-c[1]), abs(x-d[0])+abs(y-d[1]))
        ans = min(ans, tans)
        
        return ans
        