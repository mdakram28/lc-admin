class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        a = c = 10 ** 18
        b = d = -10 ** 18
        for x,y in points:
            a = min(x + y, a)
            b = max(x + y, b)
            c = min(x - y, c)
            d = max(x - y, d)
        ans = -1
        choose = -1
        for i, (x,y) in enumerate(points):
            dis = max(x + y - a, b - x - y, x - y - c, d - x + y)
         #   print(dis,1111)
            if dis > ans: 
                ans = dis
                choose = i
                print(ans,dis)
        i = 0
     #   print(choose,dis)
        for x,y in points:
            if abs(x - points[choose][0]) + abs(y - points[choose][1]) == ans:
                print('dinf')
                another = i
                break
            i += 1
        def f(choose):
            a = c = 10 ** 18
            b = d = -10 ** 18
            point=points.copy()
            point.pop(choose)    
            for x,y in point:
                a = min(x + y, a)
                b = max(x + y, b)
                c = min(x - y, c)
                d = max(x - y, d)
            ans = -1
            choose = -1
            for i, (x,y) in enumerate(point):
                dis = max(x + y - a, b - x - y, x - y - c, d - x + y)
                if dis > ans: 
                    ans = dis
                    choose = i
            return ans
        #print(choose,another)
        return min(f(choose),f(another))