class Solution {
public:
  int minimumDistance(vector<vector<int>>& points) {
    int n = points.size();
    vector<array<int, 4>> info(n, array<int, 4>{});
    for (int i = 0; i < n; i++) {
      int x = points[i][0], y = points[i][1];
      info[i] = {
        x + y,
        x - y,
        -x + y,
        -x - y
      };
    }
    array<multiset<int>, 4> st{};
    for (int i = 0; i < n; i++) {
      for (int t = 0; t < 4; t++) {
        st[t].insert(info[i][t]);
      }
    }
    int ans = int(1e9);
    for (int i = 0; i < n; i++) {
      // erase points[i]
      for (int t = 0; t < 4; t++) {
        st[t].erase(st[t].find(info[i][t]));
      }
      int best = 0;
      // query the max distance
      for (int t = 0; t < 4; t++) {
        best = max(best, *st[t].rbegin() - *st[t].begin());
      }
      // readd points[i]
      for (int t = 0; t < 4; t++) {
        st[t].insert(info[i][t]);
      }
      ans = min(ans, best);
    }
    return ans;
  }
};