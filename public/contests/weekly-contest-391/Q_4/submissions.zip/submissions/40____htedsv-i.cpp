#pragma GCC optimize("Ofast","unroll-loops","omit-frame-pointer","inline")
#pragma GCC option("arch=native","tune=native","no-zero-upper")
//#pragma GCC target("avx2")
#include <bits/stdc++.h>
using namespace std;
//#define INF 2147483647
#define infL (1LL<<60)
#define inf (1<<30)
#define inf9 (1000000000)
#define MOD  998244353 //1000000007
#define EPS 1e-9
#define Gr 9.8
#define PI acos(-1)
#define REP(i,n) for(int (i)=0;(i)<(int)(n);(i)++)
#define REQ(i,n) for(int (i)=1;(i)<=(int)(n);(i)++)
#define lch (rt<<1)
#define rch (rt<<1|1)
#define readmp(n) for(int i=0,u,v;i<n;i++) {scanf("%d%d",&u,&v); mp[u].push_back(v); mp[v].push_back(u);}
typedef  long long ll;
typedef pair<int, int> pii;
typedef pair<int, vector<int>> piv;
typedef pair<ll, ll> pll;
typedef long double ld;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef double ValType;
template<typename  T> void maxtt(T& t1, T t2) {
    t1=max(t1,t2);
}
template<typename  T> void mintt(T& t1, T t2) {
    t1=min(t1,t2);
}


bool debug = 0;
int n,m,k;
int dx[4] = {0,1,0,-1}, dy[4] = {1,0,-1,0};
string direc="RDLU";
const ll MOD2 = (ll)MOD * (ll)MOD;
ll ln, lk, lm;
void etp(bool f = 0) {
    puts(f ?"YES" : "NO");
    exit(0);
}
void addmod(int &x, int y, int mod = MOD){
    x+=y; if (x>=mod) x-=mod;
    if(x<0) x+=mod;
    assert(x>=0 && x<mod);
}
void et(int x=-1) {
    printf("%d\n", x); exit(0);
}
ll fastPow(ll x, ll y, int mod=MOD) {
    ll ans = 1;
    while(y>0) {
        if(y&1) ans = (x * ans)%mod;
        x = x*x%mod;
        y>>=1;
    }
    return ans;
}
ll gcd1(ll x, ll y) {
    return y?gcd1(y,x%y):x;
}

//#include <atcoder/all>
//using mint = atcoder::modint998244353;
#define MAX (1000005)


void fmain(int tid) {
    scanf("%d", &n);
    scanf("%d", &k);

}
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<pii> vx, vy;
        REP(i,n) {
            int x=points[i][0], y=points[i][1];
            vx.push_back({x+y,i});
            vy.push_back({x-y,i});
        }
        sort(vx.begin(),  vx.end());
        sort(vy.begin(),  vy.end());
        vector<int> sus;
        sus.push_back(vx[0].second);
        sus.push_back(vx.back().second);
        sus.push_back(vy[0].second);
        sus.push_back(vy.back().second);
        int ans = inf;
        for(int id: sus) {
            vx.clear(); vy.clear();
            REP(i,n) if (id!=i){
                int x=points[i][0], y=points[i][1];
                vx.push_back({x+y,i});
                vy.push_back({x-y,i});
            }
            sort(vx.begin(),  vx.end());
            sort(vy.begin(),  vy.end());
            int tt= max(vx.back().first-vx[0].first, vy.back().first-vy[0].first);
            mintt(ans, tt);
        }
        return ans;
    }
};
int mai1n() {
//    freopen("hash_slinger_input.txt","r",stdin);
//    freopen("hash_slinger_oo.txt","w",stdout);
    int t=1;
//    ios::sync_with_stdio(false);
//    cin.tie(0); cout.tie(0);
//    cin>>t;
    scanf("%d", &t);
    REQ(i,t) {
        fmain(i);
    }
    return 0;
}