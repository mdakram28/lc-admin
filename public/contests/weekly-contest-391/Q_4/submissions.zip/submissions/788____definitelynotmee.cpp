#include<bits/stdc++.h>
#define all(x) x.begin(), x.end()
#define ff first
#define ss second
#define O_O
using namespace std;
template <typename T>
using bstring = basic_string<T>;
template <typename T>
using matrix = vector<vector<T>>;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef double dbl;
typedef long double dbll; 
const ll INFL = 4e18+25;
const int INF = 1e9+42;
const double EPS = 1e-7;
const int MOD = (1<<23)*17*7 + 1; // 998244353
const int RANDOM = chrono::high_resolution_clock::now().time_since_epoch().count();
const int MAXN = 1e6+1;

inline int getd1(pii point){
    return point.ff;
};

inline int getd2(pii point){
    return point.ss;
};

int get_resp(vector<pii>& v, vector<int> & d1, vector<int> & d2, int erase){
    int ret = 0;
    
    int n = v.size();
    
    int l = 0, r = n-1;
    
    if(d1[l] == erase)
        l++;
    if(d1[r] == erase)
        r--;

    ret = getd1(v[d1[r]]) - getd1(v[d1[l]]);
    
    l = 0, r = n-1;
    
    if(d2[l] == erase)
        l++;
    if(d2[r] == erase)
        r--;
    
    return max(ret, getd2(v[d2[r]]) - getd2(v[d2[l]]));
}

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        
        vector<pii> v(n);
        
        for(int i = 0; i < n; i++)
            v[i] = {points[i][0]+points[i][1], points[i][0]-points[i][1]};
        
        vector<int> d1(n), d2(n);
        
        iota(all(d1),0), iota(all(d2),0);
        
        
        
        sort(all(d1),[&](int a, int b){
            return getd1(v[a]) < getd1(v[b]);
        });
        sort(all(d2),[&](int a, int b){
            return getd2(v[a]) < getd2(v[b]);
        });
        
        int resp = INF;
        
        
        resp = min(resp,get_resp(v,d1,d2,d1[0]));
        resp = min(resp,get_resp(v,d1,d2,d1.back()));
        resp = min(resp,get_resp(v,d1,d2,d2[0]));
        resp = min(resp,get_resp(v,d1,d2,d2.back()));
        return resp;
        
        
        return resp;
    }
};