class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        if len(points)<=2: return 0
        a,b = [], []
        for i,p in enumerate(points):
            a.append((p[0]+p[1], i))
            b.append((p[0]-p[1], i))
        a.sort()
        b.sort()
        def cal(i):
            x,y = a[0][0], a[-1][0]
            if a[0][1]==i: x=a[1][0]
            if a[-1][1]==i: y=a[-2][0]
            res=y-x
            x,y = b[0][0], b[-1][0]
            if b[0][1]==i: x=b[1][0]
            if b[-1][1]==i: y=b[-2][0]
            res = max(res, y-x)
            return res
        return min(cal(i) for i in (a[0][1], a[-1][1], b[0][1], b[-1][1]))