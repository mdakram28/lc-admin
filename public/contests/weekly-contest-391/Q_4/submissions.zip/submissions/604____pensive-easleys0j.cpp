class Solution {
#include <set>
public:
	int minimumDistance(vector<vector<int>>& points) {
		multiset<int> mst1,mst2;
		int ans = 1e9 + 10;
		for(auto p : points){
			mst1.insert(p[0] + p[1]);
			mst2.insert(p[0] - p[1]);
		}
		for(auto p : points){
			//p[0],p[1]
			mst1.erase(mst1.find(p[0]+p[1]));
			mst2.erase(mst2.find(p[0]-p[1]));
			ans = min(ans,max(*--mst1.end()-*mst1.begin(),*--mst2.end()-*mst2.begin()));
			mst1.insert(p[0] + p[1]);
			mst2.insert(p[0] - p[1]);
		}
		return ans;
	}
};