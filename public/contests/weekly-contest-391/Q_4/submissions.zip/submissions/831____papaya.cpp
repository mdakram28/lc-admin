#include<bits/stdc++.h>
using namespace std ; 

#define add emplace_back 

typedef long long int64 ; 

const int64 INF = 1e18 ; 

class Solution {
public:
    vector<vector<int>> a ; 
    int n ; 

    vector< vector<pair<int64, int64 > > > info ; 

    void init_1 ( ) { 

        multiset< tuple<int64,  int64 >> s ; 
        s.emplace( -INF ,  -1 ) ; 
        s.emplace( -INF ,  -1 ) ; 
        
        info.assign( n , {} ) ; 

        // cout << "in in 1111 \n" ;

        for( int i = n - 1 ; i >= 0 ; i-- ) {
            int64 x = a[i][0] ;
            int64 y = a[i][1] ; 
            
            auto p1 = ( --s.end() ) ;
            auto p2 = prev( p1 ) ; 

            auto [ vj_1 , j1 ] = *p1 ;
            auto [ vj_2 , j2 ] = *p2 ; 

            int64 v1 = vj_1 - ( x + y ) ;
            int64 v2 = vj_2 - ( x + y ) ;

            if( j1 >= 0 ) { 
                info[i].add( v1 , j1 ) ; 
            }
            if( j2 >= 0 ) { 
                info[i].add( v2 , j2 ) ; 
            }

            if( j1 >= 0 ) { 
                info[j1].add( v1 , i ) ;
            }
            if( j2 >= 0 ) { 
                info[j2].add( v2 , i ) ; 
            }

            s.emplace( x + y , i ) ; 
        }
        // cout << " over init 1 \n" ; 
     
    }
    void init_2 ( ) { 

        multiset< tuple<int64,  int64 >> s ; 
        s.emplace( -INF ,  -1 ) ; 
        s.emplace( -INF ,  -1 ) ; 
        
        for( int i = n - 1 ; i >= 0 ; i-- ) {
            int64 x = a[i][0] ;
            int64 y = a[i][1] ; 
            
            auto p1 = ( --s.end() ) ;
            auto p2 = prev( p1 ) ; 

            auto [ vj_1 , j1 ] = *p1 ;
            auto [ vj_2 , j2 ] = *p2 ; 

            int64 v1 = vj_1 - ( x - y ) ;
            int64 v2 = vj_2 - ( x - y ) ;

            if( j1 >= 0 ) { 
                info[i].add( v1 , j1 ) ; 
            }
            if( j2 >= 0 ) { 
                info[i].add( v2 , j2 ) ; 
            }

            if( j1 >= 0 ) { 
                info[j1].add( v1 , i ) ;
            }
            if( j2 >= 0 ) { 
                info[j2].add( v2 , i ) ; 
            }

            s.emplace( x - y , i ) ; 
        }
    }
    void init ( ) {

        // cout  << " start 1 111 1\n" ; 

        init_1() ;

        // cout << "over 11111 \n" ; 

        init_2() ; 

        // cout << " over all init\n" ; 
     

        for( int i = 0 ; i < n ; i++ ) {
            auto &p = info[i] ; 
            if( p.size() == 0 ) {
                continue ; 
            }
            sort( p.begin() , p.end() , greater<>() ) ; 

            // cout << "\n\ni: " << i << "\n" ; 
            // cout << a[i][0] << " " << a[i][1] << "\n" ; 

            // for( auto [ val , j ] : p ) {
            //     cout << "val: " << val << " j: " << j << "\n" ; 
            // }
            // cout << "\n" ;
        }
    }
    int64 get( int x ) {
        int64 max_val = -INF ; 
        for( int i = 0 ; i < n ; i++ ) {
            auto &p = info[i] ; 
            if( p.size() == 0 ) {
                continue ; 
            }
            if( i == x ) {
                continue ; 
            }
            for( auto [ vj , j2 ] : p ) {
                if( j2 == x ) {
                    continue ; 
                }
                max_val = max( max_val , vj ) ; 
                break ; 
            }
        }
        return max_val ; 
    }
    int solve( ) { 

        init( ) ; 
        
        int64 max_val = -INF ; 
        for( int i = 0 ; i < n ; i++ ) {
            auto &p = info[i] ; 
            if( p.size() == 0 ) {
                continue ; 
            }
            auto [vj, j2 ] = p[0] ;
            max_val = max( max_val , vj ) ; 
        }

        vector<int> tmp ; 
        vector<int> in_deg( n , 0 ) ; 
        for( int i = 0 ; i < n ; i++ ) {
            auto &p = info[i] ; 
            if( p.size() == 0 ) {
                continue ; 
            }
            auto [vj, j2 ] = p[0] ;
            if( vj == max_val ) { 
                tmp.add( i ) ; 

                in_deg[i]++ ; 
                // in_deg[ j2]++ ; 
            }
        }
        int m = tmp.size() ; 

        // cout << "m: " << m << "\n" ; 

        int64 ret = INF ; 
        for( auto x : tmp ) { 

            int64 max_val2 = get( x ) ; 

            // cout << "del x ; " << x << " max_val2 : " << max_val2 << "\n" ; 

            ret = min( ret , max_val2 ) ; 
        }
        return ret ; 
    }

    int minimumDistance(vector<vector<int>>& points) {
        a = points; 
        n = a.size() ; 
        sort( a.begin() , a.end() ) ; 

        return solve( ) ; 

    }
};




int mai22n( )  { 
    Solution  t; 

    vector<vector<int> > a ;
    int n ; 

    a =  { { 3 , 10 } , { 5 , 15 } , { 10 , 2 } , { 4 , 4 } } ; 
    
    a = { { 1 , 1 } , { 1 , 1 } , { 1 , 1 } } ; 

    
    // [[4,1],[10,7],[5,6],[3,2],[10,9],[2,9],[2,8]]

    a = { { 4 , 1 , } , { 10 , 7 } , { 5 , 6 } , { 3 , 2 } , { 10 , 9 } , 
        { 2 , 9 } , { 2 , 8 } 
    } ;

    auto ans = t.minimumDistance(  a ) ; 
    cout << ans << "\n" ;


    return 0 ; 
}
