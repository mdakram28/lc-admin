class Solution {
    public int minimumDistance(int[][] points) {
        int n = points.length;
        int[][] xpy = new int[n][2];
        int[][] xmy = new int[n][2];
        for(int i = 0; i < n; i++){
            xpy[i][0] = points[i][0] + points[i][1];
            xmy[i][0] = points[i][0] - points[i][1];
            xpy[i][1] = i;
            xmy[i][1] = i;
        }
        Arrays.sort(xpy, (a,b) -> Integer.compare(a[0], b[0]));
        Arrays.sort(xmy, (a,b) -> Integer.compare(a[0], b[0]));
        int res = maxDist(points, xpy[0][1]);
        res = Math.min(res, maxDist(points, xpy[n - 1][1]));
        res = Math.min(res, maxDist(points, xmy[0][1]));
        res = Math.min(res, maxDist(points, xmy[n - 1][1]));
        return res;
    }
    
    int maxDist(int[][] points, int k){
        int n = points.length;
        var xpy = new ArrayList<Integer>();
        var xmy = new ArrayList<Integer>();
        for(int i = 0; i < n; i++){
            if(i != k){
                xpy.add(points[i][0] + points[i][1]);
                xmy.add(points[i][0] - points[i][1]);
            }
        }
        Collections.sort(xpy);
        Collections.sort(xmy);
        return Math.max(xpy.get(xpy.size() - 1) - xpy.get(0), xmy.get(xmy.size() - 1) - xmy.get(0));
    }
}