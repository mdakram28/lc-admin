class Solution {
    public int minimumDistance(int[][] points) {
        int N = 1_0000_0000;
        PriorityQueue<Integer> NE = new PriorityQueue<Integer>((a, b) -> ((points[b][0] + points[b][1]) - (points[a][0] + points[a][1])));
        PriorityQueue<Integer> NW = new PriorityQueue<Integer>((a, b) -> ((points[b][0] + N - points[b][1]) - (points[a][0] + N - points[a][1])));
        PriorityQueue<Integer> SE = new PriorityQueue<Integer>((a, b) -> ((N - points[b][0] + points[b][1]) - (N - points[a][0] +points[a][1])));
        PriorityQueue<Integer> SW = new PriorityQueue<Integer>((a, b) -> ((2 * N - points[b][0] - points[b][1]) - (2 * N -points[a][0] - points[a][1])));
        for (int i = 0; i < points.length; i++) {
            NE.offer(i);
            NW.offer(i);
            SE.offer(i);
            SW.offer(i);
            if (NE.size() > 2) {
                NE.poll();
            }
            if (NW.size() > 2) {
                NW.poll();
            }
            if (SE.size() > 2) {
                SE.poll();
            }
            if (SW.size() > 2) {
                SW.poll();
            }
        }
        Set<Integer> set = new HashSet();
        set.addAll(NE);
        set.addAll(NW);
        set.addAll(SE);
        set.addAll(SW);
        List<Integer> list = new ArrayList(set);
        int min = Integer.MAX_VALUE;
        for (int k = 0; k < list.size(); k++) {
            int max = 0;
            for (int i = 0; i < list.size(); i++) {
                if (k == i) {
                    continue;
                }
                int[] a = points[list.get(i)];
                for (int j = i + 1; j < list.size(); j++) {
                    if (k == j) {
                        continue;
                    }
                    int[] b = points[list.get(j)];
                    max = Math.max(max, Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]));
                }
            }
            min = Math.min(min, max);
        }
        return min;
    }
}