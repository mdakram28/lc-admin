from collections import Counter

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        ps = [(x, y, x + y, x - y) for x, y in points]
        
        ps1 = sorted(ps, key = lambda x: x[2])
        ps2 = sorted(ps, key = lambda x: x[3])
        
        answer = max(ps1[-1][2] - ps1[0][2], ps2[-1][3] - ps2[0][3])
        for x, y, _, _ in ps1:
            if (x, y) == ps1[0][:2]:
                d1 = ps1[1][2]
            else:
                d1 = ps1[0][2]
            if (x, y) == ps1[-1][:2]:
                d2 = ps1[-2][2]
            else:
                d2 = ps1[-1][2]
            if (x, y) == ps2[0][:2]:
                d3 = ps2[1][3]
            else:
                d3 = ps2[0][3]
            if (x, y) == ps2[-1][:2]:
                d4 = ps2[-2][3]
            else:
                d4 = ps2[-1][3]
                
            # print(x, y, d1, d2, d3, d4)
                
            answer = min(answer, max(d2 - d1, d4 - d3))
                
        return answer