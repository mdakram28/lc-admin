def MaxDist(A, N):
 
        # Variables to track running extrema
        minsum = maxsum = A[0][0] + A[0][1]
        mindiff = maxdiff = A[0][0] - A[0][1]
        
        mins = 0
        mind = 0
        maxs = 0
        maxd = 0
        for i in range(1,N):
            summ = A[i][0] + A[i][1]
            diff = A[i][0] - A[i][1]
            if (summ < minsum):
                minsum = summ
                mins = i
            elif (summ > maxsum):
                maxsum = summ
                maxs = i
            if (diff < mindiff):
                mindiff = diff
                mind = i
            elif (diff > maxdiff):
                maxdiff = diff
                maxd = i

        maximum = max(maxsum - minsum, maxdiff - mindiff)
        
        if maxsum - minsum >= maxdiff - mindiff:
            return [maximum, maxs, mins]
        else:
            return [maximum, maxd, mind]
 


class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        _, i1, i2 = MaxDist(points, len(points))
        wo1 = points[:i1] + points[i1+1:]
        wo2 = points[:i2] + points[i2+1:]
        r1, _, _ = MaxDist(wo1, len(points)-1)
        r2, _, _ = MaxDist(wo2, len(points)-1)
        return min(r1, r2)
        
        
    