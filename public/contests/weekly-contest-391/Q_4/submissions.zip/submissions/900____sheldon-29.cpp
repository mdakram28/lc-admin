class Solution {
    const int inf = 0x3f3f3f3f;
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        auto cmp1 = [&](pair<int,int>&a,pair<int,int>&b)->bool{
            return a.first < b.first;
        };
         auto cmp2 = [&](pair<int,int>&a,pair<int,int>&b)->bool{
            return a.first > b.first;
        };
       
        priority_queue<pair<int,int>,vector<pair<int,int>>,decltype(cmp1)>pq1(cmp1);
        priority_queue<pair<int,int>,vector<pair<int,int>>,decltype(cmp2)>pq2(cmp2);
        priority_queue<pair<int,int>,vector<pair<int,int>>,decltype(cmp2)>pq3(cmp2);
        priority_queue<pair<int,int>,vector<pair<int,int>>,decltype(cmp1)>pq4(cmp1);
        
        for(int i = 0;i<n;i++){
            int x = p[i][0],y = p[i][1];
            pq1.push(make_pair(x+y,i));
            pq2.push(make_pair(x+y,i));
            pq3.push(make_pair(x-y,i));
            pq4.push(make_pair(x-y,i));
        }
        int ret = inf;
        for(int i = 0;i<n;i++){
            int x = p[i][0],y = p[i][1];
            bool b1 = false,b2 = false,b3 = false,b4 = false;
            auto tmp1 = pq1.top();
            if(tmp1.second == i){
                pq1.pop();
                b1 = true;
                tmp1 = pq1.top();
            }
            if(b1){
                pq1.push(make_pair(x+y,i));
            }
            
            auto tmp2 = pq2.top();
            if(tmp2.second == i){
                pq2.pop();
                b2 = true;
                tmp2 = pq2.top();
            }
            if(b2){
                pq2.push(make_pair(x+y,i));
            }
            
            auto tmp3 = pq3.top();
            if(tmp3.second == i){
                pq3.pop();
                b3 = true;
                tmp3 = pq3.top();
            }
            if(b3){
                pq3.push(make_pair(x-y,i));
            }
            
            auto tmp4 = pq4.top();
            if(tmp4.second == i){
                pq4.pop();
                b4 = true;
                tmp4 = pq4.top();
            }
            if(b4){
                pq4.push(make_pair(x-y,i));
            }
            
            int t1 = (tmp1.first)-tmp2.first;
            int t2 = tmp4.first - tmp3.first;
            t1 = max(t1,t2);
            ret = min(ret,t1);
        }
        return ret;
    }
};