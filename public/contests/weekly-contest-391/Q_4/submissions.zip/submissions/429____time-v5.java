class Solution {
     public int minimumDistance(int[][] points) {
        int n = points.length;
        int[] arr1 = new int[n], arr2 = new int[n], arr3 = new int[n], arr4 = new int[n];
        int[] minL1 = new int[n], minL2 = new int[n], minL3 = new int[n], minL4 = new int[n];
        int[] minR1 = new int[n], minR2 = new int[n], minR3 = new int[n], minR4 = new int[n];
        int[] maxL1 = new int[n], maxL2 = new int[n], maxL3 = new int[n], maxL4 = new int[n];
        int[] maxR1 = new int[n], maxR2 = new int[n], maxR3 = new int[n], maxR4 = new int[n];
        for (int i = 0; i < n; i++) {
            int x = points[i][0], y = points[i][1];
            arr1[i] = x + y;
            arr2[i] = x - y;
            arr3[i] = y - x;
            arr4[i] = -y - x;
        }
        minL1[0] = arr1[0]; minL2[0] = arr2[0]; minL3[0] = arr3[0]; minL4[0] = arr4[0];
        minR1[n - 1] = arr1[n - 1]; minR2[n - 1] = arr2[n - 1]; minR3[n - 1] = arr3[n - 1]; minR4[n - 1] = arr4[n - 1];
        maxL1[0] = arr1[0]; maxL2[0] = arr2[0]; maxL3[0] = arr3[0]; maxL4[0] = arr4[0];
        maxR1[n - 1] = arr1[n - 1]; maxR2[n - 1] = arr2[n - 1]; maxR3[n - 1] = arr3[n - 1]; maxR4[n - 1] = arr4[n - 1];
        for (int i = 1; i < n; i++) {
            minL1[i] = Math.min(minL1[i - 1], arr1[i]);
            minL2[i] = Math.min(minL2[i - 1], arr2[i]);
            minL3[i] = Math.min(minL3[i - 1], arr3[i]);
            minL4[i] = Math.min(minL4[i - 1], arr4[i]);
            maxL1[i] = Math.max(maxL1[i - 1], arr1[i]);
            maxL2[i] = Math.max(maxL2[i - 1], arr2[i]);
            maxL3[i] = Math.max(maxL3[i - 1], arr3[i]);
            maxL4[i] = Math.max(maxL4[i - 1], arr4[i]);
        }
        for (int i = n - 2; i >= 0; i--) {
            minR1[i] = Math.min(minR1[i + 1], arr1[i]);
            minR2[i] = Math.min(minR2[i + 1], arr2[i]);
            minR3[i] = Math.min(minR3[i + 1], arr3[i]);
            minR4[i] = Math.min(minR4[i + 1], arr4[i]);
            maxR1[i] = Math.max(maxR1[i + 1], arr1[i]);
            maxR2[i] = Math.max(maxR2[i + 1], arr2[i]);
            maxR3[i] = Math.max(maxR3[i + 1], arr3[i]);
            maxR4[i] = Math.max(maxR4[i + 1], arr4[i]);
        }
        int ans = Math.max(Math.max(maxR1[1] - minR1[1], maxR2[1] - minR2[1]), Math.max(maxR3[1] - minR3[1], maxR4[1] - minR4[1]));
        ans = Math.min(ans, Math.max(Math.max(maxL1[n - 2] - minL1[n - 2], maxL2[n - 2] - minL2[n - 2]), Math.max(maxL3[n - 2] - minL3[n - 2], maxL4[n - 2] - minL4[n - 2])));
        for (int i = 1; i < n - 1; i++) {
            int max1 = Math.max(maxL1[i - 1], maxR1[i + 1]), min1 = Math.min(minL1[i - 1], minR1[i + 1]);
            int max2 = Math.max(maxL2[i - 1], maxR2[i + 1]), min2 = Math.min(minL2[i - 1], minR2[i + 1]);
            int max3 = Math.max(maxL3[i - 1], maxR3[i + 1]), min3 = Math.min(minL3[i - 1], minR3[i + 1]);
            int max4 = Math.max(maxL4[i - 1], maxR4[i + 1]), min4 = Math.min(minL4[i - 1], minR4[i + 1]);
            ans = Math.min(ans, Math.max(Math.max(max1 - min1, max2 - min2), Math.max(max3 - min3, max4 - min4)));
        }
        return ans;
    }
}