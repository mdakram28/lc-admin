class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<int> a(n);
        vector<int> b(n);
        for (int i = 0; i < n; i ++) {
            a[i] = points[i][0] - points[i][1];
            b[i] = points[i][0] + points[i][1];
        }
        sort(a.begin(), a.end());
        sort(b.begin(), b.end());
        /*
        for (int val: a) {
            cout << val << " ";
        }
        cout << endl;
        for (int val: b) {
            cout << val << " ";
        }
        cout << endl;
        */
        int d = max(a[n-1]- a[0], b[n-1] - b[0]);
        //cout << "originl: " << a[n-1]- a[0] << " " << b[n-1] - b[0] << endl;
        for (int i = 0; i < n; i ++) {
            int x = points[i][0] - points[i][1];
            int y = points[i][0] + points[i][1];
            int p = a[n-1]- a[0];
            int q= b[n-1] - b[0];
            if (x  == a[0]) {
                p = a[n-1] - a[1];
            }
            if (x == a[n-1]) {
                p = a[n-2] - a[0];
            }
            if (y == b[0]) {
                q = b[n-1] - b[1];
            }
            if (y == b[n-1]) {
                q = b[n-2] - b[0];
            }
            //cout << "remove " << i << " " << p << " + " << q << endl;
            d = min(d, max(p, q));
        }
        return d;
    }
};