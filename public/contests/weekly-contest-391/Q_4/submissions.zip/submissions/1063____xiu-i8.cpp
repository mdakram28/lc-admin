class Solution {
#include <set>
#include <algorithm>
    const int N = 0x7fffffff;
public:
    int minimumDistance(vector<vector<int>>& points) {
         multiset<int> ctt1,ctt2;
        int num = N;
        int len=points.size();
        for(int i=0;i<len;i++){
            ctt1.insert(points[i][0] + points[i][1]);
            ctt2.insert(points[i][0] - points[i][1]);
        }
         for(int i=0;i<len;i++){
            ctt1.erase(ctt1.find(points[i][0]+points[i][1]));
            ctt2.erase(ctt2.find(points[i][0]-points[i][1]));
            int x=*--ctt1.end()-*ctt1.begin();
            int y=*--ctt2.end()-*ctt2.begin();
            num = min(num,max({x,y}));
            ctt2.insert(points[i][0] - points[i][1]);
            ctt1.insert(points[i][0] + points[i][1]);
        }
        return num;
    }
};