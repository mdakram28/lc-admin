const int inf = 0x3f3f3f3f;
int xl[4] = {-1, -1, 1, 1};
int yl[4] = {-1, 1, -1, 1};
class Solution {
public:
    int solve(vector<vector<int>> &p, int skip, int &key){
        vector<int> a(4, -inf);
        int mx = -inf;
        key = -1;
        for(int i=0; i<p.size(); ++i){
            if(i == skip)   continue;
            int x = p[i][0], y = p[i][1];
            int v = -inf;
            for(int j=0; j<4; ++j){
                v = max(v, -xl[j] * x - yl[j] * y + a[j]);
            }
            if(v > mx){
                mx = v;
                key = i;
            }
            for(int j=0; j<4; ++j){
                a[j] = max(a[j], xl[j] * x + yl[j] * y);
            }
        }
        return mx;
    }
    int minimumDistance(vector<vector<int>>& p) {
        int key = 0;
        int ans = solve(p, -1, key);
        int key2 = -1;
        for(int i=0; i<p.size(); ++i){
            if(abs(p[i][0] - p[key][0]) + abs(p[i][1] - p[key][1]) == ans){
                key2 = i;
                break;
            }
        }
        int tmp;
        ans = min(ans, solve(p, key, tmp));
        ans = min(ans, solve(p, key2, tmp));
        return ans;
    }
};