class Solution {
public:
    int minimumDistance(vector<vector<int>>& A) {
        int N = A.size();
        vector<int> sum(N),diff(N);
        for (int i = 0; i < N; i++) {
            sum[i] = A[i][0] + A[i][1];
            diff[i] = A[i][0] - A[i][1];
        }
        
        multiset<int> sumSt,diffSt;
        for(int i=0;i<N;++i) {
            sumSt.insert(sum[i]);
            diffSt.insert(diff[i]);
        }
        
        int ans = 1e9;
        for(int i=0;i<N;++i) {
            sumSt.erase(sumSt.find(sum[i]));
            diffSt.erase(diffSt.find(diff[i]));
            
            int val = max( *(--sumSt.end()) - *(sumSt.begin()) , *(--diffSt.end()) - *(diffSt.begin()));
            ans = min(ans,val);
            
            sumSt.insert(sum[i]);
            diffSt.insert(diff[i]);
        }
        return ans; 
    }
};