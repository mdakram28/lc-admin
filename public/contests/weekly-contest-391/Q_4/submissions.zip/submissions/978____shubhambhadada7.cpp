class Solution {
public:
    

    class sparse1{
    public:
        vector<vector<int>> st;
        int n;
        sparse1(int n,int *a){
            this->n=n;
            st.resize(n+1);
            for(int i=0;i<=n;++i){
                st[i].resize(30);
            }
            for(int i=0;i<n;++i){
                st[i][0]=a[i];
            }
            for(int j=1;j<=log2(n);++j){
                for(int i=0;i+(1<<j)<=n;++i){
                    st[i][j]=max(st[i][j-1],st[i+(1<<(j-1))][j-1]);
                }
            }
        }
        int shoot(int l,int r){
            int j=log2(r-l+1);
            int ans=max(st[l][j],st[r-(1<<(j))+1][j]);
            return ans;
        }

    };



    class sparse{
    public:
        vector<vector<int>> st;
        int n;
        sparse(int n,int *a){
            this->n=n;
            st.resize(n+1);
            for(int i=0;i<=n;++i){
                st[i].resize(30);
            }
            for(int i=0;i<n;++i){
                st[i][0]=a[i];
            }
            for(int j=1;j<=log2(n);++j){
                for(int i=0;i+(1<<j)<=n;++i){
                    st[i][j]=min(st[i][j-1],st[i+(1<<(j-1))][j-1]);
                }
            }
        }
        int shoot(int l,int r){
            int j=log2(r-l+1);
            int ans=min(st[l][j],st[r-(1<<(j))+1][j]);
            return ans;
        }

    };
    int minimumDistance(vector<vector<int>>& a) {
        int n=a.size();
        
        int p[n],q[n];
        for(int i=0;i<n;++i){
            p[i]=a[i][0]-a[i][1];
            q[i]=(a[i][0]+a[i][1]);
            // cout<<p[i]<<" "<<q[i]<<endl;
        }

        sparse s1(n,p),s2(n,q);
        sparse1 s3(n,p),s4(n,q);
        // cout<<s1.shoot(1,n)<<endl;
        int ans=max(s3.shoot(1,n-1)-s1.shoot(1,n-1),s4.shoot(1,n-1)-s2.shoot(1,n-1));
        // cout<<ans<<endl;
        for(int i=1;i<n-1;++i){
            int one = max(s3.shoot(0,i-1),s3.shoot(i+1,n-1));
            int two = min(s1.shoot(0,i-1),s1.shoot(i+1,n-1));
            int three = min(s2.shoot(0,i-1),s2.shoot(i+1,n-1));
            int four = max(s4.shoot(0,i-1),s4.shoot(i+1,n-1));
            ans=min(ans,max(one-two,four-three));
        }
        ans=min(ans,max(s3.shoot(0,n-2)-s1.shoot(0,n-2),s4.shoot(0,n-2)-s2.shoot(0,n-2)));
        return ans;

    }
};