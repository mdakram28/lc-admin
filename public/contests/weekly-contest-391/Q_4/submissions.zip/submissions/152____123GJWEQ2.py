class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        for i in range(len(points)):
            points[i] = tuple(points[i])
        res = float("inf")
        
        def MaxDist(A, N):
            V = [0 for i in range(N)]
            V1 = [0 for i in range(N)]
            map1 = {}
            map2 = {}

            for i in range(N):
                V[i] = A[i][0] + A[i][1]
                map1[V[i]] = A[i]
                V1[i] = A[i][0] - A[i][1]
                map2[V1[i]] = A[i]
            V.sort()
            V1.sort()

            maximum = max(V[-1] - V[0],
                          V1[-1] - V1[0])
            
            if V[-1] - V[0] > V1[-1] - V1[0]:
                return maximum, map1[V[0]], map1[V[-1]]
            return maximum, map2[V1[0]], map2[V1[-1]]

            
        maximum, p1, p2 = MaxDist(points, len(points))
        points.remove(p1)
        res = min(res, MaxDist(points, len(points))[0])
        points.append(p1)
        points.remove(p2)
        res = min(res, MaxDist(points, len(points))[0])
        
        return res