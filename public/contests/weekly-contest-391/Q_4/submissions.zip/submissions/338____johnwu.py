class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        plus = [a + b for a, b in points]
        minus = [a - b for a, b in points]
        maxplus = max(plus)
        minplus = min(plus)
        maxminus = max(minus)
        minminus = min(minus)
        plusv = maxplus - minplus
        minusv = maxminus - minminus
        if plusv > minusv:
            maxidx = plus.index(maxplus)
            minidx = plus.index(minplus)
        else:
            maxidx = minus.index(maxminus)
            minidx = minus.index(minminus)
        ans = float('inf')
        for idx in [minidx, maxidx]:
            tmp = points[:idx] + points[idx+1:]
            p0 = [a + b for a, b in tmp]
            p1 = [a - b for a, b in tmp]
            plus = max(p0) - min(p0)
            minus = max(p1) - min(p1)
            ans = min(ans, max(plus, minus))
        return ans