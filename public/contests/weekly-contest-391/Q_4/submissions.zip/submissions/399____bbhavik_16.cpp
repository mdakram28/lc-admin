class Solution {
public:
    int minimumDistance(vector<vector<int>>& points){
        int n = points.size();
        vector<int> v1(n), v2(n);
        multiset<int> st1, st2;
        for(int i=0; i<n; i++){
            v1[i] = points[i][0] + points[i][1];
            v2[i] = points[i][0] - points[i][1];
            st1.insert(v1[i]);
            st2.insert(v2[i]);
        }
        
        int ans = INT_MAX;
        for(int i=0; i<n; i++){
            st1.erase(st1.find(v1[i]));
            st2.erase(st2.find(v2[i]));
            
            int curr = max(*st1.rbegin() - *st1.begin(), *st2.rbegin() - *st2.begin());
            ans = min(ans, curr);
            
            st1.insert(v1[i]);
            st2.insert(v2[i]);
        }
        
        return ans;
    }
};