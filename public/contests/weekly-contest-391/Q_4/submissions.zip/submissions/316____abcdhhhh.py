class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        points = [[i,x+y,x-y] for i,(x,y) in enumerate(points)]
        a = sorted(points, key=lambda x:x[1])
        b = sorted(points, key=lambda x:x[2])
        r1 = max(a[-2][1] - a[0][1], b[-1][2] - b[0][2])
        r2 = max(a[-1][1] - a[1][1], b[-1][2] - b[0][2])
        r3 = max(a[-1][1] - a[0][1], b[-2][2] - b[0][2])
        r4 = max(a[-1][1] - a[0][1], b[-1][2] - b[1][2])
        ret = min(r1, r2, r3, r4)
        # print(a,b)
        # print(r1,r2,r3,r4)
        if a[0][0]==b[0][0]:
            ret = min(ret, max(a[-1][1]-a[1][1],b[-1][2]-b[1][2]))
        if a[-1][0] == b[-1][0]:
            ret = min(ret, max(a[-2][1]-a[0][1],b[-2][2]-b[0][2]))
        if a[0][0] == b[-1][0]:
            ret = min(ret, max(a[-1][1]-a[1][1],b[-2][2]-b[0][2]))
        if a[-1][0] == b[0][0]:
            ret = min(ret, max(a[-2][1]-a[0][1],b[-1][2]-b[1][2]))
        return ret
            
            