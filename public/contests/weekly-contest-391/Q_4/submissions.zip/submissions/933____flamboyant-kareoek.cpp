class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        vector<int> ans(2);
        int dem = 0;
        int res;
        for (int i = 0; i < 4; i++) {
            int Min = 2e8, Max = -2e8;
            int maxpair, minpair;
            for (int j = 0; j < n; j++) {
                int sum = 0;
                int s = i & 1, t = i & 2;
                if (s) 
                    sum += p[j][0];
                else 
                    sum -= p[j][0];
                if (t) 
                    sum += p[j][1];
                else 
                    sum -= p[j][1];
                if (sum > Max) {
                    Max = sum;
                    maxpair = j;
                }
                if (sum < Min) {
                    Min = sum;
                    minpair = j;
                }
            }
            if (Max - Min > dem) {
                ans[0] = maxpair;
                ans[1] = minpair;
                dem = Max - Min;
            }
        }
        int dem1 = 0;
        for (int i = 0; i < 4; i++) {
            int Min = 2e8, Max = -2e8;
            for (int j = 0; j < n ; j++) {
                if (j == ans[0]) 
                    continue;
                int sum = 0;
                int s = i & 1, t = i & 2;
                if (s) 
                    sum += p[j][0];
                else 
                    sum -= p[j][0];
                if (t) 
                    sum += p[j][1];
                else 
                    sum -= p[j][1];
                if (sum > Max) {
                    Max = sum;
                }
                if (sum < Min) {
                    Min = sum;
                }
            }
            if (Max - Min > dem1) {
                dem1 = Max - Min;
            }
        }
        int dem2 = 0;
        for (int i = 0; i < 4; i++) {
            int Min = 2e8, Max = -2e8;
            for (int j = 0; j < n ; j++) {
                if (j == ans[1]) 
                    continue;
                int sum = 0;
                int s = i & 1, t = i & 2;
                if (s) 
                    sum += p[j][0];
                else 
                    sum -= p[j][0];
                if (t) 
                    sum += p[j][1];
                else 
                    sum -= p[j][1];
                if (sum > Max) {
                    Max = sum;
                }
                if (sum < Min) {
                    Min = sum;
                }
            }
            if (Max - Min > dem2) {
                dem2 = Max - Min;
            }
        }
        res = min(dem1, dem2);
        return res;
    }
};