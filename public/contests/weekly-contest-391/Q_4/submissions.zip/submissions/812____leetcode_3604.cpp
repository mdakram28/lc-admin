class Solution {
public:
    
    bool f[100010];
    int GetDis(vector<vector<int>>& points) {
        vector<pair<int, int>> a;
        vector<pair<int, int>> b;
        int n = points.size();
        for(int i = 0; i < n; ++i) {
            if(f[i]) continue;
            a.push_back({points[i][0] + points[i][1], i});
            b.push_back({points[i][0] - points[i][1], i});
        }
        sort(a.begin(), a.end());
        sort(b.begin(), b.end());
        int m = a.size();
        int v = max(a[m-1].first - a[0].first, b[m-1].first - b[0].first);
        return v;
    }
    
    
    
    int minimumDistance(vector<vector<int>>& points) {
        if (points.size() <= 2) return 0;
        vector<pair<int, int>> a;
        vector<pair<int, int>> b;
        int n = points.size();
        for(int i = 0; i < n; ++i) {
            if(f[i]) continue;
            a.push_back({points[i][0] + points[i][1], i});
            b.push_back({points[i][0] - points[i][1], i});
        }
        int m = a.size();
        sort(a.begin(), a.end());
        sort(b.begin(), b.end());
        memset(f, 0, sizeof(f));
        
        f[a[0].second] = 1;
        int ans = GetDis(points);
        f[a[0].second] = 0;
        
        f[a[m-1].second] = 1;
        int tmp = GetDis(points);
        f[a[m-1].second] = 0;
        ans = min(ans, tmp);
        
        f[b[0].second] = 1;
        tmp = GetDis(points);
        f[b[0].second] = 0;
        ans = min(ans, tmp);
        
        f[b[m-1].second] = 1;
        tmp = GetDis(points);
        f[b[m-1].second] = 0;
        ans = min(ans, tmp);
        return ans;
    }
};