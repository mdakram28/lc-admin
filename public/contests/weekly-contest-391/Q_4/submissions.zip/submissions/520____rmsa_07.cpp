class Solution {
public:
    int minimumDistance(vector<vector<int>>& A) {
        int n=A.size();
        set<pair<int,int>>s,b;
        n=A.size();
 
   
        for(int i=0;i<n;i++){ 
            s.insert({A[i][0]-A[i][1],i});
            b.insert({A[i][0]+A[i][1],i});
        }
        
        int ans=INT_MAX;
        for(int i=0;i<n;i++){
            int x = 0,y=0;
            //for x
            auto it=s.end();
            it--;
            if(it->second==i)it--;
            x=it->first;
            auto itt=s.begin();
            if(itt->second==i)itt++;
            x-=itt->first;
            
            auto pp = b.end();
            pp--;
            if(pp->second==i)pp--;
            y=pp->first;
            auto p=b.begin();
            if(p->second==i)p++;
            y-=p->first;
            ans=min(ans,max(x,y));
        }
 
      
 
        return ans;
    }
};