class Solution {
public:
    static bool cmp(const vector<int>& point1, const vector<int>& point2) {
        return point1[0] - point1[1] < point2[0] - point2[1];
    }
    static bool cmp2(const vector<int>& point1, const vector<int>& point2) {
        return point1[0] + point1[1] < point2[0] + point2[1];
    }
    
    int dist(vector<int> a, vector<int> b) {
        return abs(a[0] - b[0]) + abs(a[1] - b[1]);
    }
    pair<int, vector<vector<int>>> func(vector<vector<int>>& v) {
        vector<vector<int>> v_cp = v;
        
        sort(v.begin(), v.end(), cmp);
        
        sort(v_cp.begin(), v_cp.end(), cmp2);
        
        int dist1 = dist(v[0], v.back());
        
        int dist2 = dist(v_cp[0], v_cp.back());
        
        if(dist1 > dist2) {
            return {dist1, {v[0], v.back()}};
        }
        return {dist2, {v_cp[0], v_cp.back()}};
    }
    
    int minimumDistance(vector<vector<int>>& v) {
        vector<vector<int>> points = func(v).second;
        vector<vector<int>> nw;
        bool taken = false;
        
        for(auto x : v) {
            if(x[0] == points[0][0] && x[1] == points[0][1] && !taken) {
                taken = true;
                continue;
            }
            // if(x[0] == points[1][0] && x[1] == points[1][1]) continue;
            nw.push_back(x);
        }
        int ans = func(nw).first;
        
        nw.clear();
        taken = false;
        
        for(auto x : v) {
            if(x[0] == points[1][0] && x[1] == points[1][1] && !taken) {
                taken = true;
                continue;
            }
            nw.push_back(x);
        }
        
        ans = min(ans, func(nw).first);
        
        return ans;
    }
};