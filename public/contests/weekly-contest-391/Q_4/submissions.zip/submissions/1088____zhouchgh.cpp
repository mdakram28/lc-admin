class Solution {
public:
    vector<int> helper(vector<vector<int>>& points, int ri){
        int n = points.size();
        int min_x = 100000001, max_x = 0, min_y = 100000001, max_y = 0;
        for(int i = 0; i < n; i++){
            if(i != ri){
                min_x = min(min_x, points[i][0]);
                max_x = max(max_x, points[i][0]);
                min_y = min(min_y, points[i][1]);
                max_y = max(max_y, points[i][1]);
            }
        }
        vector<vector<int>> mp = {{min_x, min_y}, {max_x, max_y}, {min_x, max_y}, {max_x, min_y}};
        vector<int> md(4, 100000001);
        vector<int> mi(4, -1);
        for(int i = 0; i < n; i++){
            if(i != ri){
                for(int k = 0; k < 4; k++){
                    int c = abs(points[i][0] - mp[k][0]) + abs(points[i][1] - mp[k][1]);
                    if(c < md[k]){
                        md[k] = c;
                        mi[k] = i;
                    }
                }
            }
        }
        int d1 = abs(points[mi[0]][0] - points[mi[1]][0]) + abs(points[mi[0]][1] - points[mi[1]][1]);
        int d2 = abs(points[mi[2]][0] - points[mi[3]][0]) + abs(points[mi[2]][1] - points[mi[3]][1]);
        if(d1 > d2) return {d1, mi[0], mi[1]};
        return {d2, mi[2], mi[3]};
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        vector<int> res = helper(points, -1);
        vector<int> r1 = helper(points, res[1]);
        vector<int> r2 = helper(points, res[2]);
        return min(r1[0], r2[0]);
    }
};