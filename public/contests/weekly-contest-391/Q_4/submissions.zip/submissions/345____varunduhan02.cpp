class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        multiset<int> sum, diff;
        
        for (int i=0; i<n; i++) {
            int s = points[i][0] + points[i][1];
            int d = points[i][0] - points[i][1];
            
            sum.insert(s);
            diff.insert(d);
        }
        
        auto it1 = sum.end(); it1--;
        auto it2 = diff.end(); it2--;
        
        int ans = max(*it1 - *sum.begin(), *it2 - *diff.begin());
        
        for (int i=0; i<n; i++) {
            int s = points[i][0] + points[i][1];
            int d = points[i][0] - points[i][1];
            
            sum.erase(sum.find(s));
            diff.erase(diff.find(d));
            
            it1 = sum.end(); it1--;
            it2 = diff.end(); it2--;
            
            ans = min(ans, max(*it1 - *sum.begin(), *it2 - *diff.begin()));
            
            sum.insert(s);
            diff.insert(d);
        }
        
        return ans;
    }
};