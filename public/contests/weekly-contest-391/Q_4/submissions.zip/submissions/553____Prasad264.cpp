class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<int> minXPlusY(n), maxXPlusY(n), minXMinusY(n), maxXMinusY(n);
        
        for(int i = 0; i < n; ++i) {
            int xPlusY = points[i][0] + points[i][1];
            int xMinusY = points[i][0] - points[i][1];
            if(i == 0 || xPlusY < minXPlusY[0]) {
                minXPlusY = {xPlusY, i};
            }
            if(i == 0 || xPlusY > maxXPlusY[0]) {
                maxXPlusY = {xPlusY, i};
            }
            if(i == 0 || xMinusY < minXMinusY[0]) {
                minXMinusY = {xMinusY, i};
            }
            if(i == 0 || xMinusY > maxXMinusY[0]) {
                maxXMinusY = {xMinusY, i};
            }
        }

        int res = INT_MAX;
        for(auto& it : {minXPlusY, maxXPlusY, minXMinusY, maxXMinusY}) {
            int maxDist = 0;
            for(int i = 0; i < n; ++i) {
                if(i == it[1]) continue;
                for(auto& itt : {minXPlusY, maxXPlusY, minXMinusY, maxXMinusY}) {
                    if (itt[1] == it[1]) continue;
                    int dist = abs(points[i][0] - points[itt[1]][0]) + abs(points[i][1] - points[itt[1]][1]);
                    maxDist = max(maxDist, dist);
                }
            }
            res = min(res, maxDist);
        }

        return res;   
    }
};