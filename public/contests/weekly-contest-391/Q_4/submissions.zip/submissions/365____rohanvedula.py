class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        # first idea: dp on removing element?
        # second idea: some type of divide and conquer?
        # third idea: find 3 separate instance a) with all points, max distance has to be between x and y
        # b) remove x then find max, 
        # c) remove y then find max, return min of x,y
        
    
        # to-do: find max mahattan distance given set of points
        n = len(points)
        def find_max_distance(points):
            maxs = mins = 0
            maxd = mind = 0
            
            for i in range(1, n):
                s = points[i][0]+points[i][1]
                d = points[i][0]-points[i][1]
                if s>points[maxs][0]+points[maxs][1]:
                    maxs = i
                elif s<points[mins][0]+points[mins][1]:
                    mins = i
                
                if d>points[maxd][0]-points[maxd][1]:
                    maxd = i
                elif d<points[mind][0]-points[mind][1]:
                    mind = i
            
            if points[maxs][0]+points[maxs][1]-(points[mins][0]+points[mins][1])>points[maxd][0]-points[maxd][1]-(points[mind][0]-points[mind][1]):
                return points[maxs][0]+points[maxs][1]-(points[mins][0]+points[mins][1]), (maxs, mins)
            return points[maxd][0]-points[maxd][1]-(points[mind][0]-points[mind][1]), (maxd, mind)
        
        d, p = find_max_distance(points)
        temp = points[p[0]]
        points[p[0]] = points[p[1]]
        
        min_dist1, k = find_max_distance(points)
        points[p[0]] = temp
        points[p[1]] = temp
        
        min_dist2, k = find_max_distance(points)
        return min(min_dist1, min_dist2)
        
        
        
        