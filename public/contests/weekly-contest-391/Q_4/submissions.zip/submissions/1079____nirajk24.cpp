class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        multiset<int> sum;
        multiset<int> diff;
        
        for (int i = 0; i < n; i++) {
            sum.insert(points[i][0] + points[i][1]);
            diff.insert(points[i][0] - points[i][1]);
        }

        // Sorting both the vectors
        // sort(sum.begin(), sum.end());
        // sort(diff.begin(), diff.end());
        
        int ans = max(*sum.rbegin() - *sum.begin(), *diff.rbegin() - *diff.begin());
        for(int i = 0; i < n; i++){
            int s = points[i][0] + points[i][1];
            int d = points[i][0] - points[i][1];
            
            auto it = sum.find(s);
            sum.erase(it);
            auto it2 = diff.find(d);
            diff.erase(it2);
            int x = max(*sum.rbegin() - *sum.begin(), *diff.rbegin() - *diff.begin());
            ans = min(x, ans);
            sum.insert(s);
            diff.insert(d);
        }

        return ans;
        
    }
};