class Solution {
    class Point {
        Integer value;
        Integer index;
    }

    public int minimumDistance(int[][] points) {
        Map<Integer, List<Point>> map = new HashMap<>();
        List<Point> list1 = new ArrayList<>();
        List<Point> list2 = new ArrayList<>();
        List<Point> list3 = new ArrayList<>();
        List<Point> list4 = new ArrayList<>();
        for (int i = 0; i < points.length; i++) {
            Point p1 = new Point();
            p1.index = i;
            p1.value = points[i][0] + points[i][1];
            list1.add(p1);
            Point p2 = new Point();
            p2.index = i;
            p2.value = -points[i][0] + points[i][1];
            list2.add(p2);
            Point p3 = new Point();
            p3.index = i;
            p3.value = points[i][0] - points[i][1];
            list3.add(p3);
            Point p4 = new Point();
            p4.index = i;
            p4.value = -points[i][0] - points[i][1];
            list4.add(p4);
        }
        list1.sort(Comparator.comparing(p -> p.value));
        list2.sort(Comparator.comparing(p -> p.value));
        list3.sort(Comparator.comparing(p -> p.value));
        list4.sort(Comparator.comparing(p -> p.value));
        map.put(0, list1);
        map.put(1, list2);
        map.put(2, list3);
        map.put(3, list4);

        List<Integer> removeList = new ArrayList<>();
        int max = 0;
        for (int i = 0; i < 4; i++) {
            List<Point> list = map.get(i);
            int k = list.get(list.size() - 1).value - list.get(0).value;
            if (max < k) {
                removeList.clear();
                 max = k;
            }
            if (max == k) {
                removeList.add(list.get(list.size() - 1).index);
                removeList.add(list.get(0).index);
            }
        }
        int ans = Integer.MAX_VALUE;
        for (Integer index : removeList) {
            int m = 0;
            for (int i = 0; i < 4; i++) {
                List<Point> list = map.get(i);
                 int minIndex = index.equals(list.get(0).index)? 1 :0;
                int maxIndex = index.equals(list.get(list.size()-1).index)? list.size()-2 :list.size()-1;
                int k = list.get(maxIndex).value - list.get(minIndex).value;
                m = Math.max(m, k);
            }
            ans = Math.min(ans, m);
        }
        return ans;
    }
}