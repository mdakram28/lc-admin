class Solution {
public:
            vector<int> min_element(vector<int>a)
{
        int n=a.size();

    vector<int> pre(n);
 
    pre[0] = a[0];
    for (int i = 1; i < n; i++)
        pre[i] = min(pre[i - 1], a[i]);
 
    
    vector<int> suf(n);
 
    suf[n - 1] = a[n - 1];
    for (int i = n - 2; i >= 0; i--)
        suf[i] = min(suf[i + 1], a[i]);
 
     vector<int>ans;
    for (int i = 0; i < n; i++) {
        if (i == 0)
            ans.push_back(suf[i + 1]);
 
        else if (i == n - 1)
            ans.push_back( pre[i - 1]);
 
        else
            ans.push_back(min(pre[i - 1], suf[i + 1]));
    }
        return ans;
}
    vector<int> max_element(vector<int>a)
{
        int n=a.size();

    vector<int> pre(n);
 
    pre[0] = a[0];
    for (int i = 1; i < n; i++)
        pre[i] = max(pre[i - 1], a[i]);
 
    
    vector<int> suf(n);
 
    suf[n - 1] = a[n - 1];
    for (int i = n - 2; i >= 0; i--)
        suf[i] = max(suf[i + 1], a[i]);
 
     vector<int>ans;
    for (int i = 0; i < n; i++) {
        if (i == 0)
            ans.push_back(suf[i + 1]);
 
        else if (i == n - 1)
            ans.push_back( pre[i - 1]);
 
        else
            ans.push_back(max(pre[i - 1], suf[i + 1]));
    }
        return ans;
}
    int minimumDistance1(vector<vector<int>>& points) {
       vector<int>diff;
        vector<int>sum;
        for(int i=0;i<points.size();i++){
            sum.push_back(points[i][0]+points[i][1]);
            diff.push_back(points[i][0]-points[i][1]);
        }
        vector<int>min_sum=min_element(sum);
        vector<int>max_sum=max_element(sum);
        vector<int>min_diff=min_element(diff);
        vector<int>max_diff=max_element(diff);
        
        vector<int>ans(points.size(),0);
        for(int i=0;i<ans.size();i++){
            ans[i]=max(max_sum[i] - min_sum[i], max_diff[i] - min_diff[i]);
        }
        int x=INT_MAX;
        for(int i=0;i<ans.size();i++){
            x=min(ans[i],x);
        }
        return x;
    }
    int minimumDistance(vector<vector<int>>& points) {
        return minimumDistance1(points);
    }
};