class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        // sort(p.begin(), p.end());
        vector<vector<int>> s, d;
        for(int i = 0; i < n; i++) {
            s.push_back({p[i][0] + p[i][1], i});
            d.push_back({p[i][0] - p[i][1], i});
        }
        sort(s.begin(), s.end());
        sort(d.begin(), d.end());
        // for(auto &i : s) cout << i[0] << " " << i[1] << "\n";
        // cout << "\n";
        // for(auto &i : d) cout << i[0] << " " << i[1] << "\n";
        // cout << "\n";
        set<int> st;
        st.insert(s[0][1]);
        st.insert(s[n - 1][1]);
        st.insert(d[0][1]);
        st.insert(d[n - 1][1]);
        int ans = INT_MAX;
        for(auto& j : st) {
            vector<int> ss, dd;
            for(int i = 0; i < n; i++) {
                if(j == i) continue;
                ss.push_back(p[i][0] + p[i][1]);
                dd.push_back(p[i][0] - p[i][1]);
            }
            sort(ss.begin(), ss.end());
            sort(dd.begin(), dd.end());
            ans = min(ans, max(ss.back() - ss[0], dd.back() - dd[0]));
        }
        return ans;
    }
};