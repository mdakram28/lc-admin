class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<int> a, b;
        int n = points.size();
        unordered_map<int, int> mpa, mpb;
        for(int i=0; i<n; i++) {
            a.push_back(points[i][0]+points[i][1]);
            mpa[a.back()]++;
            b.push_back(points[i][0]-points[i][1]);
            mpb[b.back()]++;
        }
        sort(a.begin(), a.end());
        sort(b.begin(), b.end());
        int ans = INT_MAX;
        for(int i=0; i<n; i++) {
            int t1 = points[i][0]+points[i][1];
            int t2 = points[i][0]-points[i][1];
            int c, d;
            if(t1 == a.front() || t1 == a.back()) {
                if(t1 == a.front() && t1 == a.back()) {
                    c = 0;
                }
                else{
                    if(mpa[t1] > 1) {
                        c = a.back() - a.front();
                    }
                    else {
                        c = (t1 == a.front() ? a.back() - a[1] : a[n-2] - a.front());
                    }   
                }
            }
            else {
                c = a.back() - a.front();
            }
            
            if(t2 == b.front() || t2 == b.back()) {
                if(t2 == b.front() && t2 == b.back()) {
                    d = 0;
                }
                else{
                    if(mpb[t2] > 1) {
                        d = b.back() - b.front();
                    }
                    else {
                        d = (t2 == b.front() ? b.back() - b[1] : b[n-2] - b.front());
                    }   
                }
            }
            else {
                d = b.back() - b.front();
            }
            // cout << c << ' ' << d << endl;
            ans = min(ans, max(c, d));
        } 
        return ans;
    }
};