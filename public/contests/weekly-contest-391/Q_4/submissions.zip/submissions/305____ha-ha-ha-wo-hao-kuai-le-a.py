class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        ans = 10 ** 10
        n = len(points)
        v = [[[0] * 2 for _ in range(n)] for __ in range(4)]
        for i in range(n):
            v[0][i][0] = points[i][0] + points[i][1]
            v[1][i][0] = points[i][0] - points[i][1]
            v[2][i][0] = -points[i][0] + points[i][1]
            v[3][i][0] = -points[i][0] - points[i][1]
            v[0][i][1] = v[1][i][1] = v[2][i][1] = v[3][i][1] = i
        v[0].sort()
        v[1].sort()
        v[2].sort()
        v[3].sort()
        for i in range(n):
            cur_mx = 0
            for j in range(4):
                if v[j][0][1] == i:
                    cur_mx = max(cur_mx, v[j][n - 1][0] - v[j][1][0])
                elif v[j][n - 1][1] == i:
                    cur_mx = max(cur_mx, v[j][n - 2][0] - v[j][0][0])
                else:
                    cur_mx = max(cur_mx, v[j][n - 1][0] - v[j][0][0])
            ans = min(ans, cur_mx)
        return ans
