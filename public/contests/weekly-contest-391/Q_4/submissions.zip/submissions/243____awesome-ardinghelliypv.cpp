#include<bits/stdc++.h>
#pragma GCC optimize("Ofast") 
#pragma GCC optimize("unroll-loops")
#define mp make_pair
#define pb push_back
#define SZ(x) (int)(x.size())
#define all(x) x.begin(),x.end()
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int>pii;
const int maxn = 2e6 + 6;
const int  inf = 0x3f3f3f3f;
const int mod = 1e9+7;
const int N = 2e3 + 3;
class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {

    	multiset<int>s1,s2,s3,s4;
    	for(auto v:p){
    		int x=v[0],y=v[1];
    		s1.insert(x+y);
    		s2.insert(-x-y);
    		s3.insert(-x+y);
    		s4.insert(x-y);
    	}
    	int mini=1e9;
    	for(auto v:p){
    		int x=v[0],y=v[1];
    		s1.erase(s1.find(x+y));
    		s2.erase(s2.find(-x-y));
    		s3.erase(s3.find(-x+y));
    		s4.erase(s4.find(x-y));

    		int a=*s1.rbegin();
    		int b=*s2.rbegin();
			int c=*s3.rbegin();
			int d=*s4.rbegin();



    		mini=min(mini, max(a+b,c+d));

    		s1.insert(x+y);
    		s2.insert(-x-y);
    		s3.insert(-x+y);
    		s4.insert(x-y);
    	}
    	return mini;
        
    }
};