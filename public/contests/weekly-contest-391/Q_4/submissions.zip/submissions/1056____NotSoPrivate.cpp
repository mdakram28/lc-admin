class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        int ans = INT_MAX;
        map<int, int> a;
        map<int, int> b;
        
        for(auto i: points) {
            int x = i[0] + i[1];
            int y = i[0] - i[1];
            a[x]++;
            b[y]++;
        }
        for(auto i: points) {
            int x = i[0] + i[1];
            int y = i[0] - i[1];
            a[x]--;
            if(a[x] == 0) {
                a.erase(x);
            }
            b[y]--;
            if(b[y] == 0) {
                b.erase(y);
            }
            int temp = max(a.rbegin() -> first - a.begin() -> first, b.rbegin() -> first - b.begin() -> first);
            ans = min(ans, temp);
            a[x]++;
            b[y]++;
        }
        
        return ans;
    }
};