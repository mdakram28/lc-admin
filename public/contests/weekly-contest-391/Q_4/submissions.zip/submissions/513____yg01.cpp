class Solution {
public:
    int func(vector<vector<int>> &points){
        int n = points.size();
        vector<int> sum_val(n), diff(n), max_dist(n);
        
        for (int i = 0; i < n; ++i) {
            sum_val[i] = points[i][0] + points[i][1];
            diff[i] = points[i][0] - points[i][1];
        }
        
        int max_sum = *max_element(sum_val.begin(), sum_val.end());
        int min_sum = *min_element(sum_val.begin(), sum_val.end());
        int max_diff = *max_element(diff.begin(), diff.end());
        int min_diff = *min_element(diff.begin(), diff.end());
        
        for (int i = 0; i < n; ++i) {
            max_dist[i] = max({abs(sum_val[i] - min_sum), abs(sum_val[i] - max_sum),
                         abs(diff[i] - min_diff), abs(diff[i] - max_diff)});
        }
        
        sort(max_dist.begin(), max_dist.end());
        
        return max_dist.back();
    }
     

vector<int> func1(vector<vector<int> >& a)
{
    // Vectors to store maximum and
    // minimum of all the four forms
    int n = a.size();
    // vector<int> v(n), v1(n);
    vector<vector<int>> v(n), v1(n);
    for (int i = 0; i < n; i++) {
        v[i] = {a[i][0] + a[i][1],i};
        v1[i] = {a[i][0] - a[i][1],i};
    }
 
    // Sorting both the vectors
    sort(v.begin(), v.end());
    sort(v1.begin(), v1.end());
 
    if(v.back()[0] - v.front()[0]>=v1.back()[0] - v1.front()[0]){
        return {a[v.back()[1]][0],a[v.back()[1]][1],a[v.front()[1]][0],a[v.front()[1]][1]};
    }
    else{
        return {a[v1.back()[1]][0],a[v1.back()[1]][1],a[v1.front()[1]][0],a[v1.front()[1]][1]};
    }
 

}
    int minimumDistance(vector<vector<int>>& a) {
        int n = a.size();
        //find the 4 coordinates
        int ans = INT_MAX;
        vector<int> tmp = func1(a);
        int x1 = tmp[0], y1 = tmp[1], x2 = tmp[2], y2 = tmp[3];
        
        //remove x1,y1;
        map<pair<int,int>,int> mp;
        for(auto &i:a){
            mp[{i[0], i[1]}]++;
        }
        
        vector<vector<int>> tmp1,tmp2;
        for(auto &i:a){
            if(i[0]==x1 and i[1]==y1){
                if(mp[{x1,y1}]<=1)continue;
            }
            tmp1.push_back({i[0], i[1]});
        }
        for(auto &i:a){
            if(i[0]==x2 and i[1]==y2){
                if(mp[{x2,y2}]<=1)continue;
            }
            tmp2.push_back({i[0], i[1]});
        }
        ans = func(tmp2);
        ans = min(ans, func(tmp1));
        return ans;
    }
};