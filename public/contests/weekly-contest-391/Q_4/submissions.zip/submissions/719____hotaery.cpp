class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<int> sum(n), diff(n);
        for (int i = 0; i < n; i++) {
            sum[i] = (points[i][0] + points[i][1]);
            diff[i] = (points[i][0] - points[i][1]);
        }
            
        vector<int> sum_idx(n), diff_idx(n);
        for (int i = 0; i < n; i++) {
            sum_idx[i] = i;
            diff_idx[i] = i;
        }
        sort(sum_idx.begin(), sum_idx.end(), [&](int i, int j) {
            if (sum[i] == sum[j]) {
                return i < j;
            } 
            return sum[i] < sum[j];
        });
        sort(diff_idx.begin(), diff_idx.end(), [&](int i, int j) {
            if (diff[i] == diff[j]) {
                return i < j;
            }
            return diff[i] < diff[j];
        });
        
        // for (int i = 0; i < n; i++) {
        //     cout << sum[i] << ", " << diff[i] << endl;
        // }
        // for (int i = 0; i < n; i++) {
        //     cout << sum_idx[i] << " ";
        // }
        // cout << endl;
        // for (int i = 0; i < n; i++) {
        //     cout << diff_idx[i] << " ";
        // }
        // cout << endl;
        
        int ans = max(sum[sum_idx.back()] - sum[sum_idx[0]], diff[diff_idx.back()] - diff[diff_idx[0]]);
        // cout << ans << endl;
        auto cal = [&](int i) {
            int left, right;
            if (sum_idx[0] == i) {
                left = sum_idx[1];
            } else {
                left = sum_idx[0];
            }
            if (sum_idx[n - 1] == i) {
                right = sum_idx[n - 2];
            } else {
                right = sum_idx[n - 1];
            }
            int ans = sum[right] - sum[left];
            if (diff_idx[0] == i) {
                left = diff_idx[1];
            } else {
                left = diff_idx[0];
            }
            if (diff_idx[n - 1] == i) {
                right = diff_idx[n - 2];
            } else {
                right = diff_idx[n - 1];
            }
            ans = max(ans, diff[right] - diff[left]);
            return ans;
        };
        
        ans = min(ans, cal(sum_idx[0]));
        ans = min(ans, cal(sum_idx[n - 1]));
        ans = min(ans, cal(diff_idx[0]));
        ans = min(ans, cal(diff_idx[n - 1]));
        return ans;
    }
};