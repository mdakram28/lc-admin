class Solution {
public:

    unordered_map<int,int> sumP;
    unordered_map<int,int> diffP;
    set<int> harsum,rajotiyaDiff;
int minDis=INT_MAX;
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();

        for(int i=0;i<n;i++){
            int x=points[i][0];
            int y=points[i][1];
            
            int sum=x+y;
            int dff=x-y;
            sumP[sum]++;
            diffP[dff]++;
            harsum.insert(sum);
            rajotiyaDiff.insert(dff);
        }
        
            

        for(int i=0;i<n;i++){
            
            int sum=points[i][0]+points[i][1],diff=points[i][0]-points[i][1];
            
            if(sumP[sum]==1)
            harsum.erase(sum);
            if(diffP[diff]==1)
            rajotiyaDiff.erase(diff);
            
            int rhehe=0;
            
            if(harsum.size())rhehe=max( *harsum.rbegin()- *harsum.begin() , *rajotiyaDiff.rbegin()- *rajotiyaDiff.begin());
            
            if(sumP[sum]==1)
            harsum.insert(sum);
            if(diffP[diff]==1)
            rajotiyaDiff.insert(diff);

            if(minDis>rhehe)minDis=rhehe;
        }
        
        return minDis;
    }
};


