class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int ans=INT_MAX;
        int n=points.size();
        multiset<int> add;
        multiset<int> diff;
        for(auto it:points)
        {
            int x=it[0];
            int y=it[1];
            add.insert(x+y);
            diff.insert(x-y);
        }
        
        for(int i=0;i<n;i++)
        {
            int x=points[i][0];
            int y=points[i][1];
            
            add.erase(add.find(x+y));
            diff.erase(diff.find(x-y));
            
            int dist=max(*add.rbegin()-*add.begin(),*diff.rbegin()-*diff.begin());
            ans=min(ans,dist);
            
            add.insert(x+y);
            diff.insert(x-y);
        }   
        return ans;
    }
};