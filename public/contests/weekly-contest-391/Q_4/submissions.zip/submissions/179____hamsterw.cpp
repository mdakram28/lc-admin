class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<int>mx(2), cmx(2), mn(2), cmn(2);
        mx[0] = mx[1] = -1000000000;
        cmx[0] = cmx[1] = -1000000000;
        mn[0] = mn[1] = 1000000000;
        cmn[0] = cmn[1] = 1000000000;
        for(auto p:points){
            int x = p[0], y = p[1];
            int s = x+y, d = x-y;
            if(s>=mx[0]){
                cmx[0] = mx[0];mx[0] = s;
            }else if(s>=cmx[0])cmx[0] = s;
            if(d>=mx[1]){
                cmx[1] = mx[1];mx[1] = d;
            }else if(d>=cmx[1])cmx[1] = d;
            
            if(s<=mn[0]){
                cmn[0] = mn[0];mn[0] = s;
            }else if(s<=cmn[0])cmn[0] = s;
            if(d<=mn[1]){
                cmn[1] = mn[1];mn[1] = d;
            }else if(d<=cmn[1])cmn[1] = d;
            
        }
        int ans = max(mx[0] - mn[0], mx[1] - mn[1]);
        cout<<mx[0]<<" "<<cmx[0]<<" "<<mn[0]<<" "<<cmn[0]<<endl;
        cout<<mx[1]<<" "<<cmx[1]<<" "<<mn[1]<<" "<<cmn[1]<<endl;
        int n = points.size();
        for(int i=0;i<n;i++){
            
            int now1, now2;
            int s = points[i][0] + points[i][1];
            int d = points[i][0] - points[i][1];
            
            if(mx[0]==s)now1 = cmx[0] - mn[0];
            else if(mn[0]==s)now1 = mx[0] - cmn[0];
            else now1 = mx[0] - mn[0];
            
            if(mx[1]==d)now2 = cmx[1] - mn[1];
            else if(mn[1]==d)now2 = mx[1] - cmn[1];
            else now2 = mx[1] - mn[1];
            
            ans = min(ans, max(now1, now2));
            
        }
        
        return ans;
    }
};