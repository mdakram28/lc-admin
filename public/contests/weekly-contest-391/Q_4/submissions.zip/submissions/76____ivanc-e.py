from sortedcontainers import SortedList

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        x = SortedList()
        y = SortedList()
        for p in points:
            x.add(p[0] + p[1])
            y.add(p[0] - p[1])
        ans = inf

        for p in points:
            x.remove(p[0] + p[1])
            y.remove(p[0] - p[1])
            ans = min(ans, max(x[-1] - x[0], y[-1] - y[0]))
            x.add(p[0] + p[1])
            y.add(p[0] - p[1])
        
        return ans
        