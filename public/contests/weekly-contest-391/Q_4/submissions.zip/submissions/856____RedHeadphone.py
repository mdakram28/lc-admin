class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        summ = [0]*n 
        diff = [0]*n

        for i in range(n):
            summ[i] = (points[i][0]+points[i][1],i)
            diff[i] = (points[i][0]-points[i][1],i)
        
        summ.sort()
        diff.sort()

        l_t = None
        ans = None
        if summ[-1][0] - summ[0][0] > diff[-1][0] - diff[0][0]:
            l_t = (summ[-1][1],summ[0][1])
            ans = summ[-1][0] - summ[0][0]
        else:
            l_t = (diff[-1][1],diff[0][1])
            ans = diff[-1][0] - diff[0][0]
        # print(l_t,ans)
        for ignore in l_t:
            tsumm = [x for x in summ if x[1] != ignore]
            tdiff = [x for x in diff if x[1] != ignore]

            t_ans = max(
                tsumm[-1][0] - tsumm[0][0],
                tdiff[-1][0] - tdiff[0][0]
            )
            ans = min(ans, t_ans)
        
        return ans