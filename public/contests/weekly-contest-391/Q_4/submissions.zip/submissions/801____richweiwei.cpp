class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        
        int n = points.size();
        
        vector<pair<int, int>> plus;
        vector<pair<int, int>> minus;
        
        for (int i = 0; i < n; ++i) {
            plus.push_back({points[i][0] + points[i][1], i});
            minus.push_back({points[i][0] - points[i][1], i});
        }
        
        sort(plus.begin(), plus.end());
        sort(minus.begin(), minus.end());
                            
        vector<int> cand = {plus[0].second, plus[n-1].second, minus[0].second, minus[n-1].second};
        
        int sol = INT_MAX;
        
        for (int k = 0; k < 4; ++k) {
            // cout<<cand[k]<<endl;
            vector<int> t_plus;
            vector<int> t_minus;
            
            for (int i = 0; i < n; ++i) {
                if (i != cand[k]) {
                    t_plus.push_back(points[i][0] + points[i][1]);
                    t_minus.push_back(points[i][0] - points[i][1]);
                }
            }
            
            sort(t_plus.begin(), t_plus.end());
            sort(t_minus.begin(), t_minus.end());
            
            int case1 = t_plus[n-2] - t_plus[0];
            int case2 = -1* t_minus[0] + t_minus[n-2];
            int mm = max(case1, case2);
            sol = min(sol, mm);
        }
            
        return sol;
                            
        
        
        
        
    }
};