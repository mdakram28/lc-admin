class Solution {
public:
    int calc(vector<pair<int, int>> V, vector<pair<int, int>> V1, int r)
    {
        if(V1[0].second == r)
        {
            V1.erase(V1.begin());
        }
        else if((V1.back()).second == r)
        {
            V1.pop_back();
        }
        if(V[0].second == r)
        {
            V.erase(V.begin());
        }
        else if((V.back()).second == r)
        {
            V.pop_back();
        }
        vector<pair<int,int>> x = V, y = V1;
        int ans = max(abs(V1.front().first - V1.back().first), abs(V.front().first - V.back().first));
        return ans;
    }
    
    int comp(vector<vector<int>>& A, int N)
    {
        vector<pair<int, int>> V(N), V1(N);
        for (int i = 0; i < N; i++) 
        {
            V[i] = {A[i][0] + A[i][1], i};
            V1[i] = {A[i][0] - A[i][1], i};
        }
        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());
        int ans = INT_MAX;
        if(abs(V.front().first - V.back().first) > abs(V1.front().first - V1.back().first))
        {
            int r1 = V.front().second, r2 = V.back().second;   
            ans = min(calc(V, V1, r1), calc(V, V1, r2));
        }
        else
        {
            int r1 = V1.front().second, r2 = V1.back().second;   
            ans = min(calc(V, V1, r1), calc(V, V1, r2));
        }
        return ans;
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        return comp(points, n);
    }
};