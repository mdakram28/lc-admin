class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        const int inf = 1<<30;
        vector<int> big_pref(n, -inf), big_suff(n, -inf);
        vector<vector<int>> at_pref, at_suff;
        vector<int> best(4, -inf);
        for(int i = 0; i < n; i++){
            if(i) big_pref[i] = big_pref[i - 1];
            for(int j = 0; j < 4; j++){
                int sx = (j&1) ? -1 : 1, sy = (j & 2) ? -1 : 1;
                int val = sx * p[i][0] + sy * p[i][1];
                big_pref[i] = max(big_pref[i], val + best[j ^ 3]);
            }
            for(int j = 0; j < 4; j++){
                int sx = (j&1) ? -1 : 1, sy = (j & 2) ? -1 : 1;
                int val = sx * p[i][0] + sy * p[i][1];
                best[j] = max(best[j], val);
            }
            at_pref.push_back(best);
        }
        fill(best.begin(), best.end(), -inf);
        for(int i = n - 1; i >= 0; i--){
            if(i + 1 < n) big_suff[i] = big_suff[i + 1];
            for(int j = 0; j < 4; j++){
                int sx = (j&1) ? -1 : 1, sy = (j & 2) ? -1 : 1;
                int val = sx * p[i][0] + sy * p[i][1];
                big_suff[i] = max(big_suff[i], val + best[j ^ 3]);
            }
            for(int j = 0; j < 4; j++){
                int sx = (j&1) ? -1 : 1, sy = (j & 2) ? -1 : 1;
                int val = sx * p[i][0] + sy * p[i][1];
                best[j] = max(best[j], val);
            }
            at_suff.push_back(best);
        }
        reverse(at_suff.begin(), at_suff.end());
        int res = inf;
        for(int i = 0; i < n; i++){
            int cur = -inf;
            if(i) cur = max(cur, big_pref[i - 1]);
            if(i + 1 < n) cur = max(cur, big_suff[i + 1]);
            if(i && i + 1 < n){
                for(int j = 0; j < 4; j++){
                    cur = max(cur, at_pref[i - 1][j] + at_suff[i + 1][j ^ 3]);
                }
            }
            res = min(res, cur);
        }
        return res;
    }
};