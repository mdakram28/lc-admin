class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def helper(A):
            n = len(A)
            max_sum_p, min_sum_p = 0, 0
            max_diff_p, min_diff_p = 0, 0
            minsum = maxsum = A[0][0] + A[0][1]
            mindiff = maxdiff = A[0][0] - A[0][1]
            for i in range(1, n):
                sum = A[i][0] + A[i][1]
                diff = A[i][0] - A[i][1]
                if (sum < minsum):
                    minsum = sum
                    min_sum_p = i
                elif (sum > maxsum):
                    maxsum = sum
                    max_sum_p = i
                if (diff < mindiff):
                    mindiff = diff
                    min_diff_p = i
                elif (diff > maxdiff):
                    maxdiff = diff
                    max_diff_p = i
            diff = max(maxsum - minsum, maxdiff - mindiff)
            if maxsum-minsum > maxdiff-mindiff:
                return min_sum_p, max_sum_p, diff
            return min_diff_p, max_diff_p, diff
        p1, p2, diff = helper(points)
        temp_1 = points[:p1]+points[p1+1:]
        temp_2 = points[:p2]+points[p2+1:]
        p1, p2, diff1 = helper(temp_1)
        p1, p2, diff2 = helper(temp_2)
        return min(diff1, diff2)