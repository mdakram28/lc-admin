class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        init(points);
        
        int res = INT_MAX;
        for(auto& p : points) {
            sum.erase(sum.find(p[0] + p[1]));
            diff.erase(diff.find(p[0] - p[1]));
            
            int cur = max(*sum.rbegin() - *sum.begin(), *diff.rbegin() - *diff.begin());
            res = min(res, cur);
            
            sum.insert(p[0] + p[1]);
            diff.insert(p[0] - p[1]);
        }
        return res;
    }
private:
    multiset<int> sum, diff;
    
    void init(auto& points) {
        for(auto& p : points) {
            sum.insert(p[0] + p[1]);
            diff.insert(p[0] - p[1]);
        }
    }
};
/*

*/