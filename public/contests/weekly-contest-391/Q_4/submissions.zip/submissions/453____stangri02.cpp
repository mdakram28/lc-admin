typedef long long ll;
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int N = points.size();
        multiset<ll> s1; 
        multiset<ll> s2;
        vector<ll> v(N), v1(N);
        for(int i = 0; i < N; ++i) {
            ll d1 = (ll)points[i][0] + points[i][1];
            ll d2 = (ll)points[i][0] - points[i][1];
            v[i] = d1;
            v1[i] = d2;
            s1.insert(d1);
            s2.insert(d2);
        }
        ll minDist = LLONG_MAX;
        for(int i = 0; i < N; ++i) {
            ll d1 = v[i];
            ll d2 = v1[i];
            s1.erase(s1.find(d1));
            s2.erase(s2.find(d2));
            auto b1 = *s1.begin();
            auto b2 = *s2.begin();
            auto e1 = *(prev(s1.end()));
            auto e2 = *(prev(s2.end()));
            ll currDist = max(e1 - b1, e2 - b2);
            minDist = min(minDist, currDist);
            s1.insert(d1);
            s2.insert(d2);
        }
        return minDist;
        
    }
};