class Solution {
public:
    int help(vector<vector<int>> points, int ind)
    {
        int res = 0;
        vector<int> newx, newy;
        int i = -1;
        for(auto it : points)
        {
            i++;
            if(i == ind) continue;
            int x = it[0], y = it[1];
            newx.push_back(x + y);
            newy.push_back(x - y);
        }
        sort(newx.begin(), newx.end());
        sort(newy.begin(), newy.end());
        res = newx.back() - newx.front();
        res = max(res, newy.back() - newy.front());
        
        return res;
    }
    int minimumDistance(vector<vector<int>>& points) {
        int res = INT_MAX;
        int ind =0;
        vector<pair<int, int>> newx, newy;
        for(auto it : points)
        {
            int x = it[0], y = it[1];
            newx.push_back({x + y, ind});
            newy.push_back({x - y, ind});
            ind++;
        }
        sort(newx.begin(), newx.end());
        sort(newy.begin(), newy.end());
        int ind1 = -1, ind2 = -1;
        int max1 = newx.back().first - newx.front().first;
        int max2 = newy.back().first - newy.front().first;
        
        if(max1 > max2)
        {
            ind1 = newx.back().second;
            ind2 = newx.front().second;
        }
        else{
            ind1 = newy.back().second;
            ind2 = newy.front().second;
        }
        res = help(points, ind1);
        res = min(res, help(points, ind2));
        
        return res;
    }
};