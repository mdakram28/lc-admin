class Solution:
    def minimumDistance(self, a: List[List[int]]) -> int:
        n = len(a)
        transformed = [[0] * n for _ in range(4)]
        sorted_indices = [[0] * n for _ in range(4)]

        for i in range(n):
            transformed[0][i] = a[i][0] + a[i][1]
            transformed[1][i] = -a[i][0] + a[i][1]
            transformed[2][i] = a[i][0] - a[i][1]
            transformed[3][i] = -a[i][0] - a[i][1]
            for j in range(4):
                sorted_indices[j][i] = i

        for i in range(4):
            sorted_indices[i].sort(key=lambda idx: transformed[i][idx])

        res = float('inf')
        for i in range(4):
            # Drop the first sorted index
            dropped_index = sorted_indices[i][0]
            max_distance = transformed[i][sorted_indices[i][n - 1]] - transformed[i][sorted_indices[i][1]]
            for j in range(4):
                if j == i:
                    continue
                first, last = sorted_indices[j][0], sorted_indices[j][n - 1]
                if last == dropped_index:
                    last = sorted_indices[j][n - 2]
                elif first == dropped_index:
                    first = sorted_indices[j][1]
                max_distance = max(max_distance, transformed[j][last] - transformed[j][first])
            res = min(res, max_distance)

            # Drop the last sorted index
            dropped_index = sorted_indices[i][n - 1]
            max_distance = transformed[i][sorted_indices[i][n - 2]] - transformed[i][sorted_indices[i][0]]
            for j in range(4):
                if j == i:
                    continue
                first, last = sorted_indices[j][0], sorted_indices[j][n - 1]
                if last == dropped_index:
                    last = sorted_indices[j][n - 2]
                elif last == dropped_index:
                    first = sorted_indices[j][1]
                max_distance = max(max_distance, transformed[j][last] - transformed[j][first])
            res = min(res, max_distance)

        return res