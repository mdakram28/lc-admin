class Solution {
public:
    int a(const vector<vector<int>>& p, const pair<int,int>& x){
        return abs(p[x.first][0]-p[x.second][0])+abs(p[x.first][1]-p[x.second][1]);
    }
    // pair<int,int> cal(const vector<vector<int>>& p, const vector<bool>& col){
    //     int n=p.size();
    //     int t=col[0]?0:1;
    //     int r=t;
    //     int M=-1;
    //     bool c=1;
    //     while(c){
    //         c=0;
    //         swap(t,r);
    //         for(int i=0;i<n;++i){
    //             if(i!=t&&col[i]){
    //                 int z=a(p,{t,i});
    //                 if(z>M){
    //                     M=z;
    //                     c=1;
    //                     r=i;
    //                 }
    //             }
    //         }
    //     }
    //     return {t,r};
    // }
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        vector<pair<int,int>> a,b;
        for(int i=0;i<n;++i){
            a.emplace_back(points[i][0]+points[i][1],i);
            b.emplace_back(points[i][0]-points[i][1],i);
        }
        sort(a.begin(),a.end());
        sort(b.begin(),b.end());
        int M=-1;
        pair<int,int> p;
        int da=abs(a[0].first-a.back().first);
        int db=abs(b[0].first-b.back().first);
        if(db>da){
            swap(a,b);
        }
        auto c=[&](int x){
            int res=0;
            int l=0;
            int r=n-1;
            while(a[l].second==x){
                ++l;
            }
            while(a[r].second==x){
                --r;
            }
            res=max(res,abs(a[l].first-a[r].first));
            l=0;
            r=n-1;
            while(b[l].second==x){
                ++l;
            }
            while(b[r].second==x){
                --r;
            }
            res=max(res,abs(b[l].first-b[r].first));
            return res;
        };
        return min(c(a[0].second),c(a.back().second));
    }
};