class Solution {
public:
    int LC = 0;
    int RC = 0;
    int maxDist(vector<pair<int,int>>& points) {
        vector<pair<int,int>> s;
        vector<pair<int,int>> d;
        
        for (int i = 0; i < points.size(); i++) {
            s.push_back({points[i].first + points[i].second, i});
            d.push_back({points[i].first - points[i].second, i});
        }
        sort(s.begin(), s.end());
        sort(d.begin(), d.end());
        
        int d1 = s[s.size() - 1].first - s[0].first;
        int d2 = d[d.size() - 1].first - d[0].first;
        if (d1 > d2) {
            LC = s[s.size()-1].second;
            RC = s[0].second;
        } else {
            LC = d[d.size() - 1].second;
            RC = d[0].second;
        }
        return max(d1, d2);
    }
    int minimumDistance(vector<vector<int>>& p) {
        vector<pair<int,int>> points;
        for (vector<int> v : p) points.push_back({v[0],v[1]});
        sort(points.begin(), points.end(), [](pair<int,int> x, pair<int,int> y) {
           if (x.first == y.first) {
               return x.second < y.second;
           }
            return x.first < y.first;
        });
        
        vector<pair<int,int>> points2;
        for (pair<int,int> lawl : points) points2.push_back(lawl);
        maxDist(points);

        points.erase(points.begin() + LC);
        points2.erase(points2.begin() + RC);
        
        
        return min(maxDist(points),maxDist(points2));
    }
};