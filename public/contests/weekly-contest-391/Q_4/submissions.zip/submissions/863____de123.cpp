class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int>sum;
        multiset<int>diff;
        
        for(int i=0; i<points.size(); i++){
            sum.insert(points[i][0] + points[i][1]);
            diff.insert(points[i][0]-points[i][1]);
        }
        
        int ans = INT_MAX;
        
        for(int i=0; i<points.size(); i++){
            int s = points[i][0] + points[i][1];
            int d = points[i][0] - points[i][1];
            
            sum.erase(sum.find(s));
            diff.erase(diff.find(d));
            
            int temp1 = (*sum.rbegin())-(*sum.begin());
            int temp2 = (*diff.rbegin()) - (*diff.begin());
            
            ans = min(ans,max(temp1,temp2));
            
            sum.insert(s);
            diff.insert(d);
        }
        
        return ans;
    }
};