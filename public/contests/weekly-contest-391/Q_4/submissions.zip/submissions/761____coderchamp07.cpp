class Solution {
public:
    int manhattan(vector<int>& a, vector<int>& b) {
        return abs(a[0] - b[0]) + abs(a[1] - b[1]);
    }
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        int mnX = points[0][0], mxX = points[0][0];
        int mnY = points[0][1], mxY = points[0][1];
        
        for(int i = 0; i < n; i++) {
            mnX = min(mnX, points[i][0]);
            mxX = max(mxX, points[i][0]);
            mnY = min(mnY, points[i][1]);
            mxY = max(mxY, points[i][1]);
        }
        
        vector<vector<int>> corners = {{mnX, mnY}, {mxX, mnY}, {mnX, mxY}, {mxX, mxY}};
        
        set<int> closests;
        for(auto c : corners) {
            int mnDist = INT_MAX;
            for(auto p : points)
                mnDist = min(mnDist, manhattan(p, c));
            for(int i = 0; i < n; i++) {
                if(manhattan(c, points[i]) == mnDist)
                    closests.insert(i);
            }
        }
        
        set<int> pointsWithMxDist;
        int mxDist = 0;
        for(auto parentIdx : closests) {
            for(auto p : points)
                mxDist = max(mxDist, manhattan(p, points[parentIdx]));
        }
        for(auto parentIdx : closests) {
            for(int i = 0; i < n; i++) {
                if(manhattan(points[i], points[parentIdx]) == mxDist) {
                    pointsWithMxDist.insert(parentIdx);
                    pointsWithMxDist.insert(i);
                }
            }
        }
        
        // remove corner
        vector<vector<int>> saved = points;
        int ans = INT_MAX;
        for(int remove : pointsWithMxDist) {
            points = saved;
            points.erase(points.begin() + remove);
            n = points.size();
            mnX = points[0][0], mxX = points[0][0];
            mnY = points[0][1], mxY = points[0][1];

            for(int i = 0; i < n; i++) {
                mnX = min(mnX, points[i][0]);
                mxX = max(mxX, points[i][0]);
                mnY = min(mnY, points[i][1]);
                mxY = max(mxY, points[i][1]);
            }

            corners = {{mnX, mnY}, {mxX, mnY}, {mnX, mxY}, {mxX, mxY}};

            closests.clear();
            for(auto c : corners) {
                int mnDist = INT_MAX;
                for(auto p : points)
                    mnDist = min(mnDist, manhattan(p, c));
                for(int i = 0; i < n; i++) {
                    if(manhattan(c, points[i]) == mnDist)
                        closests.insert(i);
                }
            }

            mxDist = 0;
            for(auto parentIdx : closests) {
                for(auto p : points)
                    mxDist = max(mxDist, manhattan(p, points[parentIdx]));
            }
            ans = min(ans, mxDist);
        }
        return ans;
    }
};