class Solution {
public:
    vector<int> maxdist(vector<vector<int>>& points, int skip) {
        int dist = INT_MIN, stor1 = INT_MIN, stor2 = INT_MIN, pt1, pt2;
        vector<int> res(3);
        for (int i = 0; i < points.size(); i++)
            if (i != skip) {
                if (stor1 != INT_MIN) {
                    int chk1 = points[i][0] - points[i][1], chk2 = points[i][0] + points[i][1];
                    if (chk1 + stor1 > dist) {
                        res = {pt1, i, chk1 + stor1};
                        dist = chk1 + stor1;
                    }
                    if (chk2 + stor2 > dist) {
                        res = {pt2, i, chk2 + stor2};
                        dist = chk2 + stor2;
                    }
                }
                if (-points[i][0] + points[i][1] > stor1) {
                    stor1 = -points[i][0] + points[i][1];
                    pt1 = i;
                }
                if (-points[i][0] - points[i][1] > stor2) {
                    stor2 = -points[i][0] - points[i][1];
                    pt2 = i;
                }
            }
        return res;
    }
    int minimumDistance(vector<vector<int>>& points) {
        sort(points.begin(), points.end());
        vector<int> pts = maxdist(points, -1);
        // cout << maxdist(points, pts[0])[2] << ' ' << maxdist(points, pts[1])[2] << '\n';
        return min(maxdist(points, pts[0])[2], maxdist(points, pts[1])[2]);
    }
};