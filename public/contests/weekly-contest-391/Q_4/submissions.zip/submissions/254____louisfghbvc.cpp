class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        // goal: find the minimum distance move exactly one point
        // idea:
        // enumerate the point
        // sort the point by x
        
        // [[3,10],[5,15],[10,2],[4,4]], ans=12
        // [3,10],[4,4],[5,15],[10,2]
        // D = |xi-xj| + |yi-yj|
        // => (xi-xj) + (yi-yj) => (xi+yi) - (xj+yj)
        // => -(xi-xj) + (yi-yj) => -(xi-yi) + (xj-yj)
        // => (xi-xj) + -(yi-yj) => (xi-yi) - (xj-yj)
        // => -(xi-xj) + -(yi-yj) => -(xi+yi) + (xj+yj)
        
        // only need to consider (xi-yi), (xi+yi)
        // idea: maintain a multiset
        
        multiset<int> dif1, dif2;
        for (auto &p : points) {
            dif1.insert(p[0]-p[1]);
            dif2.insert(p[0]+p[1]);
        }
        
        int ans = INT_MAX;
        for (auto &p: points) {
            dif1.erase(dif1.find(p[0]-p[1]));
            dif2.erase(dif2.find(p[0]+p[1]));
            ans = min(ans, max(*dif1.rbegin()-*dif1.begin(), *dif2.rbegin()-*dif2.begin()));
            dif1.insert(p[0]-p[1]);
            dif2.insert(p[0]+p[1]);
        }
        
        return ans;
    }
};