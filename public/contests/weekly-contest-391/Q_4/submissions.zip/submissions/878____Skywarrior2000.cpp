class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        multiset<int> mt1, mt2;
        int n = p.size();
        for(int i = 0; i < n; i++){
            int x = p[i][0], y = p[i][1];
            mt1.insert(x+y);
            mt2.insert(x-y);
        }
        
        int ans = INT_MAX;
        
        for(int i = 0; i < n; i++){
            int x = p[i][0], y = p[i][1];
            mt1.erase(mt1.find(x+y));
            mt2.erase(mt2.find(x-y));
            int r1 = (*(--mt1.end())) - (*mt1.begin());
            int r2 = (*(--mt2.end())) - (*mt2.begin());
            ans = min(ans, max(r1, r2));
            mt1.insert(x+y);
            mt2.insert(x-y);
        }
        return ans;
        
        
    }
};