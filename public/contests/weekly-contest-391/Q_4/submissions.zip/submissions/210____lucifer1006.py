class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        # Convert Manhattan distance to Chebyshev distance
        px = [(x + y, i) for i, (x, y) in enumerate(points)]
        py = [(x - y, i) for i, (x, y) in enumerate(points)]
        px.sort()
        py.sort()
        
        ans = 10 ** 9
        
        # Try eliminate one endpoint
        for i in [px[0][1], px[-1][1], py[0][1], py[-1][1]]:
            xl = 0
            if px[0][1] == i:
                xl = 1
            xr = len(px) - 1
            if px[-1][1] == i:
                xr = len(px) - 2
            
            yl = 0
            if py[0][1] == i:
                yl = 1
                
            yr = len(py) - 1
            if py[-1][1] == i:
                yr = len(py) - 2
                
            d = max(px[xr][0] - px[xl][0], py[yr][0] - py[yl][0])
            ans = min(ans, d)
        
        return ans