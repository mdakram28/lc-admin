class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        map<int,int>mpsum,mpdiff;
        for(int i=0;i<n;i++){
            int s1=points[i][0] + points[i][1];
            int s2=points[i][0] - points[i][1];
            mpsum[s1]++;
            mpdiff[s2]++;
        }
        int mn=INT_MAX;
        for(int i=0;i<n;i++){
            int curr_sum=points[i][0]+points[i][1];
            int curr_diff=points[i][0]-points[i][1];
            mpsum[curr_sum]--;
            if(mpsum[curr_sum]==0) mpsum.erase(curr_sum);
            mpdiff[curr_diff]--;
            if(mpdiff[curr_diff]==0) mpdiff.erase(curr_diff);
            
            auto mpsbg=mpsum.begin();
            auto mpsen=mpsum.end();
            mpsen--;
            
            auto mpdbg=mpdiff.begin();
            auto mpden=mpdiff.end();
            mpden--;
            
            int maximum=max((mpsen->first)-(mpsbg->first),(mpden->first)-(mpdbg->first));
            mn=min(mn,maximum);
            
            mpsum[curr_sum]++;
            mpdiff[curr_diff]++;
        }
        return mn;
    }
};