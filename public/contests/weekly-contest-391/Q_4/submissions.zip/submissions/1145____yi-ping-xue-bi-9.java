class Solution {
    public int minimumDistance(int[][] points) {
        int n=points.length;
        int max=Integer.MAX_VALUE,min=Integer.MIN_VALUE;
        int a=min,b=max,c=min,d=max;
        int index1=-1,index2=-1,index3=-1,index4=-1;
        for(int i=0;i<n;i++){
            int x=points[i][0],y=points[i][1];
            if(x+y>a){
                index1=i;
                a=x+y;
            }
            if(x+y<b){
                b=x+y;
                index2=i;
            }
            if(x-y>c){
                c=x-y;
                index3=i;
            }
            if(x-y<d){
                d=x-y;
                index4=i;
            }
        }
        // System.out.println(indx1+" "index2+" "index3+" "+index4);
        int ans1=Math.min(max(points,index1),max(points,index2));
        int ans2=Math.min(max(points,index3),max(points,index4));
        return Math.min(ans1,ans2);
        
    }
    public int max(int[][] points,int index){
        int n=points.length;
        int max=Integer.MAX_VALUE,min=Integer.MIN_VALUE;
        int a=min,b=max,c=min,d=max;
        for(int i=0;i<n;i++){
            if(i==index) continue;
            int x=points[i][0],y=points[i][1];
            a=Math.max(a,x+y);
            b=Math.min(b,x+y);
            c=Math.max(c,x-y);
            d=Math.min(d,x-y);
        }
        return Math.max(a-b,c-d);
    }
}