class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<vector<int>> v(n), v1(n);
        for(int i = 0; i < n; i++){
            v[i] = {points[i][0] + points[i][1], i};
            v1[i] = {points[i][0] - points[i][1], i};
        }
        ranges::sort(v);
        ranges::sort(v1);
        
        int m = INT_MAX;
        for(int i = 0; i < n; i++){
            int vf = v.front()[0], vb = v.back()[0] , v1f = v1.front()[0], v1b = v1.back()[0];
            if(v.front()[1] == i)vf = v[1][0];
            if(v.back()[1] == i)vb = v[n-2][0];
            if(v1.front()[1] == i)v1f = v1[1][0];
            if(v1.back()[1] == i)v1b = v1[n-2][0];
            
            m = min(m,max(vb-vf, v1b-v1f));
        }
        
        
        return m;
    }
};