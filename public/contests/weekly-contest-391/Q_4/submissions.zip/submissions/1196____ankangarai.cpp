class Solution {
public:
    int minimumDistance(vector<vector<int>>& v) {
        int n = v.size();
        vector <pair<int, int>> a(n), b(n);
        for(int i = 0; i<n; i++){
            a[i].first = v[i][0] + v[i][1]; a[i].second = i;
            b[i].first = v[i][0] - v[i][1]; b[i].second = i;
        }
        sort(a.begin(), a.end());
        sort(b.begin(), b.end());
        int curr = INT_MAX;
        for(int i = 0; i<n; i++){
            int x, y, ans = INT_MIN;
            if(a[0].second == i) ans = max(ans, a[n-1].first - a[1].first);
            else if(a[n-1].second == i) ans = max(ans, a[n-2].first - a[0].first);
            else ans = max(ans, a[n-1].first - a[0].first);
            if(b[0].second == i) ans = max(ans, b[n-1].first - b[1].first);
            else if(b[n-1].second == i) ans = max(ans, b[n-2].first - b[0].first);
            else ans = max(ans, b[n-1].first - b[0].first);
            curr = min(ans, curr);
        }
        return curr;
    }
};