class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        n = len(points)
        
        add, sub = [], []
        for i in range(n):
            x, y = points[i]
            add.append((x + y, i))
            sub.append((x - y, i))
            
        add.sort()
        sub.sort()
        
        cands = [add[-1][1], add[0][1], sub[-1][1], sub[0][1]]
        
        res = float('inf')
        for cand in cands:
            i, j = 0, n - 1
            if add[0][1] == cand:
                i += 1
            if add[-1][1] == cand:
                j -= 1
                
            a, b = 0, n - 1
            if sub[0][1] == cand:
                a += 1
            if sub[-1][1] == cand:
                b -= 1
                
            cur = max(add[j][0] - add[i][0], sub[b][0] - sub[a][0])
            res = min(res, cur)
        return res