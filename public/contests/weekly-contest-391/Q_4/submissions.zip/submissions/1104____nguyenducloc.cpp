class Solution {
   public:
    int minimumDistance(vector<vector<int>>& points) {
        map<int, int> mp1;
        map<int, int> mp2;
        for (auto& e : points) {
            mp1[e[0] + e[1]]++;
            mp2[e[0] - e[1]]++;
        }
        int ans = INT_MAX;
        for (auto& e : points) {
            int s1 = e[0] + e[1];
            int s2 = e[0] - e[1];
            if (!(--mp1[s1])) {
                mp1.erase(s1);
            }
            if (!(--mp2[s2])) {
                mp2.erase(s2);
            }
            ans = min(ans, max(mp1.rbegin()->first - mp1.begin()->first,
                               mp2.rbegin()->first - mp2.begin()->first));
            mp1[s1]++;
            mp2[s2]++;
        }
        return ans;
    }
};