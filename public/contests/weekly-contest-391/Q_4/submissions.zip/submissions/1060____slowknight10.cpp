#define lli long long int 
#define ld long double
#define vi vector<int>
#define vlli vector<lli>
#define vpii vector<pair<int, int>>
#define pb push_back 

template<typename T> void debug(T _a) {cout << _a << " ";}
template<typename T1, typename T2> void debug(pair<T1, T2> _p) {cout<<"{";debug(_p.first);cout<<": ";debug(_p.second);cout<<"}\n";}
template<typename T> void debug(vector<T> _aa) {for (auto h: _aa) debug(h); cout << endl;}
template<typename T> void debug(deque<T> _aa) {for (auto h: _aa) debug(h); cout << endl;}
template<typename T> void debug(multiset<T> _aa) {for (auto h: _aa) debug(h); cout << endl;}
template<typename T> void debug(multiset<T, greater<T>> _aa) {for (auto h: _aa) debug(h); cout << endl;}
template<typename T> void debug(set<T> _aa) {for (auto h: _aa) debug(h); cout << endl;}
template<typename T1, typename T2> void debug(map<T1, T2> _mm) {for (auto h: _mm) debug(h);}


class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        multiset<int> sx, sy;
        multiset<int, greater<int>> gx, gy;
        for (auto &i: p) {
            sx.insert(i[0]+i[1]);
            sy.insert(i[0]-i[1]);
            
            gx.insert(i[0]+i[1]);
            gy.insert(i[0]-i[1]);
        }
        
        
        int ans = INT_MAX;
        
        for (auto &i: p) {
            sx.erase(sx.find(i[0]+i[1]));
            sy.erase(sy.find(i[0]-i[1]));
            gx.erase(gx.find(i[0]+i[1]));
            gy.erase(gy.find(i[0]-i[1]));
            
            
            int xx = *gx.begin() - *sx.begin();
            int yy = *gy.begin() - *sy.begin();
            
//             debug(sx); debug(gx);
            
//             debug(sy); debug(gy);
//             cout << xx << " " << yy << endl;
//             cout << "=============\n";
            
            ans = min(ans, max(xx, yy));
            
            sx.insert(i[0]+i[1]);
            sy.insert(i[0]-i[1]);
            
            gx.insert(i[0]+i[1]);
            gy.insert(i[0]-i[1]);
            
            
        }
        return ans;
    }
};