typedef pair<int, int> PII;
class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        vector<vector<PII>> vec(4, vector<PII>(n));
        for (int i = 0; i < n; ++i) {
            vec[0][i] = make_pair(p[i][0] + p[i][1], i);
            vec[1][i] = make_pair(-p[i][0] + p[i][1], i);
            vec[2][i] = make_pair(p[i][0] - p[i][1], i);
            vec[3][i] = make_pair(-p[i][0] - p[i][1], i);
        }
        
        for (int i = 0; i < 4; ++i) sort(vec[i].begin(), vec[i].end());
        
        int ans = 200000000;
        for (int i = 0; i < n; ++i) {
            // remove i
            
            int res = 0;
            for (int j = 0; j < 4; ++j) {
                int l = 0;
                int r = n - 1;
                if (vec[j][0].second == i) l = 1;
                if (vec[j][n - 1].second == i) r = n - 2;
                res = max(res, vec[j][r].first - vec[j][l].first);
            }
            
            ans = min(ans, res);
        }
        
        return ans;
    }
};