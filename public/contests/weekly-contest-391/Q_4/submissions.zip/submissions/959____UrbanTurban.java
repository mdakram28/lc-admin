class Solution {
    public int minimumDistance(int[][] points) {
        
        int n=points.length;
        List<Pair> ls = new ArrayList<>();
        for(int i=0;i<n;++i)
        {
            ls.add(new Pair(points[i][0], points[i][1]));
        }
        
        long[] sum = new long[n];
        long[] diff = new long[n];
        for (int i = 0; i < n; i++) 
        {
            sum[i] = ls.get(i).x + ls.get(i).y;
            diff[i] = ls.get(i).x - ls.get(i).y;
        }
    
        // Arrays.sort(sum);
        // Arrays.sort(diff);
        
//         debugLong(sum);
//         debugLong(diff);
        
        MultiSet<Long> set1 = new MultiSet<>();
        MultiSet<Long> set2 = new MultiSet<>();
        
        for(int i=0;i<n;++i)
        {
            set1.add(sum[i]);
            set2.add(diff[i]);
        }
        
        int ans=Integer.MAX_VALUE;
        for(int i=0;i<n;++i)
        {
            long Sum = sum[i];
            long Diff = diff[i];
            
            set1.remove(Sum);
            set2.remove(Diff);
            
            long poss = Math.max(set1.last() - set1.first(), set2.last() - set2.first());
            ans = Math.min(ans, (int) poss);
            
            set1.add(Sum);
            set2.add(Diff);
            
        }
        
        return ans;
        
    }
    public void debugLong(long[] arr)
    {
        for(int i=0;i<arr.length;++i)
            System.out.print(arr[i]+" ");
        System.out.println();
    }
}
class Pair
{
    int x;
    int y;
    Pair(int X, int Y)
    {
        x = X;
        y = Y;
    }
    public String toString()
    {
        return x+","+y;
    }
}
class MultiSet<T> 
{
    private int size;
    TreeMap<T, Integer> map;

    public MultiSet(){
            size = 0;
            map = new TreeMap<>();
        }
        public int size(){return size;}
        public int dsize(){return map.size();}
        public boolean isEmpty(){return size==0;}
        public void add(T t){
            size++;
            map.put(t, map.getOrDefault(t, 0)+1);
        }
        public boolean remove(T t){ // single removal of occurence of element
            if(!map.containsKey(t))return false;
            size--;
            int c = map.get(t);
            if(c==1)map.remove(t);
            else map.put(t, c-1);
            return true;
        }
        public int freq(T t){return map.getOrDefault(t, 0);}
        public boolean contains(T t){return map.getOrDefault(t,0)>0;}
        public T ceiling(T t){return map.ceilingKey(t);}
        public T floor(T t){return map.floorKey(t);}
        public T first(){return map.firstKey();}
        public T last(){return map.lastKey();}
        
        public ArrayList<T> keySet()
        {
            ArrayList<T> list=new ArrayList<>();

            for(T key: map.keySet())
            {
                int cnt=map.get(key);
                while(cnt-->0)
                {
                    list.add(key);
                }
            }
            return list;
        }

        public String toString()
        {
            StringBuilder sb=new StringBuilder();
            for(T key: map.keySet())
            {
                int cnt=map.get(key);
                while(cnt-->0)
                {
                    sb.append(key+" ");
                }
            }
            return sb.toString();
        }
}