class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        
        n = len(points)
        xs = [x for x, y in points]
        ys = [y for x, y in points]
        xs.sort()
        ys.sort()
        corners = [(xs[0], ys[0]), (xs[0], ys[-1]), (xs[-1], ys[0]), (xs[-1], ys[-1])]
        
        indi = indj = None
        max_dis = 0
        
        for x, y in corners:
            dist = [(abs(x - px) + abs(y - py), i) for i,[px, py] in enumerate(points)]
            dist.sort()
            if dist[-1][0] - dist[0][0] > max_dis:
                max_dis = dist[-1][0] - dist[0][0]
                indi, indj = (dist[-1][1] , dist[0][1])
                
        res =float('inf')
        
        #remove i
        max_dis = 0
        for x, y in corners:
            dist = [(abs(x - px) + abs(y - py), ind) for ind,[px, py] in enumerate(points) if ind != indi]
            dist.sort()
            if dist[-1][0] - dist[0][0] > max_dis:
                max_dis =dist[-1][0] - dist[0][0]
        res = min(max_dis, res)
        max_dis = 0
        for x, y in corners:
            dist = [(abs(x - px) + abs(y - py), ind) for ind,[px, py] in enumerate(points) if ind != indj]
            dist.sort()
            if dist[-1][0] - dist[0][0] > max_dis:
                max_dis =dist[-1][0] - dist[0][0]
        res = min(max_dis, res)
        return res