class Solution {
public:
    int dist(vector<vector<int>>& points, int ignore) {
        int minSum = INT_MAX;
        int maxSum = INT_MIN;
        int minDiff = INT_MAX;
        int maxDiff = INT_MIN;
        
        for (int i = 0; i < points.size(); i++) {
            if (i == ignore) continue;
            auto& p = points[i];
            minSum = min(minSum, p[0] + p[1]);
            maxSum = max(maxSum, p[0] + p[1]);
            minDiff = min(minDiff, p[0] - p[1]);
            maxDiff = max(maxDiff, p[0] - p[1]);
        }
        return max(maxSum - minSum, maxDiff - minDiff);
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        // sort(points.begin(), points.end());
        
        
        int minSum = INT_MAX;
        int maxSum = INT_MIN;
        int minDiff = INT_MAX;
        int maxDiff = INT_MIN;
        
        for (int i = 0; i < points.size(); i++) {
            auto& p = points[i];
            minSum = min(minSum, p[0] + p[1]);
            maxSum = max(maxSum, p[0] + p[1]);
            minDiff = min(minDiff, p[0] - p[1]);
            maxDiff = max(maxDiff, p[0] - p[1]);
        }
        
        int o = INT_MAX;
        for (int i = 0; i < points.size(); i++) {
            auto& p = points[i];
            if (p[0] + p[1] == minSum || 
                p[0] + p[1] == maxSum || 
                p[0] - p[1] == minDiff || 
                p[0] - p[1] == maxDiff) {
                o = min(o, dist(points, i));
            }
        }
        
        return o;
    }
};