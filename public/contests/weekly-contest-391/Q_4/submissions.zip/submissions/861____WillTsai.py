class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        ll, lr, ul, ur = [], [], [], []
        
        for i, p in enumerate(points):
            heapq.heappush(ll, (-p[0]-p[1], i))
            if len(ll) >= 3:
                heapq.heappop(ll)
            heapq.heappush(lr, (-p[0]+p[1], i))
            if len(lr) >= 3:
                heapq.heappop(lr)
            heapq.heappush(ul, (p[0]-p[1], i))
            if len(ul) >= 3:
                heapq.heappop(ul)
            heapq.heappush(ur, (p[0]+p[1], i))
            if len(ur) >= 3:
                heapq.heappop(ur)
                
        
        ps = set()
        # print('ll', f"{[points[i] for _, i in ll]}")
        # print('lr', f"{[points[i] for _, i in lr]}")
        # print('ul', f"{[points[i] for _, i in ul]}")
        # print('ur', f"{[points[i] for _, i in ur]}")
        for _, i in ll:
            ps.add(i)
        for _, i in lr:
            ps.add(i)
        for _, i in ul:
            ps.add(i)
        for _, i in ur:
            ps.add(i)
        ps = list(ps)
        # print(ps)
        res = 1e10
        for rm in ps:
            r = 0
            for ii in ps:
                if ii == rm:
                    continue
                for jj in ps:
                    if ii == jj or jj == rm:
                        continue
                    r = max(r, abs(points[ii][0]-points[jj][0])+abs(points[ii][1]-points[jj][1]))
                    # print(points[ii], points[jj], abs(points[ii][0]-points[jj][0])+abs(points[ii][1]-points[jj][1]))
            # print(rm, r)
            res = min(res, r)
                
        return res