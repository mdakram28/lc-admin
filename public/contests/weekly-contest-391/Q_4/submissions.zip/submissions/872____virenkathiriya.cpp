class Solution {
public:
    long long f(vector<vector<int>>& points, int skip, int N) {
        long long minsum, maxsum, mindiff, maxdiff;

        if (skip != 0) {
            minsum = maxsum = points[0][0] * 1LL + points[0][1];
            mindiff = maxdiff = points[0][0] - points[0][1];
        } else {
            minsum = maxsum = points[1][0] * 1LL  + points[1][1];
            mindiff = maxdiff = points[1][0] * 1LL  - points[1][1];
        }
        for (int i = (skip == 0 ? 2: 1); i < N; i++) {
            if (i == skip) continue;
            int sum = points[i][0] * 1LL  + points[i][1];
            int diff = points[i][0] * 1LL - points[i][1];
            if (sum < minsum)
                minsum = sum;
            else if (sum > maxsum)
                maxsum = sum;
            if (diff < mindiff)
                mindiff = diff;
            else if (diff > maxdiff)
                maxdiff = diff;
        }

        return max(maxsum - minsum, maxdiff - mindiff);
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        long long n = points.size();
        vector<vector<long long>> diff(n), sum(n);
        for (int i = 0; i < n; i++) {
            sum[i] = {points[i][0] + points[i][1], i};
            diff[i] = {points[i][0] - points[i][1], i};
        }
        sort(sum.begin(), sum.end());
        sort(diff.begin(), diff.end());
        
        int sumMax = sum[n - 1][0] - sum[0][0];
        int diffMax = diff[n - 1][0] - diff[0][0];
        
        vector<long long> candidates;
        if (sumMax > diffMax) {
            candidates = {sum[n - 1][1], sum[0][1]};
        } else {
            candidates = {diff[n - 1][1], diff[0][1]};
        }
        long long ans = 1e15;
        ans = min(f(points, candidates[0], n), ans);
        ans = min(f(points, candidates[1], n), ans);
        return ans;
    }
};