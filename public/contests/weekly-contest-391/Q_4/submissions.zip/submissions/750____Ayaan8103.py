class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def distance(point1, point2):
            return abs(point1[0] - point2[0]) + abs(point1[1] - point2[1])
        
        n = len(points)
        sums = [[0, i] for i in range(n)]
        diffs = [[0, i] for i in range(n)]

        for i in range(n):
            sums[i][0] = points[i][0] + points[i][1]
            diffs[i][0] = points[i][0] - points[i][1]

        sums.sort()
        diffs.sort()

        res = float('inf')
        for i in range(n):
            a, b, c, d = sums[-1][0], sums[0][0], diffs[-1][0], diffs[0][0]
            if sums[-1][1] == i:
                a = sums[-2][0]
            if sums[0][1] == i:
                b = sums[1][0]
            if diffs[-1][1] == i:
                c = diffs[-2][0]
            if diffs[0][1] == i:
                d = diffs[1][0]

            max_dist = max(a - b, c - d)
            res = min(res, max_dist)
        return res
        