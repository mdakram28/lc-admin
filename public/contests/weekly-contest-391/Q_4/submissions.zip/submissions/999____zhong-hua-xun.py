class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        t1 = []
        t2 = []
        for i,(x,y) in  enumerate(points):
            t1.append((x-y,i))
            t2.append((x+y,i))
        t1.sort()
        t2.sort()
        ans = inf
        
        del1 = t1[0][1]
        l,r = 0,n-1
        if t2[l][1]==del1: 
            l+=1
        if t2[r][1]==del1: 
            r-=1
        cur = max(t1[-1][0]-t1[1][0], t2[r][0]-t2[l][0])
        ans = min(ans, cur)
        
        del2 = t1[-1][1]
        l,r = 0,n-1
        if t2[l][1]==del2: 
            l+=1
        if t2[r][1]==del2: 
            r-=1
        cur = max(t1[-2][0]-t1[0][0], t2[r][0]-t2[l][0])
        ans = min(ans, cur)
        
        del3 = t2[-1][1]
        l,r = 0,n-1
        if t1[l][1]==del3: 
            l+=1
        if t1[r][1]==del3: 
            r-=1
        cur = max(t1[r][0]-t1[l][0], t2[-2][0]-t2[0][0])
        ans = min(ans, cur)
        
        del4 = t2[0][1]
        l,r = 0,n-1
        if t1[l][1]==del4: 
            l+=1
        if t1[r][1]==del4: 
            r-=1
        cur = max(t1[r][0]-t1[l][0], t2[-1][0]-t2[1][0])
        ans = min(ans, cur)
        
        return ans
    