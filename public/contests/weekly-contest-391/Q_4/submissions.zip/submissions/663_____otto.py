from sortedcontainers import SortedList
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        # t1 = [x - y for x, y in points]
        # t2 = [x + y for x, y in points]
        # t1.sort()
        # t2.sort()
        # print(t1)
        # print(t2)
        # print(max(t1[-1] - t1[0], t2[-1] - t2[0]))
        # return min(
        #     max(t1[-1] - t1[1], t2[-1] - t2[1]),
        #     max(t1[-2] - t1[0], t2[-2] - t2[0]),
        # )
        
        t1 = []
        t2 = []
        for i in range(len(points)):
            t1.append((points[i][0] - points[i][1], i))
            t2.append((points[i][0] + points[i][1], i))
        sl1 = SortedList(t1)
        sl2 = SortedList(t2)
        ans = inf
        for i in range(len(points)):
            a = (points[i][0] - points[i][1], i)
            b = (points[i][0] + points[i][1], i)
            sl1.remove(a)
            sl2.remove(b)
            ans = min(max(sl1[-1][0] - sl1[0][0], sl2[-1][0] - sl2[0][0]), ans)
            sl1.add(a)
            sl2.add(b)
        return ans