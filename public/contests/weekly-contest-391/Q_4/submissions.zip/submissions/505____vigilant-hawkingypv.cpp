class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        const int INF = 0x3f3f3f3f;
        
        pair<int,int> addMax1 = {-1, -INF}, addMax2 = {-1, -INF};
        pair<int,int> addMin1 = {-1, INF}, addMin2 = {-1, INF};
        
        pair<int,int> delMax1 = {-1, -INF}, delMax2 = {-1, -INF};
        pair<int,int> delMin1 = {-1, INF}, delMin2 = {-1, INF};
        
        int n = points.size();
        for (int i = 0; i < n; ++ i) {
            int add = points[i][0] + points[i][1];
            int del = points[i][0] - points[i][1];
            
            if (add > addMax1.second) {
                addMax2 = addMax1;
                addMax1 = {i, add};
            } else if (add > addMax2.second) {
                addMax2 = {i, add};
            }
            
            if (add < addMin1.second) {
                addMin2 = addMin1;
                addMin1 = {i, add};
            } else if (add < addMin2.second) {
                addMin2 = {i, add};
            }
            
            if (del > delMax1.second) {
                delMax2 = delMax1;
                delMax1 = {i, del};
            } else if (del > delMax2.second) {
                delMax2 = {i, del};
            }
            
            if (del < delMin1.second) {
                delMin2 = delMin1;
                delMin1 = {i, del};
            } else if (del < delMin2.second) {
                delMin2 = {i, del};
            }
        }
        
        int ans = INF;
        for (int i = 0; i < n; ++ i) {
            int res1 = (addMax1.first != i ? addMax1.second : addMax2.second) - (addMin1.first != i ? addMin1.second : addMin2.second);
            int res2 = (delMax1.first != i ? delMax1.second : delMax2.second) - (delMin1.first != i ? delMin1.second : delMin2.second);
            ans = min(ans, max(res1, res2));
        }
        return ans;
    }
};