import java.util.Arrays;
import java.util.PriorityQueue;

class Solution {
    public int minimumDistance(int[][] points) {

        int n = points.length;
        Arrays.sort(points, (a, b) -> {
            return Integer.compare(a[0], b[0]);
        });


        int[] arr = f(points, -1);

        // System.out.println(Arrays.toString(arr));

        int max = arr[0];

        int[] cur = f(points, arr[1]);
        // System.out.println(Arrays.toString(cur));

        max = Math.min(max, cur[0]);

        cur = f(points, arr[2]);
        // System.out.println(Arrays.toString(cur));

        max = Math.min(max, cur[0]);

        return max;
    }

    int[] f(int[][] arr, int ignore) {
        PriorityQueue<int[]> pq1 = new PriorityQueue<>((a, b) -> {
            return Integer.compare(b[0], a[0]);
        });
        PriorityQueue<int[]> pq2 = new PriorityQueue<>((a, b) -> {
            return Integer.compare(b[0], a[0]);
        });
        int n = arr.length;

        int max = -1;
        int a = 0;
        int b = 0;

        // x2 - x1 + y1 - y2
        // x2 - y2        - x1 + y1

        // x2 - x1 + y2 - y1
        // x2 + y2        - x1 - y1

        for (int i = 0; i < arr.length; i++) {
            if (i == ignore) {
                continue;
            }

            if (!pq1.isEmpty()) {
                int[] cur1 = pq1.peek();
                int[] cur2 = pq2.peek();
                int x = arr[i][0];
                int y = arr[i][1];

                if (x - y + cur1[0] > max) {
                    max = x - y + cur1[0];
                    a = i;
                    b = cur1[1];
                }

                if (x + y + cur2[0] > max) {
                    max = x + y + cur2[0];
                    a = i;
                    b = cur2[1];
                }
            }

            pq1.offer(new int[]{arr[i][1] - arr[i][0], i});
            pq2.offer(new int[]{-arr[i][1] - arr[i][0], i});
        }

//        pq1.clear();
//        pq2.clear();
//
//        idx = n - 1;
//        if (ignore == n - 1) {
//            idx = n - 2;
//        }
//        // x1 - x2 + y1 - y2
//        // -x2 - y2        x1 + y1
//
//        // x1 - x2 + y2 - y1
//        // -x2 + y2        x1 - y1
//        pq1.offer(new int[]{arr[idx][1] + arr[idx][0], idx});
//        pq2.offer(new int[]{arr[idx][1] - arr[idx][0], idx});
//
//        for (int i = n - 1; i >= 0; i--) {
//            if (i == ignore) {
//                continue;
//            }
//
//            int[] cur1 = pq1.peek();
//            int[] cur2 = pq2.peek();
//            int x = arr[i][0];
//            int y = arr[i][1];
//
//            if (-x - y + cur1[0] > max) {
//                max = -x - y + cur1[0];
//                a = i;
//                b = cur1[1];
//            }
//
//            if (-x + y + cur2[0] > max) {
//                max = -x + y + cur2[0];
//                a = i;
//                b = cur2[1];
//            }
//
//            pq1.offer(new int[]{arr[i][1] + arr[i][0], i});
//            pq2.offer(new int[]{arr[i][1] - arr[i][0], i});
//
//        }

        return new int[]{max, a, b};
    }


}