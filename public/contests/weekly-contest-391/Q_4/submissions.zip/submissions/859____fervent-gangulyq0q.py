class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        points.sort()
        # a + b a - b
        min1,max1,min1id,max1id = float('inf'),-float('inf'),-1,-1
        min2,max2,min2id,max2id = float('inf'),-float('inf'),-1,-1
        for i in range(n):
            v1 = points[i][0] + points[i][1]
            if v1 < min1:
                min1 = v1
                min1id = i
            if v1 > max1:
                max1 = v1
                max1id = i
            v2 = points[i][0] - points[i][1]
            if v2 < min2:
                min2 = v2
                min2id = i
            if v2 > max2:
                max2 = v2
                max2id = i
        
        def cal(id):
            ans = 0
            min1,max1,min2,max2 = float('inf'),-float('inf'),float('inf'),-float('inf')
            for i in range(n):
                if i == id:
                    continue
                d = max(points[i][0] + points[i][1] - min1,points[i][0] - points[i][1] - min2,-points[i][0] + points[i][1] + max2,-points[i][0] - points[i][1] + max1)
                ans = max(ans,d)
                min1 = min(min1,points[i][0] + points[i][1])
                max1 = max(max1,points[i][0] + points[i][1])
                min2 = min(min2,points[i][0] - points[i][1])
                max2 = max(max2,points[i][0] - points[i][1])
            return ans
        return min(cal(min1id),cal(min2id),cal(max1id),cal(max2id))