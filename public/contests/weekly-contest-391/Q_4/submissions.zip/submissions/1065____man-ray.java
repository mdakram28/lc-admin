class Solution {
      public int minimumDistance(int[][] points) {
       int n = points.length;
        int[][] a = new int[n][2], b = new int[n][2];
        for (int i = 0; i < n; i++) {
            int x = points[i][0], y = points[i][1];
            a[i][0] = x + y;
            a[i][1] = i;
            b[i][0] = x - y;
            b[i][1] = i;
        }
        Arrays.sort(a, (o1, o2) -> o1[0] - o2[0]);
        Arrays.sort(b, (o1, o2) -> o1[0] - o2[0]);
        int ans = (int) 2e9;
        //a[0]
        int v1 = a[n - 1][0] - a[1][0];
        int u = a[0][1];
        int v2;
        if (u == b[0][1]) {
            v2 = b[n - 1][0] - b[1][0];
        } else if (u == b[n - 1][1]) {
            v2 = b[n - 2][0] - b[0][0];
        } else {
            v2 = b[n - 1][0] - b[0][0];
        }
        ans = Math.min(ans, Math.max(v1, v2));
        //a[n-1]
        v1 = a[n - 2][0] - a[0][0];
        u = a[n - 1][1];
        if (u == b[0][1]) {
            v2 = b[n - 1][0] - b[1][0];
        } else if (u == b[n - 1][1]) {
            v2 = b[n - 2][0] - b[0][0];
        } else {
            v2 = b[n - 1][0] - b[0][0];
        }
        ans = Math.min(ans, Math.max(v1, v2));
        //b[0]
        v1 = b[n - 2][0] - b[0][0];
        u = b[n - 1][1];
        if (u == a[0][1]) {
            v2 = a[n - 1][0] - a[1][0];
        } else if (u == a[n - 1][1]) {
            v2 = a[n - 2][0] - a[0][0];
        } else {
            v2 = a[n - 1][0] - a[0][0];
        }
        ans = Math.min(ans, Math.max(v1, v2));

        //b[0]
        v1 = b[n - 1][0] - b[1][0];
        u = b[0][1];
        if (u == a[0][1]) {
            v2 = a[n - 1][0] - a[1][0];
        } else if (u == a[n - 1][1]) {
            v2 = a[n - 2][0] - a[0][0];
        } else {
            v2 = a[n - 1][0] - a[0][0];
        }
        ans = Math.min(ans, Math.max(v1, v2));

        return ans;

    }

    int dis(int x1, int y1, int x2, int y2) {
        return Math.abs(x1 - x2) + Math.abs(y1 - y2);
    }
}