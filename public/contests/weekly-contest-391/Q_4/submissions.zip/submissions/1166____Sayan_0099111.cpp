#include <vector>
#include <set>
#include <utility>
#include <climits>
#include <algorithm>

using namespace std;

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<pair<int,int>> coordinates;
        multiset<int> sumDistances;
        multiset<int> diffDistances;
        initializeDistances(points, sumDistances, diffDistances);

        int minDistance = INT_MAX;
        int n = points.size();
        for(int i = 0; i < n; i++) {
            int currentSum = points[i][0] + points[i][1];
            int currentDiff = points[i][0] - points[i][1];
            updateDistances(sumDistances, diffDistances, currentSum, currentDiff);
            int currentDistance = computeMinimumDistance(sumDistances, diffDistances);
            minDistance = min(minDistance, currentDistance);
            restoreDistances(sumDistances, diffDistances, currentSum, currentDiff);
        }
        return minDistance;
    }

private:
    void initializeDistances(const vector<vector<int>>& points, multiset<int>& sumDistances, multiset<int>& diffDistances) {
        for(auto it : points) {
            sumDistances.insert(it[0] + it[1]);
            diffDistances.insert(it[0] - it[1]);
        }
    }

    void updateDistances(multiset<int>& sumDistances, multiset<int>& diffDistances, int currentSum, int currentDiff) {
        sumDistances.erase(sumDistances.find(currentSum));
        diffDistances.erase(diffDistances.find(currentDiff));
    }

    void restoreDistances(multiset<int>& sumDistances, multiset<int>& diffDistances, int currentSum, int currentDiff) {
        sumDistances.insert(currentSum);
        diffDistances.insert(currentDiff);
    }

    int computeMinimumDistance(const multiset<int>& sumDistances, const multiset<int>& diffDistances) {
        int maxSumDistance = *(sumDistances.rbegin()) - *(sumDistances.begin());
        int maxDiffDistance = *(diffDistances.rbegin()) - *(diffDistances.begin());
        return max(maxSumDistance, maxDiffDistance);
    }
}; 

