class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size(); int minDist = INT_MAX;
        map<int, int> sumcount, diffcount;
        for(int i=0; i<n; i++){
            int sum = points[i][0] + points[i][1];
            int diff = points[i][0] - points[i][1];
            sumcount[sum]++;
            diffcount[diff]++;
        }
        for(int i=0; i<n; i++){
            int sum = points[i][0] + points[i][1];
            int diff = points[i][0] - points[i][1];
            sumcount[sum]--;
            diffcount[diff]--;
            if(sumcount[sum] == 0) sumcount.erase(sum);
            if(diffcount[diff] == 0) diffcount.erase(diff);
            int maxsum = sumcount.rbegin()->first, minsum = sumcount.begin()->first;
            int maxdiff = diffcount.rbegin()->first, mindiff = diffcount.begin()->first;
            int maximum = max(maxsum - minsum, maxdiff - mindiff);
            minDist = min(minDist, maximum);
            sumcount[sum]++;
            diffcount[diff]++;
        }
        return minDist;
    }
};