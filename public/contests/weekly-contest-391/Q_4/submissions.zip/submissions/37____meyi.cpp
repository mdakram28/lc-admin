#pragma GCC optimize("Ofast,no-stack-protector,unroll-loops")
#define ALL(v) v.begin(),v.end()
#define For(i,_) for(int i=0,i##end=_;i<i##end;++i) // [0,_)
#define FOR(i,_,__) for(int i=_,i##end=__;i<i##end;++i) // [_,__)
#define Rep(i,_) for(int i=(_)-1;i>=0;--i) // [0,_)
#define REP(i,_,__) for(int i=(__)-1,i##end=_;i>=i##end;--i) // [_,__)
typedef long long ll;
typedef unsigned long long ull;
#define V vector
#define pb push_back
#define pf push_front
#define qb pop_back
#define qf pop_front
#define eb emplace_back
typedef pair<int,int> pii;
typedef pair<ll,int> pli;
#define fi first
#define se second
const int dir[4][2]={{-1,0},{0,1},{1,0},{0,-1}},inf=0x3f3f3f3f,mod=1e9+7;
const ll infl=0x3f3f3f3f3f3f3f3fll;
template<class T>inline bool ckmin(T &x,const T &y){return x>y?x=y,1:0;}
template<class T>inline bool ckmax(T &x,const T &y){return x<y?x=y,1:0;}
int init=[](){return cin.tie(nullptr)->sync_with_stdio(false),0;}();
class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n=p.size();
        V<int>x(n),y(n);
        For(i,n)x[i]=p[i][0]+p[i][1],y[i]=p[i][0]-p[i][1];
        V<int>idx(n),idy(n);
        iota(ALL(idx),0),iota(ALL(idy),0);
        sort(ALL(idx),[&](int u,int v){return x[u]<x[v];}),sort(ALL(idy),[&](int u,int v){return y[u]<y[v];});
        int ret=INT_MAX;
        For(i,n)ckmin(ret,max((idx[n-1]==i?x[idx[n-2]]:x[idx[n-1]])-(idx[0]==i?x[idx[1]]:x[idx[0]]),(idy[n-1]==i?y[idy[n-2]]:y[idy[n-1]])-(idy[0]==i?y[idy[1]]:y[idy[0]])));
        return ret;
    }
};