class Solution {
public:
    int helper(const vector<pair<int, int>> &sums, const vector<pair<int, int>> &diffs, int idx, const int &n){
        int sl = sums[0].second == idx ? sums[1].first : sums[0].first;
        int sr = sums[n-1].second == idx ? sums[n-2].first : sums[n-1].first;
        int dl = diffs[0].second == idx ? diffs[1].first : diffs[0].first;
        int dr = diffs[n-1].second == idx ? diffs[n-2].first : diffs[n-1].first;
        return max(sr - sl, dr - dl);
    }
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<pair<int, int>> sums, diffs;
        for(int i = 0; i < n; ++i){
            sums.emplace_back(points[i][0] + points[i][1], i);
            diffs.emplace_back(points[i][0] - points[i][1], i);
        }
        sort(sums.begin(), sums.end());
        sort(diffs.begin(), diffs.end());
        
        int res = helper(sums, diffs, sums[0].second, n);
        res = min(res, helper(sums, diffs, sums[n-1].second, n));
        res = min(res, helper(sums, diffs, diffs[0].second, n));
        res = min(res, helper(sums, diffs, diffs[n-1].second, n));
                  
        // printf("%d %d %d %d\n", sums[0], sums[1], sums[n-2], sums[n-1]);
        // int res1 = min(sums[n-2] - sums[0], sums[n-1] - sums[1]);
        // int res2 = min(diffs[n-2] - diffs[0], diffs[n-1] - diffs[1]);
        // int res3 = max(sums.back() - sums.front(), diffs.back() - diffs.front());
        // printf("%d %d %d %d\n", diffs[0], diffs[1], diffs[n-2], diffs[n-1]);
        // printf("%d %d %d\n", res1, res2, res3);
        return res;
    }
};