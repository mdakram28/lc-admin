class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<map<int,int>>s(2);
        for(auto i:points){
            s[0][i[0]+i[1]]++;
            s[1][i[0]-i[1]]++;
        }
        
        int ans=INT_MAX;
        for(auto i:points){
            s[0][i[0]+i[1]]--;
            if(s[0][i[0]+i[1]]==0) s[0].erase(i[0]+i[1]);
            s[1][i[0]-i[1]]--;
            if(s[1][i[0]-i[1]]==0) s[1].erase(i[0]-i[1]);
            int cur=0;

            auto it1=s[0].begin();
            auto it2=--s[0].end();
            cur=max(cur,abs(it1->first-it2->first));
            
            auto it3=s[1].begin();
            auto it4=--s[1].end();
                        cur=max(cur,abs(it3->first-it4->first));
           ans=min(cur,ans);
            
            
            s[0][i[0]+i[1]]++;
            s[1][i[0]-i[1]]++;
        }
        return ans;
    }
};