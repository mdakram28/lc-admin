class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        points.sort()
        max1 = -inf
        max2 = -inf
        min1 = inf
        min2 = inf
        m = 0
        p = 0
        # print(points)
        for i, (x, y) in enumerate(points):
            max1 = max(max1, x + y)
            max2 = max(max2, x - y)
            min1 = min(min1, x + y)
            min2 = min(min2, x - y)
            # print("max1 - min1: " + str(max1 - min1))
            # print("max2 - min2: " + str(max2 - min2))
            c = max(max1 - min1, max2 - min2)
            if m < c:
                p = i
                m = c
        a, b = points[p]
        q = 0
        for i in range(n):
            if abs(a - points[i][0]) + abs(b - points[i][1]) == m:
                q = i
                break
        # print(p, q)
        max1 = -inf
        max2 = -inf
        min1 = inf
        min2 = inf
        cur = points[:p] + points[p + 1:]
        m1 = 0
        for x, y in cur:
            max1 = max(max1, x + y)
            max2 = max(max2, x - y)
            min1 = min(min1, x + y)
            min2 = min(min2, x - y)
            c = max(max1 - min1, max2 - min2)
            # print(c)
            if m1 < c:
                m1 = c
        max1 = -inf
        max2 = -inf
        min1 = inf
        min2 = inf
        cur = points[:q] + points[q + 1:]
        m2 = 0
        for x, y in cur:
            max1 = max(max1, x + y)
            max2 = max(max2, x - y)
            min1 = min(min1, x + y)
            min2 = min(min2, x - y)
            c = max(max1 - min1, max2 - min2)
            # print("max1 - min1: " + str(max1 - min1))
            # print("max2 - min2: " + str(max2 - min2))
            # print(c)
            if m2 < c:
                m2 = c
        return min(m1, m2)
        # for i in range(n):
        #     cur = points[:i] + points[i + 1:]
        #     max1 = -inf
        #     max2 = -inf
        #     min1 = inf
        #     min2 = inf
        #     print(cur)
        #     for x, y in cur:
        #         max1 = max(max1, x + y)
        #         max2 = max(max2, x - y)
        #         min1 = min(min1, x + y)
        #         min2 = min(min2, x - y)
        #         print("max1 - min1: " + str(max1 - min1))
        #         print("max2 - min2: " + str(max2 - min2))