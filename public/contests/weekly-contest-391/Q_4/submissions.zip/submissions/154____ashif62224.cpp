class Solution {
public:
    int minimumDistance(vector<vector<int>>& arr) {
        int ans=INT_MAX;
        multiset<int>a,b;
        for(auto &i:arr){
            a.emplace(i[0]+i[1]);
            b.emplace(i[0]-i[1]);
        }
        for(auto &i:arr){
            a.erase(a.find(i[0]+i[1]));
            b.erase(b.find(i[0]-i[1]));
            int cur=max(*a.rbegin() - *a.begin(), *b.rbegin() - *b.begin());
            ans=min(ans,cur);
            a.emplace(i[0]+i[1]);
            b.emplace(i[0]-i[1]);
        }
        return ans;
    }
};