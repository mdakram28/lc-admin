class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        vector<pair<int,int>> sums(n),dif(n);
        for(int i=0;i<n;i++)
        {
            sums[i]={points[i][0]+points[i][1],i};
            dif[i]={points[i][0]-points[i][1],i};
        }
        sort(sums.begin(),sums.end());
        sort(dif.begin(),dif.end());
        int ans=INT_MAX;
        for(int i=0;i<n;i++)
        {
            int idx1i=0,idx1j=n-1,idx2i=0,idx2j=n-1;
            if(sums[0].second==i) idx1i++;
            if(dif[0].second==i) idx2i++;
            if(sums[n-1].second==i) idx1j--;
            if(dif[n-1].second==i) idx2j--;
            ans=min(ans,max(sums[idx1j].first-sums[idx1i].first,dif[idx2j].first-dif[idx2i].first));
        }
        return ans;
    }
};