class Solution {
public:
    int findMin(vector<pair<long long, long long>>&diff, vector<pair<long long, long long>>&sum, long long i, long long minDistance) {
        #define int long long
        int n = diff.size();
        // int minDistance = 1e18;
        /* last of diff */
        // int i = diff[n - 1].second;
        int i1 = 0, i2 = n - 1, j1 = 0, j2 = n - 1;
        if(diff[i1].second == i) {
            i1 = i1 + 1;
        }
        if(diff[i2].second == i) {
            i2 = i2 - 1;
        }
        if(sum[j1].second == i) {
            j1 = j1 + 1;
        }
        if(sum[j2].second == i) {
            j2 = j2 - 1;
        }
        // vector<int>x = {minDistance, diff[i2].first - diff[i1].first, sum[j2].first - sum[j1].first};
        // for(auto z : x)cout<<z<<" ";
        // cout<<endl;
        minDistance = min(minDistance, (max(diff[i2].first - diff[i1].first, sum[j2].first - sum[j1].first)));
        
        #undef int
        return minDistance;
        
    }
    int minimumDistance(vector<vector<int>>& points) {
        #define int long long
        vector<pair<int, int>>diff;
        vector<pair<int, int>>sum;
        int n = points.size();
        for(int i = 0; i < n; i++) {
            int a = points[i][0];
            int b = points[i][1];
            diff.push_back({a - b, i});
            sum.push_back({a + b, i});
        }
        sort(diff.begin(), diff.end());
        sort(sum.begin(), sum.end());
        
        int minDistance = 1e18;
        /* try all four points */
        minDistance = findMin(diff, sum, diff[n - 1].second, minDistance);
        minDistance = findMin(diff, sum, diff[0].second, minDistance);
        minDistance = findMin(diff, sum, sum[0].second, minDistance);
        minDistance = findMin(diff, sum, sum[n - 1].second, minDistance);
        
        
        #undef int
        return minDistance;
            
    }
};