class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int length = points.size();            
        multiset<int> sum, diff;

        
        for(int i = 0; i < length; i++){
            sum.insert(points[i][0] + points[i][1]);
            diff.insert(points[i][0] - points[i][1]);
        }
        
        int distance = 0;
        int pointSum, pointDiff;
        int result = INT_MAX;
        
        for(int i = 0; i < length; i++){
            pointSum = points[i][0] + points[i][1];
            pointDiff = points[i][0] - points[i][1];
            
            auto it1 = sum.find(pointSum);
            sum.erase(it1);
            
            auto it2 = diff.find(pointDiff);
            diff.erase(it2);
            
            distance = max(*(--sum.end()) - *sum.begin(), *(--diff.end()) - *diff.begin());
            
            result = min(result, distance);
            
            sum.insert(pointSum);
            diff.insert(pointDiff);
        }
        
        return result;
    }
};