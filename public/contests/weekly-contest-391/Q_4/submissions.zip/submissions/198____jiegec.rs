impl Solution {
    pub fn minimum_distance(points: Vec<Vec<i32>>) -> i32 {
        let mut sums = vec![];
        let mut subs = vec![];
        for point in &points {
            sums.push(point[0] + point[1]);
            subs.push(point[0] - point[1]);
        }

        let mut max_sum_i = 0;
        for i in 0..sums.len() {
            if sums[i] > sums[max_sum_i] {
                max_sum_i = i;
            }
        }

        let mut min_sum_i = 0;
        for i in 0..sums.len() {
            if sums[i] < sums[min_sum_i] {
                min_sum_i = i;
            }
        }

        let mut max_sub_i = 0;
        for i in 0..subs.len() {
            if subs[i] > subs[max_sub_i] {
                max_sub_i = i;
            }
        }

        let mut min_sub_i = 0;
        for i in 0..subs.len() {
            if subs[i] < subs[min_sub_i] {
                min_sub_i = i;
            }
        }

        let mut res = None;
        for i in [max_sum_i, min_sum_i, max_sub_i, min_sub_i] {
            let mut new_max_sum = None;
            for j in 0..sums.len() {
                if j != i && (new_max_sum.is_none() || new_max_sum.unwrap() < sums[j]) {
                    new_max_sum = Some(sums[j]);
                }
            }

            let mut new_min_sum = None;
            for j in 0..sums.len() {
                if j != i && (new_min_sum.is_none() || new_min_sum.unwrap() > sums[j]) {
                    new_min_sum = Some(sums[j]);
                }
            }

            let mut new_max_sub = None;
            for j in 0..subs.len() {
                if j != i && (new_max_sub.is_none() || new_max_sub.unwrap() < subs[j]) {
                    new_max_sub = Some(subs[j]);
                }
            }

            let mut new_min_sub = None;
            for j in 0..subs.len() {
                if j != i && (new_min_sub.is_none() || new_min_sub.unwrap() > subs[j]) {
                    new_min_sub = Some(subs[j]);
                }
            }

            let new_res = std::cmp::max(
                new_max_sum.unwrap() - new_min_sum.unwrap(),
                new_max_sub.unwrap() - new_min_sub.unwrap(),
            );
            if res.is_none() || res.unwrap() > new_res {
                res = Some(new_res);
            }
        }

        res.unwrap()
    }
}
