class Solution {
#define ll long long
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        multiset<ll> sum,diff;
        
        for(int i=0;i<n;i++){
            int xCord = points[i][0];
            int yCord = points[i][1];
            sum.insert(xCord+yCord);
            diff.insert(xCord-yCord);
        }
        
        ll ans = 1e9;
        for(int i=0;i<n;i++){
            int xCord = points[i][0];
            int yCord = points[i][1];
            ll SUM = xCord + yCord;
            ll DIFF = xCord - yCord;
            sum.erase(sum.find(SUM));
            diff.erase(diff.find(DIFF));
            ll val1 = *sum.rbegin()- *sum.begin();
            ll val2 = *diff.rbegin() - *diff.begin();
            ans=min(ans,max(val1,val2));
            sum.insert(SUM);
            diff.insert(DIFF);
        }
        
        return ans;
    }
};