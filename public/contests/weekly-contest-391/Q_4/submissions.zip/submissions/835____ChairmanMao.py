class Solution(object):
    def minimumDistance(self, A):
        """
        :type points: List[List[int]]
        :rtype: int
        """
        N = len(A)
        V = [0 for i in range(N)]
        V1 = [0 for i in range(N)]

        for i in range(N):
            V[i] = (A[i][0] + A[i][1], i)
            V1[i] = (A[i][0] - A[i][1], i)

        # Sorting both the vectors
        V.sort()
        V1.sort()
        
        print V
        print V1
        
        

        res = max(V[-1][0] - V[0][0], V1[-1][0] - V1[0][0])
        i = V[0][1]
        if V1[-1][1] == i:
            res = min(res, max(V[-1][0] - V[1][0], V1[-2][0] - V1[0][0]))
        elif V1[0][1] == i:
            res = min(res, max(V[-1][0] - V[1][0], V1[-1][0] - V1[1][0]))
        else:
            res = min(res, max(V[-1][0] - V[1][0], V1[-1][0] - V1[0][0]))
            
        i = V[-1][1]
        if V1[-1][1] == i:
            res = min(res, max(V[-2][0] - V[0][0], V1[-2][0] - V1[0][0]))
        elif V1[0][1] == i:
            res = min(res, max(V[-2][0] - V[0][0], V1[-1][0] - V1[1][0]))
        else:
            res = min(res, max(V[-2][0] - V[0][0], V1[-1][0] - V1[0][0]))
            
        i = V1[0][1]
        if V[-1][1] == i:
            res = min(res, max(V1[-1][0] - V1[1][0], V[-2][0] - V[0][0]))
        elif V[0][1] == i:
            res = min(res, max(V1[-1][0] - V1[1][0], V[-1][0] - V[1][0]))
        else:
            res = min(res, max(V1[-1][0] - V1[1][0], V[-1][0] - V[0][0]))
            
            
        i = V1[-1][1]
        if V[-1][1] == i:
            res = min(res, max(V1[-2][0] - V1[0][0], V[-2][0] - V[0][0]))
        elif V[0][1] == i:
            res = min(res, max(V1[-2][0] - V1[0][0], V[-1][0] - V[1][0]))
        else:
            res = min(res, max(V1[-2][0] - V1[0][0], V[-1][0] - V[0][0]))
            
        return res