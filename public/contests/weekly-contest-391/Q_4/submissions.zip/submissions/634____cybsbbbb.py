class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        
        idx_list = list(range(n))
        candidates = set()
        candidates.add(max(idx_list, key=lambda i: [points[i][0], points[i][1]]))
        candidates.add(max(idx_list, key=lambda i: [points[i][0], -points[i][1]]))
        candidates.add(max(idx_list, key=lambda i: [-points[i][0], points[i][1]]))
        candidates.add(max(idx_list, key=lambda i: [-points[i][0], -points[i][1]]))
        candidates.add(max(idx_list, key=lambda i: [points[i][1], points[i][0]]))
        candidates.add(max(idx_list, key=lambda i: [points[i][1], -points[i][0]]))
        candidates.add(max(idx_list, key=lambda i: [-points[i][1], points[i][0]]))
        candidates.add(max(idx_list, key=lambda i: [-points[i][1], -points[i][0]]))
        candidates.add(max(idx_list, key=lambda i: points[i][1] + points[i][0]))
        candidates.add(max(idx_list, key=lambda i: points[i][1] - points[i][0]))
        candidates.add(max(idx_list, key=lambda i: -points[i][1] + points[i][0]))
        candidates.add(max(idx_list, key=lambda i: -points[i][1] - points[i][0]))

        def dist(i, j):
            return abs(points[i][0] - points[j][0]) + abs(points[i][1] - points[j][1])
        
        def helper(idx):
            idx_list = list(range(idx)) + list(range(idx + 1, n))
            candidates = set()
            candidates.add(max(idx_list, key=lambda i: [points[i][0], points[i][1]]))
            candidates.add(max(idx_list, key=lambda i: [points[i][0], -points[i][1]]))
            candidates.add(max(idx_list, key=lambda i: [-points[i][0], points[i][1]]))
            candidates.add(max(idx_list, key=lambda i: [-points[i][0], -points[i][1]]))
            candidates.add(max(idx_list, key=lambda i: [points[i][1], points[i][0]]))
            candidates.add(max(idx_list, key=lambda i: [points[i][1], -points[i][0]]))
            candidates.add(max(idx_list, key=lambda i: [-points[i][1], points[i][0]]))
            candidates.add(max(idx_list, key=lambda i: [-points[i][1], -points[i][0]]))
            candidates.add(max(idx_list, key=lambda i: points[i][1] + points[i][0]))
            candidates.add(max(idx_list, key=lambda i: points[i][1] - points[i][0]))
            candidates.add(max(idx_list, key=lambda i: -points[i][1] + points[i][0]))
            candidates.add(max(idx_list, key=lambda i: -points[i][1] - points[i][0]))
            
            ans = 0
            candidate_list = list(candidates)
            for i in range(len(candidate_list)):
                for j in range(i + 1, len(candidate_list)):
                    ans = max(ans, dist(candidate_list[i], candidate_list[j]))
            return ans
        
        return min(helper(candidate) for candidate in candidates)
        
        