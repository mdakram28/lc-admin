class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> v, v1;
        int n = points.size();
        for(int i = 0; i < n; i++){
            v.insert(points[i][0] + points[i][1]);
            v1.insert(points[i][0] - points[i][1]);
        }
        
        
        int ans = INT_MAX;
//         cout << *v.begin() << " " << *(--v.end()) << endl;
//         cout << *v1.begin() << " " << *v1.end() << endl;
        
        for(int i = 0; i < n; i++){
            int sm1 = points[i][0] + points[i][1];
            int sm2 = points[i][0] - points[i][1];
            auto it1 = v.find(sm1);
            v.erase(it1);
            auto it2 = v1.find(sm2);
            v1.erase(it2);
            int dist = max(*(--v.end()) - *v.begin(), *(--v1.end()) - *v1.begin());
            
            ans = min(ans, dist);
            v.insert(sm1);
            v1.insert(sm2);
        }
        return ans;
    }
};