class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        priority_queue<vector<int>> xpy , xmy;
        priority_queue<vector<int> , vector<vector<int>>,greater<vector<int>>> mxpy,mxmy;
        int n = points.size();
        int p,q,r,s;
        vector<int> t1,t2,t3,t4;
        int ans = INT_MAX;
        for(int i = 0;i<n;i++)
        {
            xpy.push({points[i][0] + points[i][1],i});
            xmy.push({points[i][0] - points[i][1],i});
            mxpy.push({points[i][0] + points[i][1],i});
            mxmy.push({points[i][0] - points[i][1],i});
        }
        for(int i = 0;i<n;i++)
        {
            if(xpy.top()[1] == i)
            {
                t1 = xpy.top();
                xpy.pop();
                p = xpy.top()[1];
                xpy.push(t1);
            }
            else
                p = xpy.top()[1];
            
            if(xmy.top()[1] == i)
            {
                t2 = xmy.top();
                xmy.pop();
                r = xmy.top()[1];
                xmy.push(t2);
            }
            else
                r = xmy.top()[1];
            
            
             if(mxpy.top()[1] == i)
            {
                t3 = mxpy.top();
                mxpy.pop();
                q = mxpy.top()[1];
                mxpy.push(t3);
            }
            else
                q = mxpy.top()[1];
            
            if(mxmy.top()[1] == i)
            {
                t4 = mxmy.top();
                mxmy.pop();
                s = mxmy.top()[1];
                mxmy.push(t4);
            }
            else
                s = mxmy.top()[1];
            
            
            ans = min(ans,max((points[p][0] + points[p][1])-(points[q][0] + points[q][1]),(points[r][0] - points[r][1])-(points[s][0] - points[s][1])));
        }
        return ans;
    }
};