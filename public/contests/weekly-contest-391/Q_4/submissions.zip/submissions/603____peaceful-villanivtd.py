def MaxDist2(A, N):
    V = [0 for i in range(N)]
    V1 = [0 for i in range(N)]

    for i in range(N):
        V[i] = A[i][0] + A[i][1]
        V1[i] = A[i][0] - A[i][1]

    V.sort()
    V1.sort()

    maximum = max(V[-1] - V[0],
                  V1[-1] - V1[0])

    return maximum


def MaxDist(A, N):
    V = [[0, 0] for i in range(N)]
    V1 = [[0, 0] for i in range(N)]

    for i in range(N):
        V[i] = [A[i][0] + A[i][1], i]
        V1[i] = [A[i][0] - A[i][1], i]

    V.sort()
    V1.sort()

    
    i, j = V[-1][1], V[0][1]
    X1 = A[:i] + A[(i + 1):]
    X2 = A[:j] + A[(j + 1):]
    c1 = min(MaxDist2(X1, N - 1), MaxDist2(X2, N - 1))
    
    i, j = V1[-1][1], V1[0][1]
    X1 = A[:i] + A[(i + 1):]
    X2 = A[:j] + A[(j + 1):]
    c2 =  min(MaxDist2(X1, N - 1), MaxDist2(X2, N - 1))
    return min(c1,c2)


class Solution:

    def minimumDistance(self, points: List[List[int]]) -> int:
        return MaxDist(points, len(points))