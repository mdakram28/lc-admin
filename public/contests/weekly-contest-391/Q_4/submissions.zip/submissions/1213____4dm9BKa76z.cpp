class Solution {
public:
    #define debug(x) cout<<#x<<" = "<<x<<'\n'
    int minimumDistance(vector<vector<int>>& p) {
        int mx=-1,tmx=-1;
        int to1,to2;
        int mn0=1e9+7,mn1=1e9+7,mn2=1e9+7,mn3=1e9+7;
        int p0=1e9+7,p1=1e9+7,p2=1e9+7,p3=1e9+7;
        for(int i=0;i<p.size();i++){
            int x,t=-1;
            int tmn0=mn0,tmn1=mn1,tmn2=mn2,tmn3=mn3;
            int tp0=p0,tp1=p1,tp2=p2,tp3=p3;
            int top;
            x=p[i][0]+p[i][1];
            if(t<x-mn0)top=p0;
            t=max(t,x-mn0);
            if(x<tmn0)tp0=i;
            tmn0=min(tmn0,x);
            x=p[i][0]-p[i][1];
            if(t<x-mn1)top=p1;
            t=max(t,x-mn1);
            if(x<tmn1)tp1=i;
            tmn1=min(tmn1,x);
            x=-p[i][0]+p[i][1];
            if(t<x-mn2)top=p2;
            t=max(t,x-mn2);
            if(x<tmn2)tp2=i;
            tmn2=min(tmn2,x);
            x=-p[i][0]-p[i][1];
            if(t<x-mn3)top=p3;
            t=max(t,x-mn3);
            if(x<tmn3)tp3=i;
            tmn3=min(tmn3,x);
            
            if(t>=mx)tmx=mx,mx=t,to1=i,to2=top;
            else if(t>tmx)tmx=t;
            mn0=tmn0;
            mn1=tmn1;
            mn2=tmn2;
            mn3=tmn3;
            p0=tp0;
            p1=tp1;
            p2=tp2;
            p3=tp3;
        }
        // cout<<mx<<' '<<tmx<<'\n';
        mx=-1,tmx=-1;
        mn0=1e9+7,mn1=1e9+7,mn2=1e9+7,mn3=1e9+7;
        for(int i=0;i<p.size();i++){
            if(i==to1)continue;
            int x,t=-1;
            int tmn0=mn0,tmn1=mn1,tmn2=mn2,tmn3=mn3;
            x=p[i][0]+p[i][1];
            t=max(t,x-mn0);
            tmn0=min(tmn0,x);
            x=p[i][0]-p[i][1];
            t=max(t,x-mn1);
            tmn1=min(tmn1,x);
            x=-p[i][0]+p[i][1];
            t=max(t,x-mn2);
            tmn2=min(tmn2,x);
            x=-p[i][0]-p[i][1];
            t=max(t,x-mn3);
            tmn3=min(tmn3,x);
            
            if(t>=mx)tmx=mx,mx=t;
            else if(t>tmx)tmx=t;
            mn0=tmn0;
            mn1=tmn1;
            mn2=tmn2;
            mn3=tmn3;
        }
        int ans=mx;
        mx=-1,tmx=-1;
        mn0=1e9+7,mn1=1e9+7,mn2=1e9+7,mn3=1e9+7;
        for(int i=0;i<p.size();i++){
            if(i==to2)continue;
            int x,t=-1;
            int tmn0=mn0,tmn1=mn1,tmn2=mn2,tmn3=mn3;
            x=p[i][0]+p[i][1];
            t=max(t,x-mn0);
            tmn0=min(tmn0,x);
            x=p[i][0]-p[i][1];
            t=max(t,x-mn1);
            tmn1=min(tmn1,x);
            x=-p[i][0]+p[i][1];
            t=max(t,x-mn2);
            tmn2=min(tmn2,x);
            x=-p[i][0]-p[i][1];
            t=max(t,x-mn3);
            tmn3=min(tmn3,x);
            
            if(t>=mx)tmx=mx,mx=t;
            else if(t>tmx)tmx=t;
            mn0=tmn0;
            mn1=tmn1;
            mn2=tmn2;
            mn3=tmn3;
        }
        ans=min(ans,mx);
        
        return ans;
    }
};
/*

[[3,10],[5,15],[10,2],[4,4]]
[[1,1],[1,1],[1,1]]
[[3,2],[3,9],[7,10],[4,4],[8,10],[2,7]]
*/