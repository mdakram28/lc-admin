class Solution {
public:
    int minimumDistance(vector<vector<int>>& po) {
        
        auto cal = [](vector<vector<int>>pp, int &p1, int &p2) {
            int n = pp.size();
            vector<vector<pair<int,int>>>p(4, vector<pair<int,int>>(n));
            for(int i = 0; i < n; i ++){
               p[0][i].first = + pp[i][0] + pp[i][1];
               p[1][i].first = + pp[i][0] - pp[i][1];
               p[2][i].first = - pp[i][0] + pp[i][1];
               p[3][i].first = - pp[i][0] - pp[i][1];
               p[0][i].second = i;
               p[1][i].second = i;
               p[2][i].second = i;
               p[3][i].second = i;
            }
            for(int i = 0; i < 4; i ++)sort(p[i].begin(), p[i].end());
            int maxv = 0;
            for(int i = 0; i < 4; i ++) {
                if(maxv < p[i].back().first - p[i].front().first)
                {
                    maxv = p[i].back().first - p[i].front().first;
                    p1 = p[i].back().second, p2 = p[i].front().second;
                }
            }
            return maxv;
        };
        int p1 = -1, p2 = -1;
        cal(po,p1, p2);
        
        
        vector<vector<int>> pos1;
        for(int i = 0; i < po.size(); i ++){
            if(i == p1) continue;
            pos1.push_back(po[i]);
        }
        int p3, p4;
        int ans1 = cal(pos1, p3, p4);
        vector<vector<int>> pos2;
        for(int i = 0; i < po.size(); i ++){
            if(i == p2) continue;
            pos2.push_back(po[i]);
        }
        int ans2 = cal(pos2, p3, p4);
        return min(ans1, ans2);
        return 0;
    }
};