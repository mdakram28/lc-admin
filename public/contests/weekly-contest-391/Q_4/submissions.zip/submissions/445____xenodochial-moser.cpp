class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        map<int, vector<int>> up, down;
        
        int n = points.size();
        
        auto get_max
        = [&points](int rm)
        {
            map<int, vector<int>> up, down;
            int n = points.size();
            for (int i = 0; i < n; ++i)
            {
                if (i == rm) continue;
                auto x = points[i][0], y = points[i][1];
                up[x + y].push_back(i);
                down[y - x].push_back(i);
            }

            auto u1 = up.begin()->first;
            auto u2 = prev(up.end())->first;
            auto d1 = down.begin()->first;
            auto d2 = prev(down.end())->first;
            
            return max(u2 - u1, d2 - d1);
        };
        
        for (int i = 0; i < n; ++i)
        {
            auto x = points[i][0], y = points[i][1];
            up[x + y].push_back(i);
            down[y - x].push_back(i);
        }
        
        auto u1i = up.begin()->second;
        auto u2i = prev(up.end())->second;
        auto d1i = down.begin()->second;
        auto d2i = prev(down.end())->second;
        
        auto u1 = up.begin()->first;
        auto u2 = prev(up.end())->first;
        auto d1 = down.begin()->first;
        auto d2 = prev(down.end())->first;
        
        if (u2 - u1 > d2 - d1)
        {
            U:
            
            if (u2i.size() != 1 && u1i.size() != 1) return u2 - u1;
            int ans = 1e9;
            if (u2i.size() == 1) ans = min(ans, get_max(u2i[0]));
            if (u1i.size() == 1) ans = min(ans, get_max(u1i[0]));
            return ans;
            
        } else if (u2 - u1 < d2 - d1)
        {
            D:
            
            if (d2i.size() != 1 && d1i.size() != 1) return d2 - d1;
            int ans = 1e9;
            if (d2i.size() == 1) ans = min(ans, get_max(d2i[0]));
            if (d1i.size() == 1) ans = min(ans, get_max(d1i[0]));
            return ans;
        }else
        {
            int ans = 1e9;
            if (u2i.size() == 1) ans = min(ans, get_max(u2i[0]));
            if (u1i.size() == 1) ans = min(ans, get_max(u1i[0]));
            if (d1i.size() == 1) ans = min(ans, get_max(d1i[0]));
            if (d2i.size() == 1) ans = min(ans, get_max(d2i[0]));
            if (u2i.size() != 1 && u1i.size() != 1 && d1i.size() != 1 && d2i.size() != 1) return u2 - u1;
            return ans;
           
        }
        
        
            
        return 0;
        
    }
};