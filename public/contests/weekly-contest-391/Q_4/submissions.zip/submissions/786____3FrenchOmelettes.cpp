class Solution {
public:
    int minimumDistance(vector<vector<int>>& points)
    {
        vector<long long> sums;
        vector<long long> diffs;
        int n = points.size();
        for (int i = 0; i < n; i++)
        {
            sums.push_back(points[i][0]+points[i][1]);
            diffs.push_back(points[i][0]-points[i][1]);
        }
        
        std::sort(sums.begin(), sums.end());
        std::sort(diffs.begin(), diffs.end());
        
        int ans = INT_MAX;
        
        for (int i = 0; i < n; i++)
        {
            int sum = points[i][0] + points[i][1];
            int diff = points[i][0] - points[i][1];
            int hi = sums[n-1] == sum ? n-2 : n-1;
            int lo = sums[0] == sum ? 1 : 0;
            
            long long sub = sums[hi] - sums[lo];
            
            hi = diffs[n-1] == diff ? n-2 : n-1;
            lo = diffs[0] == diff ? 1 : 0;
            
            sub = max(sub, diffs[hi] - diffs[lo]);
            
            ans = min(ans, (int) sub);
        }
        
        return ans;
    }
};