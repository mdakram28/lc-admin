class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        sort(points.begin(),points.end());
        vector<pair<int,int>> sum,diff;
        for(int i=0;i<points.size();i++)
            sum.push_back({points[i][0]+points[i][1],i}),diff.push_back({points[i][0]-points[i][1],i});
        sort(sum.begin(),sum.end());
        sort(diff.begin(),diff.end());
        int result=INT_MAX;
        unordered_set<int> possible={sum[0].second,sum.back().second,diff[0].second,diff.back().second};
        // for(auto &[a,b]:sum)
        //     cout<<a<<" "<<b<<", ";
        // cout<<endl;
        // for(auto &[a,b]:diff)
        //     cout<<a<<" "<<b<<", ";
        // cout<<endl;
        for(auto &i:possible) {
            int sL=sum.front().second==i?sum[1].first:sum[0].first;
            int sR=sum.back().second==i?sum[sum.size()-2].first:sum.back().first;
            int dL=diff.front().second==i?diff[1].first:diff[0].first;
            int dR=diff.back().second==i?diff[diff.size()-2].first:diff.back().first;
            result=min(result,max(dR-dL,sR-sL));
        }
        return result;
    }
};