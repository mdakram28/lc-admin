typedef long double ld;
 
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<int,pii> p3;
typedef pair<ll,ll> pl;
typedef pair<int,pl> p3l;
typedef pair<double,double> pdd;
typedef vector<int> vi;
typedef vector<ld> vd;
 
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define REP(i,n) FOR(i,0,n)
#define SORT(v) sort((v).begin(),(v).end())
#define UN(v) SORT(v),(v).erase(unique((v).begin(),(v).end()),(v).end())
#define CL(a,b) memset(a,b,sizeof a)
#define pb push_back

// to_string, stoi, stoll, gcd, __builtin_popcount - already exist
//
// unordered_map<int, int> depth;
// for (auto& [k, v] : depth)

int d(vector<vi>& p, int p1,int p2){
    return abs(p[p1][0]-p[p2][0])+abs(p[p1][1]-p[p2][1]);
}

pii solve(vector<vi>& p){
    int r = 0, p1 = 0, p2 = 0;
    int v1 = 1e9, v2 = 1e9;
    int pv1 = -1, pv2 = -1;
    REP(i,p.size()){
        if (v1 > p[i][0]+p[i][1]){
            v1 = p[i][0]+p[i][1];
            pv1 = i;
        }
        if (v2 > p[i][0]-p[i][1]){
            v2 = p[i][0]-p[i][1];
            pv2 = i;
        }
        
        if(r < p[i][0]+p[i][1] - v1){
            r=p[i][0]+p[i][1]-v1;
            p1=i;
            p2=pv1;
        }
        if(r < p[i][0]-p[i][1] - v2){
            r=p[i][0]-p[i][1]-v2;
            p1=i;
            p2=pv2;
        }
        
    }
    return {p1,p2};
}

class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        SORT(p);
        pii x = solve(p);
        int r = d(p, x.first, x.second);
        vector<vi> p1 = p;
        p1.erase(p1.begin()+x.first);
        pii y = solve(p1);
        r = min(r, d(p1, y.first, y.second));
        vector<vi> p2 = p;
        p2.erase(p2.begin()+x.second);
        y = solve(p2);
        r = min(r, d(p2, y.first, y.second));        
        return r;
    }
};