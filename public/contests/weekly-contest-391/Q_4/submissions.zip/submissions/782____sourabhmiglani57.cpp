class Solution {
public:
    

  
    int minimumDistance(vector<vector<int>>& points) {
        
        multiset<int> mxs,mxd;
        for(auto it:points){
            mxs.insert(it[0] + it[1]);
            mxd.insert(it[0]-it[1]);
        }
        int minans = 1e9;
        for(auto it:points){
            int sm = it[0] + it[1],df = it[0]-it[1];
            mxs.erase(mxs.find(sm));
            mxd.erase(mxd.find(df));
            auto sts = mxs.begin(),ens = mxs.end();
            auto std = mxd.begin(),end = mxd.end();
            ens--;
            end--;
            minans = min(minans,max(*ens - *sts,*end - *std));
            mxs.insert(sm);
            mxd.insert(df);
        }
        return minans;
    }
};