class Solution:
    def maxManhattanDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        
        # a = x + y
        # b = x - y
        
        max_a = -math.inf
        min_a = math.inf
        
        max_b = -math.inf
        min_b = math.inf
        
        for i in range (n):
            a = points[i][0] + points[i][1]
            
            if (a > max_a):
                max_a = a
                
            if (a < min_a):
                min_a = a
                
            b = points[i][0] - points[i][1]
            
            if (b > max_b):
                max_b = b
                
            if (b < min_b):
                min_b = b
        
        print(max_b, min_b)
        return max(max_a - min_a, max_b - min_b)
        
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        
        # a = x + y
        # b = x - y
        
        max_a = -math.inf
        max_a_pos = -1
        min_a = math.inf
        min_a_pos = -1
        
        max_b = -math.inf
        max_b_pos = -1
        min_b = math.inf
        min_b_pos = -1
        
        for i in range (n):
            a = points[i][0] + points[i][1]
            
            if (a > max_a):
                max_a = a
                max_a_pos = i
            elif (a == max_a):
                max_a_pos = -1
                
            if (a < min_a):
                min_a = a
                min_a_pos = i
            elif (a == min_a):
                min_a_pos = -1
                
            b = points[i][0] - points[i][1]
            
            if (b > max_b):
                max_b = b
                max_b_pos = i
            elif (b == max_b):
                max_b_pos = -1
                
            if (b < min_b):
                min_b = b
                min_b_pos = i
            elif (b == min_b):
                min_b_pos = -1
            
        distance = 0
        pos_to_remove = []
        if (max_a - min_a > max_b - min_b):
            distance = max_a - min_a
            if (max_a_pos != -1):
                pos_to_remove.append(max_a_pos)
            if (min_a_pos != -1):
                pos_to_remove.append(min_a_pos)
        elif (max_a - min_a < max_b - min_b):
            distance = max_b - min_b
            if (max_b_pos != -1):
                pos_to_remove.append(max_b_pos)
            if (min_b_pos != -1):
                pos_to_remove.append(min_b_pos)
        else:
            distance = max_a - min_a
            if (max_a_pos != -1 and (max_a_pos == max_b_pos or max_a_pos == min_b_pos)):
                pos_to_remove.append(max_a_pos)
            if (min_a_pos != -1 and (min_a_pos == max_b_pos or min_a_pos == min_b_pos)):
                pos_to_remove.append(min_a_pos)
            

        if len(pos_to_remove) == 0:
            return distance
        else:
            def remove_element(array, index):
                new_array = array.copy()
                del new_array[index]
                return new_array
            
            for pos in pos_to_remove:
                new_points = remove_element(points,pos)
                temp = self.maxManhattanDistance(new_points)
                if (temp < distance):
                    distance = temp
                    
        return distance