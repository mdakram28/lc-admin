class Solution:
    def minimumDistance(self, v: List[List[int]]) -> int:
        from sortedcontainers import SortedList
        a, b = SortedList(), SortedList()
        for x, y in v:
            a.add(x - y)
            b.add(x + y)
        res = inf
        for x, y in v:
            a.remove(x - y)
            b.remove(x + y)
            res = min(res, max(a[-1] - a[0], b[-1] - b[0]))
            a.add(x - y)
            b.add(x + y)
        return res