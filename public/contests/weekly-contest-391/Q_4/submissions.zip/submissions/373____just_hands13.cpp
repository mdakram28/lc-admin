int cal(vector<int> &a, int x, vector<vector<int>> &p){
    int ans;
    int n= a.size();
    if(a[0]==x) ans = abs(p[a[1]][0] - p[a[n-1]][0]) + abs(p[a[1]][1] - p[a[n-1]][1]);
    else if(a[n-1]==x) ans= abs(p[a[0]][0] - p[a[n-2]][0]) + abs(p[a[0]][1] - p[a[n-2]][1]);
    else ans = abs(p[a[0]][0] - p[a[n-1]][0]) + abs(p[a[0]][1] - p[a[n-1]][1]);
    return ans;
}

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<int> a, b;
        for(int i=0; i<points.size(); i++) {a.push_back(i); b.push_back(i);}
        sort(a.begin(), a.end(), [&points](int i, int j)->bool{
            return points[i][0]+points[i][1] < points[j][0]+points[j][1];
        });
        sort(b.begin(), b.end(), [&points](int i, int j)->bool{
            return points[i][0]-points[i][1] < points[j][0]-points[j][1];
        });
        int ans = max(cal(a, a[0], points), cal(b, a[0], points));
        ans = min(ans, max(cal(a, a[a.size()-1], points), cal(b, a[a.size()-1], points)));
        ans = min(ans, max(cal(a, b[0], points), cal(b, b[0], points)));
        ans = min(ans, max(cal(a, b[b.size()-1], points), cal(b, b[b.size()-1], points)));
        return ans;
    }
};