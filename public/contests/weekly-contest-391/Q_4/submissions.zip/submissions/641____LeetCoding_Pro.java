class Solution
{
    public int minimumDistance(int[][] ps)
    {
        int minDist = Integer.MAX_VALUE;
        List<Integer> sums = new ArrayList<>();
        List<Integer> diffs = new ArrayList<>();
        for (int[] p : ps)
        {
            sums.add(p[0] + p[1]);
            diffs.add(p[0] - p[1]);
        }
        Collections.sort(sums);
        Collections.sort(diffs);
        int[] sumAndDiff1 = helper(ps, new int[]{-1, -1});
        int dist1 = Math.max(sumAndDiff1[0], sumAndDiff1[1]);
        minDist = Math.min(minDist, dist1);
        if (sumAndDiff1[0] >= sumAndDiff1[1])
        {
            if (sums.get(0) < sums.get(1))
            {
                int[] nop = null;
                for (int[] p : ps)
                {
                    if (p[0] + p[1] == sums.get(0))
                    {
                        nop = p;
                        break;
                    }
                }
                int[] sumAndDiff2 = helper(ps, nop);
                int dist2 = Math.max(sumAndDiff2[0], sumAndDiff2[1]);
                minDist = Math.min(minDist, dist2);
            }
            if (sums.get(sums.size() - 1) > sums.get(sums.size() - 2))
            {
                int[] nop = null;
                for (int[] p : ps)
                {
                    if (p[0] + p[1] == sums.get(sums.size() - 1))
                    {
                        nop = p;
                        break;
                    }
                }
                int[] sumAndDiff3 = helper(ps, nop);
                int dist3 = Math.max(sumAndDiff3[0], sumAndDiff3[1]);
                minDist = Math.min(minDist, dist3);
            }
        }
        if (sumAndDiff1[0] <= sumAndDiff1[1])
        {
            if (diffs.get(0) < diffs.get(1))
            {
                int[] nop = null;
                for (int[] p : ps)
                {
                    if (p[0] - p[1] == diffs.get(0))
                    {
                        nop = p;
                        break;
                    }
                }
                int[] sumAndDiff4 = helper(ps, nop);
                int dist4 = Math.max(sumAndDiff4[0], sumAndDiff4[1]);
                minDist = Math.min(minDist, dist4);
            }
            if (diffs.get(diffs.size() - 1) > diffs.get(diffs.size() - 2))
            {
                int[] nop = null;
                for (int[] p : ps)
                {
                    if (p[0] - p[1] == diffs.get(diffs.size() - 1))
                    {
                        nop = p;
                        break;
                    }
                }
                int[] sumAndDiff5 = helper(ps, nop);
                int dist5 = Math.max(sumAndDiff5[0], sumAndDiff5[1]);
                minDist = Math.min(minDist, dist5);
            }
        }
        return minDist;
    }
    
    private int[] helper(int[][] ps, int[] nop)
    {
        List<Integer> sums = new ArrayList<>();
        List<Integer> diffs = new ArrayList<>();
        boolean alreadyRemed = false;
        for (int[] p : ps)
        {
            if (p[0] == nop[0] && p[1] == nop[1] && !alreadyRemed)
            {
                alreadyRemed = true;
                continue;
            }
            sums.add(p[0] + p[1]);
            diffs.add(p[0] - p[1]);
        }
        Collections.sort(sums);
        Collections.sort(diffs);
        return new int[]{sums.get(sums.size() - 1) - sums.get(0), diffs.get(diffs.size() - 1) - diffs.get(0)};
    }
}