class Solution
{
public:
    int minimumDistance(vector<vector<int>> &points)
    {
        multiset<pair<int, int>> diff, sum;
        for (int i = 0; i < points.size(); i++)
        {
            diff.insert({points[i][0] - points[i][1], i});
            sum.insert({points[i][0] + points[i][1], i});
        }
        int res = 1e9;
        for (int i = 0; i < points.size(); i++)
        {
            diff.erase(diff.find({points[i][0] - points[i][1], i}));
            sum.erase(sum.find({points[i][0] + points[i][1], i}));
            res = min(res, max(diff.rbegin()->first - diff.begin()->first, sum.rbegin()->first - sum.begin()->first));
            diff.insert({points[i][0] - points[i][1], i});
            sum.insert({points[i][0] + points[i][1], i});
        }
        return res;
    }
};