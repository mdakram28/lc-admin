class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<vector<int>> v1(points), v2(points);
        auto [_, p1, p2] = f(points);
        v1.erase(v1.begin() + p1);
        v2.erase(v2.begin() + p2);
        return min(get<0>(f(v1)), get<0>(f(v2)));
    }
    
    tuple<int, int, int> f(vector<vector<int>>& points) {
        int n = points.size(), mx = 0, p1 = -1, p2 = -1;
        vector<vector<pair<int, int>>> p(4, vector<pair<int, int>>(n));
        for (int i = 0; i < n; ++i) {
            int x = points[i][0], y = points[i][1];
            p[0][i] = {x + y, i};
            p[1][i] = {x - y, i};
            p[2][i] = {-x + y, i};
            p[3][i] = {-x - y, i};
        }
        for (int i = 0; i < 4; ++i) {
            sort(p[i].begin(), p[i].end());
            mx = max(mx, p[i][n - 1].first - p[i][0].first);
        }
        for (int i = 0; i < 4; ++i) {
            if (p[i][n - 1].first - p[i][0].first == mx) p1 = p[i][0].second, p2 = p[i][n - 1].second;
        }
        return tuple<int, int, int>{mx, p1, p2};
    }
};