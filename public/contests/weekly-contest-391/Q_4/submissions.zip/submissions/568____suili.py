class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        sds = [(x + y, x - y) for x, y in points]
        s_list = sorted(range(n), key=lambda i: sds[i][0])
        d_list = sorted(range(n), key=lambda i: sds[i][1])
        candidates = [s_list[0], d_list[0], s_list[-1], d_list[-1]]
        res = float('inf')
        for c in candidates:
            maxs = max(sds[i][0] for i in range(n) if i != c)
            mins = min(sds[i][0] for i in range(n) if i != c)
            maxd = max(sds[i][1] for i in range(n) if i != c)
            mind = min(sds[i][1] for i in range(n) if i != c)
            dist = max(maxs - mins, maxd - mind)
            res = min(res, dist)
        return res