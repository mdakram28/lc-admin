#define ll long long int 
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        //BSA
        multiset<ll> m1;
        multiset<ll> m2;
        for(int i=0;i<points.size();i++){
            ll x=points[i][0];
            ll y=points[i][1];
            m1.insert(x+y);
            m2.insert(x-y);
        }
        ll ans=INT_MAX;
        for(int i=0;i<points.size();i++){
            ll x=points[i][0];
            ll y=points[i][1];
            m1.erase(m1.find(x+y));
            m2.erase(m2.find(x-y));
            auto it1=m1.end();
            it1--;
            auto it2=m2.end();
            it2--;
            ll maxi=max(*it1-*m1.begin(),*it2-*m2.begin());
            ans=min(ans,maxi);
            m1.insert(x+y);
            m2.insert(x-y);
        }
        return ans;
    }
};