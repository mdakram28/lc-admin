#define pb push_back
#define lb lower_bound
#define ub upper_bound
#define ins insert
#define ull unsigned long long
#define rep(i, begin, end) for (__typeof(begin) i = (begin); i <= (end); ++i)
#define repr(i, begin, end) for (__typeof(end) i = (begin); i >= (end); --i)
#define ff first
#define ss second
#define fast ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
#define nl "\n"
#define sz(a) (int)(a).size()
#define all(a) (a).begin(), (a).end()
#define fl(a,x) memset(a, x, sizeof(a));
#define present(c, x) (c.find(x) != c.end())
#define get(a, begin, end) rep(i, (begin), (end)) cin >> (a)[i];
#define show(a, begin, end) rep(i, (begin), (end)) cout << (a)[i] << " "; cout << nl;
#define ld long double
#define vec vector



typedef long long int lli;
typedef pair<int,int> pii;
typedef vector<int> vi;
typedef vector<pii> vpi;
typedef unordered_map<int,int> umi;
typedef map<int,int> mi;
typedef unordered_set<int> usi;
typedef set<int> si;


int mod = 1e9+7;
class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = sz(p);
        vector<lli> sum(n,0);
        vector<lli> diff(n,0);
        
        for(int i=0;i<n;i++){
            sum[i] = p[i][0]+p[i][1];
        }
        for(int i=0;i<n;i++){
            diff[i] = p[i][0]-p[i][1];
        }
        
        // sort(all(sum));
        // sort(all(diff));
        
        priority_queue<pii,vector<pii>,greater<>> sum_l,diff_l;
        priority_queue<pii> sum_g,diff_g;
        
        for(int i=0;i<n;i++){
            sum_l.push({sum[i],i});
            sum_g.push({sum[i],i});
            diff_l.push({diff[i],i});
            diff_g.push({diff[i],i});
        }
        
        lli ans =INT_MAX;
        for(int i=0;i<n;i++){
            vector<int> slv,sgv,dlv,dgv;
            auto sl = sum_l.top();
            if(sl.second==i){
                sum_l.pop();
                slv.pb(sl.first);
                sl = sum_l.top();
            }
            
            auto sg = sum_g.top();
            if(sg.second==i){
                sum_g.pop();
                sgv.pb(sg.first);
                sg = sum_g.top();
            }
            
            auto dl = diff_l.top();
            if(dl.second==i){
                diff_l.pop();
                dlv.pb(dl.first);
                dl = diff_l.top();
            }
            
            auto dg = diff_g.top();
            if(dg.second==i){
                diff_g.pop();
                dgv.pb(dg.first);
                dg = diff_g.top();
            }
            
            ans = min(ans,(lli)max(sg.first-sl.first,dg.first-dl.first));
            if(slv.size()){
                sum_l.push({slv[0],i});
            }
            if(sgv.size()){
                sum_g.push({sgv[0],i});
            }
            if(dlv.size()){
                diff_l.push({dlv[0],i});
            }
            if(dgv.size()){
                diff_g.push({dgv[0],i});
            }
        }
        return ans;
    }
};