class Solution {
public:
    
    
    multiset<int> mst[4];
    
    vector<vector<int>> num;
    
    void add(int x){
        for(int j=0;j<4;j++){
            int sum=0;
            for(int k=0;k<2;k++){
                if(j&(1<<k)) sum+=num[x][k];
                else sum-=num[x][k];
            }
            mst[j].insert(sum);
        }
    }
    
    void remove(int x){
        for(int j=0;j<4;j++){
            int sum=0;
            for(int k=0;k<2;k++){
                if(j&(1<<k)) sum+=num[x][k];
                else sum-=num[x][k]; 
            }
            mst[j].erase(mst[j].find(sum));
        }
    }
    
    int f(){
        int res=0;
        for(int j=0;j<4;j++){
            auto ite = mst[j].end();
            ite--;
            auto itb=mst[j].begin();
            res=max(res,*ite-*itb);
        }
        return res;
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        num = points;
        int ans = 2147483647;
        
        for(int i=0;i<n;++i){
            add(i);
        }
        
        for(int i=0;i<n;++i){
            remove(i);
            ans = min(ans,f());
            add(i);
        }
        
        return ans;
        
    }
};