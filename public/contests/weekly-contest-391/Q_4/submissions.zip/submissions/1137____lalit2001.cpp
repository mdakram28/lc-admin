class Solution {
public:

    int minimumDistance(vector<vector<int>>& A) {
        int n=A.size();
        vector<pair<int,int>> a(n);
        vector<pair<int,int>>b(n);
        for (int i = 0; i < n; i++) {
            a[i] = {A[i][0] + A[i][1],i};
            b[i] ={A[i][0] - A[i][1],i};
        }
        sort(a.begin(), a.end());
         int ans=INT_MAX;
        sort(b.begin(), b.end());
        for(int i=0;i<n;i++){
            int f=b[0].first;
            int l=b.back().first;
            if(a[i].second==b[0].second) 
                f=b[1].first;
            if(a[i].second==b.back().second) 
                l=b[n-2].first;
            int temp=a.back().first-a[0].first;
            if(i==0)
                temp=a.back().first-a[1].first;
            if(i==(n-1))
                temp=a[n-2].first-a[0].first;
            ans=min(ans,max(l-f,temp));
        }
       return ans;
    }

};