class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def stlist(r=-1):
            ss=[]
            tt=[]
            for i,(x,y) in enumerate(points):
                if i==r:continue
                ss.append((x+y,i))
                tt.append((x-y,i))
            ss.sort(key=lambda x:x[0])
            tt.sort(key=lambda x:x[0])
            return ss,tt
        
        ss,tt=stlist()
        rr=[ss[0][1],ss[-1][1],tt[0][1],tt[-1][1]]
        ans=10**9
        for r in rr:
            ss,tt=stlist(r)
            cur=max(ss[-1][0]-ss[0][0],tt[-1][0]-tt[0][0])
            ans=min(ans,cur)
        return ans
