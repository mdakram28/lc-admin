class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        vector<pair<int,int> >v1,v2;
        int l = p.size(),ct = 0;
        for(auto x:p){
           v1.push_back({x[0]+x[1],ct});
           v2.push_back({x[0]-x[1],ct});
           ct++;
        }
        sort(v1.begin(),v1.end());
        sort(v2.begin(),v2.end());
        vector<int>vv;
        vv.push_back(v1[0].second);
        vv.push_back(v1[l-1].second);
        vv.push_back(v2[0].second);
        vv.push_back(v2[l-1].second);
        int ans = 2e9;
        for(int i = 0;i < 4;i++){
            int mx = vv[i],a1,a2,a3,a4;
            if(v1[0].second != mx) a1 = v1[0].first;
            else a1 = v1[1].first;
            
            if(v1[l-1].second != mx) a2 = v1[l-1].first;
            else a2 = v1[l-2].first;
            
            if(v2[0].second != mx) a3 = v2[0].first;
            else a3 = v2[1].first;
            
            if(v2[l-1].second != mx) a4 = v2[l-1].first;
            else a4 = v2[l-2].first;
            ans = min(ans,max(a2-a1,a4-a3));
        }
        return ans;
    }
};