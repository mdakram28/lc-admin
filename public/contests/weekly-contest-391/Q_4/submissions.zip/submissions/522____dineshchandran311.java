class Solution {
    public int minimumDistance(int[][] points) {
        long min = Long.MAX_VALUE;
        int n = points.length;
        
        ArrayList<Integer> V = new ArrayList<>();
        ArrayList<Integer> V1 = new ArrayList<>();
 
        for (int i = 0; i < n; i++) {
            V.add(points[i][0] + points[i][1]);
            V1.add(points[i][0] - points[i][1]);
        }
 
        Collections.sort(V);
        Collections.sort(V1);
        // System.out.println(V);
        // System.out.println(V1);
 
        for(int i = 0; i<points.length; i++){
            int sum = points[i][0] + points[i][1];
            int diff = points[i][0] - points[i][1];
            
            int l = 0;
            int r = n-1;
            if(V.get(0) == sum){
                l++;
            }
            else if(V.get(r) == sum){
                r--;
            }
            
            int l1 = 0;
            int r1 = n-1;
            if(V1.get(0) == diff){
                l1++;
            }
            else if(V1.get(r1) == diff){
                r1--;
            }
            
            min = Math.min(min, Math.max(V.get(r) - V.get(l), V1.get(r1) - V1.get(l1)));
        }
 
        
        return (int) min;
    }
}