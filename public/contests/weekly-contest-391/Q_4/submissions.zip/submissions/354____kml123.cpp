class Solution {
public:
    vector<int>MaxDist(vector<pair<int, int> >& A, int N)
{
    // Variables to track running extrema
        int l,r;
        int minsum, maxsum, mindiff, maxdiff;
            int l1=0,r1=0,l2=0,r2=0;

        minsum = maxsum = A[0].first + A[0].second;
        mindiff = maxdiff = A[0].first - A[0].second;
        for (int i = 1; i < N; i++) {
            int sum = A[i].first + A[i].second;
            int diff = A[i].first - A[i].second;
            if (sum < minsum)
                minsum = sum,l1=i;
            else if (sum > maxsum)
                maxsum = sum,r1=i;
            if (diff < mindiff)
                mindiff = diff,l2=i;
            else if (diff > maxdiff)
                maxdiff = diff,r2=i;
        }
         if(maxsum - minsum>maxdiff - mindiff){
             l=l1;
             r=r1;
         }
         else{
             l=l2;
             r=r2;
        }
        return {l,r};
//         cout<<l<<" "<<r<<endl;
//         int maximum = max(maxsum - minsum, maxdiff - mindiff);

//         cout << maximum << endl;
}
    int MaxDist1(vector<pair<int, int> >& A, int N)
{
    // Variables to track running extrema
    int minsum, maxsum, mindiff, maxdiff;
 
    minsum = maxsum = A[0].first + A[0].second;
    mindiff = maxdiff = A[0].first - A[0].second;
    for (int i = 1; i < N; i++) {
        int sum = A[i].first + A[i].second;
        int diff = A[i].first - A[i].second;
        if (sum < minsum)
            minsum = sum;
        else if (sum > maxsum)
            maxsum = sum;
        if (diff < mindiff)
            mindiff = diff;
        else if (diff > maxdiff)
            maxdiff = diff;
    }
 
    int maximum = max(maxsum - minsum, maxdiff - mindiff);
 
    return maximum ;
}
    int minimumDistance(vector<vector<int>>& points) {
        
        int ans=0;
        int n=points.size();
        vector<pair<int,int>>p1;
        for(auto it:points){
            p1.push_back({it[0],it[1]});
        }
        vector<int>v=MaxDist(p1,n);
        vector<pair<int,int>>p2,p3;
        for(int i=0;i<points.size();i++){
            if(i!=v[0]){
                p2.push_back({points[i][0],points[i][1]});
            }
            if(i!=v[1]){
                p3.push_back({points[i][0],points[i][1]});
            }
        }
        int ans1=MaxDist1(p2,n-1);
        int ans2=MaxDist1(p3,n-1);
        return min(ans1,ans2);
    }
};