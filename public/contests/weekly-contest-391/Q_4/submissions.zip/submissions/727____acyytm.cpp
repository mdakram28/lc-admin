class Solution {
    int fp1[2];
    int fp2[2];
public:
    int max_len(vector<vector<int>>& points) {
        int minp = 1;
        int maxp = 1e8;
        int p[4][2] = {
            {minp, minp},
            {minp, maxp},
            {maxp, minp},
            {maxp, maxp}
        };
        int max_l[4] = {0};
        int min_l[4];
        memset(min_l, 0x3f, sizeof(min_l));
        auto get_len = [&](int x1, int y1, int x2, int y2) {
            return abs(x1 - x2) + abs(y1 - y2);
        };
        int pmx[4][2];
        int pmi[4][2];
        for(int i = 0; i < points.size(); i++) {
            for(int j = 0; j < 4; j++) {
                auto len = get_len(points[i][0], points[i][1], p[j][0], p[j][1]);      
                if(len > max_l[j]) {
                    max_l[j] = len;
                    pmx[j][0] = points[i][0];
                    pmx[j][1] = points[i][1];
                }
                if(len < min_l[j]) {
                    min_l[j] = len;
                    pmi[j][0] = points[i][0];
                    pmi[j][1] = points[i][1];
                }
            }
        }
        int res = 0;
        int p1[2];
        int p2[2];
        for(int i = 0; i < 4; i++) {
            if(res < max_l[i] - min_l[i]) {
                res = max_l[i] - min_l[i];
                p1[0] = pmx[i][0];
                p1[1] = pmx[i][1];
                p2[0] = pmi[i][0];
                p2[1] = pmi[i][1];
            }
        }
        fp1[0] = p1[0];
        fp2[0] = p2[0];
        fp1[1] = p1[1];
        fp2[1] = p2[1];
        return res;
    }
    int minimumDistance(vector<vector<int>>& points) {
        int len = max_len(points);
        int x1 = fp1[0], y1 = fp1[1];
        int x2 = fp2[0], y2 = fp2[1];
        int k1 = 0, k2 = 0;
        for(int i = 0; i < points.size(); i++) {
            if(points[i][0] == x1 && points[i][1] == y1) {
                k1 = i;
                break;
            } 
        }
        auto t = points;
        t.erase(t.begin() + k1);
        int res1 = max_len(t);
        for(int i = 0; i < points.size(); i++) {
            if(points[i][0] == x2 && points[i][1] == y2) {
                k2 = i;
                break;
            } 
        }
        points.erase(points.begin() + k2);
        int res2 = max_len(points);
        return min(res1, res2);
    }
};