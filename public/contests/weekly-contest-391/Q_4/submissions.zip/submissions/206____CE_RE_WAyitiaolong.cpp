int p[4][100005], v[4][100005];

class Solution {
public:
    int minimumDistance(vector<vector<int>>& a) {
        int n = a.size();
        for(int i = 0; i < n; i++) {
            p[0][i] = a[i][0] + a[i][1];
            p[1][i] = -a[i][0] + a[i][1];
            p[2][i] = a[i][0] - a[i][1];
            p[3][i] = -a[i][0] - a[i][1];
            v[0][i] = v[1][i] = v[2][i] = v[3][i] = i;
        }
        for(int i = 0; i < 4; i++) {
            sort(v[i], v[i] + n, [&](int x, int y){
                return p[i][x] < p[i][y];
            });
        }
        int res = 1e9;
        for(int i = 0; i < 4; i++) {
            // drop v[i][0]
            int x = v[i][0];
            int t = p[i][v[i][n - 1]] - p[i][v[i][1]];
            for(int j = 0; j < 4; j++) {
                if(j == i) {
                    continue;
                }
                int w = v[j][0], q = v[j][n - 1];
                if(w == x) {
                    w = v[j][1];
                } else if(q == x) {
                    q = v[j][n - 2];
                }
                t = max(t, p[j][q] - p[j][w]);
            }
            res = min(res, t);
            
            // drop v[i][n - 1]
            x = v[i][n - 1];
            t = p[i][v[i][n - 2]] - p[i][v[i][0]];
            for(int j = 0; j < 4; j++) {
                if(j == i) {
                    continue;
                }
                int w = v[j][0], q = v[j][n - 1];
                if(w == x) {
                    w = v[j][1];
                } else if(q == x) {
                    q = v[j][n - 2];
                }
                t = max(t, p[j][q] - p[j][w]);
            }
            res = min(res, t);
        }
        return res;
    }
};