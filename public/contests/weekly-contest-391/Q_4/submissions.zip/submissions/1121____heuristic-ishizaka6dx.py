class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        XpY, XsY = [], []
        for point in points:
            XpY.append(point[0]+point[1])
            XsY.append(point[0]-point[1])
        def cmp(index):
            maxXpY, minXpY, maxXsY, minXsY = -inf, inf, -inf, inf
            for i in range(n):
                if i!=index:
                    maxXpY = max(maxXpY, XpY[i])
                    minXpY = min(minXpY, XpY[i])
                    maxXsY = max(maxXsY, XsY[i])
                    minXsY = min(minXsY, XsY[i])
            return max(abs(maxXpY - minXpY), abs(maxXsY - minXsY))
        maxXpY, minXpY, maxXsY, minXsY = -inf, inf, -inf, inf
        index1, index2 = -1, -1
        index3, index4 = -1, -1
        for i in range(n):
            if maxXpY<XpY[i]:
                maxXpY = max(maxXpY, XpY[i])
                index1 = i
            if minXpY>XpY[i]:
                minXpY = min(minXpY, XpY[i])
                index2 = i
            if maxXsY<XsY[i]:
                maxXsY = max(maxXsY, XsY[i])
                index3 = i
            if minXsY>XsY[i]:
                minXsY = min(minXsY, XsY[i])
                index4 = i
        query = []
        if abs(maxXpY - minXpY) >= abs(maxXsY - minXsY):
            query = [index1, index2]
        else:
            query = [index3, index4]
        cnt = inf
        for i in range(2):
            cnt = min(cnt, cmp(query[i]))
        return cnt
            
        