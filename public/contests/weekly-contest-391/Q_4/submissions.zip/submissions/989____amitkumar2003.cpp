class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        set<pair<int,int>>a,b;
        int j=0;
        map<int,int>mp1,mp2;
        for(auto x:points){
            int u=x[0];
            int v=x[1];
            a.insert({u+v,j});
            b.insert({u-v,j});
            mp1[j]=u+v;
            mp2[j]=u-v;
            j++;
        }
        int n = points.size();
        if(n==1 || n==2)
            return 0;
        int ans = INT_MAX;
        for(int i=0;i<n;i++){
            int cur = i;
            int plus = mp1[cur];
            int neg = mp2[cur];
            a.erase({plus,cur});
            b.erase({neg,cur});
              
            int curres = max(prev(a.end())->first - a.begin()->first,prev(b.end())->first - b.begin()->first); 
            ans = min(curres,ans);
            a.insert({plus,cur});
            b.insert({neg,cur});
            
            
        }
        return ans;
    }
};