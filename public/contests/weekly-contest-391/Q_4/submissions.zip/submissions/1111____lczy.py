class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        sumA = []
        diffA = []
        
        for idx, i in enumerate(points):
            sumA.append((i[0] + i[1], idx))
            diffA.append((i[0] - i[1], idx))
            
        sumA.sort()
        diffA.sort()
        
        res = 0
        
        sum_i, sum_j = sumA[0][1], sumA[-1][1]
        diff_i, diff_j = diffA[0][1], diffA[-1][1]
        
        if sum_i != diff_j and sum_j != diff_i:
            if sum_i == diff_i:
                if sum_j != diff_j:
                    res = min(max(sumA[-1][0] - sumA[1][0], diffA[-1][0] - diffA[1][0]), max(sumA[-2][0] - sumA[0][0], diffA[-1][0] - diffA[0][0]), max(sumA[-1][0] - sumA[0][0], diffA[-2][0] - diffA[0][0]))
                else:
                    res = min(max(sumA[-1][0] - sumA[1][0], diffA[-1][0] - diffA[1][0]), max(sumA[-2][0] - sumA[0][0], diffA[-2][0] - diffA[0][0]))
            else:
                if sum_j != diff_j:
                    res = min(max(sumA[-1][0] - sumA[1][0], diffA[-1][0] - diffA[0][0]), max(sumA[-1][0] - sumA[0][0], diffA[-1][0] - diffA[1][0]), max(sumA[-2][0] - sumA[0][0], diffA[-1][0] - diffA[0][0]), max(sumA[-1][0] - sumA[0][0], diffA[-2][0] - diffA[0][0]))
                else:
                    res = min(max(sumA[-1][0] - sumA[1][0], diffA[-1][0] - diffA[0][0]), max(sumA[-1][0] - sumA[0][0], diffA[-1][0] - diffA[1][0]), max(sumA[-2][0] - sumA[0][0], diffA[-2][0] - diffA[0][0]))
        else:
            if sum_i == diff_j and sum_j == diff_i:
                res = min(max(sumA[-1][0] - sumA[1][0], diffA[-2][0] - diffA[0][0]), max(sumA[-2][0] - sumA[0][0], diffA[-1][0] - diffA[1][0]))
            elif sum_i == diff_j and sum_j != diff_i:
                res = min(max(sumA[-1][0] - sumA[1][0], diffA[-2][0] - diffA[0][0]), max(sumA[-2][0] - sumA[0][0], diffA[-1][0] - diffA[0][0]), max(sumA[-1][0] - sumA[0][0], diffA[-1][0] - diffA[1][0]))
            else: # sum_i != diff_j and sum_j == diff_i:
                res = min(max(sumA[-1][0] - sumA[1][0], diffA[-1][0] - diffA[0][0]), max(sumA[-2][0] - sumA[0][0], diffA[-1][0] - diffA[1][0]), max(sumA[-1][0] - sumA[0][0], diffA[-2][0] - diffA[0][0]))
                
        
        # print(sumA)
        # print(diffA)
        # print(sum_i, sum_j, diff_i, diff_j)
        # print(max(sumA[-1][0] - sumA[1][0], diffA[-1][0] - diffA[0][0]), max(sumA[-2][0] - sumA[0][0], diffA[-1][0] - diffA[1][0]), max(sumA[-1][0] - sumA[0][0], diffA[-2][0] - diffA[0][0]))
        
        return res
            
            
        