class Solution {
public:
    vector <int> MaxDist(vector<vector<int> >& A, int N){
        vector<pair<int,int>> V(N), V1(N);
        for (int i = 0; i < N; i++) {
            V[i].first = A[i][0] + A[i][1];
            V1[i].first = A[i][0] - A[i][1];
            V[i].second=i;
            V1[i].second=i;
        }
        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());
        int k1=V.back().first - V.front().first;
        int k2=V1.back().first - V1.front().first;
        if(k1 > k2){
            return {V.back().second,V.front().second};
        }
        else if(k1 < k2){
            return {V1.back().second,V1.front().second};
        }
        else{
            return {V.back().second,V.front().second,V1.back().second,V1.front().second};
        }
        
    }
    int mxdist(vector<vector<int> >& A, int N){
        vector<int> V(N), V1(N);
        for (int i = 0; i < N; i++) {
            V[i] = A[i][0] + A[i][1];
            V1[i] = A[i][0] - A[i][1];
        }
        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());
        return max(V.back() - V.front(), V1.back() - V1.front());
    }
        int minimumDistance(vector<vector<int>>& points) {
              vector <int> possible=MaxDist(points,points.size());
              int ans=INT_MAX;
              int n=points.size();
              for(auto &it:possible){
                  vector <vector<int>> temp;
                  for(int i=0;i<n;i++){
                      if(it==i)continue;
                      temp.push_back(points[i]);
                  }
                  int q=mxdist(temp,temp.size());
                  ans=min(ans,q);
              }
            return ans;
        }
};