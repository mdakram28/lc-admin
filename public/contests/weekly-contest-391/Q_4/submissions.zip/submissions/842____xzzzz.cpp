class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        // Manhattan -> Chebyshev
        for (int i = 0; i < points.size(); i++) {
            int x = points[i][0], y = points[i][1];
            points[i][0] = x + y;
            points[i][1] = x - y;
        }
        vector<int> idx = findminmax(-1, points);
        // for (auto it:idx)   cout << it << " ";
        // cout << endl; 

        int ans = INT_MAX;
        vector<int> t;
        for (auto it:idx) {
            t = findminmax(it, points);
            int tman = max(points[t[2]][0] - points[t[0]][0], 
                           points[t[3]][1] - points[t[1]][1]);
            ans = min(ans, tman);
        }
        return ans;
        

    }
    vector<int> findminmax(int k, vector<vector<int>>& points) {
        int minx = INT_MAX, miny = INT_MAX, maxx = INT_MIN, maxy = INT_MIN;
        vector<int> idx(4, -1); //min xy, max xy
        for (int i = 0; i < points.size(); i++) {
            if (i == k) continue;
            if (points[i][0] < minx) {
                minx = points[i][0];
                idx[0] = i;
            }
            if (points[i][1] < miny) {
                miny = points[i][1];
                idx[1] = i;
            }
            if (points[i][0] > maxx) {
                maxx = points[i][0];
                idx[2] = i;
            }
            if (points[i][1] > maxy) {
                maxy = points[i][1];
                idx[3] = i;
            }
        }
        return idx;
        
        
    }
};