class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        typedef pair<int, int> pii;
        int n = points.size();
        vector<pii> A, B;
        for (int i = 0; i < n; i++) {
            auto &p = points[i];
            A.push_back(pii(p[0] - p[1], i));
            B.push_back(pii(p[0] + p[1], i));
        }
        sort(A.begin(), A.end());
        sort(B.begin(), B.end());

        auto calc = [&](int ban) {
            vector<int> A, B;
            for (int i = 0; i < n; i++) if (i != ban) {
                auto &p = points[i];
                A.push_back(p[0] - p[1]);
                B.push_back(p[0] + p[1]);
            }
            sort(A.begin(), A.end());
            sort(B.begin(), B.end());
            return max(A[n - 2] - A[0], B[n - 2] - B[0]);
        };

        return min({calc(A[0].second), calc(A[n - 1].second), calc(B[0].second), calc(B[n - 1].second)});
    }
};
