class Solution {
public:
    int minimumDistance(vector<vector<int>>& a) {
        int n = a.size();
        int x, y;
        auto get = [&](vector<array<int, 2>> &v) {
            int m = v.size();
            vector<vector<array<int, 2>>> p(4, vector<array<int, 2>> (m));
            for(int i = 0; i < m; i++) {
                p[0][i][0] = v[i][0] + v[i][1];
                p[1][i][0] = v[i][0] - v[i][1];
                p[2][i][0] = -v[i][0] + v[i][1];
                p[3][i][0] = -v[i][0] - v[i][1];
                p[0][i][1] = i;
                p[1][i][1] = i;
                p[2][i][1] = i;
                p[3][i][1] = i;
            }
            int mx = 0;
            for(int i = 0; i < 4; i++) {
                sort(p[i].begin(), p[i].end());
                if(p[i][m - 1][0] - p[i][0][0] >= mx) {
                    mx = p[i][m - 1][0] - p[i][0][0];
                    x = p[i][m - 1][1], y = p[i][0][1];
                }
            }
            return mx;
        };
        vector<array<int, 2>> v;
        for(int i = 0; i < n; i++) {
            v.push_back({a[i][0], a[i][1]});
        }
        get(v);
        vector<array<int, 2>> v1;
        vector<array<int, 2>> v2;
        for(int i = 0; i < n; i++) {
            if(i != x) {
                v1.push_back({a[i][0], a[i][1]});
            }
        }
        for(int i = 0; i < n; i++) {
            if(i != y) {
                v2.push_back({a[i][0], a[i][1]});
            }
        }
        return min(get(v1), get(v2));
    }
};