class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        
        vector<int> ys(n);
        for (int i=0; i<n; i++) ys[i] = points[i][1];
        sort(ys.begin(), ys.end());
        ys.resize(unique(ys.begin(), ys.end()) - ys.begin());
        auto idy = [&](int y) -> int {
            return lower_bound(ys.begin(), ys.end(), y) - ys.begin();  
        };
        
        vector<pair<int, int>> tu, td;
        auto update = [&](auto self, vector<pair<int, int>> &tree, int pos, pair<int, int> val, int l, int r, int v) -> void {
            if (l == r) tree[v] = max(tree[v], val);
            else {
                int mid = (l+r)/2;
                if (pos <= mid) self(self, tree, pos, val, l, mid, v*2);
                else self(self, tree, pos, val, mid+1, r, v*2+1);
                tree[v] = max(tree[v*2], tree[v*2+1]);
            }
        };
        auto query = [&](auto self, vector<pair<int, int>> &tree, int ql, int qr, int l, int r, int v) -> pair<int, int> {
            if (r < ql || l > qr || ql > qr) return {-1e9, -1};
            if (l >= ql && r <= qr) return tree[v];
            int mid = (l+r)/2;
            return max(self(self, tree, ql, qr, l, mid, v*2), self(self, tree, ql, qr, mid+1, r, v*2+1));
        };
        
        auto calc = [&](vector<vector<int>> &points) -> tuple<int, int, int> {
            tu.assign(4*n, {-1e9, -1}); td.assign(4*n, {-1e9, -1});
            sort(points.begin(), points.end());
            tuple<int, int, int> ret = {-1e9, -1, -1};
            for (int i=0; i<(int)points.size(); i++) {
                int id = idy(points[i][1]);
                auto mxd = query(query, td, 0, id, 0, n-1, 1);
                mxd.first += points[i][0] + points[i][1];
                auto mxu = query(query, tu, id, n-1, 0, n-1, 1);
                mxu.first += points[i][0] - points[i][1];
                if (mxd.first > get<0>(ret)) ret = {mxd.first, mxd.second, i};
                if (mxu.first > get<0>(ret)) ret = {mxu.first, mxu.second, i};
                update(update, td, id, {- points[i][0] - points[i][1], i}, 0, n-1, 1);
                update(update, tu, id, {- points[i][0] + points[i][1], i}, 0, n-1, 1);
            }
            return ret;
        };
        
        auto [mx, i1, i2] = calc(points);
        // cout << mx << ' ' << i1 << ' ' << i2 << '\n';
        auto points1 = points; points1.erase(points1.begin() + i1);
        auto points2 = points; points2.erase(points2.begin() + i2);
        return min(get<0>(calc(points1)), get<0>(calc(points2)));
    }
};