class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<int> plus(n), minus(n);
        iota(plus.begin(), plus.end(), 0);
        iota(minus.begin(), minus.end(), 0);
        sort(plus.begin(), plus.end(), [&] (int lhs, int rhs) { return points[lhs][0] + points[lhs][1] < points[rhs][0] + points[rhs][1]; });
        sort(minus.begin(), minus.end(), [&] (int lhs, int rhs) { return points[lhs][0] - points[lhs][1] < points[rhs][0] - points[rhs][1]; });
        // for (int x : plus) cout << x << ' '; cout << endl;
        // for (int x : minus) cout << x << ' '; cout << endl;
        int ans = 0x3f3f3f3f;
        auto updateAns = [&] (int removedPoint) {
            int p0 = plus[0] == removedPoint ? plus[1] : plus[0];
            int p1 = plus[n - 1] == removedPoint ? plus[n - 2] : plus[n - 1];
            int p2 = minus[0] == removedPoint ? minus[1] : minus[0];
            int p3 = minus[n - 1] == removedPoint ? minus[n - 2] : minus[n - 1];
            int cans = 0;
            vector<int> p{p0, p1, p2, p3};
            for (int pi : p) for (int pj : p) {
                cans = max(cans, abs(points[pi][0] - points[pj][0]) + abs(points[pi][1] - points[pj][1]));
            }
            // cout << p0 << ' ' << p1 << ' ' << p2 << ' ' << p3 << ' ' << cans << endl;
            ans = min(ans, cans);
        };
        //updateAns(-1);
        updateAns(plus.front());
        updateAns(plus.back());
        updateAns(minus.front());
        updateAns(minus.back());
        return ans;
    }
};