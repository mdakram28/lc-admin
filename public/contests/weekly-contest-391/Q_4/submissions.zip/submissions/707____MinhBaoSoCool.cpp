class Item {
public:
    int value;
    int index;
    Item(int v, int i){
        value=v;
        index=i;
    }
};

class Solution {
public:
    
    Item calcA(vector<int>& point, int way, int i){
        if(way==0) return Item(point[0]+point[1], i);
        if(way==1) return Item(point[0]-point[1], i);
        if(way==2) return Item(-point[0]+point[1], i);
        return Item(-point[0]-point[1], i);
    }
    
    static bool cmpItem(Item i1, Item i2)
    {
        return (i1.value < i2.value);
    }
    
    vector<vector<Item>> calcP(vector<vector<int>>& points){
        vector<vector<Item>> p;
        for(int way=0;way<4;++way){
            vector<Item> k;
            for(int i=0;i<points.size();++i){
                vector<int> point=points[i];
                Item a=calcA(point, way, i);
                k.push_back(a);
            }
            sort(k.begin(), k.end(), cmpItem);
            p.push_back(k);
        }
        return p;
    }
    
    int getLargestIndNotI(vector<Item>& pway, int ind){
        int n=pway.size();
        if(pway[n-1].index==ind) return n-2;
        return n-1;
    }
    
    int getSmallestIndNotI(vector<Item>& pway, int ind){
        if(pway[0].index==ind)return 1;
        return 0;
    }
    
    int handleRemovePointI(vector<vector<Item>>& p, int ind){
        int ans=0;
        for(int way=0;way<p.size();++way){
            int largestInd=getLargestIndNotI(p[way], ind);
            int smallestInd=getSmallestIndNotI(p[way], ind);
            ans=max(ans, p[way][largestInd].value-p[way][smallestInd].value);
        }
        return ans;
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        int ans = 2e8+10;
        
        vector<vector<Item>> p=calcP(points);
        
        for(int i=0;i<points.size();++i){
            int tmp = handleRemovePointI(p, i);
            ans=min(ans, tmp);
        }
        return ans;
    }
};