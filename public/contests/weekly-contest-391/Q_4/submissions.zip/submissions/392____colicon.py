class Solution:
    def minimumDistance(self, p: List[List[int]]) -> int:
        p.sort()

        def d(p1, p2):
            return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])
        
        def solve(p):
            ans = -1
            mn_i = 0
            mx_i = 0
            for i in range(1, len(p)):
                x, y = p[i]

                if ans < d(p[mn_i], p[i]):
                    ans = d(p[mn_i], p[i])
                    far1, far2 = mn_i, i
                if ans < d(p[mx_i], p[i]):
                    ans = d(p[mx_i], p[i])
                    far1, far2 = mx_i, i

                if x - p[mn_i][0] - p[mn_i][1] < -y:
                    mn_i = i
                if x - p[mx_i][0] + p[mx_i][1] < y:
                    mx_i = i
            
            return far1, far2, ans
        
        far1, far2, _ = solve(p)
        
        return min(solve(p[:far1] + p[far1+1:])[2], solve(p[:far2] + p[far2+1:])[2])
    