class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        s = []
        d = []
        for i in range(n):
            s.append(points[i][0] + points[i][1])
            d.append(points[i][0] - points[i][1])
        max_s = max(s)
        min_s = min(s)
        max_d = max(d)
        min_d = min(d)
        print(max_s, min_s, max_d, min_d)
        
        if max_s - min_s >= max_d - min_d:
            best = max_s - min_s
            argmax = 0
            while s[argmax] != max_s:
                argmax += 1
            argmin = 0
            while s[argmin] != min_s:
                argmin += 1
            #print("s", argmax, argmin)
        else:
            best = max_d - min_d
            argmax = 0
            while d[argmax] != max_d:
                argmax += 1
            argmin = 0
            while d[argmin] != min_d:
                argmin += 1
            #print("d", argmax, argmin)
        
        for skiped in [argmax, argmin]:
            s1 = s[:skiped] + s[skiped + 1:]
            d1 = d[:skiped] + d[skiped + 1:]
            best = min(best, max(max(s1) - min(s1), max(d1) - min(d1)))
        
        return best
    