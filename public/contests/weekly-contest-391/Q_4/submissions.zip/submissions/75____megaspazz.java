class Solution {
    public int minimumDistance(int[][] points) {
        CountMapLong<Integer> forward = new CountMapLong<>();
        CountMapLong<Integer> backward = new CountMapLong<>();
        
        for (int[] p : points) {
            int x = p[0];
            int y = p[1];
            
            int f = x + y;
            int b = x - y;
            
            forward.increment(f, 1);
            backward.increment(b, 1);
        }
        
        int ans = Integer.MAX_VALUE;
        for (int[] p : points) {
            int x = p[0];
            int y = p[1];
            
            int f = x + y;
            int b = x - y;
            
            forward.increment(f, -1);
            backward.increment(b, -1);
            
            int curr = Math.max(forward.lastKey() - forward.firstKey(), backward.lastKey() - backward.firstKey());
            ans = Math.min(ans, curr);
            
            forward.increment(f, 1);
            backward.increment(b, 1);
        }
        return ans;
    }

	/**
	 * Counts the frequency of objects.
	 * Change to extend TreeMap instead, if ordering of objects is required.
	 * 
	 * NOTE:  If `total` is needed, only use `increment(...)` for updates.
	 */
	public static class CountMapLong<T> extends TreeMap<T, Long> {
		private static final long serialVersionUID = -9079906779955923767L;

		public long total;

		public long getCount(T k) {
			return getOrDefault(k, 0L);
		}

		public void increment(T k, long v) {
			total += v;
			long next = getCount(k) + v;
			if (next == 0) {
				remove(k);
			} else {
				put(k, next);
			}
		}

		public static <T> CountMapLong<T> fromArray(T[] A) {
			CountMapLong<T> cm = new CountMapLong<>();
			for (T x : A) {
				cm.increment(x, 1);
			}
			return cm;
		}
	}
}