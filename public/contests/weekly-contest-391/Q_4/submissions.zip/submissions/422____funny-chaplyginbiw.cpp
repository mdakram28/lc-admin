class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        for(int i = 0; i < n; i++) {
            int x = p[i][0], y = p[i][1];
            p[i][0] = x + y;
            p[i][1] = y - x;
            //cout << p[i][0] << ", " << p[i][1] << endl;
        }
        
        auto p1 = p;
        sort(p.begin(), p.end(),
        [](const vector<int>& lhs, const vector<int>& rhs) 
           {
               if(lhs[0] != rhs[0])
                    return lhs[0] < rhs[0]; 
               else
                   return lhs[1] < rhs[1];
           } );
        
        sort(p1.begin(), p1.end(),
        [](const vector<int>& lhs, const vector<int>& rhs) 
           {
               if(lhs[1] != rhs[1])
                    return lhs[1] < rhs[1];
               else
                   return lhs[0] < rhs[0]; 
           } );
        
        int can1 = min(helper(p, 0, n - 2), helper(p, 1, n - 1));
        int can2 = min(helper(p1, 0, n - 2), helper(p1, 1, n - 1));
        
        return min(can1, can2);
    }
    
    int helper(vector<vector<int>>& p, int lo, int hi) {
        int mi0 = 1e9, mi1 = 1e9, mx0 = -1e9, mx1 = -1e9;
        for(int i = lo; i <= hi; i++) {
            mi0 = min(mi0, p[i][0]);
            mx0 = max(mx0, p[i][0]);
            mi1 = min(mi1, p[i][1]);
            mx1 = max(mx1, p[i][1]);
        }
        
        //cout << mi0 << " " << mx0 << " " << mi1 << " " << mx1 << endl;
        
        return max(mx0 - mi0, mx1 - mi1);
    }
};