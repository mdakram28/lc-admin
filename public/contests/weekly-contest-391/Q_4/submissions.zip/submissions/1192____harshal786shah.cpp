class Solution {
public:
   
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
       vector<pair<int,int>>vec;
        multiset<int>ms;
        multiset<int>ms2;
        int maxi=INT_MAX;
        for(auto it:points){
            int sum = it[0]+it[1];
            int sub=it[0]-it[1];
            ms.insert(sum);
            ms2.insert(sub);
        }
        for(int i=0;i<n;i++){
            int maxi2=INT_MAX;
            int sum = points[i][0] + points[i][1];
            int sub = points[i][0]-points[i][1];
            ms.erase(ms.find(sum));
            ms2.erase(ms2.find(sub));
            int diff=*(ms.rbegin())- *(ms.begin());
            int diff2=*(ms2.rbegin())- *(ms2.begin());
            ms.insert(sum);
            ms2.insert(sub);
            maxi2=max(diff,diff2);
            maxi=min(maxi2,maxi);
        }
        
        return maxi;
    }
};