class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        t1, t2 = [], []
        for index, p in enumerate(points):
            x, y = p
            t1.append([x - y, index])
            t2.append([x + y, index])
        t1.sort()
        t2.sort()
        t = set([t1[0][1], t1[-1][1], t2[0][1], t2[-1][1]])
        m = 1000000000
        for i in t:
            left1 = left2 = 0
            right1 = right2 = len(t1) - 1
            if t1[0][1] == i:
                left1 = 1
            if t1[-1][1] == i:
                right1 = len(t1) - 2
            if t2[0][1] == i:
                left2 = 1
            if t2[-1][1] == i:
                right2 = len(t2) - 2
            m = min(m, max(t1[right1][0] - t1[left1][0],t2[right2][0] - t2[left2][0]))
        return m