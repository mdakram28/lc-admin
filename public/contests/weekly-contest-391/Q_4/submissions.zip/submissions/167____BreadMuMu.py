class Solution:
    def minimumDistance(self, A: List[List[int]]) -> int:
        # Variables to track running extrema
        N = len(A)
        p1 = 0
        p2 = 0
        p3 = 0
        p4 = 0
        minsum = maxsum = A[0][0] + A[0][1]
        mindiff = maxdiff = A[0][0] - A[0][1]
 
        for i in range(1, N):
            sum = A[i][0] + A[i][1]
            diff = A[i][0] - A[i][1]
            if (sum < minsum):
                minsum = sum
                p1 = i
            elif (sum > maxsum):
                maxsum = sum
                p2 = i
            if (diff < mindiff):
                mindiff = diff
                p3 = i
            elif (diff > maxdiff):
                maxdiff = diff
                p4 = i
        
        answer = float('inf')
        tmp = A[p1]
        A.pop(p1)
        answer = min(answer, self.MaxDist(A))
        A.insert(p1, tmp)
        
        tmp = A[p2]
        A.pop(p2)
        answer = min(answer, self.MaxDist(A))
        A.insert(p2, tmp)
        
        tmp = A[p3]
        A.pop(p3)
        answer = min(answer, self.MaxDist(A))
        A.insert(p3, tmp)
        
        tmp = A[p4]
        A.pop(p4)
        answer = min(answer, self.MaxDist(A))
        A.insert(p4, tmp)
        
        return answer

    def MaxDist(self, A):
        N = len(A)

        # Variables to track running extrema
        minsum = maxsum = A[0][0] + A[0][1]
        mindiff = maxdiff = A[0][0] - A[0][1]

        for i in range(1,N):
            sum = A[i][0] + A[i][1]
            diff = A[i][0] - A[i][1]
            if (sum < minsum):
                minsum = sum
            elif (sum > maxsum):
                maxsum = sum
            if (diff < mindiff):
                mindiff = diff
            elif (diff > maxdiff):
                maxdiff = diff

        maximum = max(maxsum - minsum, maxdiff - mindiff)
        return maximum