class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        int k = 2, ans = INT32_MAX;
        
        if (n < 6) {
            int ans = INT32_MAX;
            for (int i = 0; i < n; i++) {
                int sum = 0;
                for (int j = 0; j < n; j++) {
                    for (int k = 0; k < n; k++) {
                        if (j != k && j != i && k != i) {
                        sum = std::max(sum, abs(p[j][0] - p[k][0]) + abs(p[j][1] - p[k][1]));
                        }
                    }
                }
                ans = min(ans, sum);
            }
            return ans;
        }

        std::vector<std::vector<std::pair<int, int>>> allmx(4);
        std::vector<std::vector<std::pair<int, int>>> allmn(4);
        std::set<int> st;
        for (int s = 0; s < (1<<k); ++s) {
            std::vector<std::pair<int, int>> mx, mn;
            for (int i = 0; i < n; ++i) {
                int sum = 0;
                for (int j = 0; j < k; ++j) {
                    sum += (s & (1<<j)) ? p[i][j] : -p[i][j];
                }
                mx.push_back(make_pair(sum, i));
                mn.push_back(make_pair(sum, i));
            }
            std::sort(mx.begin(), mx.end(), std::greater<>());
            std::sort(mn.begin(), mn.end());
            
            for (int i = 0; i < 3; i++) {
                allmx[s].push_back(mx[i]);
                allmn[s].push_back(mn[i]);
                st.insert(mx[i].second);
                st.insert(mn[i].second);
            }
        }
        
        for (int x : st) {
            int sum = 0;
            for (int s = 0; s < 4; s++)
            for (int j = 0; j < 3; j++) {
                for (int k = 0; k < 3; k++) {
                    int y1 = allmx[s][j].first, x1 = allmx[s][j].second;
                    int y2 = allmn[s][k].first, x2 = allmn[s][k].second;
                    if (x1 != x2 && x1 != x && x2 != x) {
                        sum = max(sum, y1 - y2);
                    }
                }
            }
            ans = min(ans, sum);
        }
        return ans;
    }
};