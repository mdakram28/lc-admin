class Solution {
public:
int minimumDistance(vector<vector<int>> &points)
{

    int n = points.size();
    vector<int> sums(n), diff(n);
    multiset<int> sum, dif;
    for (int i = 0; i < n; i++)
    {
        sum.insert(points[i][0] + points[i][1]);
        dif.insert(points[i][0] - points[i][1]);
    }
    int ans = INT_MAX;
    for (int i = 0; i < n; i++)
    {
        sum.erase(sum.find(points[i][0] + points[i][1]));
        dif.erase(dif.find(points[i][0] - points[i][1]));
        ans = min(ans, max(*sum.rbegin() - *sum.begin(), *dif.rbegin() - *dif.begin()));
           sum.insert(points[i][0] + points[i][1]);
        dif.insert(points[i][0] - points[i][1]);
    }
    return ans;
}
};