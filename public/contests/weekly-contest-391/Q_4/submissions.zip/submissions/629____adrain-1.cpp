class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
		vector<int> v1(n), v2(n);
		iota(v1.begin(), v1.end(), 0);
		iota(v2.begin(), v2.end(), 0);
		sort(v1.begin(), v1.end(), [&](int& a, int& b) {
			return points[a][0] - points[a][1] < points[b][0] - points[b][1];
			});
		sort(v2.begin(), v2.end(), [&](int& a, int& b) {
			return points[a][0] + points[a][1] < points[b][0] + points[b][1];
			});
		unordered_set<int> us = {v1[0], v1[n - 1], v2[0], v2[n - 1]};
		int res = INT_MAX;
		for (auto& c : us) {
			int i1 = 0, i2 = 0, j1 = n - 1, j2 = n - 1, t = 0;
			if (c == v1[0]) {
				i1++;
			}
			if (c == v2[0]) {
				i2++;
			}
			if (c == v1[n - 1]) {
				j1--;
			}
			if (c == v2[n - 1]) {
				j2--;
			}
			t = max(t, points[v1[j1]][0] - points[v1[j1]][1] - (points[v1[i1]][0] - points[v1[i1]][1]));
			t = max(t, points[v2[j2]][0] + points[v2[j2]][1] - (points[v2[i2]][0] + points[v2[i2]][1]));
			res = min(res, t);
		}
		return res;
    }
};