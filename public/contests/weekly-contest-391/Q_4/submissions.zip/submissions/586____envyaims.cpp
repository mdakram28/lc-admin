class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        #define S second
        #define F first
        // x and y independent
        // track four points
        
        multiset<int> t1, t2;
        for(int i= 0; i < n; i++){
            int X = p[i][0], Y = p[i][1];
            t1.insert(X + Y);
            t2.insert(X - Y);
        }
        
        int ans = 1e9;
        for(int i = 0; i < n; i++){
            int X = p[i][0], Y = p[i][1];
            t1.erase(t1.find(X + Y));
            t2.erase(t2.find(X - Y));
            ans = min(ans, max(*prev(t1.end()) - *t1.begin(), *prev(t2.end()) - *t2.begin()));
            t1.insert(X + Y);
            t2.insert(X - Y);
        }
        return ans;
        
//         map<int, multiset<int>> x, y;
//         multiset<int> tx, ty;
//         for(int i = 0; i < n; i++){
//             int X = p[i][0], Y = p[i][1];
//             x[X].insert(Y);
//             y[Y].insert(X);
//             tx.insert(X);
//             ty.insert(Y);
//         }
        
//         int ans = 1e9;
//         auto test = [&](){
//             vector<pair<int, int>> v;
//             for(int i: {*tx.begin(), *prev(tx.end())}){
//                 assert(!x[i].empty());
//                 v.push_back({i, *x[i].begin()});
//                 v.push_back({i, *prev(x[i].end())});
//             }
//              for(int i: {*ty.begin(), *prev(ty.end())}){
//                 assert(!y[i].empty());
//                 v.push_back({*y[i].begin(), i});
//                 v.push_back({*prev(y[i].end()), i});
//             }
//             int mx_ans = 0;
//             for(int i = 0; i < v.size(); i++){
//                 for(int j = i + 1; j < v.size(); j++){
//                     mx_ans = max(mx_ans, abs(v[i].first - v[j].first) + abs(v[i].second - v[j].second));
//                 }
//             }
//             ans = min(ans, mx_ans);
//         };
        
//         for(int i = 0; i < n; i++){
//             int X = p[i][0], Y = p[i][1];
//             x[X].erase(x[X].find(Y));
//             y[Y].erase(y[Y].find(X));
//             tx.erase(tx.find(X));
//             ty.erase(ty.find(Y));
//             test();
//             x[X].insert(Y);
//             y[Y].insert(X);
//             tx.insert(X);
//             ty.insert(Y);
//         }
        
        // return ans;
    }
};