class Solution:
	def minimumDistance(self, points: List[List[int]]) -> int:
		def f(ls):
			t1=[]
			t2=[]
			for x,y,idx in ls:
				t1.append([x-y, idx])
				t2.append([x+y,idx])
			t1.sort()
			t2.sort()
			if t1[-1][0]-t1[0][0]>t2[-1][0]-t2[0][0]:
				return (t1[-1][0]-t1[0][0], t1[-1][1], t1[0][1])
			else:
				return (t2[-1][0]-t2[0][0], t2[-1][1], t2[0][1])
		new=[]
		for i,(x,y) in enumerate(points):
			new.append([x,y,i])
		mx,p1,p2=f(new)
		new1=deepcopy(new)
		del new1[p1]
		ans1=f(new1)
		new2=deepcopy(new)
		del new2[p2]
		ans2=f(new2)
		return min(ans1[0], ans2[0])
