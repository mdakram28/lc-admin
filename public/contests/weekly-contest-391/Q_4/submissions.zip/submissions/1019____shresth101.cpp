class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        
        multiset<pair<long long,int>> s,d;
        
        for(int i=0;i<n;i++){
            s.insert({points[i][0]+points[i][1],i});
            d.insert({points[i][0]-points[i][1],i});
        }
        
//         for(auto it:s){
//             cout << it.first << " " << it.second << endl;
//         }
        
//         cout << endl;
        
//         for(auto it:d){
//             cout << it.first << " " << it.second << endl;
//         }
        
//         cout << endl;
        
        // cout << " " << s.begin()->first << " " << s.rbegin()->first;
        
        
        int ans=1e9;
        for(int i=0;i<n;i++){
            long long sum=points[i][0]+points[i][1];
            int diff=points[i][0]-points[i][1];
            
            s.erase({sum,i});
            d.erase({diff,i});
            
            // cout <<i<<" index pe " << (s.rbegin()->first - s.begin()->first) << " " << (d.rbegin()->first - d.begin()->first) << endl;
            
            int x=max({s.rbegin()->first - s.begin()->first, abs((d.rbegin()->first) - (d.begin()->first))});
            
            ans=min(ans,x);
            
            s.insert({sum,i});
            d.insert({diff,i});
        }
        
        // [[3,2],[3,9],[7,10],[4,4],[8,10],[2,7]]
//         ans = 10

        
        return ans;
    }
};