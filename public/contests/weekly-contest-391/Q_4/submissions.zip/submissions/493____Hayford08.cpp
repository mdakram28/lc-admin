class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> st1, st2;
        for (auto &pt : points){
            st1.insert(pt[0] + pt[1]);
            st2.insert(pt[0] - pt[1]);
        }
        int ans = 1e9;
        for (auto &pt : points){
            int d1 = pt[0] + pt[1];
            int d2 = pt[0] - pt[1];
            st1.erase(st1.find(d1));
            st2.erase(st2.find(d2));
            
            int h1 = *st1.rbegin() - *st1.begin();
            int h2 = *st2.rbegin() - *st2.begin();
            ans = min(ans, max(h1, h2));
            
            st1.insert(d1);
            st2.insert(d2);
        }
        return ans;
    }
};