class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<pair<int, int> > sum, dif;
        for(int i = 0; i<points.size(); i++) {
            sum.push_back(make_pair(points[i][0] + points[i][1], i));
            dif.push_back(make_pair(points[i][0] - points[i][1], i));
        }
        sort(sum.begin(), sum.end());
        sort(dif.begin(), dif.end());
        int ans = sum.back().first - sum[0].first;
        ans = max(ans, dif.back().first - dif[0].first);
        for(int i = 0; i<points.size(); i++) {
            int sumStart = (i == sum[0].second) ? 1 : 0;
            int sumEnd = (i == sum.back().second) ? sum.size()-2 : sum.size()-1;
            int difStart = (i == dif[0].second) ? 1 : 0;
            int difEnd = (i == dif.back().second) ? dif.size()-2 : dif.size()-1;
            ans = min(ans, max(sum[sumEnd].first-sum[sumStart].first, dif[difEnd].first-dif[difStart].first));
        }
        return ans;
    }
};