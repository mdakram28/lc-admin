class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        vector<int> xpy;
        vector<int> xmy;
        for (int i=0; i<p.size(); ++i) {
            xpy.push_back(p[i][0]+p[i][1]);
            xmy.push_back(p[i][0]-p[i][1]);
        }
        // for (int i:xpy) cout << i << " ";
        // cout << endl;
        // for (int i:xmy) cout << i << " ";
        // cout << endl;
        int mina1=min(xpy[0],xpy[1]), mina2=max(xpy[0],xpy[1]), maxa1=max(xpy[0],xpy[1]), maxa2=min(xpy[0],xpy[1]);
        int minb1=min(xmy[0],xmy[1]), minb2=max(xmy[0],xmy[1]), maxb1=max(xmy[0],xmy[1]), maxb2=min(xmy[0],xmy[1]);
        // cout << mina1 << " " << mina2 << endl;
        for (int i=2; i<p.size(); ++i) {
            if (xpy[i]<=mina1) {
                mina2=mina1;
                mina1=xpy[i];
            } else if (xpy[i]<=mina2) {mina2=xpy[i];}
            
            if (xpy[i]>=maxa1) {
                maxa2=maxa1;
                maxa1=xpy[i];
            } else if (xpy[i]>=maxa2) {maxa2=xpy[i];}
            
            if (xmy[i]<=minb1) {
                minb2=minb1;
                minb1=xmy[i];
            } else if (xmy[i]<=minb2) {minb2=xmy[i];}
            
            if (xmy[i]>=maxb1) {
                maxb2=maxb1;
                maxb1=xmy[i];
            } else if (xmy[i]>=maxb2) {maxb2=xmy[i];}
        }
        // cout << mina1 << " " << mina2 << endl;
        // cout << maxa1 << " " << maxa2 << endl;
        // cout << minb1 << " " << minb2 << endl;
        // cout << maxb1 << " " << maxb2 << endl;
        int res=max(maxa1-mina1, maxb1-minb1);
        for (int i=0; i<p.size(); ++i) {
            int mxa=maxa1, mia=mina1, mxb=maxb1, mib=minb1;
            if (xpy[i]==mina1) mia=mina2;
            if (xpy[i]==maxa1) mxa=maxa2;
            if (xmy[i]==minb1) mib=minb2;
            if (xmy[i]==maxb1) mxb=maxb2;
            res=min(res, max(mxa-mia, mxb-mib));
        }
        return res;
    }
};