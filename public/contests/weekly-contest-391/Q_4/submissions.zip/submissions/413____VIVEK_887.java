class Solution {
    public int minimumDistance(int[][] points) {
        TreeMap<Integer,Integer> map1 = new TreeMap<>();
        TreeMap<Integer,Integer> map2 = new TreeMap<>();
        
        for(int[] p : points) {
            int d1 = p[0]+p[1];
            int d2 = p[0]-p[1];
            map1.put(d1,map1.getOrDefault(d1,0)+1);
            map2.put(d2,map2.getOrDefault(d2,0)+1);
        }
        
        int ans=Integer.MAX_VALUE;
        
        for(int[] p : points) {
            int d1 = p[0]+p[1];
            int d2 = p[0]-p[1];
            // System.out.println(map1+" "+map2);
            if(map1.get(d1)==1) {
                map1.remove(d1);
            } else {
                map1.put(d1,map1.get(d1)-1);
            }
            
            if(map2.get(d2)==1) {
                map2.remove(d2);
            } else {
                map2.put(d2,map2.get(d2)-1);
            }
            
            int m0 = map1.firstKey();
            int m1 = map1.lastKey();
            // System.out.println(map1+" "+m0+" "+m1);
            int n0 = map2.firstKey();
            int n1 = map2.lastKey();
            // System.out.println(map2+" "+n0+" "+n1);
            // answer
            int max = Math.max((m1- m0),(n1 - n0));
            // System.out.println(max);
            ans=Math.min(ans,max);
                
            
            
            
            map1.put(d1,map1.getOrDefault(d1,0)+1);
            map2.put(d2,map2.getOrDefault(d2,0)+1);
        }
        
        return ans;
    }
}