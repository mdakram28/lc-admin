class Solution {
public:
    pair<int,int> getD(vector<vector<int>>& p){
        int n=p.size();
        vector<int> idx(n);
        for(int i=0;i<n;i++) idx[i]=i;
        sort(idx.begin(),idx.end(),[&](int i,int j){
            return p[i][0]+p[i][1]<p[j][0]+p[j][1];
        });
        pair<int,int> r1={idx[0],idx.back()};
        int s1=abs(p[r1.second][0]-p[r1.first][0])+abs(p[r1.second][1]-p[r1.first][1]);
        sort(idx.begin(),idx.end(),[&](int i,int j){
            return p[i][0]-p[i][1]<p[j][0]-p[j][1];
        });
        pair<int,int> r2={idx[0],idx.back()};
        int s2=abs(p[r2.second][0]-p[r2.first][0])+abs(p[r2.second][1]-p[r2.first][1]);
        return s1>s2?r1:r2;
    }
    int minimumDistance(vector<vector<int>>& points) {
        auto r=getD(points);
        vector<vector<int>> t1,t2;
        for(int i=0;i<points.size();i++){
            if(i!=r.first) t1.push_back(points[i]);
            if(i!=r.second) t2.push_back(points[i]);
        }
        auto r1=getD(t1),r2=getD(t2);
        int s1=abs(t1[r1.second][0]-t1[r1.first][0])+abs(t1[r1.second][1]-t1[r1.first][1]);
        int s2=abs(t2[r2.second][0]-t2[r2.first][0])+abs(t2[r2.second][1]-t2[r2.first][1]);
        return min(s1,s2);
    }
};