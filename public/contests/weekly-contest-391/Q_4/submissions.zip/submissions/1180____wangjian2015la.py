
import numpy as np
class Solution:
    def minimumDistance(self, points0: List[List[int]]) -> int:
        
        def get_max_i_j(points):
            points.sort(key=lambda x: x[0])
            #print(points)
            p = [ xy[0] + xy[1] for xy in points]
            m = [ xy[0] - xy[1] for xy in points]
            pmin = np.argmin(p)
            pmax = np.argmax(p)

            mmin = np.argmin(m)
            mmax = np.argmax(m)

            i,j = 0,0
            if p[pmax] - p[pmin] >= m[mmax] - m[mmin]:
                i = pmax
                j = pmin
            else:
                i = mmin
                j = mmax
            return max(p[pmax] - p[pmin], m[mmax] - m[mmin]), i,j
        
        a,i,j = get_max_i_j(points0)
        #print(a,i,j)
        bi, _, _ = get_max_i_j(points0[0:i]+points0[i+1:])
        bj, _, _ = get_max_i_j(points0[0:j]+points0[j+1:])


        return min(bi,bj)
