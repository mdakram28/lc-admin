class Solution {
public:
    #define ll long long
    int minimumDistance(vector<vector<int>>& points) {
        ll n = points.size();
        multiset<ll> sum;
        multiset<ll> diff;
        for(int i=0;i<n;i++){
            sum.insert(points[i][0]+points[i][1]);
            diff.insert(points[i][0]-points[i][1]);
        }
        ll mndist = 1e18;
        for(int i=0;i<n;i++){
            ll sumrem = points[i][0]+points[i][1];
            ll diffrem = points[i][0]-points[i][1];
            sum.erase(sum.find(sumrem));
            diff.erase(diff.find(diffrem));
            ll tmpans1 = ((*sum.rbegin())- (*sum.begin()));
            ll tmpans2 = ((*diff.rbegin())- (*diff.begin()));
            ll tmpans = max(tmpans1,tmpans2);
            mndist= min(mndist,tmpans);
            sum.insert(sumrem);
            diff.insert(diffrem);
        }
        return mndist;
    }
};