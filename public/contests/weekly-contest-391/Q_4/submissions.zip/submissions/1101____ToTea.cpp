class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        sort(points.begin(), points.end());
        
        auto [idxs, _1] = getMaxDist(points, -1);
        auto [_2, r1] = getMaxDist(points, idxs[0]);
        auto [_3, r2] = getMaxDist(points, idxs[1]);
        return min(r1, r2);
    }
    
private:
    pair<vector<int>,int> getMaxDist(vector<vector<int>>& points, int ignore) {
        int maxDist = 0;
        vector<int> maxIdxs(2, -1);
        
        bool start = false;
        int preX = points[0][0];
        int minY = points[0][1];
        int maxY = points[0][1];
        int preMinIdx = 0;
        int preMaxIdx = 0;
        for (int i = 0; i < points.size(); ++i) {
            if (i == ignore) continue;
            auto& point = points[i];
            if (!start) {
                preX = point[0];
                minY = point[1];
                maxY = point[1];
                preMinIdx = i;
                preMaxIdx = i;
                start = true;
                continue;
            }
            
            int x = point[0];
            int y = point[1];
            int diff = x - preX;
            minY -= diff;
            maxY += diff;
            
            int dist = max(maxY-y, y-minY);
            if (dist > maxDist) {
                maxDist = dist;
                maxIdxs[0] = i;
                if (maxY-y > y-minY) {
                    maxIdxs[1] = preMaxIdx;
                } else {
                    maxIdxs[1] = preMinIdx;
                }
            }
            
            if (y < minY) {
                minY = y;
                preMinIdx = i;
            }
            
            if (y > maxY) {
                maxY = y;
                preMaxIdx = i;
            }
            
            preX = x;
        }
        return {maxIdxs, maxDist};
    }
};