impl Solution {
    pub fn minimum_distance(points: Vec<Vec<i32>>) -> i32 {
        let n = points.len();
        // 45度回転
        let mut points = points.iter()
            .map(|p| (p[0] as i64 + p[1] as i64, p[1] as i64 - p[0] as i64))
            .collect::<Vec<_>>();
        let xmin = points.iter().map(|p| p.0).min().unwrap();
        let xmax = points.iter().map(|p| p.0).max().unwrap();
        let ymin = points.iter().map(|p| p.1).min().unwrap();
        let ymax = points.iter().map(|p| p.1).max().unwrap();
        let mut ans = i64::MAX;
        fn calc(
            points: &Vec<(i64, i64)>,
            t: usize,
        ) -> i64 {
            let xmin = points.iter()
                .enumerate()
                .filter(|(i, _)| *i != t)
                .map(|p| p.1.0)
                .min()
                .unwrap();
            let xmax = points.iter()
                .enumerate()
                .filter(|(i, _)| *i != t)
                .map(|p| p.1.0)
                .max()
                .unwrap();
            let ymin = points.iter()
                .enumerate()
                .filter(|(i, _)| *i != t)
                .map(|p| p.1.1)
                .min()
                .unwrap();
            let ymax = points.iter()
                .enumerate()
                .filter(|(i, _)| *i != t)
                .map(|p| p.1.1)
                .max()
                .unwrap();
            std::cmp::max(xmax - xmin, ymax - ymin)
        }

        for i in 0..n {
            if points[i].0 == xmin {
                let ans1 = calc(&points, i);
                ans = ans.min(ans1);
                break;
            }
        }
        for i in (0..n).rev() {
            if points[i].0 == xmin {
                let ans1 = calc(&points, i);
                ans = ans.min(ans1);
                break;
            }
        }
        for i in 0..n {
            if points[i].0 == xmax {
                let ans1 = calc(&points, i);
                ans = ans.min(ans1);
                break;
            }
        }
        for i in (0..n).rev() {
            if points[i].0 == xmax {
                let ans1 = calc(&points, i);
                ans = ans.min(ans1);
                break;
            }
        }
        for i in 0..n {
            if points[i].1 == ymin {
                let ans1 = calc(&points, i);
                ans = ans.min(ans1);
                break;
            }
        }
        for i in (0..n).rev() {
            if points[i].1 == ymin {
                let ans1 = calc(&points, i);
                ans = ans.min(ans1);
                break;
            }
        }
        for i in 0..n {
            if points[i].1 == ymax {
                let ans1 = calc(&points, i);
                ans = ans.min(ans1);
                break;
            }
        }
        for i in (0..n).rev() {
            if points[i].1 == ymax {
                let ans1 = calc(&points, i);
                ans = ans.min(ans1);
                break;
            }
        }
        ans as i32
    }
}