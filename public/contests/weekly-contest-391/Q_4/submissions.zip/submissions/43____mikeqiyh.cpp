#include <bits/stdc++.h>
using namespace std;
#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pi;
typedef pair<ll, ll> pll;
typedef vector<bool> vb;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef vector<vll> vvll;
typedef vector<pi> vpi;
typedef vector<pll> vpll;
typedef vector<ld> vld;
#define ms(x, a) memset(x, a, sizeof(x))
#define siz(x) (int)x.size()
#define len(x) (int)x.length()
#define pb push_back
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define F first
#define S second
#define FOR(i, x) for (int i = 0; i < x; i++)
const int NO_DEB = 0;
#define deb(...) logger(#__VA_ARGS__, __VA_ARGS__)
template <typename... Args>
void logger(string vals, Args &&...values){
    if (NO_DEB) return;
    cout << vals << " = ";
    string delim = "";
    (..., (cout << delim << values, delim = ", "));
    cout << endl;
}
const int INF = 0x3f3f3f3f;
const ll LLINF = 0x3f3f3f3f3f3f3f3f;
const ll MOD = 1e9+7; //998244353;
//===========================================
template<int MOD> struct mint {
    static const int mod = MOD;
     int v;
     explicit operator int() const { return v; }
    mint():v(0) {}
    mint(ll _v):v(int(_v%MOD)) { v += (v<0)*MOD; }
    mint& operator+=(mint o) {
        if ((v += o.v) >= MOD) v -= MOD;
        return *this; }
    mint& operator-=(mint o) {
        if ((v -= o.v) < 0) v += MOD;
        return *this; }
    mint& operator*=(mint o) {
        v = int((ll)v*o.v%MOD); return *this; }
    mint& operator/=(const mint& o) { return (*this) *= inv(o); }
    friend mint pow(mint a, ll p) { assert(p >= 0);
        return p==0?1:pow(a*a,p/2)*(p&1?a:1); }
    friend mint inv(mint a) { assert(a.v != 0); return pow(a,MOD-2); }
    friend mint operator+(mint a, mint b) { return a += b; }
    friend mint operator-(mint a, mint b) { return a -= b; }
    friend mint operator*(mint a, mint b) { return a *= b; }
    friend mint operator/(mint a, const mint& b) { return a /= b; }
};
using mi = mint<MOD>;
//===========================================
class Solution {
public:
    int minimumDistance(vector<vector<int>>& pp) {
        int n = siz(pp);
        multiset<int> a, b;
        for (int i = 0; i < n; i++){
            int x = pp[i][0], y = pp[i][1];
            a.insert(x+y); b.insert(x-y);
        }
        int mn = INF;
        for (int i = 0; i < n; i++){
            int x = pp[i][0], y = pp[i][1];
            a.erase(a.find(x+y)); b.erase(b.find(x-y));
            auto it = a.begin();
            int ra = -(*it);
            it = a.end(); it--;
            ra += (*it);
            it = b.begin();
            int rb = -(*it);
            it = b.end(); it--;
            rb += (*it);
            mn = min(mn, max(ra, rb));
            a.insert(x+y); b.insert(x-y);
        }
        return mn;
    }
};