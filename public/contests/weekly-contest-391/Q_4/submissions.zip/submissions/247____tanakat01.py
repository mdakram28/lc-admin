class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        points.sort()
        #print(f'points={points}')
        def maxpair(points):
            maxv = (-float('inf'), -1, -1)
            min_xpy = (float('inf'), -1)
            min_xmy = (float('inf'), -1)
            for i, (x, y) in enumerate(points):
                xpy = x + y
                xmy = x - y
                if i == 0:
                    min_xpy = (xpy, 0)
                    min_xmy = (xmy, 0)
                else:
                    for j in (min_xpy[1], min_xmy[1]):
                        v = abs(points[j][0] - x) + abs(points[j][1] - y)
                        if maxv[0] < v:
                            maxv = (v, i, j)
                    min_xpy = min(min_xpy, (xpy, i))
                    min_xmy = min(min_xmy, (xmy, i))
            return maxv                        
        v, i, j = maxpair(points)       
        #print(f'v, i, j = {(v, i, j)}')
        ans1 = maxpair(points[:i] + points[(i + 1):])
        ans2 = maxpair(points[:j] + points[(j + 1):])
        return min(ans1[0], ans2[0])
                
        