// #define ll long long int

class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        
        int n = p.size();
        
        multiset<int>mn, mx;
        
        for(int i = 0; i < n; i++)
        {
            int tp1 = (p[i][0] + p[i][1]);
            int tp2 = (p[i][0] - p[i][1]);
            
            mn.insert(tp2);
            mx.insert(tp1);
        }
        
        
        int res = INT_MAX;
        
        for(int i = 0; i < n; i++)
        {
            int tp1 = (p[i][0] + p[i][1]);
            int tp2 = (p[i][0] - p[i][1]);
            
            mn.erase(mn.find(tp2));
            
            mx.erase(mx.find(tp1));
            
            int mx1 = (*mx.rbegin() - *mx.begin());
            int mx2 = (*mn.rbegin() - *mn.begin());
            
            res = min(res, max(mx1, mx2));
            
            
            mn.insert(tp2);
            mx.insert(tp1);
            
        }
        
        
        return res;
        
        
    
        
        
        
    }
};