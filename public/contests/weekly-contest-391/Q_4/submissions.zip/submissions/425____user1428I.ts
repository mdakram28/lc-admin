function minimumDistance(p: number[][]): number {
  // 求 x,y min
  const n = p.length;
  let minx = Number.MAX_SAFE_INTEGER;
  let miny = Number.MAX_SAFE_INTEGER;
  let maxx = 0;
  let maxy = 0;

  for (let i = 0; i < n; ++i) {
    const [x, y] = p[i];

    minx = Math.min(minx, x);
    maxx = Math.max(maxx, x);
    miny = Math.min(miny, y);
    maxy = Math.max(maxy, y);
  }

  const f = (u: number[][], si = -1) => {
    // 左下 右上
    let amini = -1;
    let aminv = Number.MAX_SAFE_INTEGER;
    let amaxi = -1;
    let amaxv = 0;
    let bmini = -1;
    let bminv = Number.MAX_SAFE_INTEGER;
    let bmaxi = -1;
    let bmaxv = 0;

    for (let i = 0; i < n; ++i) {
      if (i === si) {
        continue;
      }

      const [x, y] = p[i];
      let v = x - minx + y - miny;

      if (v < aminv) {
        amini = i;
        aminv = v;
      }

      if (v > amaxv) {
        amaxi = i;
        amaxv = v;
      }

      v = x - minx + maxy - y;

      if (v < bminv) {
        bmini = i;
        bminv = v;
      }

      if (v > bmaxv) {
        bmaxi = i;
        bmaxv = v;
      }
    }

    if (amaxv - aminv > bmaxv - bminv) {
      return [amaxv - aminv, amaxi, amini];
    } else {
      return [bmaxv - bminv, bmaxi, bmini];
    }
  };

  const [, i, j] = f(p);
  const [k1] = f(p, i);
  const [k2] = f(p, j);

  return Math.min(k1, k2);
}
