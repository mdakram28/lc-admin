class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        def MaxDist(A, N, need = True):

            minsum = maxsum = A[0][0] + A[0][1]
            mindiff = maxdiff = A[0][0] - A[0][1]
            p1 = p2 = p3 = p4 = 0

            for i in range(1,N):
                sum = A[i][0] + A[i][1]
                diff = A[i][0] - A[i][1]
                if (sum < minsum):
                    minsum = sum
                    p1 = i
                elif (sum > maxsum):
                    maxsum = sum
                    p2 = i
                if (diff < mindiff):
                    mindiff = diff
                    p3 = i
                elif (diff > maxdiff):
                    maxdiff = diff
                    p4 = i

            maximum = max(maxsum - minsum, maxdiff - mindiff)
            
            if not need:
                if maxsum - minsum >= maxdiff - mindiff:
                    return (p1, p2)
                else:
                    return (p3, p4)

            return maximum

        n = len(points)

        p1, p2 = MaxDist(points, n, False)
        # print(p1, p2)
        lst = []
        for x in range(n):
            if x != p1:
                lst.append(points[x])
                
        # print(lst)
        rslt = MaxDist(lst, n - 1)
        lst = []
        
        for x in range(n):
            if x != p2:
                lst.append(points[x])
                
        # print(lst)
        # print()
        rslt = min(rslt, MaxDist(lst, n - 1))
        return rslt
