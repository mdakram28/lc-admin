class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        vector<int>pos;
        vector<int>neg;
        for(int i=0;i<n;i++){
           pos.push_back(points[i][0]+points[i][1]);
         neg.push_back(points[i][0]-points[i][1]);
        }
        multiset<int>s1;
        multiset<int>s2;
        for(auto it:pos)s1.insert(it);
        for(auto it:neg)s2.insert(it);
        int mini=INT_MAX;
        for(int i=0;i<n;i++){
            s1.erase(s1.find(pos[i]));
            s2.erase(s2.find(neg[i]));
            int a=*(s1.rbegin())-*(s1.begin());
            int b=*(s2.rbegin())-*(s2.begin());
            int k=max(a,b);
            mini=min(mini,k);
            s1.insert(pos[i]);
            s2.insert(neg[i]);
        }
        return mini;
    }
};