class Solution {
public:
    int minimumDistance(vector<vector<int>>& v) {
        vector<int> sum,diff;
        for(auto &x:v){
            sum.push_back(x[0]+x[1]);
            diff.push_back(x[0]-x[1]);
        }
        sort(sum.begin(),sum.end());
        sort(diff.begin(),diff.end());
        int ans = INT_MAX,n=v.size();
        for(auto &x:v){
            int s = x[0]+x[1];
            int d = x[0]-x[1];
            int mxs,mns,mxd,mnd;
            mns= sum[0]==s?sum[1]:sum[0];
            mxs= sum[n-1]==s?sum[n-2]:sum[n-1];
            mnd= diff[0]==d?diff[1]:diff[0];
            mxd= diff[n-1]==d?diff[n-2]:diff[n-1];
            ans=min(ans,max(mxs-mns,mxd-mnd));
        }
        return ans;
    }
};