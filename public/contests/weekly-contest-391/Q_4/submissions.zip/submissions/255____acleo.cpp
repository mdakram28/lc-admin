#include <array>
#include <cstdio>
#include <algorithm>
#include <cassert>
#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <bitset>
#define pb push_back
#define mk make_pair
#define eb emplace_back
#define eps 1e-8
#define fi first
#define se second
#define all(x) (x).begin(),(x).end()
using namespace std;

typedef long double ld;
typedef pair<int,int> pii;
typedef tuple<int, int, int> tiii;
typedef vector<int> vi;
typedef vector<pii> vii;
typedef vector<long double> vd;
const int inf = 1e9;
const long long INF = 1e18;

const int maxn = 5e5;
const int maxm = 5e5;
const int mod = 998244353;
void debug_out() { std::cout << std::endl; }
template <typename Head>
void debug_out(Head H) {
	std::cout << H << std::endl;
}

template <typename Head, typename... Tail>
void debug_out(Head H, Tail... T) {
	std::cout << H << ", ";
	debug_out(T...);
}

#ifdef DEBUG
#define debug(...) std::cout << "[" #__VA_ARGS__ "]: ", debug_out(__VA_ARGS__)
struct ListNode {
	int val;
	ListNode *next;
	ListNode() : val(0), next(nullptr) {}
	ListNode(int x) : val(x), next(nullptr) {}
	ListNode(int x, ListNode *next) : val(x), next(next) {}
};
#else
#define debug(...)
#endif

class Solution {
public:
    int minimumDistance(vector<vector<int>>& a) {
		int n = a.size();
		int ans = 0;
		int d = 2;
		int x, y;
		for(int i = 0 ; i < (1 << d); i ++ )
		{
			int maxv = -1e9, minv = 1e9;
			int tx, ty;
			for(int j = 0; j < n; j ++ )
			{
				int sum = 0;
				for(int k = 0 ; k < d ; k ++ )
				{
					if(i >> k & 1) sum += a[j][k];
					else sum -= a[j][k];
				}
				if (sum > maxv) {
					tx = j;
					maxv = sum;
				}
				if (sum < minv) {
					ty = j;
					minv = sum;
				}
			}
			if (ans < maxv - minv) {
				ans = maxv - minv;
				x = tx;
				y = ty;
			}
			// ans = max(ans, maxv - minv);
		}
		cout << ans << endl;
		int res = inf;
		ans = 0;
		for(int i = 0 ; i < (1 << d); i ++)
		{
			int maxv = -1e9, minv = 1e9;
			for(int j = 0; j < n; j ++ )
			{
				if (j == x) continue;
				int sum = 0;
				for(int k = 0 ; k < d ; k ++ )
				{
					if(i >> k & 1) sum += a[j][k];
					else sum -= a[j][k];
				}
				maxv = max(maxv, sum), minv = min(minv, sum);
			}
			ans = max(ans, maxv - minv);
		}
		res = min(res, ans);
		cout << ans << endl;
		ans = 0;
		for(int i = 0 ; i < (1 << d); i ++)
		{
			int maxv = -1e9, minv = 1e9;
			for(int j = 0; j < n; j ++ )
			{
				if (j == y) continue;
				int sum = 0;
				for(int k = 0 ; k < d ; k ++ )
				{
					if(i >> k & 1) sum += a[j][k];
					else sum -= a[j][k];
				}
				maxv = max(maxv, sum), minv = min(minv, sum);
			}
			ans = max(ans, maxv - minv);
		}
		res = min(res, ans);
		cout << ans << endl;

		cout << x << ' ' << y << endl;
		return res;
    }
};



#ifdef DEBUG
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
#ifdef DEBUG
	freopen("in", "r", stdin);
	freopen("out", "w", stdout);
#endif



	Solution lst;
	

	return 0;
}
#endif