from sortedcontainers import SortedList
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        # https://www.geeksforgeeks.org/maximum-manhattan-distance-between-a-distinct-pair-from-n-coordinates/
        n = len(points)
        sums = SortedList()
        diffs = SortedList()
        for i in range(n):
            sums.add((points[i][0] + points[i][1], i))
            diffs.add((points[i][0] - points[i][1], i))
        ans = float('inf')
        for i in range(n):
            sums.remove((points[i][0] + points[i][1], i))
            diffs.remove((points[i][0] - points[i][1], i))
            ans = min(ans, max(sums[-1][0] - sums[0][0], diffs[-1][0] - diffs[0][0]))
            sums.add((points[i][0] + points[i][1], i))
            diffs.add((points[i][0] - points[i][1], i))
        return ans