class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def MaxDist(A, N):
            minsum = maxsum = A[0][0] + A[0][1]
            mindiff = maxdiff = A[0][0] - A[0][1]
            minsum_p = A[0]
            maxsum_p = A[0]
            mindiff_p = A[0]
            maxdiff_p = A[0]
            for i in range(1,N):
                sum = A[i][0] + A[i][1]
                diff = A[i][0] - A[i][1]
                if (sum < minsum):
                    minsum = sum
                    minsum_p = A[i]
                elif (sum > maxsum):
                    maxsum = sum
                    maxsum_p = A[i]
                if (diff < mindiff):
                    mindiff = diff
                    mindiff_p = A[i]
                elif (diff > maxdiff):
                    maxdiff = diff
                    maxdiff_p = A[i]
            if maxsum - minsum > maxdiff - mindiff:
                return maxsum - minsum, minsum_p, maxsum_p
            return maxdiff - mindiff, mindiff_p, maxdiff_p
        
        max_distance, min_point, max_point = MaxDist(points, len(points))
        print(max_distance, min_point, max_point)
        if min_point==max_point==None:
            return max_distance
        
        temp = points[:]
        temp.remove(min_point)
        first_distance, _, _ = MaxDist(temp, len(temp))
        
        temp = points[:]
        temp.remove(max_point)
        second_distance, _, _ = MaxDist(temp, len(temp))
        
        return min(first_distance, second_distance)
 