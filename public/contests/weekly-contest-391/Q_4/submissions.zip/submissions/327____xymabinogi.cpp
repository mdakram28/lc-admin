class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<vector<int>> best(4, vector<int>(2, 0));
        for (int i = 0; i < 2; i++){ //[maxsum, maxdiff]
            for (int j = 0; j < 2; j++){
                best[i][j] = INT_MIN;
            }
        }
        for (int i = 2; i < 4; i++){ //[minsum, mindiff]
            for (int j = 0; j < 2; j++){
                best[i][j] = INT_MAX;
            }
        }
        
        
        for (int i = 0; i < n; i++){
            int x = points[i][0], y = points[i][1];
            int sum = x + y, diff = x - y;
            if (sum >= best[0][1]){
                best[0][1] = sum;
            }
            if (sum < best[2][1]) best[2][1] = sum;
            if (diff > best[1][1]) best[1][1] = diff;
            if (diff < best[3][1]) best[3][1] = diff;
            
            for (int j = 0; j < 2; j++){
                if (best[j][1] > best[j][0]) swap(best[j][1], best[j][0]);
            }
            for (int j = 2; j < 4; j++){
                if (best[j][1] < best[j][0]) swap(best[j][1], best[j][0]);
            }
        }
        // for (int i = 0; i < 4; i++){
        //     for (int j = 0; j < 2; j++){
        //         cout << best[i][j] << " \n"[j == 1];
        //     }
        // }
        
        
        int res = INT_MAX;
        for (int i = 0; i < n; i++){
            int x = points[i][0], y = points[i][1];
            int sum = x + y, diff = x - y;
            
            int maxsum = (best[0][0] == sum ? best[0][1] : best[0][0]);
            int minsum = (best[2][0] == sum ? best[2][1] : best[2][0]);
            int maxdiff = (best[1][0] == diff ? best[1][1] : best[1][0]);
            int mindiff = (best[3][0] == diff ? best[3][1] : best[3][0]);
            res = min(res, max(maxsum - minsum, maxdiff - mindiff));
        }
        return res;
        
        
        
        
    }
};