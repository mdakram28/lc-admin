class Solution {
    public int minimumDistance(int[][] ps) {
        int n=ps.length;
        int res=Integer.MAX_VALUE/2;
        
        TreeMap<Integer,Integer>[] ts=new TreeMap[4];
        for(int i=0;i<4;i++){
            ts[i]=new TreeMap();
        }
        for(int i=0;i<n;i++){
            int[] cv=new int[4];
            cv[0]=ps[i][0]+ps[i][1];
            cv[1]=ps[i][0]-ps[i][1];
            cv[2]=-ps[i][0]+ps[i][1];
            cv[3]=-ps[i][0]-ps[i][1];
            
            for(int j=0;j<4;j++){
                ts[j].put(cv[j],ts[j].getOrDefault(cv[j],0)+1);
            }
        }
        
        for(int i=0;i<n;i++){
            int[] cv=new int[4];
            cv[0]=ps[i][0]+ps[i][1];
            cv[1]=ps[i][0]-ps[i][1];
            cv[2]=-ps[i][0]+ps[i][1];
            cv[3]=-ps[i][0]-ps[i][1];
            
            for(int j=0;j<4;j++){
                int cc=ts[j].get(cv[j]);
                if(cc==1){
                    ts[j].remove(cv[j]);
                }else{
                    ts[j].put(cv[j],cc-1);
                }
            }
            int cmax=0;
            for(int j=0;j<4;j++){
                int first=ts[j].firstKey(),last=ts[j].lastKey();
                cmax=Math.max(cmax,last-first);
            }
            res=Math.min(res,cmax);
            
            for(int j=0;j<4;j++){
                ts[j].put(cv[j],ts[j].getOrDefault(cv[j],0)+1);
            }
            
        }
        
        
        return res;
    }
}