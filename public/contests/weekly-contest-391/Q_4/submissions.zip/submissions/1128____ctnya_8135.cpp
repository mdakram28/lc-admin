class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        multiset<pair<int, int>> s1, s2;
        int sd, dd, ans = 3e8;
        for (int i = 0; i < n; i++) {
            sd = points[i][0] + points[i][1];
            dd = points[i][0] - points[i][1];
            s1.insert({sd, dd});
            s2.insert({dd, sd});
        }
        function<void(pair<int, int>)> rc = [&](pair<int, int> cur) {
            s1.erase(s1.find(cur));
            s2.erase(s2.find({cur.second, cur.first}));
            ans = min(ans, max(s1.rbegin()->first - s1.begin()->first, s2.rbegin()->first - s2.begin()->first));
            s1.insert(cur); s2.insert({cur.second, cur.first});
        };
        rc(*s1.begin());
        rc(*s1.rbegin());
        rc({s2.begin()->second, s2.begin()->first});
        rc({s2.rbegin()->second, s2.rbegin()->first});
        return ans;
    }
};