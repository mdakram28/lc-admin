def max_distance_brute(points: List[List[int]]) -> int:
    n = len(points)
    max_dist = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            _, x1, y1 = points[i]
            _, x2, y2 = points[j]
            max_dist = max(max_dist, abs(x2 - x1) + abs(y2 - y1))
    return max_dist

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        # Find the center
        avg_x = sum([p[0] for p in points]) / len(points)
        avg_y = sum([p[1] for p in points]) / len(points)
        
        # Quadrant maxima
        h1 = []
        h2 = []
        h3 = []
        h4 = []
        
        #
        for x, y in points:
            dist = abs(avg_x - x) + abs(avg_y - y)
            if x >= avg_x and y >= avg_y:
                heapq.heappush(h1, (dist, x, y))
                if len(h1) > 2:
                    heapq.heappop(h1)
            elif x >= avg_x and y < avg_y:
                heapq.heappush(h2, (dist, x, y))
                if len(h2) > 2:
                    heapq.heappop(h2)
            elif x < avg_x and y >= avg_y:
                heapq.heappush(h3, (dist, x, y))
                if len(h3) > 2:
                    heapq.heappop(h3)
            else:
                heapq.heappush(h4, (dist, x, y))
                if len(h4) > 2:
                    heapq.heappop(h4)
                    
        # Get the candidates
        pts = h1 + h2 + h3 + h4
        
        # Find the points to drop
        n = len(pts)
        ret = None
        for i in range(n):
            new_pts = pts[:i] + pts[i + 1:]
            max_dist = max_distance_brute(new_pts)
            if ret is None:
                ret = max_dist
            else:
                ret = min(ret, max_dist)
        return ret
            
        
                