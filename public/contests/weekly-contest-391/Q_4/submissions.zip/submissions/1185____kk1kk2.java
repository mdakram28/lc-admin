class Solution {
    public int calc(int a, int b, int c, int d)
    {
        // System.out.println(a + " "+b+ " "+c+ " "+ d);
        return Math.max(a - b, c -d );
    }
    public int minimumDistance(int[][] points) {
        int n = points.length;
        int sum[][] = new int[n][2];
        int diff[][] = new int[n][2];
                
        for(int i=0;i<n; i++)
        {
            sum [i][0] = points[i][0] + points[i][1];
            diff [i][0] = points[i][0] - points[i][1];
            sum [i][1] = i;
            diff [i][1] = i;
            
        }
        Arrays.sort(sum, (a,b)->Integer.compare(a[0],b[0]));
        Arrays.sort(diff, (a,b)->Integer.compare(a[0],b[0]));
        
        //  for(int i=0;i<n; i++)
        // {
        //      System.out.println(diff[i][0]);
        //  }
        int ans = calc(sum[n-2][0], sum[0][0], sum[n-1][1]==diff[n-1][1]?diff[n-2][0]:diff[n-1][0], 
                                        sum[n-1][1]==diff[0][1]?diff[1][0]:diff[0][0]);
        
        ans = Math.min(ans,
                       calc(sum[n-1][0], sum[1][0], sum[0][1]==diff[n-1][1]?diff[n-2][0]:diff[n-1][0], 
                                        sum[0][1]==diff[0][1]?diff[1][0]:diff[0][0])
                      );
        ans = Math.min(ans,
                       calc(diff[n-2][0], diff[0][0], diff[n-1][1]==sum[n-1][1]?sum[n-2][0]:sum[n-1][0], 
                                        diff[n-1][1]==sum[0][1]?sum[1][0]:sum[0][0])
                      );
        
        ans = Math.min(ans,
                       calc(diff[n-1][0], diff[1][0], diff[0][1]==sum[n-1][1]?sum[n-2][0]:sum[n-1][0], 
                                        diff[0][1]==sum[0][1]?sum[1][0]:sum[0][0])
                      );
            
        return ans;
        
    }
}