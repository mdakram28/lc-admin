class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<pair<int,int>>v1,v2;
        for(int i=0;i<points.size();i++) {
            v1.push_back({points[i][0]+points[i][1],i});
            v2.push_back({points[i][0]-points[i][1],i});
        }
        
        sort(v1.begin(),v1.end());
        sort(v2.begin(),v2.end());
        int n=v1.size();
        int ans=INT_MAX;
        // max(v1[n-1]-v1[0],v2[n-1]-v2[0])
        int a=0,b=n-1,c=0,d=n-1;
        // v1 ki 0th
        int idx=v1[0].second;
        a=1;
        if(v2[0].second==idx) c=1;
        if(v2[n-1].second==idx) d=n-2;
        ans=min(ans,max(v1[b].first-v1[a].first,v2[d].first-v2[c].first));
        
        // v1 ki n-1th
        a=0,b=n-1,c=0,d=n-1;
        idx=v1[n-1].second;
        b=n-2;
        if(v2[0].second==idx) c=1;
        if(v2[n-1].second==idx) d=n-2;
        ans=min(ans,max(v1[b].first-v1[a].first,v2[d].first-v2[c].first));
        
        // v2 ki 0th
        a=0,b=n-1,c=0,d=n-1;
        idx=v2[0].second;
        c=1;
        if(v1[0].second==idx) a=1;
        if(v1[n-1].second==idx) b=n-2;
        ans=min(ans,max(v1[b].first-v1[a].first,v2[d].first-v2[c].first));
        
        // v2 ki 0th
        a=0,b=n-1,c=0,d=n-1;
        idx=v2[n-1].second;
        d=n-2;
        if(v1[0].second==idx) a=1;
        if(v1[n-1].second==idx) b=n-2;
        ans=min(ans,max(v1[b].first-v1[a].first,v2[d].first-v2[c].first));
        
        return ans;
    }
};