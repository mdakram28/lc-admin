from sortedcontainers import SortedList
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        N = len(points)

        SUMS = [0] * N
        DIFFS = [0] * N

        for i in range(N):
            SUMS[i] = points[i][0] + points[i][1]
            DIFFS[i] = points[i][0] - points[i][1]
            
        SUMS = SortedList(SUMS)
        DIFFS = SortedList(DIFFS)
        
        RES = float('inf')
        
        
        for x, y in points:
            s = x + y
            d = x - y
            SUMS.remove(s)
            DIFFS.remove(d)
            cur_res = max(SUMS[-1] - SUMS[0], DIFFS[-1] - DIFFS[0])
            SUMS.add(s)
            DIFFS.add(d)
            RES = min(RES, cur_res)

        return RES
