class Solution {
public:
    int brute(vector<vector<int>> &p, int skip){
        int n = p.size();
        vector<int> sum;
        vector<int> sub;
        for(int i = 0; i < n;i++){
            if(i == skip) continue;
            sum.push_back(p[i][0] + p[i][1]);
            sub.push_back(p[i][0] - p[i][1]);
        }
        sort(sum.begin(), sum.end());
        sort(sub.begin(), sub.end());
        return max(sum.back() - sum.front(), sub.back() - sub.front());
    }
    int minimumDistance(vector<vector<int>>& p) {
        // can remove 1 such that minimize the maximum
        int n = p.size();
        vector<pair<int, int>> sum;
        vector<pair<int, int>> sub;
        for(int i = 0; i < n;i++){
            sum.push_back({p[i][0] + p[i][1], i});
            sub.push_back({p[i][0] - p[i][1], i});
        }
        sort(sum.begin(), sum.end());
        sort(sub.begin(), sub.end());
        int ans = 1e9;
        ans = min(ans, brute(p, sum.front().second));
        ans = min(ans, brute(p, sum.back().second));
        ans = min(ans, brute(p, sub.front().second));
        ans = min(ans, brute(p, sub.back().second));
        return ans;
        
    }
};