class Solution {
public:
    #define x first
    #define y second
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<int> x(n + 1), y(n + 1);
        vector<vector<pair<int,int>>> p(4, vector<pair<int,int>>(n + 1));
        for(int i = 0; i < n; i ++){
            x[i + 1] = points[i][0];
            y[i + 1] = points[i][1];
        }
        for(int i=1;i<=n;i++)
        {
            p[0][i]={x[i]+y[i],i};
            p[1][i]={-x[i]+y[i],i};
            p[2][i]={x[i]-y[i],i};
            p[3][i]={-x[i]-y[i],i};
        }
        for(int i=0;i<4;i++){
            sort(p[i].begin() + 1, p[i].end());
        }
        int mx=0;
        int a, b;
        for(int i=0;i<4;i++)
        {
            if(p[i][n].x-p[i][1].x > mx){
                mx = p[i][n].x-p[i][1].x;
                a = p[i][n].y, b = p[i][1].y;
            }
        }
        // cout << a << " " << b << " "<<mx << endl;
        int mn = 1e9;
        mx = -1;
        for(int i=0;i<4;i++)
        {
            for(int i=0;i<4;i++)
            {
                if(p[i][n].y == a){
                    mx = max(mx, p[i][n - 1].x - p[i][1].x);
                }
                if(p[i][1].y == a){
                    mx = max(mx, p[i][n].x - p[i][2].x);
                }

                if(p[i][n].y != a && p[i][1].y != a){
                    mx = max(mx, p[i][n].x-p[i][1].x);
                }
            }
        }
        mn = min(mn, mx);
        mx = -1;
        for(int i=0;i<4;i++)
        {
            if(p[i][n].y == b){
                mx = max(mx, p[i][n - 1].x - p[i][1].x);
            }
            if(p[i][1].y == b){
                mx = max(mx, p[i][n].x - p[i][2].x);
            }
            
            if(p[i][n].y != b && p[i][1].y != b){
                mx = max(mx, p[i][n].x-p[i][1].x);
            }
        }
        mn = min(mn, mx);
        return mn;

    }
};