class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        x,y = points[0]
        a = [x+y,x+y,x-y,x-y]
        b = [inf,-inf,inf,-inf]
        cnt = [[0] for _ in range(4)]
        for i,(x,y) in enumerate(points):
            if i == 0: continue
            c, d = x + y, x - y
            if c < a[0]: a[0], b[0], cnt[0] = c, a[0], [i]
            elif c == a[0]: cnt[0].append(i)
            elif c < b[0]: b[0] = c
            if c > a[1]: a[1], b[1], cnt[1] = c, a[1], [i]
            elif c == a[1]: cnt[1].append(i)
            elif c > b[1]: b[1] = c
            if d < a[2]: a[2], b[2], cnt[2] = d, a[2], [i]
            elif d == a[2]: cnt[2].append(i)
            elif d < b[2]: b[2] = d
            if d > a[3]: a[3], b[3], cnt[3] = d, a[3], [i]
            elif d == a[3]: cnt[3].append(i)
            elif d > b[3]: b[3] = d
        # print(a,b,cnt)
        c,d = a[1] - a[0], a[3] - a[2]
        # print(c,d)
        res = set()
        if c > d:
            if len(cnt[0]) > 1 and len(cnt[1]) > 1: return c
            if len(cnt[0]) == 1: res.add(cnt[0][0])
            if len(cnt[1]) == 1: res.add(cnt[1][0])
        elif d > c:
            if len(cnt[2]) > 1 and len(cnt[3]) > 1: return d
            if len(cnt[2]) == 1: res.add(cnt[2][0])
            if len(cnt[3]) == 1: res.add(cnt[3][0])
        else:
            if (len(cnt[0]) > 1 and len(cnt[1]) > 1) or (len(cnt[2]) > 1 and len(cnt[3]) > 1): return c
            for i in [0,1]:
                for j in [2,3]:
                    if len(cnt[i]) == 1 and len(cnt[j]) == 1 and cnt[i][0] == cnt[j][0]: res.add(cnt[i][0])
        # print(res)
        ans = max(c,d)
        for x in res:
            e = [-1] * 4
            for i in range(4):
                if x in cnt[i] and len(cnt[i]) == 1: e[i] = b[i]
                else: e[i] = a[i]
            score = max(e[1]-e[0],e[3]-e[2])
            # print(x,e,score)
            ans = min(ans, score)
        return ans