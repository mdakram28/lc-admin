#define inf (1000000000)
#define ninf (-1000000000)
class Solution {
public:
    int dist(vector<int> &l, vector<int> &r) {
        return abs(r[0] - l[0]) + abs(r[1] - l[1]);
    }
    pair<vector<int>, vector<int>> maxDist(vector<vector<int>> &points) {
        vector<int> bl = {ninf, ninf}, tl = {inf, ninf}, br = {ninf, inf}, tr = {inf, inf};
        for(vector<int> &point : points) {
            if(point[0] + point[1] > bl[0] + bl[1]) bl = point;
            if(point[0] - point[1] > br[0] - br[1]) br = point;
            if(- point[0] + point[1] > - tl[0] + tl[1]) tl = point;
            if(- point[0] - point[1] > - tr[0] - tr[1]) tr = point;
        }
        vector<vector<int>> c = {bl, tl, br, tr};
        pair<vector<int>, vector<int>> res = {{0, 0}, {0, 0}};
        for(int i = 0; i < 4; ++ i) {
            if(c[i][0] == inf || c[i][1] == ninf) continue;
            for(int j = i + 1; j < 4; ++ j) {
                if(c[j][0] == inf || c[j][1] == ninf) continue;
                if(dist(c[i], c[j]) > dist(res.first, res.second)) res = {c[i], c[j]};
            }
        }
        return res;
    }
    int minimumDistance(vector<vector<int>>& points) {
        pair<vector<int>, vector<int>> p = maxDist(points);
        vector<int> a = p.first, b = p.second;
        vector<vector<int>> tmp1, tmp2;
        bool u = true, v = true;
        for(vector<int> &point : points) {
            if(u == true && dist(point, a) == 0) {
                u = false;
            }
            else {
                tmp1.push_back(point);
            }
            if(v == true && dist(point, b) == 0) {
                v = false;
            }
            else {
                tmp2.push_back(point);
            }
        }
        auto x = maxDist(tmp1), y = maxDist(tmp2);
        return min(dist(x.first, x.second), dist(y.first, y.second));
    }
};