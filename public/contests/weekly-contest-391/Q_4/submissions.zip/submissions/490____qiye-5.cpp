int X[100'003], Y[100'003];
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        for (int i = 0; i < n; ++i) X[i] = points[i][0] + points[i][1], Y[i] = points[i][0] - points[i][1];
        // for (int i = 0; i < n; ++i) cout << X[i] << " " << endl;
        // for (int i = 0; i < n; ++i) cout << Y[i] << " " << endl;

        X[n] = min_element(X, X + n) - X;
        X[n + 1] = max_element(X, X + n) - X;
        Y[n] = min_element(Y, Y + n) - Y;
        Y[n + 1] = max_element(Y, Y + n) - Y;

        auto CalRemove = [&](int *f, int k) {
            int min_k = f[n], max_k = f[n + 1];
            if (k == min_k) {
                int y = INT_MAX;
                for (int i = 0; i < n; ++i)if (i != k && y > f[i]) y = f[min_k = i];
            }

            if (k == max_k) {
                int y = INT_MIN;
                for (int i = 0; i < n; ++i) if (i != k && y < f[i]) y = f[max_k = i];
            }
            return f[max_k] - f[min_k];
        };

        int res = INT_MAX;
        for (int i = 0; i < n; ++i) {
            // cout << CalRemove(X, i) + CalRemove(Y, i) << endl;
            res = min(res, max(CalRemove(X, i), CalRemove(Y, i)));
        }
        return res;
    }
};