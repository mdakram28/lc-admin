class Solution {
    private int cal(List<int[]> points) 
    {
        int n = points.size();
        List<int[]>[] p = new List[4];
        for (int i = 0; i < 4; i++) {
            p[i] = new ArrayList<>();
        }
        for (int i = 0; i < n; i++) {
            int xi = points.get(i)[0];
            int yi = points.get(i)[1];
            p[0].add(new int[]{xi + yi, i});
            p[1].add(new int[]{-xi + yi, i});
            p[2].add(new int[]{xi - yi, i});
            p[3].add(new int[]{-xi - yi, i});
        }
        for (int i = 0; i < 4; i++) {
            p[i].sort((a, b) -> Integer.compare(a[0], b[0]));
        }

        int mx = 0;
        int pos1 = 0, pos2 = 0;
        for (int i = 0; i < 4; i++) {
            int tmp = p[i].get(p[i].size() - 1)[0] - p[i].get(0)[0];
            if (tmp > mx) {
                mx = tmp;
                pos1 = p[i].get(p[i].size() - 1)[1];
                pos2 = p[i].get(0)[1];
            }
        }
        return mx;
    }
    
    public int minimumDistance(int[][] points) {
        int n = points.length;
        List<int[]>[] p = new List[4];
        for (int i = 0; i < 4; i++) {
            p[i] = new ArrayList<>();
        }
        for (int i = 0; i < n; i++) {
            int xi = points[i][0];
            int yi = points[i][1];
            p[0].add(new int[]{xi + yi, i});
            p[1].add(new int[]{-xi + yi, i});
            p[2].add(new int[]{xi - yi, i});
            p[3].add(new int[]{-xi - yi, i});
        }
        for (int i = 0; i < 4; i++) {
            p[i].sort((a, b) -> Integer.compare(a[0], b[0]));
        }

        int mx = 0;
        int pos1 = 0, pos2 = 0;
        for (int i = 0; i < 4; i++) {
            int tmp = p[i].get(p[i].size() - 1)[0] - p[i].get(0)[0];
            if (tmp > mx) {
                mx = tmp;
                pos1 = p[i].get(p[i].size() - 1)[1];
                pos2 = p[i].get(0)[1];
            }
        }

        List<int[]> pointsList1 = new ArrayList<>(Arrays.asList(points));
        pointsList1.remove(pos1);
        mx = Math.min(mx, cal(pointsList1));

        List<int[]> pointsList2 = new ArrayList<>(Arrays.asList(points));
        pointsList2.remove(pos2);
        mx = Math.min(mx, cal(pointsList2));

        return mx;
    }
}
