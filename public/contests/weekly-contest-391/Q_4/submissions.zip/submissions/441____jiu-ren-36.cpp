class Solution {
public:
    int minimumDistance(vector<vector<int>>& po) {
        multiset<int> st[4];
        for(auto i: po)
        {
            st[0].insert(i[0] + i[1]);
            st[1].insert(-i[0] + i[1]);
            st[2].insert(-i[0] - i[1]);
            st[3].insert(i[0] - i[1]);
        }
        // cout << st[0].size() << ' ';
        int n = po.size();
        int res = 1e9;
        for(auto i: po)
        {
            int mx = 0;
            auto it = st[0].lower_bound(i[0] + i[1]);
            auto it1 = st[1].lower_bound(-i[0] + i[1]);
            auto it2 = st[2].lower_bound(-i[0] - i[1]);
            auto it3 = st[3].lower_bound(i[0] - i[1]);
            st[0].erase(it);
            st[1].erase(it1);
            st[2].erase(it2);
            st[3].erase(it3);
            mx = max(mx, *st[0].rbegin() - *st[0].begin());
            mx = max(mx, *st[1].rbegin() - *st[1].begin());
            mx = max(mx, *st[2].rbegin() - *st[2].begin());
            mx = max(mx, *st[3].rbegin() - *st[3].begin());
            res = min(res, mx);
            st[0].insert(i[0] + i[1]);
            st[1].insert(-i[0] + i[1]);
            st[2].insert(-i[0] - i[1]);
            st[3].insert(i[0] - i[1]);
        }
        return res;
        
    }
};