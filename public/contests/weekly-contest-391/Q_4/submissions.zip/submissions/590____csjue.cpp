class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int j1 = 0;
        int j2 = 0;
        find(points,&j1,&j2);
        // cout<<j1<<" "<<j2<<endl;
        int x = find2(points,j1);
        int y = find2(points,j2);
        // cout<<x<<" "<<y<<endl;
        return min(x,y);
    }
    void find(vector<vector<int>>& points, int*j1, int*j2){
        int n = points.size();
        vector<vector<pair<int,int>>> v(4,vector<pair<int,int>>(n));
        int d1 = 0;
        int d2 = 0;
        for(int i = 0; i < n; i++){
            v[0][i] = {points[i][0]+points[i][1],i};
            v[1][i] = {points[i][0]-points[i][1],i};
            v[2][i] = {-points[i][0]+points[i][1],i};
            v[3][i] = {-points[i][0]-points[i][1],i};
        }
        for(int i=0;i<4;i++)sort(v[i].begin(),v[i].end());

        for(int i=0;i<4;i++)
        {
            if(v[i][n-1].first-v[i][0].first>d1){
                *j1 = v[i][n-1].second;
                *j2 = v[i][0].second;
                d1 = v[i][n-1].first-v[i][0].first;
            }
        }

    }
    int find2(vector<vector<int>>& points, int j1){
        int n = points.size();
        vector<vector<pair<int,int>>> v(4);
        int d1 = 0;
        int d2 = 0;
        for(int i = 0; i < n; i++){
            if(i==j1)
                continue;
            v[0].push_back({points[i][0]+points[i][1],i});
            v[1].push_back({points[i][0]-points[i][1],i});
            v[2].push_back({-points[i][0]+points[i][1],i});
            v[3].push_back({-points[i][0]-points[i][1],i});
        }
        for(int i=0;i<4;i++)sort(v[i].begin(),v[i].end());

        for(int i=0;i<4;i++)
        {
            if(v[i][n-2].first-v[i][0].first>d1){
                d1 = v[i][n-2].first-v[i][0].first;
            }
        }
        return d1;
    }
};