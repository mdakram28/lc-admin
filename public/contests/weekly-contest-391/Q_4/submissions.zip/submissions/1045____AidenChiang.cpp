class Solution {
public:
    int getDistance(vector<int> &p1, vector<int> &p2) {
        return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1]);
    }
    
    int getMaximumAfterRemoveI(vector<pair<int, int>> &arr, int i) {
        if(arr.back().second == i)
            return arr[arr.size() - 2].first - arr[0].first;
        if(arr.front().second == i)
            return arr.back().first - arr[1].first;
        return arr.back().first - arr.front().first;
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<pair<int, int>> sum(n), diff(n);
        for(int i = 0; i < n; i++) {
            sum[i] = {points[i][0] + points[i][1], i};
            diff[i] = {points[i][0] - points[i][1], i};
        }
        sort(sum.begin(), sum.end());
        sort(diff.begin(), diff.end());
        // for(auto &s: sum) {
        //     cout << s << " ";
        // }
        // cout << "\n";
        // cout << abs(sum[n-1] - sum[0]) << " " <<  abs(diff[n-1] - diff[0]) << "\n";
        if(sum[n-1].first - sum[0].first > diff[n-1].first - diff[0].first) {
            int res1 = max(getMaximumAfterRemoveI(sum, sum[n-1].second), getMaximumAfterRemoveI(diff, sum[n-1].second));
            int res2 = max(getMaximumAfterRemoveI(sum, sum[0].second), getMaximumAfterRemoveI(diff, sum[0].second));
            return min(res1, res2);
        }
        else {
            int res1 = max(getMaximumAfterRemoveI(sum, diff[n-1].second), getMaximumAfterRemoveI(diff, diff[n-1].second));
            int res2 = max(getMaximumAfterRemoveI(sum, diff[0].second), getMaximumAfterRemoveI(diff, diff[0].second));
            return min(res1, res2);
        }
    }
};