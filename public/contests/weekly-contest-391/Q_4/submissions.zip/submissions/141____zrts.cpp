class Solution {
    int mn[4];
    int mn_pos[4];
    int s1[4]={1,1,-1,-1};
    int s2[4]={1,-1,1,-1};
public:
    int minimumDistance(vector<vector<int>>& a) {
        int n = a.size();
        for(int i=0;i<4;i++) mn[i] = 1e9;
        int mx = -1;
        int pos1=-1,pos2=-1;
        for(int i=0;i<n;i++){
            for(int k=0;k<4;k++){
                int sum = a[i][0] * s1[k] + a[i][1] * s2[k];
                // printf("## %d %d %d %d\n",mx, sum, mn[k], k);
                if(i>0){
                    if((sum) - mn[k]>mx){
                        mx = (sum) - mn[k];
                        pos1 = i;
                        pos2 = mn_pos[k];
                    }
                }
                if(sum < mn[k]){
                    mn[k] = sum;
                    mn_pos[k] = i;
                }
            }
        }

        int final_ans = mx;
        // try del pos1
        for(int i=0;i<4;i++) mn[i] = 1e9;
         mx = -1;
        for(int i=0;i<n;i++){
            if(i==pos1) continue;
            for(int k=0;k<4;k++){
                int sum = a[i][0] * s1[k] + a[i][1] * s2[k];
                // printf("## %d %d %d %d\n",mx, sum, mn[k], k);
                if(i>0){
                    if((sum) - mn[k]>mx){
                        mx = (sum) - mn[k];
                    }
                }
                if(sum < mn[k]){
                    mn[k] = sum;
                    mn_pos[k] = i;
                }
            }
        }
        final_ans = min(final_ans, mx);
        
        // try del pos1
        for(int i=0;i<4;i++) mn[i] = 1e9;
         mx = -1;
        for(int i=0;i<n;i++){
            if(i==pos2) continue;
            for(int k=0;k<4;k++){
                int sum = a[i][0] * s1[k] + a[i][1] * s2[k];
                // printf("## %d %d %d %d\n",mx, sum, mn[k], k);
                if(i>0){
                    if((sum) - mn[k]>mx){
                        mx = (sum) - mn[k];
                    }
                }
                if(sum < mn[k]){
                    mn[k] = sum;
                    mn_pos[k] = i;
                }
            }
        }
        
        final_ans = min(final_ans, mx);
        
        
        return final_ans;
    }
};