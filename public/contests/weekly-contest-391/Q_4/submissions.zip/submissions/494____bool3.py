class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        pts1, pts2 = [], []
        for i in range(len(points)):
            x, y = points[i]
            pts1.append((x+y, i))
            pts2.append((x-y, i))
        pts1.sort(); pts2.sort()
        ans = 0
        a, b = pts1[-1][0]-pts1[0][0], pts2[-1][0]-pts2[0][0]
        print(a, b)
        if a == max(a, b):
            iptss, iptsd = [], []
            for i in range(len(points)):
                if i == pts1[0][1]: continue
                x, y = points[i]
                iptss.append(x+y)
                iptsd.append(x-y)
            iptss.sort(); iptsd.sort()
            rf = max(iptss[-1]-iptss[0], iptsd[-1]-iptsd[0])
            iptss, iptsd = [], []
            for i in range(len(points)):
                if i == pts1[-1][1]: continue
                x, y = points[i]
                iptss.append(x+y)
                iptsd.append(x-y)
            iptss.sort(); iptsd.sort()
            rl = max(iptss[-1]-iptss[0], iptsd[-1]-iptsd[0])
            ans = min(rf, rl)
        else:
            iptss, iptsd = [], []
            for i in range(len(points)):
                if i == pts2[0][1]: continue
                x, y = points[i]
                iptss.append(x+y)
                iptsd.append(x-y)
            iptss.sort(); iptsd.sort()
            rf = max(iptss[-1]-iptss[0], iptsd[-1]-iptsd[0])
            iptss, iptsd = [], []
            for i in range(len(points)):
                if i == pts2[-1][1]: continue
                x, y = points[i]
                iptss.append(x+y)
                iptsd.append(x-y)
            iptss.sort(); iptsd.sort()
            rl = max(iptss[-1]-iptss[0], iptsd[-1]-iptsd[0])
            ans = min(rf, rl)
        return ans