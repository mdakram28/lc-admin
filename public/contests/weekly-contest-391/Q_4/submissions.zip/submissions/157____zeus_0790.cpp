class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> ms1,ms2;
        int n=points.size();
        for(int i=0;i<n;i++){
            ms1.insert(points[i][0]+points[i][1]);
            ms2.insert(points[i][0]-points[i][1]);
        }
        long long int ans=1e9;
        for(int i=0;i<n;i++){
            ms1.erase(ms1.find(points[i][0]+points[i][1]));
            ms2.erase(ms2.find(points[i][0]-points[i][1]));
            long long int maxi1=(*(--ms1.end()))-(*ms1.begin());
            long long int maxi2=(*(--ms2.end()))-(*ms2.begin());
            ans=min(ans,max(maxi1,maxi2));
            ms1.insert((points[i][0]+points[i][1]));
            ms2.insert((points[i][0]-points[i][1]));
        }
        return ans;
    }
};