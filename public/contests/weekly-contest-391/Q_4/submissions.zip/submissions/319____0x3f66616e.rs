impl Solution {
    pub fn minimum_distance(ps: Vec<Vec<i32>>) -> i32 {
        let n = ps.len();
        let mut indices: Vec<_> = (0..n).collect();
        let mut max = vec![i32::MIN; n];
        
        indices.sort_unstable_by_key(|&i| ps[i][0] + ps[i][1]);
        let dist = |l: usize, r: usize| {
            ps[indices[r]][0] + ps[indices[r]][1] - ps[indices[l]][0] - ps[indices[l]][1]
        };
        for (i, &idx) in indices.iter().enumerate() {
            if i == 0 {
                max[idx] = max[idx].max(dist(1, n - 1));
            } else if i == n - 1 {
                max[idx] = max[idx].max(dist(0, n - 2));
            } else {
                max[idx] = max[idx].max(dist(0, n - 1));
            }
        }
        
        indices.sort_unstable_by_key(|&i| ps[i][0] - ps[i][1]);
        let dist = |l: usize, r: usize| {
            ps[indices[r]][0] - ps[indices[r]][1] - (ps[indices[l]][0] - ps[indices[l]][1])
        };
        for (i, &idx) in indices.iter().enumerate() {
            if i == 0 {
                max[idx] = max[idx].max(dist(1, n - 1));
            } else if i == n - 1 {
                max[idx] = max[idx].max(dist(0, n - 2));
            } else {
                max[idx] = max[idx].max(dist(0, n - 1));
            }
        }
        
        indices.sort_unstable_by_key(|&i| -ps[i][0] + ps[i][1]);
        let dist = |l: usize, r: usize| {
            -ps[indices[r]][0] + ps[indices[r]][1] - (-ps[indices[l]][0] + ps[indices[l]][1])
        };
        for (i, &idx) in indices.iter().enumerate() {
            if i == 0 {
                max[idx] = max[idx].max(dist(1, n - 1));
            } else if i == n - 1 {
                max[idx] = max[idx].max(dist(0, n - 2));
            } else {
                max[idx] = max[idx].max(dist(0, n - 1));
            }
        }
        
        indices.sort_unstable_by_key(|&i| -ps[i][0] - ps[i][1]);
        let dist = |l: usize, r: usize| {
            -ps[indices[r]][0] - ps[indices[r]][1] - (-ps[indices[l]][0] - ps[indices[l]][1])
        };
        for (i, &idx) in indices.iter().enumerate() {
            if i == 0 {
                max[idx] = max[idx].max(dist(1, n - 1));
            } else if i == n - 1 {
                max[idx] = max[idx].max(dist(0, n - 2));
            } else {
                max[idx] = max[idx].max(dist(0, n - 1));
            }
        }
        
        *max.iter().min().unwrap()
    }
}