class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int l = INT_MAX, r = INT_MIN, u = INT_MIN, d = INT_MAX;
        int l_id = -1, r_id = -1, u_id = -1, d_id = -1;
        int n = points.size();
        for (int i = 0; i < n; i++) {
            if (points[i][0] - points[i][1] > r) {
                r = points[i][0] - points[i][1];
                r_id = i;
            }
            if (points[i][0] - points[i][1] < l) {
                l = points[i][0] - points[i][1];
                l_id = i;
            }
            if (points[i][0] + points[i][1] > u) {
                u = points[i][0] + points[i][1];
                u_id = i;
            }
            if (points[i][0] + points[i][1] < d) {
                d = points[i][0] + points[i][1];
                d_id = i;
            }
        }
       vector<int> ids = {l_id, r_id, u_id, d_id};
       int ans = INT_MAX;
       for (auto &id : ids) {
           int l1 = INT_MAX, r1 = INT_MIN, u1 = INT_MIN, d1 = INT_MAX;
           for (int i = 0; i < n; i++) {
               if (i == id) continue;
               l1 = min(l1, points[i][0] - points[i][1]);
               r1 = max(r1, points[i][0] - points[i][1]);
               u1 = max(u1, points[i][0] + points[i][1]);
               d1 = min(d1, points[i][0] + points[i][1]);
           }
           ans = min(ans, max(r1-l1, u1-d1));
       }
       return ans;
    }
};