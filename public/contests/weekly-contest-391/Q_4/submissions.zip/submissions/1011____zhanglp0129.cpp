class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        vector<pair<int,int>> sum(n), sub(n);
        for(int i=0;i<n;i++) {
            sum[i].first=points[i][0]+points[i][1];
            sum[i].second=i;
            sub[i].first=points[i][0]-points[i][1];
            sub[i].second=i;
        }
        
        sort(sum.begin(), sum.end());
        sort(sub.begin(), sub.end());
        // max(sum.back()-sum[0], sub.back()-sub[0]);
        int ans=max(sum.back().first-sum[0].first, sub.back().first-sub[0].first);
        
        int index;
        int right;
        int left;
        // 删除sum的最大
        index=sum.back().second;
        right=sub.back().first-sub[0].first;
        if(sub[0].second==index) {
            right=sub.back().first-sub[1].first;
        }else if(sub.back().second==index) {
            right=sub[n-2].first-sub[0].first;
        }
        ans=min(ans, max(sum[n-2].first-sum[0].first, right));
        
        // 删除sum的最小
        index=sum[0].second;
        right=sub.back().first-sub[0].first;
        if(sub[0].second==index) {
            right=sub.back().first-sub[1].first;
        }else if(sub.back().second==index) {
            right=sub[n-2].first-sub[0].first;
        }
        ans=min(ans, max(sum[n-1].first-sum[1].first, right));
        
        // 删除sub的最大
        index=sub.back().second;
        left=sum.back().first-sum[0].first;
        if(sum[0].second==index) {
            left=sum.back().first-sum[1].first;
        }else if(sum.back().second==index) {
            left=sum[n-2].first-sum[0].first;
        }
        ans=min(ans, max(left, sub[n-2].first-sub[0].first));
        
        // 删除sub的最小
        index=sub[0].second;
        left=sum.back().first-sum[0].first;
        if(sum[0].second==index) {
            left=sum.back().first-sum[1].first;
        }else if(sum.back().second==index) {
            left=sum[n-2].first-sum[0].first;
        }
        ans=min(ans, max(left, sub[n-1].first-sub[1].first));
        
        return ans;
    }
};