class Solution {
public:
    
    
    vector<int> solve(vector<vector<int> >& A, int N)
{
   
    vector<pair<int,int>> V(N), V1(N);
 
    for (int i = 0; i < N; i++) {
        V[i].first = A[i][0] + A[i][1];
        V1[i].first = A[i][0] - A[i][1];
        V[i].second=i;
        V1[i].second=i;
    }
 
    // Sorting both the vectors
    sort(V.begin(), V.end());
    sort(V1.begin(), V1.end());
 
    // int maximum
    //     = max(V.back() - V.front(), V1.back() - V1.front());
        int p,q;
        int mx;
        if((V.back().first - V.front().first)>(V1.back().first - V1.front().first)){
            mx=V.back().first - V.front().first;
            p=V.back().second;
            q=V.front().second;
        }
        else 
        {
            mx=(V1.back().first - V1.front().first);
            p=V1.back().second;
            q=V1.front().second;
        }
        vector<int> v;
        v.push_back(p);
        v.push_back(q);
        v.push_back(mx);
        return v;
 
    // cout << maximum << endl;
}
    int minimumDistance(vector<vector<int>>& p) {
        int n=p.size();
        vector<int> a=solve(p,n);
        int c=a[0];
        int d=a[1];
        int ans=a[2];
       vector<vector<int>> s;
        for(int i=0;i<n;i++){
         if(i!=c) s.push_back(p[i]); 
        }
       
        a=solve(s,n-1);
        ans=min(ans,a[2]);
        
        
        
        vector<vector<int>> r;
        for(int i=0;i<n;i++){
         if(i!=d) r.push_back(p[i]); 
        }
        
        
        a=solve(r,n-1);
        ans=min(ans,a[2]);
        return ans;
    }
};