class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)

        s = []
        d = []
        for i in range(n):
            x, y = points[i]
            s.append((x + y, i))
            d.append((x - y, i))
        s.sort()
        d.sort()
        su = set()
        sl = set()
        M = s[-1][0]
        for i in range(n - 1, -1, -1):
            if s[i][0] == M:
                su.add(s[i][1])
            else:
                break
        m = s[0][0]
        for i in range(n):
            if s[i][0] == m:
                sl.add(s[i][1])
            else:
                break
        if len(su) != 1:
            supper = M
        else:
            supper = s[-2][0]
        if len(sl) != 1:
            slower = m
        else:
            slower = s[1][0]
            
        du = set()
        dl = set()
        dM = d[-1][0]
        for i in range(n - 1, -1, -1):
            if d[i][0] == dM:
                du.add(d[i][1])
            else:
                break
        dm = d[0][0]
        for i in range(n):
            if d[i][0] == dm:
                dl.add(d[i][1])
            else:
                break
        if len(du) != 1:
            dupper = dM
        else:
            dupper = d[-2][0]
        if len(dl) != 1:
            dlower = dm
        else:
            dlower = d[1][0]
            
            
        res = max(M - m, dM - dm)
        
        if len(su) == 1:
            curr = supper - m
            if len(du) == 1 and du == su:
                temp = dupper - dm
            elif len(dl) == 1 and dl == su:
                temp = dM - dlower
            else:
                temp = dM - dm
            curr = max(curr, temp)
            res = min(res, curr)
                
        if len(sl) == 1:
            curr = M - slower
            if len(du) == 1 and du == sl:
                temp = dupper - dm
            elif len(dl) == 1 and dl == sl:
                temp = dM - dlower
            else:
                temp = dM - dm
            curr = max(curr, temp)
            res = min(res, curr)
            
        if len(du) == 1:
            curr = dupper - dm
            if len(su) == 1 and du == su:
                temp = supper - m
            elif len(sl) == 1 and sl == du:
                temp = M - slower
            else:
                temp = M - m
            curr = max(curr, temp)
            res = min(res, curr)
            
        if len(dl) == 1:
            curr = dM - dlower
            if len(su) == 1 and dl == su:
                temp = supper - m
            elif len(sl) == 1 and sl == dl:
                temp = M - slower
            else:
                temp = M - m
            curr = max(curr, temp)
            res = min(res, curr)
        
        return res