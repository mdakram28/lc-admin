class Solution {
public:
    int minimumDistance(vector<vector<int>>& arr) {
        int n = arr.size();
        vector<vector<int>> t1(n), t2(n);
 
        for(int i = 0;i < n;i++){
            t1[i] = {arr[i][0] + arr[i][1], i};
            t2[i] = {arr[i][0] - arr[i][1] ,i};
        }

        sort(t1.begin(), t1.end());
        sort(t2.begin(), t2.end());
        int ans = INT_MAX;
        for(int i = 0;i < n;i++){
            int res = INT_MIN,x,y;
            if(t1.back()[1] == i){
                x = t1[n-2][0];
            }
            else
                x = t1[n-1][0];
            if(t1[0][1] == i)
                y = t1[1][0];
            else 
                y = t1[0][0];
            res = max(res, x - y);
            if(t2.back()[1] == i){
                x = t2[n-2][0];
            }
            else
                x = t2[n-1][0];
            if(t2[0][1] == i)
                y = t2[1][0];
            else 
                y = t2[0][0];
            res = max(res, x - y);
            ans = min(ans, res);
        }
        return ans;
    }
};