class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def MaxDist(A):
            N = len(A)
            # Initialize vectors to store the transformed coordinates
            V = [0 for i in range(N)]
            V1 = [0 for i in range(N)]

            # Populate the vectors with transformed coordinates
            for i in range(N):
                V[i] = (A[i][0] + A[i][1], i)  # Store the value and the original index
                V1[i] = (A[i][0] - A[i][1], i)  # Store the value and the original index

            # Sort the vectors based on the transformed coordinates
            V.sort()
            V1.sort()

            # Find the maximum distance and the indices of the corresponding points
            max_diff_V = V[-1][0] - V[0][0]
            max_diff_V1 = V1[-1][0] - V1[0][0]

            # Determine the maximum distance and the indices of the points that produce it
            if max_diff_V > max_diff_V1:
                maximum = max_diff_V
                indices = (V[0][1], V[-1][1])
            else:
                maximum = max_diff_V1
                indices = (V1[0][1], V1[-1][1])

            # Return the maximum distance and the indices of the points
            return maximum, indices
        
        mx, idxs = MaxDist(points)
        return min(MaxDist(points[:idxs[0]] + points[idxs[0] + 1:])[0], MaxDist(points[:idxs[1]] + points[idxs[1] + 1:])[0])