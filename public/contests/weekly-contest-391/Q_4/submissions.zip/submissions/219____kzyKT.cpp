#define F first
#define S second
#define R cin>>
#define ll long long
#define ln cout<<'\n'
#define in(a) insert(a)
#define pb(a) push_back(a)
#define pd(a) printf("%.10f\n",a)
#define mem(a) memset(a,0,sizeof(a))
#define all(c) (c).begin(),(c).end()
#define iter(c) __typeof((c).begin())
#define rrep(i,n) for(ll i=(ll)(n)-1;i>=0;i--)
#define REP(i,m,n) for(ll i=(ll)(m);i<(ll)(n);i++)
#define rep(i,n) REP(i,0,n)
#define tr(it,c) for(iter(c) it=(c).begin();it!=(c).end();it++)
ll check(ll n,ll m,ll x,ll y){return x>=0&&x<n&&y>=0&&y<m;}void pr(){ln;}
template<class A,class...B>void pr(const A &a,const B&...b){cout<<a<<(sizeof...(b)?" ":"");pr(b...);}
template<class A>void PR(A a,ll n){rep(i,n){if(i)cout<<' ';cout<<a[i];}ln;}
const ll MAX=1e9+7,MAXL=1LL<<52,dx[8]={-1,0,1,0,-1,-1,1,1},dy[8]={0,1,0,-1,-1,1,1,-1};
typedef pair<ll,ll> P;

class Solution {
public:
  int minimumDistance(vector<vector<int>>& a) {
    ll n=a.size();
    vector<P> v[n];
    set<ll> s;
    rep(k,2) {
      vector<P> p;
      if(k) rep(i,n) a[i][0]*=-1;
      rep(i,n) p.pb(P(a[i][0]+a[i][1],i));
      if(k) rep(i,n) a[i][0]*=-1;
      sort(all(p));
      rep(i,n) {
        v[p[i].S].pb(P(abs(p[i].F-p[0].F),p[0].S));
        v[p[i].S].pb(P(abs(p[i].F-p[1].F),p[1].S));
        v[p[i].S].pb(P(abs(p[i].F-p[n-1].F),p[n-1].S));
        v[p[i].S].pb(P(abs(p[i].F-p[n-2].F),p[n-2].S));
        s.in(p[0].S);
        s.in(p[1].S);
        s.in(p[n-1].S);
        s.in(p[n-2].S);
      }
    }
    rep(i,n) {
      sort(all(v[i]));
      set<ll> s;
      rrep(j,v[i].size()) {
        if(s.count(v[i][j].S)) v[i][j]=P(-1,-1);
        s.in(v[i][j].S);
      }
      v[i].erase(remove(all(v[i]),P(-1,-1)),v[i].end());
      v[i].erase(unique(all(v[i])),v[i].end());
      reverse(all(v[i]));
      while(v[i].size()>2) v[i].pop_back();
    }
    ll ans=MAXL;
    tr(it,s) {
      ll x=*it;
      ll M=0;
      rep(i,n) {
        if(x==i) continue;
        if(v[i][0].S==x) M=max(M,v[i][1].F);
        else M=max(M,v[i][0].F);
      }
      ans=min(ans,M);
    }
    return ans;
  }
};