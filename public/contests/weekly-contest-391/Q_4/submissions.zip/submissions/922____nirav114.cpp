class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size(), res = 1e9;
        multiset<int> sum, diff;
        for(auto x : p) {
            sum.insert(x[0] + x[1]);
            diff.insert(x[0] - x[1]);
        }
        for(auto x : p) {
            sum.erase(sum.find(x[0] + x[1]));
            diff.erase(diff.find(x[0] - x[1]));
            res = min(res, max(*sum.rbegin() - *sum.begin(), *diff.rbegin() - *diff.begin()));
            sum.insert(x[0] + x[1]);
            diff.insert(x[0] - x[1]);
        }
        return res;
    }
};