class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        map<int, int>t1, t2;
        int n = points.size();
        for(auto v: points){
            t1[v[0] - v[1]]++;
            t2[v[0] + v[1]]++;
        }
        int t1_min = t1.begin()->first;
        int t1_max = t1.rbegin()->first;
        int t2_min = t2.begin()->first;
        int t2_max = t2.rbegin()->first;
        int ans = max(t1_max - t1_min, t2_max - t2_min);
        for(auto v: points){
            if(t1[v[0] - v[1]] == 1){
                t1.erase(t1.find(v[0] - v[1]));
            }
            else t1[v[0] - v[1]]--;
            if(t2[v[0] + v[1]] == 1){
                t2.erase(t2.find(v[0] + v[1]));
            }
            else t2[v[0] + v[1]]--;
            t1_min = t1.begin()->first;
            t1_max = t1.rbegin()->first;
            t2_min = t2.begin()->first;
            t2_max = t2.rbegin()->first;
            int tmp;
            tmp = max({t1_max - t1_min, t2_max - t2_min});
            ans = min(ans, tmp);
            t1[v[0] - v[1]]++;
            t2[v[0] + v[1]]++;
        }
        return ans;
    }
};