class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) 
    {
        int n = points.size();
        vector<vector<int>> aux(n , vector<int>(2));
        for(int i = 0;i<n;i++) aux[i][0] = points[i][0] + points[i][1];
        for(int i = 0;i<n;i++) aux[i][1] = points[i][0] - points[i][1];
        
        int mx = INT_MAX , mn = INT_MIN;
        int mx_sum1 = mn, mx_sum2 = mn , mx_diff1 = mn , mx_diff2 = mn;
        int mn_sum1 = mx, mn_sum2 = mx , mn_diff1 = mx , mn_diff2 = mx;
        
        int mx_sum_idx1 = -1, mx_sum_idx2 = -1 , mx_diff_idx1 = -1 , mx_diff_idx2 = -1;
        int mn_sum_idx1 = -1, mn_sum_idx2 = -1 , mn_diff_idx1 = -1 , mn_diff_idx2 = -1;
        
        for(int i = 0;i<n;i++)
        {
            if(mx_sum2 < aux[i][0])
            {
                mx_sum2 = aux[i][0];
                mx_sum_idx2 = i;
            }
            if(mx_diff2 < aux[i][1])
            {
                mx_diff2 = aux[i][1];
                mx_diff_idx2 = i;
            }
            
            if(mx_sum1 < mx_sum2) 
            {
                swap(mx_sum1 , mx_sum2);
                swap(mx_sum_idx1 , mx_sum_idx2);
            }
            if(mx_diff1 < mx_diff2) 
            {
                swap(mx_diff1 , mx_diff2);
                swap(mx_diff_idx1 , mx_diff_idx2);
            }
            
            
            
            if(mn_sum2 > aux[i][0])
            {
                mn_sum2 = aux[i][0];
                mn_sum_idx2 = i;
            }
            if(mn_diff2 > aux[i][1])
            {
                mn_diff2 = aux[i][1];
                mn_diff_idx2 = i;
            }
            
            if(mn_sum1 > mn_sum2) 
            {
                swap(mn_sum1 , mn_sum2);
                swap(mn_sum_idx1 , mn_sum_idx2);
            }
            if(mn_diff1 > mn_diff2) 
            {
                swap(mn_diff1 , mn_diff2);
                swap(mn_diff_idx1 , mn_diff_idx2);
            }
        }
        
        int ans = max((mx_sum1 - mn_sum1) , (mx_diff1 - mn_diff1));
        for(int i = 0;i<n;i++)
        {
            int mxi_sum = mx_sum1 , mni_sum = mn_sum1;
            int mxi_diff = mx_diff1 , mni_diff = mn_diff1;
            if(mx_sum_idx1 == i) mxi_sum = mx_sum2;
            if(mn_sum_idx1 == i) mni_sum = mn_sum2;
            
            if(mx_diff_idx1 == i) mxi_diff = mx_diff2;
            if(mn_diff_idx1 == i) mni_diff = mn_diff2;
            ans = min(ans ,max(mxi_sum - mni_sum , mxi_diff - mni_diff));
        }
        return ans;
        
    }
};