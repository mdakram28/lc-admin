class Solution {
public:
    
    int helper(vector<vector<int>>& p)
    {
    int minsum, maxsum, mindiff, maxdiff;
    int N= p.size();
    minsum = maxsum = p[0][0] + p[0][1];
    mindiff = maxdiff = p[0][0] - p[0][1];
    for (int i = 1; i < N; i++) {
        int sum =  p[i][0] + p[i][1];
        int diff = p[i][0] - p[i][1];
        if (sum < minsum)
            minsum = sum;
        else if (sum > maxsum)
            maxsum = sum;
        if (diff < mindiff)
            mindiff = diff;
        else if (diff > maxdiff)
            maxdiff = diff;
    }
 
    return max(maxsum - minsum, maxdiff - mindiff);
}
    int minimumDistance(vector<vector<int>>& p) {
        
        pair<int,int> minsum, maxsum, mindiff, maxdiff;
        int n= p.size();
        minsum = maxsum = {p[0][0] + p[0][1], 0};
        mindiff = maxdiff = {p[0][0] - p[0][1], 0};
        for (int i = 1; i < n; i++) {
            int sum = p[i][0] + p[i][1];
            int diff = p[i][0] - p[i][1];
            if (sum < minsum.first)
                minsum = {sum, i};
            else if (sum > maxsum.first)
                maxsum = {sum, i};
            if (diff < mindiff.first)
                mindiff = {diff, i};
            else if (diff > maxdiff.first)
                maxdiff = {diff, i};
    }
    int p1;
    int p2;
    if(maxsum.first - minsum.first > maxdiff.first - mindiff.first){
        p1= maxsum.second;
        p2= minsum.second;
    }
    else{
        p1= maxdiff.second;
        p2= mindiff.second;
    }
    vector<vector<int>> temp=p;
    temp.erase(temp.begin()+p1);
    int ans1 =helper(temp);
    temp=p;
    temp.erase(temp.begin()+p2);
    int ans2 =helper(temp);
    return min(ans1, ans2);
    }  
};