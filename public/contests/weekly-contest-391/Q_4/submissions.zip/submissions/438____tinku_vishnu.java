class Solution {
    public int minimumDistance(int[][] points) {
        int n=points.length; TreeMap<Integer,Integer>s=new TreeMap<>();
        TreeMap<Integer,Integer>d=new TreeMap<>();
        for(int i=0;i<n;i++){
            int sum=points[i][0]+points[i][1];
            int diff=points[i][0]-points[i][1];
            if(s.containsKey(sum))s.put(sum,s.get(sum)+1);
            else s.put(sum,1);
            if(d.containsKey(diff))d.put(diff,d.get(diff)+1);
            else d.put(diff,1);
        }
        int ans=Integer.MAX_VALUE;
        for(int i=0;i<n;i++){
            int sum=points[i][0]+points[i][1];
            int diff=points[i][0]-points[i][1];
            s.put(sum,s.get(sum)-1);
            d.put(diff,d.get(diff)-1);
            if(s.get(sum)==0)s.remove(sum);
            if(d.get(diff)==0)d.remove(diff);
            //cal ans
            int minSumKey=s.firstKey(); int minDiffKey=d.firstKey();
            int minSumLastKey=s.lastKey(); int minDiffLastKey=d.lastKey();
            int max=Math.max(minSumLastKey-minSumKey,minDiffLastKey-minDiffKey);
            ans=Math.min(max,ans);
            if(s.containsKey(sum))s.put(sum,s.get(sum)+1);
            else s.put(sum,1);
            if(d.containsKey(diff))d.put(diff,d.get(diff)+1);
            else d.put(diff,1);
            
        }
        return ans;
        
    }
}