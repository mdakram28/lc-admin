class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        pts = list(tuple(it) for it in points)
        def md(pts):
            maxsum = minsum = pts[0][0] + pts[0][1]
            maxspt = pts[0]
            minspt = pts[0]
            maxdif = mindif = pts[0][0] - pts[0][1]
            maxdpt = pts[0]
            mindpt = pts[0]
            for pt in pts:
                som = pt[0] + pt[1]
                dif = pt[0] - pt[1]
                if som > maxsum:
                    maxsum = som
                    maxspt = pt
                if som < minsum:
                    minsum = som
                    minspt = pt
                if dif > maxdif:
                    maxdif = dif
                    maxdpt = pt
                if dif < mindif:
                    mindif = dif
                    mindpt = pt
            cand1 = maxsum - minsum
            cand2 = maxdif - mindif
            if cand1 > cand2:
                return (cand1, maxspt, minspt)
            return (cand2, maxdpt, mindpt)
        cand0, pt1, pt2 = md(pts)
        pts.remove(pt1)
        cand1, _, _ = md(pts)
        pts.append(pt1)
        pts.remove(pt2)
        cand2, _, _ = md(pts)
        pts.append(pt2)
        return min(cand0, cand1, cand2)