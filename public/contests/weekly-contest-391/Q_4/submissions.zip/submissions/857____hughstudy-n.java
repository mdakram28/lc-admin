class Solution {
    public int minimumDistance(int[][] points) {
        int len = points.length;
        int[] sum = new int[len], diff = new int[len];
        for (int i = 0; i < points.length; ++i) {
            sum[i] = points[i][0] + points[i][1];
            diff[i] = points[i][0] - points[i][1];
        }
        int[] removeCand = findPos(sum, diff);
        int res = Integer.MAX_VALUE;
        for (int n : removeCand) {
            res = Math.min(res, minimumDistance(sum, diff, n));
        }
        return res;
    }

    private int[] findPos(int[] sum, int[] diff) {
        int minsum, maxsum, mindiff, maxdiff;
        minsum = maxsum = 0;
        mindiff = maxdiff = 0;
        for (int i = 1; i < sum.length; i++) {
            if (sum[i] < sum[minsum]){
                minsum = i;
            } else if (sum[i] > sum[maxsum]){
                maxsum = i;
            }

            if (diff[i] < diff[mindiff]) {
                mindiff = i;
            }
            else if (diff[i] > diff[maxdiff]) {
                maxdiff = i;
            }
        }
        return new int[]{minsum, maxsum, mindiff, maxdiff};
    }

    private int minimumDistance(int[] sum, int[] diff, int skip) {
        int minsum = Integer.MAX_VALUE, maxsum = Integer.MIN_VALUE, mindiff = Integer.MAX_VALUE, maxdiff = Integer.MIN_VALUE;
        for (int i = 0; i < sum.length; ++i) {
            if (i == skip) continue;
            if (sum[i] < minsum) {
                minsum = sum[i];
            }
            if (sum[i] > maxsum) {
                maxsum = sum[i];
            }

            if (diff[i] < mindiff) {
                mindiff = diff[i];
            }
            if (diff[i] > maxdiff) {
                maxdiff = diff[i];
            }
        }
        return Math.max(maxsum - minsum, maxdiff - mindiff);
    }
}