class Solution {
    
int MaxSkip(const vector<int>& V, const vector<int>& V1, int skip_index) {
    int mxv0 = INT_MIN, mxv1 = INT_MIN, miv0 = INT_MAX, miv1 = INT_MAX;
    
    for (int i = 0; i < V.size(); i++) {
        if(i == skip_index) {
            continue;
        }
        mxv0 = max(mxv0, V[i]);
        miv0 = min(miv0, V[i]);
        
        mxv1 = max(mxv1, V1[i]);
        miv1 = min(miv1, V1[i]);
    }
    return  max((mxv0 - miv0), (mxv1 - miv1));
}

int MaxDist(vector<vector<int>>& A) {
    int N = A.size();
    vector<int> V(N), V1(N);
    int mxv0 = INT_MIN, mxv1 = INT_MIN, miv0 = INT_MAX, miv1 = INT_MAX;
    
    for (int i = 0; i < N; i++) {
        V[i] = A[i][0] + A[i][1];
        V1[i] = A[i][0] - A[i][1];
        
        mxv0 = max(mxv0, V[i]);
        miv0 = min(miv0, V[i]);
        
        mxv1 = max(mxv1, V1[i]);
        miv1 = min(miv1, V1[i]);
    }
 
    // for(int i : V) {
    //     cout << i << " ";
    // }
    // cout << endl;
    // for(int i : V1) {
    //     cout << i << " ";
    // }
    // cout << endl;
    // cout << "MX=" << mxv0 << " " << miv0 << " " << mxv1 << " " << miv1 << endl;
    
//     sort(V.begin(), V.end());
//     sort(V1.begin(), V1.end());
    
    int ma0 = -1, mi0 = -1, ma1 = -1, mi1 = -1;
    for(int i = 0; i < N; ++i) {
        if(ma0 == -1 && V[i] == mxv0) {
            ma0 = i;
        }
        
        if(mi0 == -1 && V[i] == miv0) {
            mi0 = i;
        }
        
        if(ma1 == -1 && V1[i] == mxv1) {
            ma1 = i;
        }
        
        if(mi1 == -1 && V1[i] == miv1) {
            mi1 = i;
        }
    }
    // cout << "ma0= " << ma0 << " mi0=" << mi0 << " ma1=" <<ma1 << " mi1=" << mi1 << endl; 
    
    int maximum = max((mxv0 - miv0), (mxv1 - miv1));
    // int maximum
    //     = max(V.back() - V.front(), V1.back() - V1.front());
    int m1 = MaxSkip(V, V1, ma0);
    int m2 = MaxSkip(V, V1, mi0);
    
    int m3 = MaxSkip(V, V1, ma1);
    int m4 = MaxSkip(V, V1, mi1);
    
    return min({m1, m2, m3, m4});
}

public:
    int minimumDistance(vector<vector<int>>& points) {
        return MaxDist(points);
        // cout << "Farthest pair indices: " << result.first << ", " << result.second << endl;
        // return -1;
    }
};