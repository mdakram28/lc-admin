class Solution {
public:
       int minimumDistance(vector<vector<int>>& points) {
        multiset<int>sum,dif;
        
        int n = points.size();
        int a,b=0;
         int res=0;
        int tmpx = 0,tmpy = 0;
        
        for(int i = 0; i < n; i++){
            tmpx = points[i][0];
            tmpy = points[i][1];
            
            sum.insert(tmpx + tmpy);
            dif.insert(tmpx - tmpy);
        }
        
        int mini = INT_MAX;
        
        for(int i = 0; i < n; i++){
            tmpx = points[i][0],tmpy = points[i][1];
            
            sum.erase(sum.find(tmpx + tmpy));
            dif.erase(dif.find(tmpx - tmpy));
            
            int a = *sum.begin(),b=*sum.rbegin(),c = *dif.begin(),d = *dif.rbegin();
            
            mini = min(mini,max(b - a,d - c));
            
            sum.insert(tmpx + tmpy);
            dif.insert(tmpx - tmpy);
            
        }
        return mini;
    }
};