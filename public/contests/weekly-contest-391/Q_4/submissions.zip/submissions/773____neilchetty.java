class Solution {
    public int minimumDistance(int[][] points) {
        List<Pair<Integer, Integer>> diff = new ArrayList<>();
        List<Pair<Integer, Integer>> sum = new ArrayList<>();
        int n = points.length;
        for(int i = 0; i < n; i++) {
            sum.add(new Pair<Integer, Integer>(points[i][0] + points[i][1], i));
            diff.add(new Pair<Integer, Integer>(points[i][0] - points[i][1], i));
        }
        Collections.sort(sum, Comparator.comparingInt(a->a.getKey()));
        Collections.sort(diff, Comparator.comparingInt(a->a.getKey()));
        int min = Integer.MAX_VALUE;
        for(int i = 0; i < n; i++) {
            int l1 = 0, l2 = 0, r1 = n-1, r2 = n-1;
            if(sum.get(0).getValue()==i) l1++;
            if(diff.get(0).getValue()==i) l2++;
            if(sum.get(n-1).getValue()==i) r1--;
            if(diff.get(n-1).getValue()==i) r2--;
            min = Math.min(min, Math.max(sum.get(r1).getKey() - sum.get(l1).getKey(), diff.get(r2).getKey() - diff.get(l2).getKey()));
        }
        return min;
    }
}