class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        s = []
        d = []
        
        for i,p in enumerate(points):
            s.append((p[0] + p[1],i))
            d.append((p[0] - p[1],i))
        
        s.sort()
        d.sort()
        # print(s,d)
        ans = inf
        idr = set([s[0][-1],s[-1][-1],d[0][-1],d[-1][-1]])
        
        for ci in idr:
            s1 = 0
            s2 = len(s) -1
            d1 = 0
            d2 = len(d) - 1
            # print(ci,s1,s2,d1,d2)
            while s[s1][-1] == ci:
                s1 += 1
            while s[s2][-1] == ci:
                s2 -= 1
                
            while d[d1][-1] == ci:
                d1 += 1
            while d[d2][-1] == ci:
                d2 -= 1
            # print(ci,s1,s2,d1,d2)
            # print(max(s[s2][0]-s[s1][0],d[d2][0] - d[d1][0]))
            ans = min(ans,max(s[s2][0]-s[s1][0],d[d2][0] - d[d1][0]))
        return ans
            
        