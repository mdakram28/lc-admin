#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
typedef long long ll;
#define forn(i, n) for (int i = 0; i < int(n); i++)
#define pb push_back 
#define mp make_pair 
#define all(x) (x).begin(),(x).end()
#define allb(x) (x).rbegin(),(x).rend()
#define rep_u(ii, aa, bb) for(int ii = aa; ii < bb; ii++)
#define rep_d(ii, aa, bb) for(int ii = aa; ii >= bb; ii--)
#define ff first
#define ss second
#define yes cout << "YES" << endl;
#define no cout << "NO" << endl;
#define ordered_set(type) tree<type, null_type,less_equal<type>, rb_tree_tag,tree_order_statistics_node_update>

typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<vector<ll>> vvll;
typedef priority_queue<ll> maxhi;
typedef priority_queue <ll, vector<ll>, greater<ll>> minhi;

#ifndef ONLINE_JUDGE
#define debug(x) cerr << #x <<" "; _print(x); cerr << endl;
#else
#define debug(x)
#endif

void _print(ll t) {cerr << t;}
void _print(int t) {cerr << t;}
void _print(string t) {cerr << t;}
void _print(char t) {cerr << t;}

template <class T, class V> void _print(pair <T, V> p);
template <class T> void _print(vector <T> v);
template <class T> void _print(set <T> v);
template <class T, class V> void _print(map <T, V> v);
template <class T> void _print(multiset <T> v);
template <class T, class V> void _print(pair <T, V> p) {cerr << "{"; _print(p.ff); cerr << ","; _print(p.ss); cerr << "}";}
template <class T> void _print(vector <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(set <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(multiset <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void _print(map <T, V> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}

template<class container>void print(container start,container end){while(start!=end){cout<<*start<<" ";start++;}cout<<endl;}
ll modpow(ll a, ll n, ll mod) {ll res = 1;while (n > 0) {if (n & 1) res = res * a % mod;a = a * a % mod;n >>= 1;}return res;}
ll gcd(ll a, ll b) {if (b > a) {return gcd(b, a);} if (b == 0) {return a;} return gcd(b, a % b);}
ll lcm(ll a,ll b){return (a*b)/gcd(a,b);}
ll expo(ll a, ll b, ll mod) {ll res = 1; while (b > 0) {if (b & 1)res = (res * a) % mod; a = (a * a) % mod; b = b >> 1;} return res;}
void extendgcd(ll a, ll b, ll*v) {if (b == 0) {v[0] = 1; v[1] = 10; v[2] = a; return ;} extendgcd(b, a % b, v); ll x = v[1]; v[1] = v[0] - v[1] * (a / b); v[0] = x; return;} //pass an array of size 3
ll mod_add(ll a, ll b, ll m) {a = a % m; b = b % m; return (((a + b) % m) + m) % m;}
ll mod_mul(ll a, ll b, ll m) {a = a % m; b = b % m; return (((a * b) % m) + m) % m;}
ll mod_sub(ll a, ll b, ll m) {a = a % m; b = b % m; return (((a - b) % m) + m) % m;}
ll mminv(ll a, ll b) {ll arr[3]; extendgcd(a, b, arr); return mod_add(arr[0], 0, b);} //for non prime b (using extended euclid gcd)
ll mminvprime(ll a, ll b) {return expo(a, b - 2, b);}   // for prime b (using fermat little theorem)
ll mod_div(ll a, ll b, ll m) {a = a % m; b = b % m; return (mod_mul(a, mminvprime(b, m), m) + m) % m;}  //only for prime m
bool sortcol(const vector<ll>& v1, const vector<ll>& v2){return v1[1] < v2[1];}
void fastio(){ios_base::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);}
string binary(ll n){return bitset<32>(n).to_string();}

const int maxn = 1e5+10;
vll seive(maxn,1),lpf(maxn,0),hpf(maxn,0),pf,divisors[maxn];
void primes(){seive[0]=0,seive[1]=0;lpf[1]=1;hpf[1]=1;for(int i=2;i*i<=maxn;i++){if(seive[i]){lpf[i]=hpf[i]=i;for(int j=2*i;j<maxn;j+=i){seive[j]=0;hpf[j]=i;if(lpf[j]==0){lpf[j]=i;}}}}}
void primefactors(ll n){while(n>1){ll spf=lpf[n];while(n%spf==0){n=n/spf;pf.pb(spf);}}}
void divisor(){for(int i=2;i*i<=maxn;i++){for(int j=i;j<maxn;j+=i){divisors[j].pb(i);}}}

#define MOD 1e9+7
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        multiset<ll> v1,v2;
        vector<pair<ll,ll>> arr(n);
        forn(i,n){
            arr[i].ff=points[i][0];
            arr[i].ss=points[i][1];
            v1.insert(points[i][0]+points[i][1]);
            v2.insert(points[i][0]-points[i][1]);
            
        }
        int mini=INT_MAX;
        for(auto it:arr){
            auto it1 = v1.find(it.ff + it.ss);
            if (it1 != v1.end()) v1.erase(it1);
            auto it2 = v2.find(it.ff - it.ss);
            if (it2 != v2.end()) v2.erase(it2);
            int dist=max(*v1.rbegin()-*v1.begin(),*v2.rbegin()-*v2.begin());
            mini=min(mini,dist);
            v1.insert(it.ff+it.ss);
            v2.insert(it.ff-it.ss);
            
        }
        return mini;
        
    }
};