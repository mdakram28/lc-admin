class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        def f(s):
            m = -math.inf
            d = [-math.inf] * 4
            for i, (x, y) in enumerate(points):
                if i == s:
                    continue
                for k in range(4):
                    t = a[k][0] * x + a[k][1] * y
                    m = max(m, d[k] - t)
                    d[k] = max(d[k], t)
            return m        
        
        a = [[-1, -1], [-1, 1], [1, -1], [1, 1]]
        d = [-math.inf] * 4
        e = [0 for _ in range(4)]
        m = -math.inf
        p = []
        for i, (x, y) in enumerate(points):
            for k in range(4):
                t = a[k][0] * x + a[k][1] * y
                r = d[k] - t 
                if r > m:
                    m = r
                    p = [e[k], i]
                if t > d[k]:
                    d[k] = t
                    e[k] = i
        return min(f(i) for i in p)