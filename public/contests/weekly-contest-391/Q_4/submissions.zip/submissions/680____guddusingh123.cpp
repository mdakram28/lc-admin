class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        set<pair<int, int>> xp, yp;
        for(int i = 0; i < n; i++){
            int x = p[i][0], y = p[i][1];
            int xx = x + y;
            int yy = x - y;
            xp.insert({xx, i});
            yp.insert({yy, i});
        }
        
        int res = INT_MAX;
        for(int i = 0; i < n; i++){
            int x = p[i][0], y = p[i][1];
            int xx = x + y;
            int yy = x - y;
            
            xp.erase({xx, i});
            yp.erase({yy, i});
            
            int dx = abs((*xp.begin()).first - (*xp.rbegin()).first);
            int dy = abs((*yp.begin()).first - (*yp.rbegin()).first);
            
            res = min(res, max(dx, dy));
            
            xp.insert({xx, i});
            yp.insert({yy, i});
        }
        return res;
    }
};