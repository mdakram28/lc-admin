
import java.util.*;


public class Main {
    public static void main(String[] args) {
        int[][] meetings = {{3,10},{5,15},{10,2},{4,4}};
        int[] nums={4,1,5,2,6,2};
        String[] ans={"gfnt","xn","mdz","yfmr","fi","wwncn","hkdy"};
        Solution solution=new Solution();
        solution.minimumDistance(meetings);
    }
}

class Solution {
    public int minimumDistance(int[][] points) {
        int[][] x={{1,1},{1,-1},{-1,1},{-1,-1}};
        int n=points.length;
        int p1=-1,p2=-1;
        int ans=Integer.MIN_VALUE;
        for(int i=0;i<4;++i){
            int mx=Integer.MIN_VALUE;
            int mi=Integer.MAX_VALUE;
            int tp1=-1,tp2=-1;
            for(int j=0;j<n;++j){
                int tmp=points[j][0]*x[i][0]+points[j][1]*x[i][1];
                if(mx<tmp){
                    mx=tmp;
                    tp1=j;
                }
                if(mi>tmp){
                    mi=tmp;
                    tp2=j;
                }
            }
            if(mx-mi>ans){
                ans=mx-mi;
                p1=tp1;
                p2=tp2;
            }
        }
        int sum=Integer.MIN_VALUE;
        for(int i=0;i<4;++i){
            int mx=Integer.MIN_VALUE;
            int mi=Integer.MAX_VALUE;
            for(int j=0;j<n;++j){
                if(j==p1)continue;
                int tmp=points[j][0]*x[i][0]+points[j][1]*x[i][1];
                mx=Math.max(mx,tmp);
                mi=Math.min(mi,tmp);
            }
            sum=Math.max(sum,mx-mi);
        }
        ans=Math.min(ans,sum);
        sum=Integer.MIN_VALUE;
        for(int i=0;i<4;++i){
            int mx=Integer.MIN_VALUE;
            int mi=Integer.MAX_VALUE;
            for(int j=0;j<n;++j){
                if(j==p2)continue;
                int tmp=points[j][0]*x[i][0]+points[j][1]*x[i][1];
                mx=Math.max(mx,tmp);
                mi=Math.min(mi,tmp);
            }
            sum=Math.max(sum,mx-mi);
        }
        ans=Math.min(ans,sum);
        return ans;
    }
}