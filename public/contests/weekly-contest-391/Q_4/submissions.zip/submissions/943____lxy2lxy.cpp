class Solution {
public:
	int maxdistance(vector<vector<int>>& points,int k)
	{
		int len = points.size();
		long long mzx, mzs, myx, mys;
		long long n;
		int now;
		if (k == 0)	now = 1;
		else now = 0;
		int zx = now, zs = now, yx = now, ys = now;
		mzx = points[now][0] + points[now][1];
		mzs = points[now][1] - points[now][0];
		mys = points[now][1] + points[now][0];
		myx = points[now][0] - points[now][1];
		for (int i = 1; i < len; i++)
		{
			if (i == k) continue;
			if (points[i][0] + points[i][1] < mzx)
			{
				zx = i;
				mzx = points[i][0] + points[i][1];
			}
			if (points[i][1] - points[i][0] > mzs)
			{
				zs = i;
				mzs = points[i][1] - points[i][0];
			}

			if (points[i][1] + points[i][0] > mys)
			{
				ys = i;
				mys = points[i][1] + points[i][0];
			}
			if (points[i][0] - points[i][1] > myx)
			{
				yx = i;
				myx = points[i][0] - points[i][1];
			}
		}
		int ans = 0;
		now = abs(points[zs][0] - points[yx][0]) + abs(points[zs][1] - points[yx][1]);
		ans = max(ans, now);
		now = abs(points[zx][0] - points[ys][0]) + abs(points[zx][1] - points[ys][1]);
		ans = max(ans, now);
		if (k == -1)
		{
			a[0] = zs;
			a[1] = zx;
			a[2] = ys;
			a[3] = yx;
		}
		return ans;
	}


	int minimumDistance(vector<vector<int>>& points) {
		sort(points.begin(), points.end());
		int len = points.size();
		int ans = maxdistance(points, -1);
		for (int i = 0; i < 4; i++)
		{
			ans = min(ans, maxdistance(points, a[i]));
		}
		return ans;
	}
	int a[4];
};