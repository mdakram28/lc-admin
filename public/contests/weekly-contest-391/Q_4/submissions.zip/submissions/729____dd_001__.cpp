class Solution {
public:
    int f(vector<vector<int>> points, int idx)
    {
        points.erase(points.begin() + idx);
        
        int minSum = points[0][0] + points[0][1];
        int maxSum = minSum;
        int minDiff = points[0][0] - points[0][1];
        int maxDiff = minDiff;
        
        int ans = 0;
        
        for(int i = 1; i < points.size(); i++)
        {   
            int localSum = points[i][0] + points[i][1];
            int localDiff = points[i][0] - points[i][1];
            
            if(localSum > maxSum)
                maxSum = localSum;
            
            if(localSum < minSum)
                minSum = localSum;
            
            if(localDiff > maxDiff)
                maxDiff = localDiff;
            
            if(localDiff < minDiff)
                minDiff = localDiff;
            
            ans = max(maxSum - minSum, maxDiff - minDiff);
        }
        
        return ans;
    }
    
    int minimumDistance(vector<vector<int>>& points) 
    {
        vector<pair<int, int>> sumV, diffV;
        int n = points.size();
        
        int ans = INT_MAX;
        
        for(int i = 0; i < points.size(); i++)
        {
            sumV.push_back({points[i][0] + points[i][1], i});
            diffV.push_back({points[i][0] - points[i][1], i});
        }
        
        sort(sumV.begin(), sumV.end());
        sort(diffV.begin(), diffV.end());
        
        if((sumV[n - 1].first - sumV[0].first) == (diffV[n - 1].first - diffV[0].first))
        {
            set<int> s;
            s.insert(sumV[n - 1].second);
            s.insert(sumV[0].second);
            s.insert(diffV[n - 1].second);
            s.insert(diffV[0].second);
            
            if(s.size() == 4)
                return (sumV[n - 1].first - sumV[0].first);
            
            ans = min(ans, f(points, sumV[n - 1].second)); //n - 1 removal
            ans = min(ans, f(points, sumV[0].second)); //n - 1 removal
            ans = min(ans, f(points, diffV[n - 1].second)); //0 removal
            ans = min(ans, f(points, diffV[n - 1].second)); //n - 1 removal
            
            return ans;
        }
        
        if((sumV[n - 1].first - sumV[0].first) > (diffV[n - 1].first - diffV[0].first))
        {
            
            ans = min(ans, f(points, sumV[n - 1].second)); //n - 1 removal
            ans = min(ans, f(points, sumV[0].second)); //n - 1 removal
            
            return ans;
        }
        
        ans = min(ans, f(points, diffV[n - 1].second)); //n - 1 removal
        ans = min(ans, f(points, diffV[0].second)); //0 removal

        return ans;
    }
};