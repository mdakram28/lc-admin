class Solution {
    public int minimumDistance(int[][] points) {
        //System.out.println(getMax(points, 3));
        int n = points.length;
        int maxXPlusY = Integer.MIN_VALUE;
        int minXPlusY = Integer.MAX_VALUE;
        int maxXMinusY = Integer.MIN_VALUE;
        int minXMinusY = Integer.MAX_VALUE;
        List<Integer> list1 = new ArrayList<>();
        List<Integer> list2 = new ArrayList<>();
        List<Integer> list3 = new ArrayList<>();
        List<Integer> list4 = new ArrayList<>();
        Set<Integer> set = new HashSet<>();
        
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int[] point = points[i];
            int x = point[0];
            int y = point[1];
            maxXPlusY = Math.max(maxXPlusY, x + y);
            minXPlusY = Math.min(minXPlusY, x + y);
            maxXMinusY = Math.max(maxXMinusY, x - y);
            minXMinusY = Math.min(minXMinusY, x - y);
        }
        
        for (int i = 0; i < n; i++) {
            int[] point = points[i];
            int x = point[0];
            int y = point[1];
            if (x + y == maxXPlusY) {
                list1.add(i);
                set.add(i);
            }
            if (x + y == minXPlusY) {
                list2.add(i);
                set.add(i);
            }
            if (x - y == maxXMinusY) {
                list3.add(i);
                set.add(i);
            }
            if (x - y == minXMinusY) {
                list4.add(i);
                set.add(i);
            }
        }
        int result = Integer.MAX_VALUE;
        for (int i : set) {
            result = Math.min(result, getMax(points, i));
        }
        return result;
        
    }
    private int getMax(int[][] points, int skip) {
        int n = points.length;
        int maxXPlusY = Integer.MIN_VALUE;
        int minXPlusY = Integer.MAX_VALUE;
        int maxXMinusY = Integer.MIN_VALUE;
        int minXMinusY = Integer.MAX_VALUE;
        List<Integer> list1 = new ArrayList<>();
        List<Integer> list2 = new ArrayList<>();
        List<Integer> list3 = new ArrayList<>();
        List<Integer> list4 = new ArrayList<>();
        
        for (int i = 0; i < n; i++) {
            if(i == skip) {
                continue;
            }
            int[] point = points[i];
            int x = point[0];
            int y = point[1];
            maxXPlusY = Math.max(maxXPlusY, x + y);
            minXPlusY = Math.min(minXPlusY, x + y);
            maxXMinusY = Math.max(maxXMinusY, x - y);
            minXMinusY = Math.min(minXMinusY, x - y);
        }
        return Math.max(maxXPlusY - minXPlusY, maxXMinusY - minXMinusY);
    }
}