class Solution:
    
    def get_extreme(self, points):
        x_max = [-float('inf')] * 2
        x_min = [float('inf')] * 2
        i_max = [0, 0]
        i_min = [0, 0]
        for i, p in enumerate(points):
            x = [0, 0]
            for j in range(2):
                x[j] = p[0] + (-1)**j * p[1]
            
                if x[j] > x_max[j]:
                    i_max[j] = i
                    x_max[j] = x[j]
                if x[j] < x_min[j]:
                    i_min[j] = i
                    x_min[j] = x[j]
        return i_max, i_min, x_max, x_min
    
    
    def minimumDistance(self, points: List[List[int]]) -> int:
        i_max, i_min, _, _ = self.get_extreme(points)
        
        minimum = float('inf')
        
        for i in chain(i_max, i_min):
            pts = points.copy()
            pts.pop(i)
            _, _, x_max, x_min = self.get_extreme(pts)

            minimum = min(minimum, max(x_max[0] - x_min[0], x_max[1] - x_min[1]))
        
        return minimum

                    
        