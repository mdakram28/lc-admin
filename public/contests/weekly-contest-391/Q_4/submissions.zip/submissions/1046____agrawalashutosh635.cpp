class Solution {
public:
    int minimumDistance(vector<vector<int>>& A) {
        int N = A.size();
        // vector<int> V(N), V1(N);
        // for (int i = 0; i < N; i++) V[i] = A[i][0] + A[i][1],  V1[i] = A[i][0] - A[i][1];
        // sort(V.begin(), V.end());
        // sort(V1.begin(), V1.end());
        // return min(V.back() - V.front(), V1.back() - V1.front());
        
        multiset<int> s1,s2;
        for(int i = 0;i<N;i++){
            s1.insert( A[i][0] + A[i][1]);
            s2.insert(A[i][0] - A[i][1]);
        };
        
        int res = INT_MAX;
        for(int i =0; i<N;i++){
            int temp1 = A[i][0] + A[i][1], temp2 = A[i][0] - A[i][1];
            s1.erase(s1.find(temp1));
            s2.erase(s2.find(temp2));
            res = min(res, max(
                (*s1.rbegin()) - (*s1.begin()),
                (*s2.rbegin()) - (*s2.begin())
            ));
            
            s1.insert(temp1);
            s2.insert(temp2);
        }
        return res;
    }
};