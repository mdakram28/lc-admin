class Solution:
    def minimumDistance(self, arr: List[List[int]]) -> int:
        n = len(arr)
        def maxMan(arr,n):
            A = [0] * n
            B = [0] * n
            for i in range(n):
                A[i] = arr[i][0] + arr[i][1]
                B[i] = arr[i][0] - arr[i][1]
            AA = sorted(A)
            BB = sorted(B)
            a = AA[-1] - AA[0]
            b = BB[-1] - BB[0]
            return [a,b,AA,BB]
        a,b,AA,BB = maxMan(arr,n)
        if a>=b:
            x = AA[0]
            y = AA[-1]
            xx = yy = -1
            for i in range(n):
                if arr[i][0] + arr[i][1] == x:
                    xx = i
                    break
            for i in range(n):
                if arr[i][0] + arr[i][1]==y:
                    yy = i
                    break
        else:
            x = BB[0]
            y = BB[-1]
            xx = yy = -1
            for i in range(n):
                if arr[i][0] - arr[i][1] == x:
                    xx = i
                    break
            for i in range(n):
                if arr[i][0] - arr[i][1]==y:
                    yy = i
                    break
        XX = maxMan(arr[:xx] + arr[xx+1:], n-1)
        YY = maxMan(arr[:yy] + arr[yy+1:], n-1)
        a,b = XX[0],XX[1]
        c,d = YY[0],YY[1]
        return min(max(a,b),max(c,d))