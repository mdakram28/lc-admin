class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int>sum,diff;
        for(auto it : points){
            int xi = it[0] , yi = it[1];
            sum.insert(xi+yi);
            diff.insert(xi-yi);
        }
        int ans = INT_MAX;
        for(auto it : points){
            int xi = it[0] , yi = it[1];
            sum.erase(sum.find(xi+yi));
            diff.erase(diff.find(xi-yi));
            ans = min(ans,max((*(sum.rbegin()) - *(sum.begin())) , (*(diff.rbegin()) - *(diff.begin()))));
            sum.insert(xi+yi);
            diff.insert(xi-yi);
        }
        return ans;
    }
};

/*

max( 
(Xi - Yi) - (Xj – Yj) ,
(Xj - Yj) - (Xi - Yi) ,
(Xj + Yj) - (Xi + Yi) ,
(Xj + Yj) - (Xi + Yi) ,
)

*/