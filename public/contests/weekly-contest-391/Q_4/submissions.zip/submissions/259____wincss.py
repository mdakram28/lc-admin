class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        from sortedcontainers import SortedList
        s = SortedList()
        d = SortedList()
        for i, (x, y) in enumerate(points):
            s.add((x + y, i))
            d.add((x - y, i))
        dis = max(s[-1][0] - s[0][0], d[-1][0] - d[0][0])
        mxs, mns, mxd, mnd = s[-1], s[0], d[-1], d[0]
        for i, (x, y) in enumerate(points):
            s1, s2, d1, d2 = mxs, mns, mxd, mnd
            if i == s1[1]:
                s1 = s[-2]
            if i == s2[1]:
                s2 = s[1]
            if i == d1[1]:
                d1 = d[-2]
            if i == d2[1]:
                d2 = d[1]
            if (t := max(s1[0] - s2[0], d1[0] - d2[0])) < dis:
                dis = t
        return dis