class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        def largestManhattan(excl_idx: Optional[int]=None) -> Tuple[int, Tuple[List[int]]]:
            mx_sm, mn_sm = -float("inf"), float("inf")
            mx_diff, mn_diff = -float("inf"), float("inf")
            for i, pt in enumerate(points):
                if i == excl_idx: continue
                sm = sum(pt)
                if sm > mx_sm:
                    mx_sm_inds = [i]
                    mx_sm = sm
                elif sm == mx_sm:
                    mx_sm_inds.append(i)
                if sm < mn_sm:
                    mn_sm_inds = [i]
                    mn_sm = sm
                elif sm == mn_sm:
                    mn_sm_inds.append(i)
                diff = pt[1] - pt[0]
                if diff > mx_diff:
                    mx_diff_inds = [i]
                    mx_diff = diff
                elif diff == mx_diff:
                    mx_diff_inds.append(i)
                if diff < mn_diff:
                    mn_diff_inds = [i]
                    mn_diff = diff
                elif diff == mn_diff:
                    mn_diff_inds.append(i)
            d1 = mx_sm - mn_sm
            d2 = mx_diff - mn_diff
            if d1 > d2:
                return (d1, (mx_sm_inds, mn_sm_inds))
            elif d1 < d2:
                return (d2, (mx_diff_inds, mn_diff_inds))
            return (d2, (mx_sm_inds, mn_sm_inds), (mx_diff_inds, mn_diff_inds))
        
        ans = largestManhattan()
        #print(ans)
        res = float("inf")
        for lst_pair in ans[1:]:
            #print(lst_pair)
            res = min(res, min(largestManhattan(lst_pair[0][0])[0], largestManhattan(lst_pair[1][0])[0]))
        return res
        """
        if len(ans) == 3:
            if len(ans[1][0]) == 1:
                if len(ans[2][0]) == 1 and ans[1][0] == ans[2][0]:
                    if len(ans[1][1]) == 1 and len(ans[2][1]) == 1 and ans[1][1] == ans[2][1]:
                        return max(largestManhattan(ans[1][0][0]), largestManhattan(ans[1][1][0]))
                    return largestManhattan(ans[1][0][0])
                if len(ans[2][1]) == 1 and ans[1][0] == ans[2][1]:
                    if len(ans[1][1]) == 1 and len(ans[2][0]) == 1 and ans[1][1] == ans[2][0]:
                        return max(largestManhattan(ans[1][0][0]), largestManhattan(ans[1][1][0]))
                    return largestManhattan(ans[1][0][0])
            if len(ans[1][1]) == 1
                if len(ans[2][0]) == 1 and ans[1][1] == ans[2][0]:
                    return largestManhattan(ans[1][1][0])
                if len(ans[1][1]) == 1 and len(ans[2][1]) == 1 and ans[1][1] == ans[2][1]:
                    return largestManhattan(ans[1][1][0])
            return ans[0]
        if len(ans[1][0]) == 1:
            if len(ans[1][1]) == 1:
                return max(largestManhattan(ans[1][0][0]), largestManhattan(ans[1][1][0]))
            return largestManhattan(ans[1][0][0])
        
        return 0
        """