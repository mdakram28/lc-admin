/**
 * @param {number[][]} points
 * @return {number}
 */
function minimumDistance(points) {
    function calcExtremes(arr) {
        let max = secondMax = -Infinity;
        let min = secondMin = Infinity;

        // Find max and min
        for (let value of arr) {
            if (value > max) {
                secondMax = max;
                max = value;
            } else if (value > secondMax) {
                secondMax = value;
            }
            if (value < min) {
                secondMin = min;
                min = value;
            } else if (value < secondMin) {
                secondMin = value;
            }
        }
        return { max, secondMax, min, secondMin };
    }

    let sumArr = points.map(([x, y]) => x + y);
    let diffArr = points.map(([x, y]) => x - y);

    let { max: maxSum, secondMax: secondMaxSum, min: minSum, secondMin: secondMinSum } = calcExtremes(sumArr);
    let { max: maxDiff, secondMax: secondMaxDiff, min: minDiff, secondMin: secondMinDiff } = calcExtremes(diffArr);

    let minMaxDist = Infinity;

    for (let i = 0; i < points.length; i++) {
        let currentSum = points[i][0] + points[i][1];
        let currentDiff = points[i][0] - points[i][1];

        let currentMaxSum = currentSum === maxSum ? secondMaxSum : maxSum;
        let currentMinSum = currentSum === minSum ? secondMinSum : minSum;
        let currentMaxDiff = currentDiff === maxDiff ? secondMaxDiff : maxDiff;
        let currentMinDiff = currentDiff === minDiff ? secondMinDiff : minDiff;

        let currentMaxDistance = Math.max(currentMaxSum - currentMinSum, currentMaxDiff - currentMinDiff);
        minMaxDist = Math.min(minMaxDist, currentMaxDistance);
    }

    return minMaxDist;
}

