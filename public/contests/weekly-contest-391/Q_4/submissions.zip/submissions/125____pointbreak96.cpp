class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> a, b;
        int n = points.size();
        for(int i=0; i<n; i++) {
            a.insert(points[i][0] + points[i][1]);
            b.insert(points[i][0] - points[i][1]);
        }
        int ans = INT_MAX;
        for(int i=0; i<n; i++) {
            int sum = points[i][0] + points[i][1];
            int diff = points[i][0] - points[i][1];
            a.erase(a.find(sum));
            b.erase(b.find(diff));
            auto fronta = a.begin();
            auto backa = a.end();
            backa--;
            auto frontb = b.begin();
            auto backb = b.end();
            backb--;
            ans = min(ans, max(*backa - *fronta, *backb - *frontb));
            a.insert(sum);
            b.insert(diff);
        }
        return ans;
    }
};