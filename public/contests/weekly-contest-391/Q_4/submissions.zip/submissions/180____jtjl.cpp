typedef pair<int, int> pii;
typedef vector<pii> vp;
typedef pair<vp, vp> vii;
typedef pair<int, vii> shb;

class Solution {
public:
    shb getmx(const vector<pii>& a, int p, int q) {
        vector<pii> mx, mn;
        int mxo = -1e9, mno = 1e9;
        for (auto &x : a) {
            int o = p * x.first + q * x.second;
            if (o > mxo) mx.clear(), mxo = o;
            if (o >= mxo) mx.emplace_back(x);
            if (o < mno) mn.clear(), mno = o;
            if (o <= mno) mn.emplace_back(x);
        }
        return {mxo - mno, {mx, mn}};
    }
    int getans(const vector<pii>& a, int p, int q) {
        vector<pii> mx, mn;
        int mxo = -1e9, mno = 1e9;
        for (auto &x : a) {
            int o = p * x.first + q * x.second;
            if (o > mxo) mx.clear(), mxo = o;
            if (o >= mxo) mx.emplace_back(x);
            if (o < mno) mn.clear(), mno = o;
            if (o <= mno) mn.emplace_back(x);
        }
        return mxo - mno;
    }
    int minimumDistance(vector<vector<int>>& points) {
        vector<pii> g;
        for (auto &x : points) g.push_back(pii(x[0], x[1]));
        shb A = getmx(g, 1, 1);
        shb B = getmx(g, 1, -1);
        if (A.first == 0 && B.first == 0) return 0;
        set<pii> C;
        vector<pii> D;
        for (int i = 0; i < 1 && i < A.second.first.size(); ++i) C.insert(A.second.first[i]);
        for (int i = 0; i < 1 && i < A.second.second.size(); ++i) C.insert(A.second.second[i]);
        for (int i = 0; i < 1 && i < B.second.first.size(); ++i) C.insert(B.second.first[i]);
        for (int i = 0; i < 1 && i < B.second.second.size(); ++i) C.insert(B.second.second[i]);
        vector<pii> h;
        for (int i = 0; i < g.size(); ++i) {
            if (C.find(g[i]) != C.end()) {
                C.erase(g[i]); D.push_back(g[i]);
            } else {
                h.push_back(g[i]);
            }
        }
        int ans = 1e9;
        for (int i = 0; i < D.size(); ++i) {
            for (int j = 0; j < D.size(); ++j) if (j != i) h.push_back(D[j]);
            // for (auto &x : h) cout << x.first << "," << x.second << "  "; cout << endl;
            ans = min(ans, max(getans(h, 1, 1), getans(h, 1, -1)));
            for (int j = 0; j < D.size(); ++j) if (j != i) h.pop_back();
        }
        return ans;
    }
};