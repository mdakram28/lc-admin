class Solution {
    
    class Point {
        int x;
        int y;
        int pos;
        
        public Point(int x, int y, int pos) {
            this.x = x;
            this.y = y;
            this.pos = pos;
        }
    }
    
    public int minimumDistance(int[][] points) {
        ArrayList<Point> pts = new ArrayList<>();
        Comparator<Point> xOrder = new Comparator<Point>() {
            public int compare(Point a, Point b) {
                if(a.x == b.x) {
                    if(a.y == b.y)
                        return a.pos - b.pos;
                    return a.y - b.y;
                }
                return a.x - b.x;
            }
        };
        Comparator<Point> yOrder = new Comparator<Point>() {
            public int compare(Point a, Point b) {
                if(a.y == b.y) {
                    if(a.x == b.x)
                        return a.pos - b.pos;
                    return a.x - b.x;
                }
                return a.y - b.y;
            }
        };
        TreeSet<Point> X = new TreeSet<>(xOrder);
        TreeSet<Point> Y = new TreeSet<>(yOrder);
        for(int i = 0; i < points.length; i++) {
            Point p = new Point(points[i][0] + points[i][1], points[i][0] - points[i][1], i);
            pts.add(p);
            X.add(p);
            Y.add(p);
        }
        int best = Integer.MAX_VALUE;
        for(int i = 0; i < pts.size(); i++) {
            Point p = pts.get(i);
            X.remove(p);
            Y.remove(p);
            int cbest = Math.max(X.last().x - X.first().x, Y.last().y - Y.first().y);
            if(cbest < best)
                best = cbest;
            X.add(p);
            Y.add(p);
        }
        return best;
    }
}