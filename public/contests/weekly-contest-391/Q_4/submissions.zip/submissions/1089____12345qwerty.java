class Solution {
    public int minimumDistance(int[][] points) {
        List<Integer> sum = new ArrayList<>(), diff = new ArrayList<>();
        for(int[] arr : points){
            sum.add(arr[0]+arr[1]);
            diff.add(arr[0]-arr[1]);
        }
        Map<Integer, Integer> summap = new HashMap<>(), diffmap = new HashMap<>();
        for(int i = 0; i < points.length; i++){
            summap.put(i, sum.get(i));
            diffmap.put(i, diff.get(i));
        }
        Collections.sort(sum);
        Collections.sort(diff);
        int min = Integer.MAX_VALUE;
        for(int i = 0; i < points.length; i++){
            int l = sum.get(0), r = sum.get(sum.size()-1);
            if(summap.get(i) == l)
                l = sum.get(1);
            if(summap.get(i) == r)
                r = sum.get(sum.size()-2);
            int num = r-l;
            l = diff.get(0);
            r = diff.get(diff.size()-1);
            if(diffmap.get(i) == l)
                l = diff.get(1);
            if(diffmap.get(i) == r)
                r = diff.get(diff.size()-2);
            num = Math.max(num, r-l);
            min = Math.min(min, num);
        }
        return min;
    }
}