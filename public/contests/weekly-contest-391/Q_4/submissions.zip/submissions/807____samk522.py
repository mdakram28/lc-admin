class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        
        def MaxDist(A):
            # print(A)
            
            N = len(A)
 
            # Variables to track running extrema
            minsum = maxsum = A[0][0] + A[0][1]
            mindiff = maxdiff = A[0][0] - A[0][1]
            minsumidx = 0
            maxsumidx = 0
            mindiffidx = 0
            maxdiffidx = 0

            for i in range(1, N):
                s = A[i][0] + A[i][1]
                
                diff = A[i][0] - A[i][1]
                if (s < minsum):
                    minsum = s
                    minsumidx = i
                elif (s > maxsum):
                    maxsum = s
                    maxsumidx = i
                if (diff < mindiff):
                    mindiff = diff
                    mindiffidx = i
                elif (diff > maxdiff):
                    maxdiff = diff
                    maxdiffidx = i
            
            dist1 = maxsum - minsum
            dist2 = maxdiff - mindiff
            # print(dist1, dist2)
            
            if dist1 > dist2:
                return (dist1, maxsumidx, minsumidx)
            elif dist2 > dist1:
                return (dist2, maxdiffidx, mindiffidx)
            else:
                return (dist1, maxsumidx, minsumidx, maxdiffidx, mindiffidx)
            
        
        maxdistreturn = MaxDist(points)
        res = maxdistreturn[0]
        
        for i in range(1, len(maxdistreturn)):
            idx = maxdistreturn[i]
            ps = []
            for i, p in enumerate(points):
                if i != idx:
                    ps.append(p)
            thisres = MaxDist(ps)[0]
            if thisres <= res:
                res = thisres
        return res
            
            