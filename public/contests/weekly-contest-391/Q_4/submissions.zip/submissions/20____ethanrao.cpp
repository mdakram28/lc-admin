class Solution {
public:
    int n;
    int a[10][5], x[100005], y[100005], d[100005];
    int cal(std::vector <int> ca){
        int m = 0;
        for(int i = 0; i < ca.size(); ++i)
            for(int j = i + 1; j < ca.size(); ++j){
                m = std::max(m, abs(x[ca[i]] - x[ca[j]]) + abs(y[ca[i]] - y[ca[j]]));
            }
        return m;
    }
    int minimumDistance(vector<vector<int>>& points) {
        n = points.size();
        for(int i = 1; i <= 4; ++i) a[i][0] = 1, a[i][1] = 2;
        for(int i = 1; i <= n; ++i){
            x[i] = points[i - 1][0];
            y[i] = points[i - 1][1];
        }
        for(int i = 1; i <= n; ++i) d[i] = i;
        std::sort(d + 1, d + n + 1, [&](int e, int f){
            return x[e] + y[e] > x[f] + y[f];
        });
        a[1][1] = d[1], a[1][2] = d[2];
        std::sort(d + 1, d + n + 1, [&](int e, int f){
            return x[e] + y[e] < x[f] + y[f];
        });
        a[2][1] = d[1], a[2][2] = d[2];
        
        std::sort(d + 1, d + n + 1, [&](int e, int f){
            return x[e] - y[e] < x[f] - y[f];
        });
        a[3][1] = d[1], a[3][2] = d[2];
        std::sort(d + 1, d + n + 1, [&](int e, int f){
            return x[e] - y[e] > x[f] - y[f];
        });
        a[4][1] = d[1], a[4][2] = d[2];
        int ans = 1000000000;
        for(int i = 1; i <= n; ++i){
            std::vector <int> ca;
            for(int j = 1; j <= 4; ++j){
                if(a[j][1] == i) ca.push_back(a[j][2]);
                else ca.push_back(a[j][1]);
            }
            ans = std::min(ans, cal(ca));
        }
        return ans;
    }
};