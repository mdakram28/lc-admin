class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<int> sum, diff;
        for (const auto& point : points) {
            sum.push_back(point[0] + point[1]);
            diff.push_back(point[0] - point[1]);
        }
        sort(sum.begin(), sum.end());
        sort(diff.begin(), diff.end());
        
        int idx = points.size() - 1;
        int ans = max(sum[idx] - sum[0], diff[idx] - diff[0]);
        
        for (const auto& point : points) {
            int s = point[0] + point[1];
            int d = point[0] - point[1];
            if (s == sum[0]) {
                ans = min(ans, max(sum[idx] - sum[1], diff[idx] - diff[0]));
                if (d == diff[0]) {
                    ans = min(ans, max(sum[idx] - sum[1], diff[idx] - diff[1]));
                }
                if (d == diff[idx]) {
                    ans = min(ans, max(sum[idx] - sum[1], diff[idx-1] - diff[0]));
                }
            }
            if (s == sum[idx]) {
                ans = min(ans, max(sum[idx-1] - sum[0], diff[idx] - diff[0]));
                if (d == diff[0]) {
                    ans = min(ans, max(sum[idx-1] - sum[0], diff[idx] - diff[1]));
                }
                if (d == diff[idx]) {
                    ans = min(ans, max(sum[idx-1] - sum[0], diff[idx-1] - diff[0]));
                }
            }
            if (d == diff[0]) {
                ans = min(ans, max(sum[idx] - sum[0], diff[idx] - diff[1]));
                if (s == sum[0]) {
                    ans = min(ans, max(sum[idx] - sum[1], diff[idx] - diff[1]));
                }
                if (s == sum[idx]) {
                    ans = min(ans, max(sum[idx-1] - sum[0], diff[idx] - diff[1]));
                }
            }
            if (d == diff[idx]) {
                ans = min(ans, max(sum[idx] - sum[0], diff[idx-1] - diff[0]));
                if (s == sum[0]) {
                    ans = min(ans, max(sum[idx] - sum[1], diff[idx-1] - diff[0]));
                }
                if (s == sum[idx]) {
                    ans = min(ans, max(sum[idx-1] - sum[0], diff[idx-1] - diff[0]));
                }
            }
        }
        
        // cout << "sum:" << endl;
        // for (const auto& x : sum) cout << x << " ";
        // cout << endl << "diff:" << endl;
        // for (const auto& x : diff) cout << x << " ";
        return ans;
    }
};