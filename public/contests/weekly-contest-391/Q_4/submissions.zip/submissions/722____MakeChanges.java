class Solution {
    public int minimumDistance(int[][] points) {
        int min = Integer.MAX_VALUE;
        Set<Integer> set = new HashSet<>();
        helper(points, -1, set);
        // System.out.println(set);
        for (int x : set) {
            int val = helper(points, x, new HashSet<>());
            min = Math.min(min, val);
        }
        return min;
    }
    
    private int helper(int[][] points, int x, Set<Integer> set) {
        int n = points.length;
        List<int[]> sum = new ArrayList<>(), diff = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (i == x) {
                continue;
            }
            sum.add(new int[]{points[i][0] + points[i][1], i});
            diff.add(new int[]{points[i][0] - points[i][1], i});
        }
        Collections.sort(sum, (a, b) -> a[0] - b[0]);
        Collections.sort(diff, (a, b) -> a[0] - b[0]);
        int size = sum.size();
        int max = Math.max(sum.get(size - 1)[0] - sum.get(0)[0], diff.get(size - 1)[0] - diff.get(0)[0]);
        set.add(sum.get(size - 1)[1]);
        set.add(sum.get(0)[1]);
        set.add(diff.get(size - 1)[1]);
        set.add(diff.get(0)[1]);
        return max;
    }
}