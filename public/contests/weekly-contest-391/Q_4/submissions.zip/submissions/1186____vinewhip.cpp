class Solution {
public:
    
    int getmax(vector<pair<int, int>>& A, int N)
    {
        vector<int> V(N), V1(N);

        for (int i = 0; i < N; i++) {
            V[i] = A[i].first + A[i].second;
            V1[i] = A[i].first - A[i].second;
        }

        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());

        int maxi = max(V.back() - V.front(), V1.back() - V1.front());
        return maxi;
    }
    
    pair<int, int> helper(vector<pair<int, int>>A, int N)
    {
        vector<pair<int, int>> V(N), V1(N);

        for (int i = 0; i < N; i++) 
        {
            V[i].first = A[i].first + A[i].second;
            V[i].second = i;

            V1[i].first = A[i].first - A[i].second;
            V1[i].second = i;
        }

        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());

        int d1 = V.back().first - V.front().first;
        int d2 = V1.back().first - V1.front().first;

        if (d1 >= d2)
            return {V.back().second, V.front().second};
        else
            return {V1.back().second, V1.front().second};
    }
    
    
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<pair<int, int>>arr;
        for (auto v : points)
            arr.push_back({v[0], v[1]});
        
        auto p = helper(arr, n);
        int idx1 = p.first, idx2 = p.second;
        
        vector<pair<int, int>>a, b;
        for (int i = 0; i < n; i++)
        {
            if (i != idx1)
                a.push_back(arr[i]);
            if (i != idx2)
                b.push_back(arr[i]);
        }
        
        int ans1 = getmax(a, a.size());
        int ans2 = getmax(b, b.size());
        
        return min(ans1, ans2);
    }
};