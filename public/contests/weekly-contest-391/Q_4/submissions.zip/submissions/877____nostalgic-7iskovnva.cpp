#ifdef LOCAL
#include <bits/stdc++.h>
using namespace std;
#endif

#define fio ios::sync_with_stdio(0);cin.tie(0)
#define For(i,n) for (int i=1;i<=(int)(n);i++)
#define rep(i,n) for (int i=0;i<(int)(n);i++)
#define all(x) (x).begin(),(x).end()
#define clr(i) memset(i,0,sizeof(i))
#define Max(a,b,c) max(a,max(b,c))
#define Min(a,b,c) min(a,min(b,c))
#define fore(i,x) for (auto &i:x)
#define pii pair <int,int>
#define vi vector <int>
#define pb push_back
#define ll long long
#define endl '\n'
#define re return
#define se second
#define fi first

const int INF = 0x7fffffff;
const int MAXN = +3;

class Solution {
public:
	int minimumDistance(vector < vector<int> >& p) {
		pii a, b, c, d;
		a = b = c = d = { p[0][0],p[0][1] };
		fore(i, p) {
			int x = i[0], y = i[1];
			if (x + y < a.first + a.second) a = { x,y };
			if (x - y < b.first - b.second) b = { x,y };
			if (-x + y < -c.first + c.second) c = { x,y };
			if (-x - y < -d.first - d.second) d = { x,y };
		}
		// int ans = INF;
		// fore(i, p) {
		// 	int x = i[0], y = i[1];
		// 	ans = min(ans, go(p, { x,y }));
		// }
		// return ans;
		return min({ go(p,a),go(p,b),go(p,c),go(p,d) });
	}

	int calc(const pii& x, const pii& y) {
		return abs(x.first - y.first) + (x.second - y.second);
	}

	int go(vector < vector<int> >& p, pii skip) {
		pii a, b, c, d;
		bool sk = 0;
		bool f = 0;
		fore(i, p) {
			int x = i[0], y = i[1];
			if (!sk && x == skip.first && y == skip.second) {
				sk = 1;
				continue;
			}
			if (!f) {
				f = 1;
				a = b = c = d = { x, y };
			}
			if (x + y < a.first + a.second) a = { x,y };
			if (x - y < b.first - b.second) b = { x,y };
			if (-x + y < -c.first + c.second) c = { x,y };
			if (-x - y < -d.first - d.second) d = { x,y };
		}
		sk = 0;
		int ret = 0;
		fore(i, p) {
			int x = i[0], y = i[1];
			if (!sk && x == skip.first && y == skip.second) {
				sk = 1;
				continue;
			}
			ret = max({ ret,calc({x,y},a),calc({x,y},b),calc({x,y},c),calc({x,y},d) });
		}
		return ret;
		// return max({ calc(a,b),calc(a,c),calc(a,d),calc(b,c),calc(b,d),calc(c,d) });
	}
};

#ifdef LOCAL
Solution s;

int main() {

}
#endif