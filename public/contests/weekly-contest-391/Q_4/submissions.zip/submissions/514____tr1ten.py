class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def find(arr):
            b,c = [],[]
            for i in range(len(arr)):
                b.append((arr[i][0]+arr[i][1],i))
                c.append((arr[i][0]-arr[i][1],i))
            b = sorted(b)
            c = sorted(c)
            if b[-1][0]-b[0][0] > c[-1][0] - c[0][0]:
                return (b[-1][0]-b[0][0],b[-1][1],b[0][1])
            return (c[-1][0]-c[0][0],c[-1][1],c[0][1])
        val,a,b = find(points)
        res = val
        for i in [a,b]:
            temp = points[:]
            temp.pop(i)
            # print("poping ",i,temp,find(temp))
            res = min(res,find(temp)[0])
        return res