class Solution {
public:
    
    int minimumDistance(vector<vector<int>>& points) {
        int n= points.size();
        
        vector<pair<int,int>> temp1(n);
        vector<pair<int,int>> temp2(n);
        
        for(int i=0;i<n;i++){
            temp1[i]= {points[i][0] + points[i][1], i};
            temp2[i]= {points[i][0]- points[i][1], i};
        }
        
        sort(temp1.begin(), temp1.end());
        
        sort(temp2.begin(), temp2.end());
        int fans=INT_MAX;
        for(int i=0;i<n;i++){
             int ans1=0;
            // ans= max(temp1[n-1].first- temp1[0].first, temp2[n-1].first- temp2[0].first);
            if(temp1[0].second==i){
                ans1= max(ans1, temp1[n-1].first- temp1[1].first);
            }
            else if(temp1[n-1].second==i){
                ans1= max(ans1, temp1[n-2].first- temp1[0].first);
            }
            else{
                ans1= max(ans1, temp1[n-1].first- temp1[0].first);
            }
            
            int ans2=0;
            if(temp2[0].second==i){
                ans2= max(ans2, temp2[n-1].first- temp2[1].first);
            }
            else if(temp2[n-1].second==i){
                ans2= max(ans2, temp2[n-2].first- temp2[0].first);
            }
            else{
                ans2= max(ans2, temp2[n-1].first- temp2[0].first);
            }
            // cout<<ans1<<<endl;
            if(max(ans1,ans2)< fans){
                fans= max(ans1, ans2);
            }
        }
        // cout<<fans<<endl;
        
        // int ans= max(temp1[n-1].first- temp1[0].first, temp2[n-1].first- temp2[0].first);
        // int ans= INT_MIN;
        // ans= max(ans, abs(temp1[n-2].first- temp1[0].first));
        // ans= max(ans, abs(temp1[n-1].first- temp1[1].first));
        // ans= max(ans, abs(temp2[n-2].first - temp2[0].first));
        // ans= max(ans, abs(temp2[n-1].first - temp2[1].first));
        // cout<<temp1[0].second<<" "<<temp1[n-1].second<<" "<<temp2[0].second<<" "<<temp2[n-1].second<<endl;
        return fans;
    }
};