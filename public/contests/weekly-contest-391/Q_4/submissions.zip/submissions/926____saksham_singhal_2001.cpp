class Solution {
public:
    
    int calc(vector<vector<int>> &points,int exc)
    {
        vector<vector<int>> s,d;
        
        for(int i=0;i<points.size();i++)
        {
            if(i==exc)
                continue;
            s.push_back({points[i][0]+points[i][1],i});
            d.push_back({points[i][0]-points[i][1],i});
        }
        
        sort(s.begin(),s.end());
        sort(d.begin(),d.end());
        
        int n = s.size();
        
        int x = s[n-1][0]-s[0][0];
        int y = d[n-1][0]-d[0][0];
        
        return max(x,y);
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        
        vector<vector<int>> s,d;
        int n = points.size();
        
        for(int i=0;i<points.size();i++)
        {
            s.push_back({points[i][0]+points[i][1],i});
            d.push_back({points[i][0]-points[i][1],i});
        }
        
        sort(s.begin(),s.end());
        sort(d.begin(),d.end());
        
        
        int x = s[n-1][0]-s[0][0];
        int y = d[n-1][0]-d[0][0];
        
        // cout<<x<<" "<<y<<endl;
        
        if(x<y)
        {
            return min(calc(points,d[0][1]),calc(points,d[n-1][1]));
        }
        else if(x>y)
        {
            return min(calc(points,s[0][1]),calc(points,s[n-1][1]));
        }
        
        
        return min({calc(points,d[0][1]),calc(points,d[n-1][1]),calc(points,s[0][1]),calc(points,s[n-1][1])});
        
    }
};