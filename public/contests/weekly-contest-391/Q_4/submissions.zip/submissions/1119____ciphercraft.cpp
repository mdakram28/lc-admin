class Solution {
private:
    int funsolve(vector<vector<int>>& a) {
        vector<pair<int,int>> v;
        multiset<int> s;
        multiset<int> d;
        for(auto it:a){
            s.insert(it[0]+it[1]);
            d.insert(it[0]-it[1]);
        }
        int ans=INT_MAX;
        int n=a.size();
        for(int i=0;i<n;i++){
            int cs=a[i][0]+a[i][1];
            int cd=a[i][0]-a[i][1];
            s.erase(s.find(cs));
            d.erase(d.find(cd));
            cout << ans << endl;
            int cans=INT_MAX;
            int v1=*(s.rbegin())- *(s.begin());
            int v2=*(d.rbegin())- *(d.begin());
            cans=max(v1,v2);
            ans=min(ans,cans);
            s.insert(cs);
            d.insert(cd);
        }
        
        return ans;
    }
public:
   
    int minimumDistance(vector<vector<int>>& a) {
       return funsolve(a);
    }
};
