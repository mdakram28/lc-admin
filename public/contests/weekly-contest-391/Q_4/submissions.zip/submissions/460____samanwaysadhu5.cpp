class Solution {
public:
    int helper(vector<pair<int, int>> s, vector<pair<int, int>> d, int pos)
    {
        int n = s.size();
        for (int i = 0; i < n; i++)
        {
            if (s[i].second == pos)
            {
                s.erase(s.begin() + i);
                break;
            }
        }
        for (int i = 0; i < n; i++)
        {
            if (d[i].second == pos)
            {
                d.erase(d.begin() + i);
                break;
            }
        }
        // cout << s.front().first << endl;
        // cout << s.back().first << endl;
        // cout << d.front().first << endl;
        // cout << d.back().first << endl;
        return max(-s.front().first + s.back().first, -d.front().first + d.back().first);
    }
    int minimumDistance(vector<vector<int>>& points)
    {
        int n = points.size();
        vector<pair<int, int>> s(n), d(n);
        for (int i = 0; i < n; i++)
        {
            s[i] = {points[i][0] + points[i][1], i};
            d[i] = {points[i][0] - points[i][1], i};
        }
        sort(s.begin(), s.end());
        sort(d.begin(), d.end());
        // cout << s.front().second << endl;
        // cout << s.back().second << endl;
        // cout << d.front().second << endl;
        // cout << d.back().second << endl;
        return min(min(helper(s, d, s.front().second), helper(s, d, s.back().second)), min(helper(s, d, d.front().second), helper(s, d, d.back().second)));
    }
};