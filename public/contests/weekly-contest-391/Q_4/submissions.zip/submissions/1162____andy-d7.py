class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        t1 = []
        t2 = [] 
        n = len(points)
        for i, v in enumerate(points):
            t1.append((v[0]+v[1], i))
            t2.append((v[0]-v[1],i))
        
        t1.sort()
        # print(t1)
         
        t2.sort()
        # print(t2)
        
        # ret1 = min(t1[-2][0] - t1[0][0], t1[-1][0] - t1[1][0])
        # if t1[-2][0] - t1[0][0]
        
        
        def calc(arr, v):
            if v == arr[-1][1]:
                return arr[-2][0] - arr[0][0]
            if v == arr[0][1]:
                return arr[-1][0] - arr[1][0]
            return arr[-1][0] - arr[0][0]
            
        s = set()
        s.add(t1[0][1])
        s.add(t1[-1][1])
        s.add(t2[0][1])
        s.add(t2[-1][1])
        # print(s)
        ret = max(t1[-1][0] - t1[0][0], t2[-1][0] - t2[0][0])
        for v in s:
            tmp = max(calc(t1, v), calc(t2, v))
            # print(v, calc(t1, v), calc(t2, v), tmp)
            ret = min(ret, tmp) 
        return ret
        
        
        