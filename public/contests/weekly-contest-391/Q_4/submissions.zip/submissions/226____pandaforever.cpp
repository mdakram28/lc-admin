int dis(int x1,int y1,int x2,int y2)
{
    return abs(x1-x2)+abs(y1-y2);
}

pair<int,int> doit(vector<vector<int> >& a)
{
    int x,y,n,i,misum,masum,midiff,madiff,sum,diff,ma,madis,vdis;
    pair<int,int> ret;
    n=a.size();
    misum=(1<<30);
    masum=-(1<<30);
    midiff=(1<<30);
    madiff=-(1<<30);
    for (i=0;i<n;i++)
    {
        sum=a[i][0]+a[i][1];
        diff=a[i][0]-a[i][1];
        misum=min(misum,sum);
        masum=max(masum,sum);
        midiff=min(midiff,diff);
        madiff=max(madiff,diff);
    }
    ret=make_pair(-1,-1);
    ma=-1;
    for (i=0;i<n;i++)
    {
        sum=a[i][0]+a[i][1];
        diff=a[i][0]-a[i][1];
        madis=max(max(sum-misum,masum-sum),max(diff-midiff,madiff-diff));
        if (madis>ma)
        {
            ma=madis;
            ret.first=i;
        }
    }
    x=ret.first;
    ma=-1;
    for (i=0;i<n;i++)
    {
        if (i==x) continue;
        vdis=dis(a[i][0],a[i][1],a[x][0],a[x][1]);
        if (vdis>ma)
        {
            ma=vdis;
            ret.second=i;
        }
    }
    /*
    for (x=0;x<n;x++) if (x!=v) break;
    y=-1;
    for (i=0;i<n;i++)
    {
        if (i==x) continue;
        if (i==v) continue;
        if (y==-1) y=i;
        else
        {
            if (dis(a[x][0],a[x][1],a[i][0],a[i][1])>dis(a[x][0],a[x][1],a[y][0],a[y][1]))
            {
                y=i;
            }
        }
    }
    x=y;
    y=-1;
    for (i=0;i<n;i++)
    {
        if (i==x) continue;
        if (i==v) continue;
        if (y==-1) y=i;
        else
        {
            if (dis(a[x][0],a[x][1],a[i][0],a[i][1])>dis(a[x][0],a[x][1],a[y][0],a[y][1]))
            {
                y=i;
            }
        }
    }
    */
    return ret;
}

class Solution {
public:
    int minimumDistance(vector<vector<int>>& a) {
        int i,j,n,v,ans,misum,masum,midiff,madiff,sum,diff;
        vector<vector<int> > tmp;
        pair<int,int> p;
        pair<int,int> pp;
        n=a.size();
        p=doit(a);
        //cout<<"p:"<<p.first<<" "<<p.second<<endl;
        tmp.clear();
        for (i=0;i<a.size();i++)
        {
            if (i==p.first) continue;
            tmp.push_back(a[i]);
        }
        pp=doit(tmp);
        //cout<<"pp1:"<<pp.first<<" "<<pp.second<<endl;
        ans=dis(tmp[pp.first][0],tmp[pp.first][1],tmp[pp.second][0],tmp[pp.second][1]);

        tmp.clear();
        for (i=0;i<a.size();i++)
        {
            if (i==p.second) continue;
            tmp.push_back(a[i]);
        }
        pp=doit(tmp);
        //cout<<"pp2:"<<pp.first<<" "<<pp.second<<endl;
        ans=min(ans,dis(tmp[pp.first][0],tmp[pp.first][1],tmp[pp.second][0],tmp[pp.second][1]));
        return ans;
        
    }
};