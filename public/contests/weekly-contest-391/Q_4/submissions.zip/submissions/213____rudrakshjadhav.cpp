class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
         int minsum, maxsum, mindiff, maxdiff;
        int a = 0, j =0, k = 0, l = 0;
        minsum = maxsum = p[0][0] + p[0][1];
        mindiff = maxdiff = p[0][0] - p[0][1];
        //a = minsum     j = maxsum      mindiff = k    maxdiff = l
        int N = p.size();
        for (int i = 1; i < N; i++) {
            int sum =  p[i][0] + p[i][1];
            int diff = p[i][0] - p[i][1];
            if (sum < minsum){
                
                minsum = sum;
                a = i;
            }
            else if (sum > maxsum){
                maxsum = sum;
            j = i;}
            if (diff < mindiff){
                mindiff = diff;k=i;}
            else if (diff > maxdiff){
                maxdiff = diff;l=i;}
        }

        int maximum = max(maxsum - minsum, maxdiff - mindiff);
        if(maxsum - minsum > maxdiff - mindiff)
        {
            int chk = a == 0 ? 1 : 0;
            minsum = maxsum = p[chk][0] + p[chk][1];
            mindiff = maxdiff = p[chk][0] - p[chk][1];
        for (int i = 1; i < N; i++) {
            if(i == a)continue;
            int sum =  p[i][0] + p[i][1];
            int diff = p[i][0] - p[i][1];
            if (sum < minsum){
                
                minsum = sum;
            }
            else if (sum > maxsum){
                maxsum = sum;}
            if (diff < mindiff){
                mindiff = diff;}
            else if (diff > maxdiff){
                maxdiff = diff;}
        }
            int d1 = max(maxsum - minsum, maxdiff - mindiff);
            chk = j == 0 ? 1 : 0;
            minsum = maxsum = p[chk][0] + p[chk][1];
            mindiff = maxdiff = p[chk][0] - p[chk][1];
        for (int i = 1; i < N; i++) {
            if(i == j)continue;
            int sum =  p[i][0] + p[i][1];
            int diff = p[i][0] - p[i][1];
            if (sum < minsum){
                
                minsum = sum;
            }
            else if (sum > maxsum){
                maxsum = sum;}
            if (diff < mindiff){
                mindiff = diff;}
            else if (diff > maxdiff){
                maxdiff = diff;}
        }
            int d2 = max(maxsum - minsum, maxdiff - mindiff);
            return min(d1, d2);
        }else{
            int chk = k == 0 ? 1 : 0;
            minsum = maxsum = p[chk][0] + p[chk][1];
            mindiff = maxdiff = p[chk][0] - p[chk][1];
        for (int i = 1; i < N; i++) {
            if(i == k)continue;
            int sum =  p[i][0] + p[i][1];
            int diff = p[i][0] - p[i][1];
            if (sum < minsum){
                
                minsum = sum;
            }
            else if (sum > maxsum){
                maxsum = sum;}
            if (diff < mindiff){
                mindiff = diff;}
            else if (diff > maxdiff){
                maxdiff = diff;}
        }
            int d1 = max(maxsum - minsum, maxdiff - mindiff);
            chk = l == 0 ? 1 : 0;
            minsum = maxsum = p[chk][0] + p[chk][1];
            mindiff = maxdiff = p[chk][0] - p[chk][1];
        for (int i = 1; i < N; i++) {
            if(i == l)continue;
            int sum =  p[i][0] + p[i][1];
            int diff = p[i][0] - p[i][1];
            if (sum < minsum){
                
                minsum = sum;
            }
            else if (sum > maxsum){
                maxsum = sum;}
            if (diff < mindiff){
                mindiff = diff;}
            else if (diff > maxdiff){
                maxdiff = diff;}
        }
            int d2 = max(maxsum - minsum, maxdiff - mindiff);
            return min(d1, d2);
        }
        return -1;
    }
};