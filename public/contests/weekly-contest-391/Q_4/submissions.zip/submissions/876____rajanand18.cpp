class Solution {
public:
    
    pair<int, int> findIndicesWithMaxManhattanDistance(const vector<vector<int>>& A) {
    int minsum, maxsum, mindiff, maxdiff;
    int i1, i2, i3, i4;
        i1=i2=i3=i4=0;
    minsum = maxsum = A[0][0] + A[0][1];
    mindiff = maxdiff = A[0][0] - A[0][1];

    for (int i = 1; i < A.size(); i++) {
        int sum = A[i][0] + A[i][1];
        int diff = A[i][0] - A[i][1];

        if (sum < minsum) {
            minsum = sum;
            i1 = i;
        } else if (sum > maxsum) {
            maxsum = sum;
            i2 = i;
        }

        if (diff < mindiff) {
            mindiff = diff;
            i3=i;
        } else if (diff > maxdiff) {
            maxdiff = diff;
            i4=i;
        }
    }

    int max_manhattan_distance = max(maxsum - minsum, maxdiff - mindiff);
    if (max_manhattan_distance == maxsum - minsum) {
        return make_pair(i1, i2);
    } else if(max_manhattan_distance==maxdiff - mindiff) {
        return make_pair(i3, i4);
    }
    return make_pair(-1,-1);
}
    
    
    pair<int, int> findIndicesWithMaxManhattanDistance2(const vector<vector<int>>& A,int ind) {
    int minsum, maxsum, mindiff, maxdiff;
    int i1, i2, i3, i4;
        
        int st=0;
        // cout<<ind<<"hello"<<endl;
        if(ind==0){
            minsum = maxsum = A[1][0] + A[1][1];
    mindiff = maxdiff = A[1][0] - A[1][1];
            st=1;
        }
        else{
            minsum = maxsum = A[0][0] + A[0][1];
    mindiff = maxdiff = A[0][0] - A[0][1];
        }
        i1=i2=i3=i4=st;
    

    for (int i = st+1; i < A.size(); i++) {
        if(i==ind){
            continue;
        }
        int sum = A[i][0] + A[i][1];
        int diff = A[i][0] - A[i][1];

        if (sum < minsum) {
            minsum = sum;
            i1 = i;
        } else if (sum > maxsum) {
            maxsum = sum;
            i2 = i;
        }

        if (diff < mindiff) {
            mindiff = diff;
            i3=i;
        } else if (diff > maxdiff) {
            maxdiff = diff;
            i4=i;
        }
    }

    int max_manhattan_distance = max(maxsum - minsum, maxdiff - mindiff);
    if (max_manhattan_distance == maxsum - minsum) {
        return make_pair(i1, i2);
    } else if(max_manhattan_distance==maxdiff - mindiff) {
        return make_pair(i3, i4);
    }
    return make_pair(-1,-1);
}
    
    
    
    int minimumDistance(vector<vector<int>>& A) {
        pair<int,int> p=findIndicesWithMaxManhattanDistance(A);
        // cout<<p.first<<' '<<p.second<<endl;
        
        int max1=abs(A[p.first][0]-A[p.second][0])+abs(A[p.first][1]-A[p.second][1]);
        
        pair<int,int> p2=findIndicesWithMaxManhattanDistance2(A,p.first);
        // cout<<p2.first<<' '<<p2.second<<endl;
        
        int max2=abs(A[p2.first][0]-A[p2.second][0])+abs(A[p2.first][1]-A[p2.second][1]);
        
        pair<int,int> p3=findIndicesWithMaxManhattanDistance2(A,p.second);
        // cout<<p3.first<<' '<<p3.second<<endl;
        
        int max3=abs(A[p3.first][0]-A[p3.second][0])+abs(A[p3.first][1]-A[p3.second][1]);
        
        return min(max1,min(max3,max2));
    }
};