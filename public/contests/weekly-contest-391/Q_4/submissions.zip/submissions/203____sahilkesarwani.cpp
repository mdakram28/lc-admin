class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<vector<int>> sum, diff;
        for(int i = 0; i < n; ++i) {
            sum.push_back({points[i][0] + points[i][1], i});
            diff.push_back({points[i][0] - points[i][1], i});
        }
        sort(sum.begin(), sum.end());
        sort(diff.begin(), diff.end());
        int ans = INT_MAX;
        for(int i = 0; i < n; ++i) {
            if(sum[n-1][1] == i && diff[n-1][1] == i) ans = min(ans, max(sum[n-2][0] - sum[0][0], diff[n-2][0] - diff[0][0]));
            else if(sum[n-1][1] == i && diff[0][1] == i) ans = min(ans, max(sum[n-2][0] - sum[0][0], diff[n-1][0] - diff[1][0]));
            else if(sum[0][1] == i && diff[n-1][1] == i) ans = min(ans, max(sum[n-1][0] - sum[1][0], diff[n-2][0] - diff[0][0]));
            else if(sum[0][1] == i && diff[0][1] == i) ans = min(ans, max(sum[n-1][0] - sum[1][0], diff[n-1][0] - diff[1][0]));
            else if(sum[n-1][1] == i) ans = min(ans, max(sum[n-2][0] - sum[0][0], diff[n-1][0] - diff[0][0]));
            else if(sum[0][1] == i) ans = min(ans, max(sum[n-1][0] - sum[1][0], diff[n-1][0] - diff[0][0]));
            else if(diff[n-1][1] == i) ans = min(ans, max(sum[n-1][0] - sum[0][0], diff[n-2][0] - diff[0][0]));
            if(diff[0][1] == i) ans = min(ans, max(sum[n-1][0] - sum[0][0], diff[n-1][0] - diff[1][0]));
            else ans = min(ans, max(sum[n-1][0] - sum[0][0], diff[n-1][0] - diff[0][0]));
        }
        return ans;
    }
};