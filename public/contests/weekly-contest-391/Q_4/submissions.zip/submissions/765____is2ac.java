class Solution {
    public int minimumDistance(int[][] points) {
        int[] d = diam(points);
        int[] temp = new int[] {0,0};
        temp[0] = points[d[0]][0];
        temp[1] = points[d[0]][1];
        points[d[0]] = points[d[1]];
        int[] a = diam(points);
         int y = Math.abs(points[a[0]][0]-points[a[1]][0]);
        y += Math.abs(points[a[0]][1]-points[a[1]][1]);
        points[d[1]] = temp;
        points[d[0]] = temp;
        int[] b = diam(points);
       /*System.out.println(Arrays.toString(d));
        System.out.println(Arrays.toString(a));
        System.out.println(Arrays.toString(b));*/
int x = Math.abs(points[b[0]][0]-points[b[1]][0]);
        x += Math.abs(points[b[0]][1]-points[b[1]][1]);
               return Math.min(x,y);
    }
    public int[] diam(int[][] points) {
        int[] a = new int[4];
        int[][] b = new int[4][2];
        for (int i = 0; i < 3; i++) {
            b[i] = points[0];
        }
        for (int i = 0; i < points.length ;i++) {
            int[] c = points[i];
            if (c[0]+c[1] < b[0][0]+b[0][1]) {
                a[0] = i;
                b[0] = c;
            }
            if (c[0]-c[1] < b[1][0]-b[1][1]) {
                a[1] = i;
                b[1] = c;
            }
            if (c[1]-c[0] < b[2][1]-b[2][0]) {
                a[2] = i;
                b[2] = c;
            }
            if (-c[1]-c[0]<b[3][1]-b[3][0]) {
                a[3] = i;
                b[3] = c;
            }
        }
        int[] d = new int[] {0,0};
        int dis = 0;
        for (int i = 0; i < points.length ;i++) {
            int cur = 0;
            for (int j = 0; j < 4; j++) {
                cur = Math.abs(b[j][0]-points[i][0]);
                cur+= Math.abs(b[j][1]-points[i][1]);
                if (cur>dis) {
                    d[0] = a[j];
                    d[1] = i;
                    dis = cur;
                }
            }
        }
        return d;
    }
}