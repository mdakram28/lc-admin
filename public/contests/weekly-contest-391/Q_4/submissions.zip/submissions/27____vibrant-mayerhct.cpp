class Solution {
public:
    int minimumDistance(vector<vector<int>>& a) {
        multiset<int> s1,s2,s3,s4;
        for(auto &v:a){
            int x=v[0];
            int y=v[1];
            s1.insert(x+y);
            s2.insert(x-y);
            s3.insert(-x+y);
            s4.insert(-x-y);
        }
        int ans=1e9;
        auto del=[&](multiset<int> &s,int v){
            auto it=s.find(v);
            s.erase(it);
        };
        auto get=[&](){
            int tmp=0;
            tmp=max(tmp,*s1.rbegin()-*s1.begin());
            tmp=max(tmp,*s2.rbegin()-*s2.begin());
            tmp=max(tmp,*s3.rbegin()-*s3.begin());
            tmp=max(tmp,*s4.rbegin()-*s4.begin());
            return tmp;
        };
        for(auto &v:a){
            int x=v[0];
            int y=v[1];
            int v1=x+y;
            int v2=x-y;
            int v3=-x+y;
            int v4=-x-y;
            del(s1,v1);
            del(s2,v2);
            del(s3,v3);
            del(s4,v4);
            ans=min(ans,get());
            s1.insert(v1);
            s2.insert(v2);
            s3.insert(v3);
            s4.insert(v4);
        }
        return ans;
    }
};