class Solution:
    
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        o=0;
        for i in range(len(points)):
            
            o+=1
            points[i].append(o)
        # Separate the x and y coordinates
        s1 = sorted(points, key=lambda x: x[1]+x[0])
        s2 = sorted(points, key=lambda x: x[1]-x[0])
        s3 = sorted(points, key=lambda x: -x[1]+x[0])
        s4 = sorted(points, key=lambda x: -x[1]-x[0])
        
        
        
        
        def dis(p1,p2):
            return abs(p1[0]-p2[0])+abs(p1[1]-p2[1])
        
        ans1 = 0
        p = s1[0][2];
        ans1 = max(ans1, dis(s1[1],s1[-1]));
        x1=[]
        x2=[]
        if(s2[0][2]!=p):
            x1=s2[0]
        else:
            x1=s2[1]
        if(s2[-1][2]!=p):
            x2=s2[-1]
        else:
            x2=s2[-2] 
        ans1 = max(ans1, dis(x1,x2));
        

        
        ans2 = 0
        p = s2[0][2];
        ans2 = max(ans2, dis(s2[1],s2[-1]));
        x1=[]
        x2=[]
        if(s1[0][2]!=p):
            x1=s1[0]
        else:
            x1=s1[1]
        if(s1[-1][2]!=p):
            x2=s1[-1]
        else:
            x2=s1[-2] 
        ans2 = max(ans2, dis(x1,x2));
        
    
        ans3 = 0
        p = s1[-1][2];
        ans3 = max(ans3, dis(s1[0],s1[-2]));
        x1=[]
        x2=[]
        if(s2[0][2]!=p):
            x1=s2[0]
        else:
            x1=s2[1]
        if(s2[-1][2]!=p):
            x2=s2[-1]
        else:
            x2=s2[-2] 
        ans3 = max(ans3, dis(x1,x2));
        
        
        ans4 = 0
        p = s2[-1][2];
        ans4 = max(ans4, dis(s2[0],s2[-2]));
        x1=[]
        x2=[]
        if(s1[0][2]!=p):
            x1=s1[0]
        else:
            x1=s1[1]
        if(s1[-1][2]!=p):
            x2=s1[-1]
        else:
            x2=s1[-2] 
        ans4 = max(ans4, dis(x1,x2));
        
        print(ans1)
        print(ans2)
        print(ans3)
        print(ans4)
        return min(ans1,ans2,ans3,ans4)
                    