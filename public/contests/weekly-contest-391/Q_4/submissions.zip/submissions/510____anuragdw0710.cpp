class Solution {
public:
    #define ll long long
    int minimumDistance(vector<vector<int>>& p) {
        int n=p.size();
        vector<pair<ll,int>> sum(n);
        vector<pair<ll,int>> diff(n);        
        for(int i=0;i<n;i++){
            sum[i]={p[i][0]+p[i][1],i};
            diff[i]={p[i][0]-p[i][1],i};
        }
        sort(sum.begin(),sum.end());
        sort(diff.begin(),diff.end());
        ll x=0,y=n-1;
        if(diff[y].second==sum[n-1].second)y--;
        if(diff[x].second==sum[n-1].second)x++;
        ll ans1=max(sum[n-2].first-sum[0].first ,diff[y].first-diff[x].first);
        x=0;y=n-1;
        if(diff[y].second==sum[0].second)y--;
        if(diff[x].second==sum[0].second)x++;
        ll ans2=max(sum[n-1].first-sum[1].first ,diff[y].first-diff[x].first);
        ans1=min(ans1,ans2);
        x=0;y=n-1;
        if(sum[y].second==diff[0].second)y--;
        if(sum[x].second==diff[0].second)x++;
        ll ans3=max(sum[y].first-sum[x].first ,diff[n-1].first-diff[1].first);
        ans1=min(ans1,ans3);
        x=0;y=n-1;
        if(sum[y].second==diff[n-1].second)y--;
        if(sum[x].second==diff[n-1].second)x++;
        ll ans4=max(sum[y].first-sum[x].first ,diff[n-2].first-diff[0].first);
        ans1=min(ans1,ans4);
        // ans1=min(ans1,max(sum[n-1].first-sum[1].first,diff[n-1].first-diff[1].first ) );
        // cout<<ans1<<endl;
        return ans1;
        
    }
};