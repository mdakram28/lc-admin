class Solution {
public:
    int minimumDistance(vector<vector<int>>& ar) {
        long long int n = ar.size();
        vector< vector<long long int>> sum(n, vector<long long int>(2)), dif(n, vector<long long int>(2));
        
        
        for (int i=0;i<n;i++)
        {
            sum[i][0] = ar[i][0]+ar[i][1];
            sum[i][1] = i;
            dif[i][0] = ar[i][0]-ar[i][1];
            dif[i][1] = i;
  
        }
        
        sort (sum.begin(), sum.end());
        sort (dif.begin(), dif.end());
        
        long long int ans = INT_MAX;
        
        long long int k = sum[0][1], pans = sum[n-1][0]-sum[1][0], st=0, en=n-1;
        
        if (dif[0][1]==k)
            st++;
        if (dif[n-1][1]==k)
            en--;
        
        pans=max(pans, dif[en][0]-dif[st][0]);
        ans = min(ans, pans);
        
        k = sum[n-1][1], pans = sum[n-2][0]-sum[0][0], st=0, en=n-1;
        
        if (dif[0][1]==k)
            st++;
        if (dif[n-1][1]==k)
            en--;
        
        pans=max(pans, dif[en][0]-dif[st][0]);
        ans = min(ans, pans);
        
        k = dif[0][1], pans = dif[n-1][0]-dif[1][0], st=0, en=n-1;
        
        if (sum[0][1]==k)
            st++;
        if (sum[n-1][1]==k)
            en--;
        
        pans=max(pans, sum[en][0]-sum[st][0]);
        ans = min(ans, pans);
        
        k = dif[n-1][1], pans = dif[n-2][0]-dif[0][0], st=0, en=n-1;
        
        if (sum[0][1]==k)
            st++;
        if (sum[n-1][1]==k)
            en--;
        
        pans=max(pans, sum[en][0]-sum[st][0]);
        ans = min(ans, pans);
        
        return ans;
        
    }
};