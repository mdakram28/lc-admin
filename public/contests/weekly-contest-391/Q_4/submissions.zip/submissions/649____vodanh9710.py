
def md(point1, point2):
    return abs(point1[0] - point2[0]) + abs(point1[1] - point2[1])

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        l, r, ml, mr = None, None, math.inf, 0
        maxx = 0
        for i in range(n):
            x, y = points[i]
            if x + y < ml:
                ml = x + y
                l = i
            if x + y > mr:
                mr = x + y
                r = i
            maxx = max(maxx, x)
        check = {l, r}
        l, r, ml, mr = None, None, math.inf, 0
        for i in range(n):
            x, y = points[i]
            x = maxx - x
            if x + y < ml:
                ml = x + y
                l = i
            if x + y > mr:
                mr = x + y
                r = i
        check.add(l)
        check.add(r)
        
        ans = math.inf
        for c in check:
            l, r, ml, mr = None, None, math.inf, 0
            maxx = 0
            for i in range(n):
                if i == c:
                    continue
                x, y = points[i]
                if x + y < ml:
                    ml = x + y
                    l = i
                if x + y > mr:
                    mr = x + y
                    r = i
                maxx = max(maxx, x)
            maxh = md(points[l], points[r])
            l, r, ml, mr = None, None, math.inf, 0
            for i in range(n):
                if i == c:
                    continue
                x, y = points[i]
                x = maxx - x
                if x + y < ml:
                    ml = x + y
                    l = i
                if x + y > mr:
                    mr = x + y
                    r = i
            maxh = max(maxh, md(points[l], points[r]))
            ans = min(ans, maxh)
        return ans