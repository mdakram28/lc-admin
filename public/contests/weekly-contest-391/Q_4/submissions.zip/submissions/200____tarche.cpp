const int INF = 1e9;

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<pair<int, int>> v;
        for (auto x : points) {
            v.emplace_back(x[0] + x[1], x[0] - x[1]);
        }
        
        vector<pair<int, int>> byX, byY;
        for (int i = 0; i < (int)(v.size()); i++) {
            byX.push_back({v[i].first, i});
            byY.push_back({v[i].second, i});
        }
        
        sort(byX.begin(), byX.end());
        sort(byY.begin(), byY.end());
        
        int n = (int)(v.size());
        int ans = min({
            max(byX[n - 2].first - byX[0].first, byY[n - 1].first - byY[0].first),
            max(byX[n - 1].first - byX[1].first, byY[n - 1].first - byY[0].first),
            max(byX[n - 1].first - byX[0].first, byY[n - 2].first - byY[0].first),
            max(byX[n - 1].first - byX[0].first, byY[n - 1].first - byY[1].first)
        });
        
        if (byX[0].second == byY[0].second) ans = min(ans, max(byX[n - 1].first - byX[1].first, byY[n - 1].first - byY[1].first));
        if (byX[0].second == byY[n - 1].second) ans = min(ans, max(byX[n - 1].first - byX[1].first, byY[n - 2].first - byY[0].first));
        if (byX[n - 1].second == byY[0].second) ans = min(ans, max(byX[n - 2].first - byX[0].first, byY[n - 1].first - byY[1].first));
        if (byX[n - 1].second == byY[n - 1].second) ans = min(ans, max(byX[n - 2].first - byX[0].first, byY[n - 2].first - byY[0].first));
        
        return ans;
    }
};