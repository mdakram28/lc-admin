class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {

        int n = points.size();
        vector<int> X(n);
        vector<int> Y(n);
        for (int i = 0; i < n; i++) {
            X[i] = points[i][0] - points[i][1];
            Y[i] = points[i][0] + points[i][1];
        }

        multiset<int> ms_X(X.begin(), X.end());
        multiset<int> ms_Y{Y.begin(), Y.end()};
        int ans = 1 << 30;

        for (int i = 0; i < n; i++) {

            int x = X[i];
            int y = Y[i];
            ms_X.erase(ms_X.find(x));
            ms_Y.erase(ms_Y.find(y));

            int diff_x = *ms_X.begin() - *ms_X.rbegin();
            int diff_y = *ms_Y.begin() - *ms_Y.rbegin();
            int tmp_ans = max(abs(diff_x), abs(diff_y));
            ans = min(ans, tmp_ans);

            ms_X.insert(x);
            ms_Y.insert(y);
        }

        return ans;
    }
};