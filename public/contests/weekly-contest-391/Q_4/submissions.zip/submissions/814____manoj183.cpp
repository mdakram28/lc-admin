class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n=p.size();
        map<int,int> mp1,mp2;
        for(int i=0;i<n;i++){
            mp1[p[i][0]+p[i][1]]++;
            mp2[p[i][0]-p[i][1]]++;
        }
        int ans=1e9;
        for(int i=0;i<n;i++){
            int x1=p[i][0]+p[i][1],x2=p[i][0]-p[i][1];
            mp1[x1]--;
            if(mp1[x1]==0)mp1.erase(x1);
            mp2[x2]--;
            if(mp2[x2]==0)mp2.erase(x2);
            ans=min(ans,max((mp1.rbegin()->first - mp1.begin()->first) , (mp2.rbegin()->first - mp2.begin()->first)));
            mp1[x1]++;
            mp2[x2]++;
        }
        return ans;
    }
};