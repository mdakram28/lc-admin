class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        multiset<int> sum, dif;
        for(int i = 0; i < n; i++){
            int s = p[i][0] + p[i][1];
            int d = p[i][0] - p[i][1];
            sum.insert(s);
            dif.insert(d);
        }
        
        
        int mxans = 1e9 + 5;
        for(int i = 0; i < n; i++){
            int s = p[i][0] + p[i][1];
            int d = p[i][0] - p[i][1];
            sum.erase(sum.find(s));
            dif.erase(dif.find(d));
            
            int mx1 = *(--sum.end()) - *(sum.begin());
            int mx2 = *(--dif.end()) - *(dif.begin());
            
            int mx = max(mx1, mx2);
            
            mxans = min(mxans, mx);
            
            sum.insert(s);
            dif.insert(d);
        }
        
        return mxans;
    }   
};