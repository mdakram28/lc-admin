class Solution {
public:
    const int inf=2e9;
    
    int minimumDistance(vector<vector<int>>& p) {
        int ma_1=-inf,ma_2=-inf,ma_3=-inf,ma_4=-inf;
        int n=p.size();
        for(int i=0;i<n;i++){
            int x=p[i][0],y=p[i][1];
            ma_1=max(ma_1,x+y);
            ma_2=max(ma_2,x-y);
            ma_3=max(ma_3,y-x);
            ma_4=max(ma_4,-x-y);
        }
        int len=0;
        vector<int> id;
        for(int i=0;i<n;i++){
            int x=p[i][0],y=p[i][1];
            int t=max(ma_1-x-y,max(ma_2-x+y,max(ma_3-y+x,ma_4+x+y)));
            if(t>len){
                len=t;
                id.clear();
                id.push_back(i);
            }else if(t==len) id.push_back(i);
        }
        if(id.size()>=10) return len;
        int res=inf;
        for(auto tt:id){
            ma_1=-inf,ma_2=-inf,ma_3=-inf,ma_4=-inf,len=0;
            for(int i=0;i<n;i++){
                if(i==tt) continue;
                int x=p[i][0],y=p[i][1];
                ma_1=max(ma_1,x+y);
                ma_2=max(ma_2,x-y);
                ma_3=max(ma_3,y-x);
                ma_4=max(ma_4,-x-y);
            }
            for(int i=0;i<n;i++){
                if(i==tt) continue;
                int x=p[i][0],y=p[i][1];
                int t=max(ma_1-x-y,max(ma_2-x+y,max(ma_3-y+x,ma_4+x+y)));
                if(t>len) len=t;
            }
            res=min(res,len);
        }
        
        return res;
    }
};