class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int idx1,idx2;
        int n=points.size();
        maxdis(n,-1,idx1,idx2,points);
        int t1,t2;
        return min(maxdis(n,idx1,t1,t2,points),maxdis(n,idx2,t1,t2,points));
    }
    int maxdis(int n,int o,int &idx1,int &idx2,vector<vector<int>>& p)
    {
        int minxpy=1e9,minxmy=1e9,maxxpy=-1e9,maxxmy=-1e9;
        int idxminxpy,idxminxmy,idxmaxxpy,idxmaxxmy;
        for(int i=0;i<n;++i)
        {
            if(i==o)
                continue;
            int tp=p[i][0]+p[i][1];
            int tm=p[i][0]-p[i][1];
            if(tp<minxpy)
            {
                idxminxpy=i;
                minxpy=tp;
            }
            if(tp>maxxpy)
            {
                idxmaxxpy=i;
                maxxpy=tp;
            }
            if(tm<minxmy)
            {
                idxminxmy=i;
                minxmy=tm;
            }
            if(tm>maxxmy)
            {
                idxmaxxmy=i;
                maxxmy=tm;
            }
        }
        if(maxxpy-minxpy>maxxmy-minxmy)
        {
            idx1=idxmaxxpy;
            idx2=idxminxpy;
            return maxxpy-minxpy;
        }
        idx1=idxmaxxmy;
        idx2=idxminxmy;
        return maxxmy-minxmy;
    }
};