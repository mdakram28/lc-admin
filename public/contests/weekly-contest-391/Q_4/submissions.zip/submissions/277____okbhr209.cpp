#include <bits/stdc++.h>
using namespace std;

#define ll long long int
#define INF 1000000000000000000  //1e18
const ll mod = 1000000007  ;

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        ll n = points.size() ;
        
        multiset<ll>x,y ;
        vector< vector<ll>>v ;
        
        for(auto it:points ){
            ll a = it[0] , b=it[1] ;
            x.insert( a+b)  ;
            y.insert( a-b) ;
            
            v.push_back({a+b,a-b}) ;
        }
        
        ll res = INF ;
        for(auto it: v ){
            ll a= it[0] , b=it[1] ;
            x.erase( x.find(a) );
            y.erase( y.find(b) );
            
            ll ans = max( *x.rbegin() - *x.begin() , *y.rbegin() - *y.begin() ) ;
            res = min(res,ans) ;
            
            x.insert(a);
            y.insert(b);
        }
        return res ;
    }
};