from sortedcontainers import SortedDict
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        points1 = [(sum(p), i) for i, p in enumerate(points)]
        points2 = [(p[0]-p[1], i) for i, p in enumerate(points)]
        p1 = SortedDict()
        p2 = SortedDict()
        for i in range(len(points)):
            if points1[i][0] not in p1:
                p1[points1[i][0]] = 0
            if points2[i][0] not in p2:
                p2[points2[i][0]] = 0
            # print(points1[i][0], points2[i][0])
                
            p1[points1[i][0]] += 1
            p2[points2[i][0]] += 1
        # print(p1, p2)
        
        res = float("inf")
        # print("start")
        for i in range(len(points)):
            s = points1[i][0]
            d = points2[i][0]
            
            # print(p1, p2)
            
            p1[s] -= 1
            p2[d] -= 1
            if p1[s] == 0:
                del p1[s]
            if p2[d] == 0:
                del p2[d]
            
            p1k = p1.keys()
            p2k = p2.keys()
            res = min(res, max(p1k[-1] - p1k[0], p2k[-1] - p2k[0]))
            
            if s not in p1:
                p1[s] = 0
            if d not in p2:
                p2[d] = 0
            p1[s] += 1
            p2[d] += 1
            
                
    
        return res
        
        
#         res = float("inf")
        
#         mins = mind = minsold = mindold = float("inf")
#         maxs = maxd = maxsold = maxdold = float("-inf")
#         for j, p in enumerate(points):
#             s = p[0] + p[1]
#             d = p[0] - p[1]
#             if s < mins:
#                 mins = s
#             if s > maxs:
#                 maxs = s
#             if d < mind:
#                 mind = d
#             if d > maxd:
#                 maxd = d
                
                
#         for j, p in enumerate(points):
#             s = p[0] + p[1]
#             d = p[0] - p[1]
#             if mins < s < minsold:
#                 minsold = s
#             if maxsold < s < maxs:
#                 maxsold = s
#             if mind < d < mindold:
#                 mindold = d
#             if maxdold < d < maxd:
#                 maxdold = d
#         print([maxd-mind, maxs-mins, maxs-minsold, maxsold-mins, maxd-mindold, maxdold-mind])
#         maxm = max(min([maxd-mind, maxs-mins, maxs-minsold, maxsold-mins, maxd-mindold, maxdold-mind]), 0)
#         return maxm