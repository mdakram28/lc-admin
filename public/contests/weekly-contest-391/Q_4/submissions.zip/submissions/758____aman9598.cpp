class Solution {
public:

    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        vector<int>sum;
        vector<int>diff;
        for(int i=0;i<n;i++){
            sum.push_back(points[i][0]+points[i][1]);
            diff.push_back(points[i][0]-points[i][1]);
        }
        sort(sum.begin(),sum.end());
        sort(diff.begin(),diff.end());
        int ans=INT_MAX;
        for(int i=0;i<n;i++){
            int x=sum[n-1]-sum[0],y=diff[n-1]-diff[0];
            if(points[i][0]+points[i][1]==sum[0])
                x=sum[n-1]-sum[1];
            else if(points[i][0]+points[i][1]==sum[n-1])
                 x=sum[n-2]-sum[0];
            if(points[i][0]-points[i][1]==diff[0])
                y=diff[n-1]-diff[1];
            else if(points[i][0]-points[i][1]==diff[n-1])
                y=diff[n-2]-diff[0];
            ans=min(ans,max(x,y));
        }
        return ans;
    }
};