class Solution {
public:
    int find(int idx,int l,vector<vector<int>>& arr){
        int n = arr.size();
        int ans = 0;
        for(int i=0;i<n;i++){
            if(i==l || i==idx) continue;
            ans = max(ans,abs(arr[idx][0]-arr[i][0]) + abs(arr[idx][1]-arr[i][1]));
        }
        return ans;
    }
    int findDis(int idx,vector<vector<int>>& arr){
        vector<int> sum,diff;
        
        int i = 0;
        for(int j=0;j<arr.size();j++){
            if(j==idx) continue;
            vector<int> x = arr[j];
            // cout<<i<<" "<<idx;
            // if(i==idx) continue;
            sum.push_back(x[0]+x[1]);
            diff.push_back(x[0]-x[1]);
            // i++;
        }
        
        sort(sum.begin(),sum.end());
        sort(diff.begin(),diff.end());
        
        int n = sum.size();
        
        return max(sum[n-1]-sum[0],diff[n-1]-diff[0]);
    }
    int minimumDistance(vector<vector<int>>& arr) {
        int n = arr.size();
        vector<vector<int>> sum,diff;
        
        int i = 0;
        for(auto x:arr){
            sum.push_back({x[0]+x[1],i});
            diff.push_back({x[0]-x[1],i});
            i++;
        }
        
        sort(sum.begin(),sum.end());
        sort(diff.begin(),diff.end());
        
        int p1,p2;
        if(sum[n-1][0]-sum[0][0]>diff[n-1][0]-diff[0][0]){
            p1 = sum[n-1][1];
            p2 = sum[0][1];
        }
        else{
            p1 = diff[n-1][1];
            p2 = diff[0][1];
        }
        
        
        
        // cout<<p1<<" "<<p2<<endl;
        
        return min(findDis(p1,arr),findDis(p2,arr));
        
        // return min(find(p1,p2,arr),find(p2,p1,arr));
    }
};