class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> m1,m2;
        int x,y;
        for(int i=0;i<points.size();i++){
            x=points[i][0]+points[i][1];
            y=points[i][0]-points[i][1];
            m1.insert(x);
            m2.insert(y);
        }
        int ans=INT_MAX;
        for(int i=0;i<points.size();i++){
            x=points[i][0]+points[i][1];
            y=points[i][0]-points[i][1];
            m1.erase(m1.find(x));
            m2.erase(m2.find(y));
            ans=min(ans,max(*m1.rbegin() - *m1.begin(), *m2.rbegin() - *m2.begin()));
            m1.insert(x);
            m2.insert(y);
            
        }
        return ans;
    }
};