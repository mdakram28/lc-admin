class Solution {
public:
    vector<int> sum, diff;

    pair<pair<int, int>, int> indexesMax(int banned) {
        int maxSum = -1e9, maxSumIdx = -1, minSum = 1e9, minSumIdx = -1;
        int maxDiff = -1e9, maxDiffIdx = -1, minDiff = 1e9, minDiffIdx = -1;
        int sz = sum.size();

        for (int i = 0; i < sz; ++i) {
            if (i != banned) {
                if (sum[i] > maxSum) maxSum = sum[i], maxSumIdx = i;
                if (sum[i] < minSum) minSum = sum[i], minSumIdx = i;

                if (diff[i] > maxDiff) maxDiff = diff[i], maxDiffIdx = i;
                if (diff[i] < minDiff) minDiff = diff[i], minDiffIdx = i;
            }
        }

        int sumDist = abs(maxSum - minSum), diffDist = abs(maxDiff - minDiff);
        if (sumDist > diffDist) return {{maxSumIdx, minSumIdx}, abs(maxSum - minSum)};
        return {{maxDiffIdx, minDiffIdx}, abs(maxDiff - minDiff)};
    }

    int minimumDistance(vector<vector<int>>& points) {
        int sz = points.size();
        sum.resize(sz), diff.resize(sz);


        for (int i = 0; i < sz; ++i) {
            sum[i] = points[i][0] + points[i][1];
            diff[i] = points[i][0] - points[i][1];
        }

        pair<pair<int, int>, int> candidates = indexesMax(-1);
        int cand0 = candidates.first.first; int cand1 = candidates.first.second;

        pair<pair<int, int>, int> wo0 = indexesMax(cand0);
        pair<pair<int, int>, int> wo1 = indexesMax(cand1);
        int distwo0 = wo0.second, distwo1 = wo1.second;
        return min(distwo0, distwo1);
    }
};