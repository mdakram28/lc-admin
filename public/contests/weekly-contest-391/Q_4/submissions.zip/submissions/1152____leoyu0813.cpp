class Solution {
public:    
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size ();
        // 1. left button -> right top;
        // 2. left top -> right button;
        map <int, vector <int>> lb2rt;
        map <int, vector <int>> lt2rb;
        for (int i = 0; i < n; ++i)
        {
            const vector <int>& p = points [i];
            lb2rt [p[0]+p[1]].push_back (i);
            lt2rb [p[1]-p[0]].push_back (i);
        }
        auto lb = lb2rt.begin ();       // x + y
        auto rt = lb2rt.rbegin ();      // x + y
        auto lt = lt2rb.begin ();       // y - x
        auto rb = lt2rb.rbegin ();      // y - x
        auto initPoint = [&]()
        {
            lb = lb2rt.begin ();       // x + y
            rt = lb2rt.rbegin ();      // x + y
            lt = lt2rb.begin ();       // y - x
            rb = lt2rb.rbegin ();      // y - x   
        };
        
        auto getDiff = [&]()->int
        {
            return max (abs(rt->first - lb->first), abs(rb->first - lt->first)) ;
        };
        int ans = getDiff ();
        auto removeIndex = [&] (int i)
        {
            int sub = points [i][1] - points [i][0];
            int add = points [i][1] + points [i][0];
            if (lt->first == sub && lt->second.size () == 1){
                lt++;
            }
            if (rb->first == sub && rb->second.size () == 1){
                rb++;
            }
            if (lb->first == add && lb->second.size () == 1){
                lb++;
            }
            if (rt->first == add && rt->second.size () == 1){
                rt++;
            }
            ans = min (ans, getDiff ());
            initPoint ();
        };
        
        if (lb->second.size () == 1)    // maybe remove;
        {
            int i = lb->second [0];
            removeIndex (i);
        }
        
        if (rt->second.size () == 1)    // maybe remove;
        {
            int i = rt->second [0];
            removeIndex (i);
        }
        
        if (lt->second.size () == 1)    // maybe remove;
        {
            int i = lt->second [0];
            removeIndex (i);
        }
        if (rb->second.size () == 1)    // maybe remove;
        {
            int i = rb->second [0];
            removeIndex (i);
        }
        return ans;
    }
};