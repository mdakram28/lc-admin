class Solution {
public:
    vector<int> calc(vector<vector<int>> & vec, vector<bool> & skip) {
        int n = vec.size();
        vector<pair<int, int>> v1;
        vector<pair<int, int>> v2;
        
        for(int i = 0; i < n; i++) {
            if(skip[i]) continue;
            v1.push_back(pair<int, int>{});
            v2.push_back(pair<int, int>{});
            int ind = v1.size() - 1;
            v1[ind].first = vec[i][0] + vec[i][1];
            v2[ind].first = vec[i][0] - vec[i][1];
            v1[ind].second = i; v2[ind].second = i;
        }
        
        sort(v1.begin(), v1.end());
        sort(v2.begin(), v2.end());
        vector<int> answer;
        
        if(v1.back().first - v1.front().first > v2.back().first - v2.front().first) {
            answer.push_back(v1.back().first - v1.front().first);
            answer.push_back(v1.front().second);
            answer.push_back(v1.back().second);
        }
        else {
            answer.push_back(v2.back().first - v2.front().first);
            answer.push_back(v2.front().second);
            answer.push_back(v2.back().second);
        }
        
        return answer;
    }
    
    
    int minimumDistance(vector<vector<int>>& points) {
        vector<bool> skip(points.size(), false);
        auto start = calc(points, skip);
        int best = start[0];
        skip[start[1]] = true;
        auto check1 = calc(points, skip);
        skip[start[1]] = false;
        skip[start[2]] = true;
        auto check2 = calc(points, skip);
        skip[start[2]] = false;
        best = min(best, check1[0]);
        best = min(best, check2[1]);
        
        return min({start[0], check1[0], check2[0]});
    }
};