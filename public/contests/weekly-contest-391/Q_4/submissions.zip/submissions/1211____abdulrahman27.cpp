#define ll long long 
class Solution {
public:
    int MaxDist(vector<pair<int, int> >& A, int N)
    {
        // Vectors to store maximum and
        // minimum of all the four forms
        vector<int> V(N), V1(N);

        for (int i = 0; i < N; i++) {
            V[i] = A[i].first + A[i].second;
            V1[i] = A[i].first - A[i].second;
        }

        // Sorting both the vectors
        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());
        int Max=V[V.size()-1]-V[0];
        Max=max(Max,min(V1[V1.size()-2]-V1[0],V1[V1.size()-1]-V1[1]));
        int Min=V1[V1.size()-1]-V1[0];
        Min=max(Min,min(V[V.size()-2]-V[0],V[V.size()-1]-V[1]));
        int ans=min(Min,Max);
        for (int i=0;i<N;i++)
        {
            if (A[i].first+A[i].second==V[0])
            {
                if (A[i].first-A[i].second==V1[0])
                    ans=min(ans,max(V[N-1]-V[1],V1[N-1]-V1[1]));
                else if (A[i].first-A[i].second==V1[N-1])
                    ans=min(ans,max(V[N-1]-V[1],V1[N-2]-V1[0]));
            }
            else if (A[i].first+A[i].second==V[N-1])
            {
                if (A[i].first-A[i].second==V1[0])
                    ans=min(ans,max(V[N-2]-V[0],V1[N-1]-V1[1]));
                else if (A[i].first-A[i].second==V1[N-1])
                    ans=min(ans,max(V[N-2]-V[0],V1[N-2]-V1[0]));
            }
            
        }
        return ans;

    }
    int minimumDistance(vector<vector<int>>& p) {
        vector<pair<int,int>> A;
        for (ll i=0;i<p.size();i++)
        {
            pair<int,int> x;
            x.first=p[i][0];
            x.second=p[i][1];
            A.push_back(x);
        }
        return MaxDist(A,A.size());
        
    }
};