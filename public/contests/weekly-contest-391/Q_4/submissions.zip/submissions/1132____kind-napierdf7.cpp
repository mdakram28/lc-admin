typedef pair<int, int> PII;
class Solution {
public:
    struct Node{
        int val, idx;
        bool operator<(const Node& t)const {
            return val < t.val;
        }
    };
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        if(n==1) return 0;
        int l = 0, r = 2e8;
        vector<vector<Node>> p(4);
        int i = 0;
        for(auto t:points){
            int x1 = t[0], y1 = t[1];
            p[0].push_back({x1+y1, i});
            p[1].push_back({x1-y1, i});
            p[2].push_back({-x1+y1, i});
            p[3].push_back({-x1-y1, i});
            i++;
        }
        for(int i = 0; i < 4; i++){
            sort(p[i].begin(), p[i].end());
        }
        function<bool(int)> check = [&](int x)->bool{
            
            for(int t = 0; t < n; t++){
                int cnt = 0;
                for(int i = 0; i < 4; i++){
                    int l = 0, r = n-1;
                    if(p[i][l].idx==t) l++;
                    if(p[i][r].idx==t) r--;
                    if(p[i][r].val-p[i][l].val>x){
                        cnt++;
                    }
                }
                if(cnt==0) return true;
            }
            return false;
        };
        while(l < r){
            int mid = (l+r) >> 1;
            if(check(mid)){
                r = mid;
            } else {
                l = mid+1;
            }
        }
        
        return l;
    }
};