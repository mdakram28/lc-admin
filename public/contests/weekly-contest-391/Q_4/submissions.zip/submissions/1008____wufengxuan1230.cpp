class Solution {
public:
    int x[4][100001] = {0};
    //  x1 - x2 + y1 - y2; x1 >= x2, y1 >= y2
    // -x1 + x2 + y1 - y2; x1 <  x2, y1 >= y2
    //  x1 - x2 - y1 + y2; x1 >= x2, y1 <  y2
    // -x1 + x2 - y1 + y2; x1 <  x2, y1 <  y2
    
    //   (x1 + y1)  - (x2 + y2)
    //  (-x1 + y1)  - (-x2 + y2)
    //   (x1 - y1)  - (x2 - y2)
    //  (-x1 - y1)  - (-x2 - y2))
    int minimumDistance(vector<vector<int>>& points) {
        for (int i = 0; i < points.size(); ++i) {
            int m = points[i][0], n = points[i][1];
            x[0][i] =  m + n;
            x[1][i] = -m + n;
            x[2][i] =  m - n;
            x[3][i] = -m - n;
        }
        
        for (int i = 0; i < 4; ++i) {
            sort(x[i], x[i] + points.size());
        }
        
        int res = INT_MAX;
        for (int i = 0; i < points.size(); ++i) {
            int m = points[i][0], n = points[i][1];
            
            int d = 0;
            if (m + n == x[0][points.size() - 1]) {
                d = max(d, x[0][points.size() - 2] - x[0][0]);
            } else if (m + n == x[0][0]) {
                d = max(d, x[0][points.size() - 1] - x[0][1]);
            } else {
                d = max(d, x[0][points.size() - 1] - x[0][0]);
            }
            
            if (-m + n == x[1][points.size() - 1]) {
                d = max(d, x[1][points.size() - 2] - x[1][0]);
            } else if (-m + n == x[1][0]) {
                d = max(d, x[1][points.size() - 1] - x[1][1]);
            } else {
                d = max(d, x[1][points.size() - 1] - x[1][0]);
            }
            
            if (m - n == x[2][points.size() - 1]) {
                d = max(d, x[2][points.size() - 2] - x[2][0]);
            } else if (m - n == x[2][0]) {
                d = max(d, x[2][points.size() - 1] - x[2][1]);
            } else {
                d = max(d, x[2][points.size() - 1] - x[2][0]);
            }
            
            if (-m - n == x[3][points.size() - 1]) {
                d = max(d, x[3][points.size() - 2] - x[3][0]);
            } else if (-m - n == x[3][0]) {
                d = max(d, x[3][points.size() - 1] - x[3][1]);
            } else {
                d = max(d, x[3][points.size() - 1] - x[3][0]);
            }
            res = min(d, res);
        }
        return res;
    }
};