class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        t=[]
        p=[]
        n=len(points)
        for i in range(n):
            a,b=points[i]
            t.append((a+b,i))
            p.append((a-b,i))
        t.sort()
        p.sort()
        u=t[-1][0]-t[0][0]
        v=p[-1][0]-p[0][0]
        if u>=v:
            r,s=t[0][1],t[-1][1]
        else:
            r,s=p[0][1],p[-1][1]
        t=[]
        p=[]
        for i in range(n):
            if i!=r:
                a,b=points[i]
                t.append(a+b)
                p.append(a-b)
        t.sort()
        p.sort()
        u=t[-1]-t[0]
        v=p[-1]-p[0]
        res1=max(u,v)
        t=[]
        p=[]
        for i in range(n):
            if i!=s:
                a,b=points[i]
                t.append(a+b)
                p.append(a-b)
        t.sort()
        p.sort()
        u=t[-1]-t[0]
        v=p[-1]-p[0]
        res1=min(res1,max(u,v))
        return res1