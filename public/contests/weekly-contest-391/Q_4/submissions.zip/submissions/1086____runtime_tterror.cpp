class Solution {
public:
    
    int fun(vector<vector<int>>& points,vector<pair<int,int>>&v1,vector<pair<int,int>>&v2,vector<pair<int,int>>&v3,vector<pair<int,int>>&v4,int rem){
        
        int dist = -1;
        int n = points.size();
       for(int i=0;i<n;i++){
           
           if(i==rem)continue;
           
            int a = points[i][0] + points[i][1];
            int b = points[i][0] - points[i][1];
            int c = -points[i][0] - points[i][1];
            int d = -points[i][0] + points[i][1];
           
           int a1 ,b1,c1,d1;
           if(v3[n-1].second!=i && v3[n-1].second!=rem){
               a1 = v3[n-1].first;
           }
           else if(v3[n-2].second!=rem){
               a1 = v3[n-2].first;
           }
           else {
               a1 = v3[n-3].first;
           }
           
           if(v4[n-1].second!=i && v4[n-1].second!=rem){
               b1 = v4[n-1].first;
           }
           else if(v4[n-2].second!=rem){
               b1 = v4[n-2].first;
           }
           else {
               b1 = v4[n-3].first;
           }
           
           if(v1[n-1].second!=i && v1[n-1].second!=rem){
               c1 = v1[n-1].first;
           }
           else if(v1[n-2].second!=rem){
               c1 = v1[n-2].first;
           }
           else {
               c1 = v1[n-3].first;
           }
           
           if(v2[n-1].second!=i && v2[n-1].second!=rem){
               d1 = v2[n-1].first;
           }
           else if(v2[n-2].second!=rem){
               d1 = v2[n-2].first;
           }
           else {
               d1 = v2[n-3].first;
           }
           
           int mac = max(max((a+a1),(b+b1)) , max((c+c1),(d+d1)) );
           dist = max(dist,mac);
       }
        return dist;
    }
    int minimumDistance(vector<vector<int>>& points) {
        
        vector<pair<int,int>>v1,v2,v3,v4;
        int n = points.size();
        
        for(int i=0;i<n;i++){
            int a = points[i][0] + points[i][1];
            int b = points[i][0] - points[i][1];
            int c = -points[i][0] - points[i][1];
            int d = -points[i][0] + points[i][1];
            
            v1.push_back({a,i});
            v2.push_back({b,i});
            v3.push_back({c,i});
            v4.push_back({d,i});
        }
        
        sort(v1.begin(),v1.end());
        sort(v2.begin(),v2.end());
        sort(v3.begin(),v3.end());
        sort(v4.begin(),v4.end());
        
        // vector<vector<int>>ans(n);
        
        int d1 = fun(points,v1,v2,v3,v4,v1[n-1].second);
        int d2 = fun(points,v1,v2,v3,v4,v2[n-1].second);
        int d3 = fun(points,v1,v2,v3,v4,v3[n-1].second);
        int d4 = fun(points,v1,v2,v3,v4,v4[n-1].second);
        
        return min(min(d1,d2), min(d3,d4));
        
    }
};