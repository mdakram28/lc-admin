class Solution:
    def minimumDistance(self, arr: List[List[int]]) -> int:
        def maxMan(arr):
            n = len(arr)
            A = [0] * n
            B = [0] * n
            for i in range(n):
                A[i] = arr[i][0] + arr[i][1]
                B[i] = arr[i][0] - arr[i][1]
            AA = sorted(A)
            BB = sorted(B)
            a = AA[-1] - AA[0]
            b = BB[-1] - BB[0]
            return [a,b,AA,BB]
        n = len(arr)
        a,b,AA,BB = maxMan(arr)
        if a>=b:
            x = AA[0]
            y = AA[-1]
            xx = yy = -1
            for i in range(n):
                if arr[i][0] + arr[i][1] == x:
                    xx = i
                if arr[i][0] + arr[i][1]==y:
                    yy = i
        else:
            x = BB[0]
            y = BB[-1]
            xx = yy = -1
            for i in range(n):
                if arr[i][0] - arr[i][1] == x:
                    xx = i
                if arr[i][0] - arr[i][1]==y:
                    yy = i
        aa,bb,AA,BB = maxMan(arr[:xx] + arr[xx+1:])
        cc,dd,CC,DD = maxMan(arr[:yy] + arr[yy+1:])
        return min(max(aa,bb),max(cc,dd))