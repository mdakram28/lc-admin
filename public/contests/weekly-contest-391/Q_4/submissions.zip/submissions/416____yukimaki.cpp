#include <vector>
#include <algorithm>
#include <limits>

using namespace std;

class Solution {
public:
    pair<int, tuple<int, int, int, int>> computeMaxDistance(const vector<vector<int>>& pts) {
        int lower_bound = numeric_limits<int>::max(), upper_bound = numeric_limits<int>::min();
        int lower_diff = numeric_limits<int>::max(), upper_diff = numeric_limits<int>::min();

        for (const auto& point : pts) {
            int coord_x = point[0], coord_y = point[1];
            int sum_coords = coord_x + coord_y, diff_coords = coord_x - coord_y;
            lower_bound = min(lower_bound, sum_coords);
            upper_bound = max(upper_bound, sum_coords);
            lower_diff = min(lower_diff, diff_coords);
            upper_diff = max(upper_diff, diff_coords);
        }

        return {max(upper_bound - lower_bound, upper_diff - lower_diff),
                {lower_bound, upper_bound, lower_diff, upper_diff}};
    }

    int minimumDistance(vector<vector<int>> pts) {
        auto [max_dist, bounds] = computeMaxDistance(pts);
        auto [low_sum, high_sum, low_diff, high_diff] = bounds;
        vector<int> critical_indices;

        for (int idx = 0; idx < pts.size(); ++idx) {
            int coord_x = pts[idx][0], coord_y = pts[idx][1];
            if (coord_x + coord_y == high_sum || coord_x + coord_y == low_sum ||
                coord_x - coord_y == high_diff || coord_x - coord_y == low_diff) {
                critical_indices.push_back(idx);
            }
        }

        int least_max_distance = max_dist;
        for (int idx : critical_indices) {
            vector<vector<int>> altered_pts = pts;
            altered_pts.erase(altered_pts.begin() + idx);
            int new_max_dist = computeMaxDistance(altered_pts).first;
            least_max_distance = min(least_max_distance, new_max_dist);
        }

        return least_max_distance;
    }
};
