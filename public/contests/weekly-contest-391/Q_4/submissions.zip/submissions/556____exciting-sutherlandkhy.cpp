class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        vector<int> a , b;
        for(int i = 0; i < p.size(); i++) {
            a.push_back(p[i][0] + p[i][1]);
            b.push_back(p[i][0] - p[i][1]);
        }
        sort(a.begin() , a.end());
        sort(b.begin() , b.end());
        int n = p.size();
        int ans = 1e9;
        for(int i = 0; i < p.size(); i++) {
            int x1 = p[i][0] + p[i][1];
            int x2 = p[i][0] - p[i][1];
            int y1 = a[n-1] , y2 = a[0] , y3 = b[n-1] , y4 = b[0];
            if(a[n-1] == x1) y1 = a[n-2];
            if(a[0] == x1) y2 = a[1];
            if(b[n-1] == x2) y3 = b[n-2];
            if(b[0] == x2) y4 = b[1];
            ans = min(ans , max(y1 - y2 , y3 - y4));
        }
        return ans;
    }
};