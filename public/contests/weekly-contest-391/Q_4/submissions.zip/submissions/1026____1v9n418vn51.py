class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def distance(x1, x2):
            return abs(x1[0] - x2[0]) + abs(x1[1] - x2[1])
        
        def get_max_dis(arr):
            res = 0
            for i in range(len(arr)):
                for j in range(i+1, len(arr)):
                    res = max(res, distance(arr[i], arr[j]))
            # print(arr)
            # print(res)
            return res
        
        
        def helper(byX, byY):
            ans = math.inf
            if byX[0] == byY[0]:
                ans = min(ans, get_max_dis([byX[1], byX[-1], byY[1], byY[-1]]))
            elif byX[0] == byY[-1]:
                ans = min(ans, get_max_dis([byX[1], byX[-1], byY[0], byY[-2]]))
            else:
                ans = min(ans, get_max_dis([byX[1], byX[-1], byY[0], byY[-1]]))

            if byX[-1] == byY[0]:
                ans = min(ans, get_max_dis([byX[0], byX[-2], byY[1], byY[-1]]))
            elif byX[-1] == byY[-1]:
                ans = min(ans, get_max_dis([byX[0], byX[-2], byY[0], byY[-2]]))
            else:
                ans = min(ans, get_max_dis([byX[0], byX[-2], byY[0], byY[-1]]))
            return ans
        
        n = len(points)
        arrx = sorted(points, key=lambda x: x[0] + x[1])
        arry = sorted(points, key=lambda x: x[0] - x[1])
        # print(arrx)
        # print(arry)
        
        r1 = helper(arrx, arry)
        r2 = helper(arry, arrx)
        return min(r1, r2)
        
        