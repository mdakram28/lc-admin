class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        
        
        
            int sz=points.size(),res=-1,val,val1,val2,num1,num2;
        
         map<int,int>  map1,map2;
        
                 
        
            for(int i=0;i<sz;i++)
            {
                      num1=points[i][0];
                 num2=points[i][1];
                  map1[points[i][0]+points[i][1]]++;
                   map2[points[i][0]-points[i][1]]++;
                    points[i][0]=num1+num2;
                   points[i][1]=num1-num2;
            }
        
        
          for(int i=0;i<sz;i++)
          {
                num1=points[i][0],num2=points[i][1];
                    if(--map1[num1]==0)
                          map1.erase(num1);
                  if(--map2[num2]==0)
                        map2.erase(num2);
                 val1=map1.rbegin()->first-map1.begin()->first;
                 val2=map2.rbegin()->first-map2.begin()->first;
                 val=max(val1,val2);
              
                  if(res==-1)
                        res=val;
              
                else  res=min(res,val);
                map1[num1]++;
                map2[num2]++;
              
          }
        
          return  res;
        
    }
};