class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<pair<int, int>> sum(n), diff(n);
        
        for (int i=0; i<n; i++) {
            sum[i] = {points[i][0] + points[i][1], i};
            diff[i] = {points[i][0] - points[i][1], i};
        }
        
        sort(sum.begin(), sum.end());
        sort(diff.begin(), diff.end());
        
        int ans = INT_MAX;
        
        if (sum[n-1].first - sum[0].first > diff[n-1].first - diff[0].first) {
            // remove n-1
            int ind = sum[n-1].second;
            int i = 0, j=n-2, k=0, l=n-1;
            if (diff[0].second == ind) k++;
            if (diff[n-1].second == ind) l--;
            
            ans = min(ans, max(sum[j].first - sum[i].first, diff[l].first - diff[k].first));
            
            // remove 0
            ind = sum[0].second;
            i = 1, j=n-1, k=0, l=n-1;
            if (diff[0].second == ind) k++;
            if (diff[n-1].second == ind) l--;
            ans = min(ans, max(sum[j].first - sum[i].first, diff[l].first - diff[k].first));
        } else {
            // remove n-1
            int ind = diff[n-1].second;
            int i = 0, j=n-1, k=0, l=n-2;
            if (sum[0].second == ind) i++;
            if (sum[n-1].second == ind) j--;
            
            ans = min(ans, max(sum[j].first - sum[i].first, diff[l].first - diff[k].first));
            
            // remove 0
            ind = diff[0].second;
            i = 0, j=n-1, k=1, l=n-1;
            if (sum[0].second == ind) i++;
            if (sum[n-1].second == ind) j--;
            ans = min(ans, max(sum[j].first - sum[i].first, diff[l].first - diff[k].first)); 
        }
        
        return ans;
    }
};