impl Solution {
        pub fn minimum_distance(points: Vec<Vec<i32>>) -> i32 {
            let mut ms_x_add_y = MultiSet::new();
            let mut ms_x_sub_y = MultiSet::new();
            for pt in points.iter() {
                let (x, y) = (pt[0], pt[1]);
                ms_x_add_y.insert(x + y);
                ms_x_sub_y.insert(x - y);
            }
            let mut res = i32::MAX;
            for pt in points.iter() {
                let (x, y) = (pt[0], pt[1]);
                ms_x_add_y.remove(&(x + y));
                ms_x_sub_y.remove(&(x - y));
                let cur1 = ms_x_add_y.last().unwrap() - ms_x_add_y.first().unwrap();
                let cur2 = ms_x_sub_y.last().unwrap() - ms_x_sub_y.first().unwrap();
                res = res.min(cur1.max(cur2));
                ms_x_add_y.insert(x + y);
                ms_x_sub_y.insert(x - y);
            }
            res
        }
}
        use std::collections::{btree_map::Entry, BTreeMap};

        #[derive(Debug)]
        pub struct MultiSet<T> {
            inner: BTreeMap<T, usize>,
            n: usize,
        }

        impl<T> MultiSet<T>
        where
            T: Ord + Clone,
        {
            pub fn new() -> Self {
                Self {
                    inner: BTreeMap::new(),
                    n: 0,
                }
            }

            pub fn len(&self) -> usize {
                self.n
            }

            pub fn clear(&mut self) {
                self.inner.clear();
                self.n = 0;
            }

            pub fn contains(&self, d: &T) -> bool {
                self.inner.contains_key(&d)
            }

            pub fn first(&self) -> Option<&T> {
                self.inner.first_key_value().map(|(k, _)| k)
            }

            pub fn last(&self) -> Option<&T> {
                self.inner.last_key_value().map(|(k, _)| k)
            }

            pub fn insert(&mut self, d: T) {
                self.inner.entry(d).and_modify(|c| *c += 1).or_insert(1);
                self.n += 1;
            }

            pub fn remove(&mut self, d: &T) -> bool {
                let k = d.clone();
                match self.inner.entry(k) {
                    Entry::Vacant(e) => false,
                    Entry::Occupied(mut e) => {
                        self.n -= 1;
                        if *e.get() == 1 {
                            e.remove();
                        } else {
                            *e.get_mut() -= 1;
                        }
                        true
                    }
                }
            }

            pub fn pop_first(&mut self) -> Option<T> {
                if let Some(mut e) = self.inner.first_entry() {
                    self.n -= 1;
                    Some(if *e.get() == 1 {
                        e.remove_entry().0
                    } else {
                        *e.get_mut() -= 1;
                        e.key().clone()
                    })
                } else {
                    None
                }
            }

            pub fn pop_last(&mut self) -> Option<T> {
                if let Some(mut e) = self.inner.last_entry() {
                    self.n -= 1;
                    Some(if *e.get() == 1 {
                        e.remove_entry().0
                    } else {
                        *e.get_mut() -= 1;
                        e.key().clone()
                    })
                } else {
                    None
                }
            }
        }