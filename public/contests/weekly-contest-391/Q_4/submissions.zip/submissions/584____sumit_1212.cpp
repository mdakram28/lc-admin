class Solution {
public:
    
    int fun(int val,vector<vector<int>>& points){
        int N = points.size();
        vector<int> V, V1;
        bool c= true;
        for (int i = 0; i < N; i++) {
            int d1 = points[i][0] + points[i][1];
            int d2 = points[i][0] - points[i][1];
            
            if(c==true && d2==val){
                c=false;
            }
            else{
                V.push_back(d1);
                V1.push_back(d2);
            }
    }
 
    // Sorting both the vectors
    sort(V.begin(), V.end());
    sort(V1.begin(), V1.end());
 
    int maximum = max(V.back() - V.front(), V1.back() - V1.front());
        
        return maximum;
    }
    
    
    int f(int val,vector<vector<int>>& points){
        int N = points.size();
        vector<int> V, V1;
        bool c= true;
        for (int i = 0; i < N; i++) {
            int d1 = points[i][0] + points[i][1];
            int d2 = points[i][0] - points[i][1];
            
            if(c==true && d1==val){
                c=false;
            }
            else{
                V.push_back(d1);
                V1.push_back(d2);
            }
    }
 
    // Sorting both the vectors
    sort(V.begin(), V.end());
    sort(V1.begin(), V1.end());
 
    int maximum = max(V.back() - V.front(), V1.back() - V1.front());
        
        return maximum;
    }
    
    
    int minimumDistance(vector<vector<int>>& points) {
         int N = points.size();
        vector<int> V(N), V1(N);
 
    for (int i = 0; i < N; i++) {
        V[i] = points[i][0] + points[i][1];
        V1[i] = points[i][0] - points[i][1];
    }
 
    // Sorting both the vectors
    sort(V.begin(), V.end());
    sort(V1.begin(), V1.end());
 
    int maximum = max(V.back() - V.front(), V1.back() - V1.front());
 
    cout << maximum << endl;
    
           int num1 = f(V.back(),points);
           int num2 = f(V.front(),points);
           maximum = min(maximum,min(num1,num2));
        
            int num3 = fun(V1.back(),points);
            int num4 = fun(V1.front(),points);
            maximum = min(maximum,min(num3,num4));
        
        
        
        return maximum;
    }
};