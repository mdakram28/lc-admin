class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        std::map<int, size_t> sum_count;
        std::map<int, size_t> diff_count;
        for (const auto &p : points)
        {
            sum_count[p[0] + p[1]]++;
            diff_count[p[0] - p[1]]++;
        }
        
        int res = std::numeric_limits<int>::max();
        for (const auto &p : points)
        {
            const auto sum = p[0] + p[1];
            const auto diff = p[0] - p[1];
            if (auto it = sum_count.find(sum); it->second == 1)
            {
                sum_count.erase(it);
                
                if (auto it2 = diff_count.find(diff); it2->second == 1)
                {
                    diff_count.erase(it2);
                    
                    res = std::min(res, std::max(sum_count.rbegin()->first - sum_count.begin()->first, diff_count.rbegin()->first - diff_count.begin()->first));
                    
                    diff_count[diff]++;
                    
                }
                else
                {
                    res = std::min(res, std::max(sum_count.rbegin()->first - sum_count.begin()->first, diff_count.rbegin()->first - diff_count.begin()->first));
                }
                
                sum_count[sum]++;
            }
            else
            {
                if (auto it2 = diff_count.find(diff); it2->second == 1)
                {
                    diff_count.erase(it2);
                    
                    res = std::min(res, std::max(sum_count.rbegin()->first - sum_count.begin()->first, diff_count.rbegin()->first - diff_count.begin()->first));
                    
                    diff_count[diff]++;
                }
                else
                {
                    res = std::min(res, std::max(sum_count.rbegin()->first - sum_count.begin()->first, diff_count.rbegin()->first - diff_count.begin()->first));
                }
            }
            
            
            
        }
        return res;
    }
};