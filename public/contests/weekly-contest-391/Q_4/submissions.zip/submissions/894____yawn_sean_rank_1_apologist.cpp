class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        map<int, set<int>> R, C;
        for (int i = 0; auto& p : points) {
            auto r = p[0], c = p[1];
            p[0] = r - c, p[1] = r + c;
            R[p[0]].insert(i), C[p[1]].insert(i);
            ++i;
        }
        int res = max(R.rbegin()->first - R.begin()->first, C.rbegin()->first - C.begin()->first);

        const auto remove_id = [&](auto id) {
            auto r = points[id][0], c = points[id][1];
            R[r].erase(id), C[c].erase(id);
            if (R[r].empty()) {
                R.erase(r);
            }
            if (C[c].empty()) {
                C.erase(c);
            }
        };
        
        const auto insert_id = [&](auto id) {
            auto r = points[id][0], c = points[id][1];
            R[r].insert(id);
            C[c].insert(id);
        };
        
        if (R.begin()->second.size() == 1) {
            auto id = *(R.begin()->second.begin());
            remove_id(id);
            res = min(res, max(R.rbegin()->first - R.begin()->first, C.rbegin()->first - C.begin()->first));
            insert_id(id);
        }
        if (R.rbegin()->second.size() == 1) {
            auto id = *(R.rbegin()->second.begin());
            remove_id(id);
            res = min(res, max(R.rbegin()->first - R.begin()->first, C.rbegin()->first - C.begin()->first));
            insert_id(id);
        }
        if (C.begin()->second.size() == 1) {
            auto id = *(C.begin()->second.begin());
            remove_id(id);
            res = min(res, max(R.rbegin()->first - R.begin()->first, C.rbegin()->first - C.begin()->first));
            insert_id(id);
        }
        if (C.rbegin()->second.size() == 1) {
            auto id = *(C.rbegin()->second.begin());
            remove_id(id);
            res = min(res, max(R.rbegin()->first - R.begin()->first, C.rbegin()->first - C.begin()->first));
            insert_id(id);
        }
        return res;
    }
};