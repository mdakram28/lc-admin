vector<pair<int, int>> pp[4];
class Solution {
public:
  int minimumDistance(vector<vector<int>>& points) {
    int n = points.size();
    for (int i = 0; i < 4; i++) pp[i].clear();
    for (int i = 0; i < points.size(); i++) {
      pp[0].push_back({ points[i][0] + points[i][1] ,i });
      pp[1].push_back({ -points[i][0] + points[i][1],i });
      pp[2].push_back({ points[i][0] - points[i][1], i });
      pp[3].push_back({ -points[i][0] - points[i][1], i });
    }
    for (int i = 0; i < 4; i++) sort(pp[i].begin(), pp[i].end());

    int mi = 1e9;
    for (int eraseIdx = 0; eraseIdx < n; eraseIdx++) {
      int mx = 0;
      for (int i = 0; i < 4; i++) {
        if (pp[i][0].second == eraseIdx) {
          mx = max(mx, pp[i][n - 1].first - pp[i][1].first);
        }
        else if (pp[i][n - 1].second == eraseIdx) {
          mx = max(mx, pp[i][n - 2].first - pp[i][0].first);
        }
        else {
          mx = max(mx, pp[i][n - 1].first - pp[i][0].first);
        }
      }
      mi = min(mi, mx);
    }
    return mi;
  }
};