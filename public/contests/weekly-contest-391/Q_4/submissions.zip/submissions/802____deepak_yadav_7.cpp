class Solution {
private:
    int MaxDist(vector<vector<int>>& A, int N, int skip){
        vector<int> V(N-1), V1(N-1);
        int ind = 0;
        for (int i = 0; i < N; i++) {
            if(i==skip) continue;
            V[ind] = A[i][0] + A[i][1];
            V1[ind] = A[i][0] - A[i][1];
            ind++;
        }
        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());
        int maximum = max(V.back() - V.front(), V1.back() - V1.front());
        return maximum;
    }
    pair<int, int> f(vector<vector<int>>& A, int N){
        vector<pair<int, int>> V(N), V1(N);
        for (int i = 0; i < N; i++) {
            V[i].first = A[i][0] + A[i][1]; V[i].second = i;
            V1[i].first = A[i][0] - A[i][1]; V1[i].second = i;
        }
        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());
        int x = V.back().first - V.front().first, y = V1.back().first - V1.front().first;
        if(x>y){
            return {V.back().second, V.front().second};
        }
        else return {V1.back().second, V1.front().second};
    }
public:
    int minimumDistance(vector<vector<int>>& nums) {
        int ans = 1e9;
        pair<int, int> skip = f(nums, nums.size());
        int dis1 = MaxDist(nums, nums.size(), skip.first);
        int dis2 = MaxDist(nums, nums.size(), skip.second);
        return min(dis1, dis2);
    }
};