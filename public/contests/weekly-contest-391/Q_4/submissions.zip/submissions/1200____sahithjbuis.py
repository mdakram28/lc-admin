from typing import List

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        min_sum = max_sum = points[0][0] + points[0][1]
        min_diff = max_diff = points[0][0] - points[0][1]
        
        all_sums = []
        all_diffs = []
        
        for x, y in points:
            sum_ = x + y
            diff = x - y
            all_sums.append(sum_)
            all_diffs.append(diff)
            min_sum = min(min_sum, sum_)
            max_sum = max(max_sum, sum_)
            min_diff = min(min_diff, diff)
            max_diff = max(max_diff, diff)
        
        def new_extrema(index, all_values, current_min, current_max):
            if all_values[index] == current_min or all_values[index] == current_max:
                return (min(all_values[:index] + all_values[index+1:]), 
                        max(all_values[:index] + all_values[index+1:]))
            else:
                return (current_min, current_max)
        
        res = max(max_sum - min_sum, max_diff - min_diff)
        
        for i in range(len(points)):
            new_min_sum, new_max_sum = new_extrema(i, all_sums, min_sum, max_sum)
            new_min_diff, new_max_diff = new_extrema(i, all_diffs, min_diff, max_diff)
            res = min(res, max(new_max_sum - new_min_sum, new_max_diff - new_min_diff))
        
        return res
