class Solution {
public:
    
    int func(vector<vector<int>> &arr, vector<vector<int>> &brr, int i){
        int lw1 =0;
        
        while(lw1<arr.size() && arr[lw1][1]==i){
            lw1++;
        }
        
        int lw2 =0;
        
        while(lw2<brr.size() && brr[lw2][1]==i){
            lw2++;
        }
        
        int hg1 = arr.size()-1;
        
        while(hg1>=0 && arr[hg1][1]==i){
            hg1--;
        }
        
        int hg2 = brr.size()-1;
        
        while(hg2>=0 && brr[hg2][1]==i){
            hg2--;
        }
        
        return max(arr[hg1][0]-arr[lw1][0], brr[hg2][0]-brr[lw2][0]);
        
    }
    int minimumDistance(vector<vector<int>>& points) {
        vector<vector<int>> arr;
        vector<vector<int>> brr;
        int n = points.size();
        
    
        for(int i=0;i<n;i++){
            arr.push_back({points[i][0]-points[i][1],i});
            brr.push_back({points[i][1]+points[i][0],i});
        }
        
        sort(arr.begin(), arr.end());
        sort(brr.begin(), brr.end());
        
        // int mx = max(arr.back()-arr.front(), brr.back()-brr.front());
        // cout<<mx<<endl;
        
        int mn = INT_MAX;
        
        mn = min(mn, func(arr, brr, arr[0][1]));
        // cout<<mn<<" "<<arr[0][1]<<endl;
        mn = min(mn, func(arr, brr, arr[n-1][1]));
        // cout<<mn<<" "<<arr[n-1][1]<<endl;
        mn = min(mn, func(arr, brr, brr[0][1]));
         // cout<<mn<<" "<<brr[0][1]<<endl;
        mn = min(mn, func(arr, brr, brr[n-1][1]));
         // cout<<mn<<" "<<brr[n-1][1]<<endl;
        return mn;
        
    }
};