class Solution {
public:
    int minD(vector<vector<int>>& points, int gindex){
        vector<int> v1;
        vector<int> v2;
        int index = 0;
        for(auto i:points){
            if(index!=gindex){
                v1.push_back(i[0] + i[1]);
                v2.push_back(i[0] - i[1]);
            }
            index++;
        }
        sort(v1.begin(), v1.end());
        sort(v2.begin(), v2.end());

        return max(v1.back() - v1.front(), v2.back() - v2.front());
    }
    int minimumDistance(vector<vector<int>>& points) {
        vector<pair<int, int>> v1;
        vector<pair<int, int>> v2;
        int index = 0;
        for(auto i:points){
            v1.push_back({i[0] + i[1], index});
            v2.push_back({i[0] - i[1], index});
            index++;
        }
        sort(v1.begin(), v1.end());
        sort(v2.begin(), v2.end());

        int maxD = max(v1.back().first - v1.front().first, v2.back().first - v2.front().first);
        vector<int> indicies = { v1.back().second, v1.front().second, v2.back().second, v2.front().second };
        for(auto i : indicies){
            // cout<<i<<" => "<<minD(points, i)<<endl;
            maxD = min(maxD, minD(points, i));
        }
        return maxD;
    }
};