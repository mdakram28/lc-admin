class Solution {
public:
    vector<int> MaxPair(vector<vector<int>>& A)
    {
        int N=A.size();
        int minsum, maxsum, mindiff, maxdiff;
        
        int minis=0;
        int maxis=0;
        int minid=0;
        int maxid=0;
        
 
        minsum = maxsum = A[0][0] + A[0][1];
        mindiff = maxdiff = A[0][0] - A[0][1];
        for (int i = 1; i < N; i++) 
        {
            int sum = A[i][0] + A[i][1];
            int diff = A[i][0] - A[i][1];
            if (sum < minsum)
            {
                minis=i;
                minsum = sum;
            }
            else if (sum > maxsum)
            {
                maxis=i;
                maxsum = sum;
            }
            if (diff < mindiff)
            {
                minid=i;
                mindiff = diff;
            }
            else if (diff > maxdiff)
            {
                maxid=i;
                maxdiff = diff;
            }
        }

        int maximum = max(maxsum - minsum, maxdiff - mindiff);
        return {minis,maxis,minid,maxid};
        
        // return maximum;
 
        cout << maximum << endl;
    }
    
    
    int MaxDist(vector<vector<int>>& A)
    {
        int N=A.size();
        int minsum, maxsum, mindiff, maxdiff;
        
        minsum = maxsum = A[0][0] + A[0][1];
        mindiff = maxdiff = A[0][0] - A[0][1];
        for (int i = 1; i < N; i++) 
        {
            int sum = A[i][0] + A[i][1];
            int diff = A[i][0] - A[i][1];
            if (sum < minsum)
            {
                minsum = sum;
            }
            else if (sum > maxsum)
            {
                maxsum = sum;
            }
            if (diff < mindiff)
            {
                mindiff = diff;
            }
            else if (diff > maxdiff)
            {
                maxdiff = diff;
            }
        }

        int maximum = max(maxsum - minsum, maxdiff - mindiff);
        return maximum;
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        vector<int> p=MaxPair(points);
        // for(auto &i:p)
        // {
        //     cout<<i<<" ";
        // }
        
        int ans=1e9;
        
        for(auto &i:p)
        {
            
            vector<vector<int>>cur;
            for(int j=0;j<points.size();j++)
            {
                if(j==i)
                {
                    continue;
                }
                cur.push_back(points[j]);
            }
            ans=min(ans,MaxDist(cur));
        }
        return ans;
        
        
        

    }
};