#include<bits/stdc++.h>
using namespace std;

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<multiset<int>> st(4);
        // ++    -+    +-    --
        for (auto&& p : points) {
            int x = p[0], y = p[1];
            st[0].insert(x + y);
            st[1].insert(-x + y);
            st[2].insert(x - y);
            st[3].insert(-x - y);
        }

        int n = points.size();
        int minn = INT_MAX;

        for (int i = 0; i < n; i++) {
            // 删除第i个点
            int x = points[i][0], y = points[i][1];
            st[0].erase(st[0].find(x + y));
            st[1].erase(st[1].find(-x + y));
            st[2].erase(st[2].find(x - y));
            st[3].erase(st[3].find(-x - y));
            int r1 = *st[0].rbegin() + *st[3].rbegin();
            int r2 = *st[1].rbegin() + *st[2].rbegin();
            int r = max(r1, r2);
            minn = min(minn, r);
            st[0].insert(x + y);
            st[1].insert(-x + y);
            st[2].insert(x - y);
            st[3].insert(-x - y);
        }

        return minn;
    }
};

// int main() {
    
//     vector<vector<int>> points = { {1,1},{1,1},{1,1} };
   
//     Solution s;
//     s.minimumDistance(points);
// }