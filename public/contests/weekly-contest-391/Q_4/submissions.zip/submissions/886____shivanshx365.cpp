class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int ans = INT_MAX, n = points.size(), mini = INT_MAX;
        int mns = points[0][0]+points[0][1], mxs = mns;
        int mnd = points[0][0]-points[0][1], mxd = mnd;
        pair<int,int> xyz = {0,0};
        pair<int,int> abc = {0,0};
        pair<int,int> tmp = {0,0};
        pair<int,int> tmp2 = {0,0};
        int k = 1;
        for(int i=1;i<points.size();i++){
            int s = points[i][0]+points[i][1], d = points[i][0]-points[i][1];
            if(s<mns){
                mns=s;
                xyz.first=i;
            }else if(s>mxs){
                mxs=s;
                abc.first=i;
            }
            if(d<mnd){
                mnd=d;
                xyz.second=i;
            }else if(d>mxd){
                mxd=d;
                abc.second=i;
            }
        }
        if(mxs-mns>mxd-mnd){
            tmp=xyz;
            tmp2=abc;
        }else if(mxs-mns>mxd-mnd){
            tmp=abc;
            tmp2=xyz;
        }else{
            tmp=xyz;
            tmp2=abc;
            k++;
        }
        vector<vector<int>> poits;
        for(int i=0;i<n;i++){
            if(tmp.first==i) continue;
            poits.push_back(points[i]);
        }
        mns = poits[0][0]+poits[0][1]; mxs = mns;
        mnd = poits[0][0]-poits[0][1]; mxd = mnd;
        for(int i=1;i<poits.size();i++){
            int s = poits[i][0]+poits[i][1], d = poits[i][0]-poits[i][1];
            if(s<mns){
                mns=s;
            }else if(s>mxs){
                mxs=s;
            }
            if(d<mnd){
                mnd=d;
            }else if(d>mxd){
                mxd=d;
            }
        }
        mini = min(mini,max(mxd-mnd,mxs-mns));
        poits.clear();
        for(int i=0;i<n;i++){
            if(tmp.second==i) continue;
            poits.push_back(points[i]);
        }
        mns = poits[0][0]+poits[0][1]; mxs = mns;
        mnd = poits[0][0]-poits[0][1], mxd = mnd;
        for(int i=1;i<poits.size();i++){
            int s = poits[i][0]+poits[i][1], d = poits[i][0]-poits[i][1];
            if(s<mns){
                mns=s;
            }else if(s>mxs){
                mxs=s;
            }
            if(d<mnd){
                mnd=d;
            }else if(d>mxd){
                mxd=d;
            }
        }
        mini = min(mini,max(mxd-mnd,mxs-mns));
        if(k){
            vector<vector<int>> poits;
            for(int i=0;i<n;i++){
                if(tmp2.first==i) continue;
                poits.push_back(points[i]);
            }
            mns = poits[0][0]+poits[0][1]; mxs = mns;
            mnd = poits[0][0]-poits[0][1]; mxd = mnd;
            for(int i=1;i<poits.size();i++){
                int s = poits[i][0]+poits[i][1], d = poits[i][0]-poits[i][1];
                if(s<mns){
                    mns=s;
                }else if(s>mxs){
                    mxs=s;
                }
                if(d<mnd){
                    mnd=d;
                }else if(d>mxd){
                    mxd=d;
                }
            }
            mini = min(mini,max(mxd-mnd,mxs-mns));
            poits.clear();
            for(int i=0;i<n;i++){
                if(tmp2.second==i) continue;
                poits.push_back(points[i]);
            }
            mns = poits[0][0]+poits[0][1]; mxs = mns;
            mnd = poits[0][0]-poits[0][1], mxd = mnd;
            for(int i=1;i<poits.size();i++){
                int s = poits[i][0]+poits[i][1], d = poits[i][0]-poits[i][1];
                if(s<mns){
                    mns=s;
                }else if(s>mxs){
                    mxs=s;
                }
                if(d<mnd){
                    mnd=d;
                }else if(d>mxd){
                    mxd=d;
                }
            }
            mini = min(mini,max(mxd-mnd,mxs-mns));
        }
        return mini;
    }
};