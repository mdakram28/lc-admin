/**
 * @param {number[][]} points
 * @return {number}
 */
var minimumDistance = function(points) {
  let [x, y] = getMaxDistIndices(points);
  return Math.min(getMaxDist(points, x), getMaxDist(points, y));
};

function getMaxDistIndices(points) {
  let diff = [], sum = [];
  for (let i = 0; i < points.length; i++) {
    let [x, y] = points[i];
    diff.push([i, x - y]);
    sum.push([i, x + y]);
  }
  diff.sort((a, b) => a[1] - b[1]);
  sum.sort((a, b) => a[1] - b[1]);
  if (sum[sum.length - 1][1] - sum[0][1] >= diff[diff.length - 1][1] - diff[0][1]) {
    return [sum[sum.length - 1][0], sum[0][0]];
  } else {
    return [diff[diff.length - 1][0], diff[0][0]];
  }
}

function getMaxDist(points, excludeIndex) {
  let diff = [], sum = [];
  for (let i = 0; i < points.length; i++) {
    if (i === excludeIndex) continue;
    let [x, y] = points[i];
    diff.push([i, x - y]);
    sum.push([i, x + y]);
  }
  diff.sort((a, b) => a[1] - b[1]);
  sum.sort((a, b) => a[1] - b[1]);
  return Math.max(sum[sum.length - 1][1] - sum[0][1], diff[diff.length - 1][1] - diff[0][1]);
}