class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        
        #trick is to consider manhattan distance as max(x1 + y1 - x2 - y2, ....)
        
        l1 = []
        l2 = []

        
        for x, y in points:
            
            l1.append(x + y)
            l2.append(-x + y)
        
        
        m1, m2, m3, m4 = max(l1), min(l1), max(l2), min(l2)
        
        minim = max(m1 - m2, m3 - m4)
        
        i1, i2, i3, i4 = l1.index(m1), l1.index(m2), l2.index(m3), l2.index(m4)
        
        
        minim = min(minim, max(max(l1[:i1] + l1[i1 + 1:]) - min(l1[:i1] + l1[i1 + 1:]), max(l2[:i1] + l2[i1 + 1:]) - min(l2[:i1] + l2[i1 + 1:])    ))
        minim = min(minim, max(max(l1[:i2] + l1[i2 + 1:]) - min(l1[:i2] + l1[i2 + 1:]), max(l2[:i2] + l2[i2 + 1:]) - min(l2[:i2] + l2[i2 + 1:])    ))
        minim = min(minim, max(max(l1[:i3] + l1[i3 + 1:]) - min(l1[:i3] + l1[i3 + 1:]), max(l2[:i3] + l2[i3 + 1:]) - min(l2[:i3] + l2[i3 + 1:])    ))
        minim = min(minim, max(max(l1[:i4] + l1[i4 + 1:]) - min(l1[:i4] + l1[i4 + 1:]), max(l2[:i4] + l2[i4 + 1:]) - min(l2[:i4] + l2[i4 + 1:])    ))
                    
                    
        return minim
        
            