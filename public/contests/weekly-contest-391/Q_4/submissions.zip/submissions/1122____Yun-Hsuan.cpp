class Solution {
public:
    pair<pair<int, int>, pair<int, int>> findFarthestPoints(const vector<vector<int>>& points) {
        if (points.size() < 2) {
            // Not enough points to determine a pair
            return {{0, 0}, {0, 0}}; // Return a default or invalid pair
        }
        // Initializing to first point for comparison
        int maxPlus = points[0][0] + points[0][1], minPlus = maxPlus;
        int maxMinus = points[0][0] - points[0][1], minMinus = maxMinus;
        pair<int, int> maxPlusPoint = {points[0][0], points[0][1]}, minPlusPoint = {points[0][0], points[0][1]};
        pair<int, int> maxMinusPoint = {points[0][0], points[0][1]}, minMinusPoint = {points[0][0], points[0][1]};

        // Iterate through all points to find the farthest pair
        for (const auto& point : points) {
            int plus = point[0] + point[1];
            int minus = point[0] - point[1];

            if (plus > maxPlus) {
                maxPlus = plus;
                maxPlusPoint = {point[0], point[1]};
            }
            if (plus < minPlus) {
                minPlus = plus;
                minPlusPoint = {point[0], point[1]};
            }
            if (minus > maxMinus) {
                maxMinus = minus;
                maxMinusPoint = {point[0], point[1]};
            }
            if (minus < minMinus) {
                minMinus = minus;
                minMinusPoint = {point[0], point[1]};
            }
        }
        
        // Determine the farthest pair based on the maximum Manhattan distance
        if (maxPlus - minPlus > maxMinus - minMinus) {
            return {maxPlusPoint, minPlusPoint};
        } else {
            return {maxMinusPoint, minMinusPoint};
        }
    }
    
    int longestManhattanDistance(const vector<vector<int>>& points) {
        if (points.empty()) return 0; // Handle empty input

        // Initialize variables to track the maximum and minimum of x+y and x-y
        int maxPlus = points[0][0] + points[0][1];
        int minPlus = points[0][0] + points[0][1];
        int maxMinus = points[0][0] - points[0][1];
        int minMinus = points[0][0] - points[0][1];

        // Iterate through all points to update the max and min values
        for (const auto& p : points) {
            int plus = p[0] + p[1];
            int minus = p[0] - p[1];
            maxPlus = max(maxPlus, plus);
            minPlus = min(minPlus, plus);
            maxMinus = max(maxMinus, minus);
            minMinus = min(minMinus, minus);
        }
        // The longest Manhattan distance is the maximum difference found
        return max(maxPlus - minPlus, maxMinus - minMinus);
    } 
    int minimumDistance(vector<vector<int>>& points) {
        pair<pair<int, int>, pair<int, int>> p12 = findFarthestPoints(points);
        pair<int, int> p1 = p12.first, p2 = p12.second;
        int res1 = longestManhattanDistance(points);
        int n = points.size(), r1 = -1, r2 = -1;
        for(int i = 0; i < n; i++){
            if(points[i][0]==p1.first && points[i][1]==p1.second)
                r1 = i;
            if(points[i][0]==p2.first && points[i][1]==p2.second)
                r2 = i;
        }
        vector<vector<int>> tmp = points;
        tmp.erase(tmp.begin()+r1);
        int res2 = longestManhattanDistance(tmp);
        tmp = points;
        tmp.erase(tmp.begin()+r2);
        int res3 = longestManhattanDistance(tmp);
        //cout << "res1: " << res1 << endl;
        //cout << "res1: " << res2 << endl;
        //cout << "res1: " << res3 << endl;
        //cout << "-----------------" << endl;
        return min({res1, res2, res3});
    }
};