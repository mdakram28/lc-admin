const int N = 1e6 + 5;
class Solution {
public:
    array<int, 2> p[N];
    int n;
    int solve(int x) {
        // cout<<x<<'\n';
        int ans = 0;
        int mn = 0x3f3f3f3f, mx = -0x3f3f3f3f;
        for(int i = 1;i<=n;++i) if(i != x) {
            mn = min(mn, p[i][0] + p[i][1]);
            mx = max(mx, p[i][0] + p[i][1]);
        }
        ans = max(mx - mn, ans);
        
        mn = 0x3f3f3f3f, mx = -0x3f3f3f3f;
        for(int i = 1;i<=n;++i) if(i != x) {
            mn = min(mn, p[i][0] - p[i][1]);
            mx = max(mx, p[i][0] - p[i][1]);
        }
        ans = max(mx - mn, ans);
        mn = 0x3f3f3f3f, mx = -0x3f3f3f3f;
        for(int i = 1;i<=n;++i) if(i != x) {
            mn = min(mn, -p[i][0] + p[i][1]);
            mx = max(mx, -p[i][0] + p[i][1]);
        }
        ans = max(mx - mn, ans);
        return ans;
    }
    int minimumDistance(vector<vector<int>>& points) {
        n = points.size();
        for(int i = 1;i<=n;++i) p[i] = {points[i - 1][0], points[i - 1][1]};
        int ans = 0x3f3f3f3f;
        int mn = 1, mx = 1;
        for(int i = 1;i<=n;++i) {
            if(p[i][0] + p[i][1] < p[mn][0] + p[mn][1]) {
                mn = i;
            }
            if(p[i][0] + p[i][1] > p[mx][0] + p[mx][1]) {
                mx = i;
            }
        }
        ans = min(ans, solve(mn));
        ans = min(ans, solve(mx));
        
        mn = 1, mx = 1;
        for(int i = 1;i<=n;++i) {
            if(p[i][0] - p[i][1] < p[mn][0] - p[mn][1]) {
                mn = i;
            }
            if(p[i][0] - p[i][1] > p[mx][0] - p[mx][1]) {
                mx = i;
            }
        }
        ans = min(ans, solve(mn));
        ans = min(ans, solve(mx));
        
        return ans;
    }
};