class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        N = len(points)
        V = [0 for i in range(N)]
        V1 = [0 for i in range(N)]

        for i in range(N):
            V[i] = [points[i][0] + points[i][1], i]
            V1[i] = [points[i][0] - points[i][1], i]

        # Sorting both the vectors
        V.sort(key = lambda x : x[0])
        V1.sort(key = lambda x : x[0])
        #print(V, V1)
        to_del = [V[0][1], V[-1][1], V1[0][1], V1[-1][1]]


        curr_min = float('inf')

        for idx in to_del:
            if idx != 0:
                minsum = maxsum = points[0][0] + points[0][1]
                mindiff = maxdiff = points[0][0] - points[0][1]
            else:
                minsum = maxsum = points[1][0] + points[1][1]
                mindiff = maxdiff = points[1][0] - points[1][1]

            for i in range(1, N):
                if i != idx:
                    sum = points[i][0] + points[i][1]
                    diff = points[i][0] - points[i][1]
                    if (sum < minsum):
                        minsum = sum
                    elif (sum > maxsum):
                        maxsum = sum
                    if (diff < mindiff):
                        mindiff = diff
                    elif (diff > maxdiff):
                        maxdiff = diff

            maximum = max(maxsum - minsum, maxdiff - mindiff)

            curr_min = min(curr_min, maximum)

        return(curr_min)
            
        
        
        
        