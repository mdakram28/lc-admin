class Solution {
public:
    vector<array<int, 2>> ps;

    int distance(array<int, 2> p1, array<int, 2> p2) {
        return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1]);
    }

    int minimumDistance(vector<vector<int>>& points) {
        for(auto &p : points) {
            ps.push_back(array{p[0], p[1]});
        }
        int n = points.size();
        
        array<int, 2> sp1{0, 0}, sp2{0, 100000001};

        vector<array<int, 2>> dist1, dist2;
        for(int i = 0; i < ps.size(); ++i) {
            dist1.push_back(array{distance(sp1, ps[i]), i});
            dist2.push_back(array{distance(sp2, ps[i]), i});
        }
        ranges::sort(dist1);
        ranges::sort(dist2);

        int minDist = INT_MAX;
        if(dist1[n - 1][0] - dist1[0][0] > dist2[n - 1][0] - dist2[0][0]) {
            {
                int remove = dist1[0][1];
                int d1 = dist1[n - 1][0] - dist1[1][0];
                int d2 = 0;
                if(remove == dist2[n-1][1] || remove == dist2[0][1]) {
                    if(remove == dist2[n-1][1]) {
                        d2 = dist2[n-2][0] - dist2[0][0];
                    } else {
                        d2 = dist2[n-1][0] - dist2[1][0];
                    }
                } else {
                    d2 = dist2[n-1][0] - dist2[0][0];
                }
                minDist = min(minDist, max(d1, d2));
            }
            {
                int remove = dist1[n - 1][1];
                int d1 = dist1[n - 2][0] - dist1[0][0];
                int d2 = 0;
                if(remove == dist2[n-1][1] || remove == dist2[0][1]) {
                    if(remove == dist2[n-1][1]) {
                        d2 = dist2[n-2][0] - dist2[0][0];
                    } else {
                        d2 = dist2[n-1][0] - dist2[1][0];
                    }
                } else {
                    d2 = dist2[n-1][0] - dist2[0][0];
                }
                minDist = min(minDist, max(d1, d2));
            }
        } else { // if (dist1[n - 1][0] - dist1[0][0] < dist2[n - 1][0] - dist2[0][0])
            {
                int remove = dist2[0][1];
                int d2 = dist2[n - 1][0] - dist2[1][0];
                int d1 = 0;
                if(remove == dist1[n-1][1] || remove == dist1[0][1]) {
                    if(remove == dist1[n-1][1]) {
                        d1 = dist1[n-2][0] - dist1[0][0];
                    } else {
                        d1 = dist1[n-1][0] - dist1[1][0];
                    }
                } else {
                    d1 = dist1[n-1][0] - dist1[0][0];
                }
                minDist = min(minDist, max(d1, d2));
            }
            {
                int remove = dist2[n - 1][1];
                int d2 = dist2[n - 2][0] - dist2[0][0];
                int d1 = 0;
                if(remove == dist1[n-1][1] || remove == dist1[0][1]) {
                    if(remove == dist1[n-1][1]) {
                        d1 = dist1[n-2][0] - dist1[0][0];
                    } else {
                        d1 = dist1[n-1][0] - dist1[1][0];
                    }
                } else {
                    d1 = dist1[n-1][0] - dist1[0][0];
                }
                minDist = min(minDist, max(d1, d2));
            }
        }
        return minDist;
    }
};