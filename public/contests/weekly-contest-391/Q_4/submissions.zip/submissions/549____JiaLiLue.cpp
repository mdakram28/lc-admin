constexpr int NN = 1e5+10;
int N, PX[NN], PY[NN], idx[NN];
using PII = pair<int,int>;
inline int dis(const PII &pii){
    auto [i1, i2] = pii;
    return abs(PX[i1]-PX[i2]) + abs(PY[i1]-PY[i2]);
}
PII maxDis(int del_idx=-1){
    int max_v1=-1e9, max_v2=-1e9, i1=-1, i2=-1;
    int best_i1=-1, best_i2=-1, max_dis=-1e9;
    for(int i=0; i<N; ++i){
        int x = PX[idx[i]], y = PY[idx[i]];
        // printf("i=%d, idx=%d, x=%d, y=%d\n", i, idx[i], x, y);
        if(idx[i]==del_idx){
            continue;
        }
        int v1 = -x-y, v2 = -x+y;
        int d1 = x+y+max_v1;
        if(d1>max_dis){
            max_dis = d1;
            best_i1 = i1;
            best_i2 = idx[i];
        }
        int d2 = x-y+max_v2;
        if(d2>max_dis){
            max_dis = d2;
            best_i1 = i2;
            best_i2 = idx[i];
        }
        if(max_v1 < v1){
            max_v1 = v1;
            i1 = idx[i];
        }
        if(max_v2 < v2){
            max_v2 = v2;
            i2 = idx[i];
        }
    }
    // printf("del=%d, best(i1=%d, i2=%d, d=%d)\n", del_idx, best_i1, best_i2, dis({best_i1, best_i2}));
    return {best_i1, best_i2};
}
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        N = points.size();
        for(int i=0; i<N; ++i){
            idx[i] = i;
            PX[i] = points[i][0];
            PY[i] = points[i][1];
        }
        sort(idx, idx+N, [&](int i, int j){return PX[i]<PX[j];});
        auto [i1, i2] = maxDis();
        // printf("i1=%d, i2=%d, maxd = %d\n", i1, i2, dis({i1,i2}));
        return min(dis(maxDis(i1)), dis(maxDis(i2)));
    }
};