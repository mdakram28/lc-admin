class Solution {
public:
    int dist(vector<vector<int>>& A, int N){
        vector<int> V(N), V1(N);

        for (int i = 0; i < N; i++) {
            V[i] = A[i][0] + A[i][1];
            V1[i] = A[i][0] - A[i][1];
        }

        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());

        int maximum
            = max(V.back() - V.front(), V1.back() - V1.front());

        return maximum;
    }
    
    int minimumDistance(vector<vector<int>>& A) {
        int N = A.size();
        vector<pair<int, int>> V(N), V1(N);

        for (int i = 0; i < N; i++) {
            V[i] = {A[i][0] + A[i][1], i };
            V1[i] = {A[i][0] - A[i][1], i};
        }

        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());

        int maximum = max(V.back().first - V.front().first, V1.back().first - V1.front().first);
        
        int id1 = V.back().second;
        int id2 = V.front().second;

        if (V.back().first - V.front().first < V1.back().first - V1.front().first){
            id1 = V1.back().second;
            id2 = V1.front().second;
        }

        // cout << id1<<" "<<id2<<" ";
        
        vector<vector<int>> temp = A;
        
        temp.erase(temp.begin() + id1);
        
        int mx1 = dist(temp, temp.size());
        
        temp = A;
        temp.erase(temp.begin() + id2);
        
        int mx2 = dist(temp, temp.size());
        // cout << maximum<<" "<<mx1<<" "<<mx2<<" : ";

        return min({maximum, mx1, mx2});
    }
};