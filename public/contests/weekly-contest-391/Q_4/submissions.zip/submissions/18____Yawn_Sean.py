inf = 10 ** 9
class Solution:
    def minimumDistance(self, p: List[List[int]]) -> int:
        n = len(p)
        v1 = [x + y for x, y in p]
        v2 = [x - y for x, y in p]
        
        v1_p_min = list(accumulate(v1, min, initial=inf))
        v1_p_max = list(accumulate(v1, max, initial=-inf))
        v2_p_min = list(accumulate(v2, min, initial=inf))
        v2_p_max = list(accumulate(v2, max, initial=-inf))
        
        v1.reverse()
        v2.reverse()
        
        v1_s_min = list(accumulate(v1, min, initial=inf))[::-1]
        v1_s_max = list(accumulate(v1, max, initial=-inf))[::-1]
        v2_s_min = list(accumulate(v2, min, initial=inf))[::-1]
        v2_s_max = list(accumulate(v2, max, initial=-inf))[::-1]
        
        ans = inf
        for i in range(n):
            ans = min(ans, max(max(v1_p_max[i], v1_s_max[i+1]) - min(v1_p_min[i], v1_s_min[i+1]), max(v2_p_max[i], v2_s_max[i+1]) - min(v2_p_min[i], v2_s_min[i+1])))
        return ans