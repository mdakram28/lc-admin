class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        multiset<int>x,y;
        int mxx=0,mnx =1e9,mxy=0,mny=1e9;
        for(auto xx:p)
        {
            int a = xx[0]+xx[1],b = xx[0]-xx[1];
            x.insert(a),y.insert(b);
            
        }
        
        int res=max((*x.rbegin()-*x.begin()),(*y.rbegin()-*y.begin()));
        
         for(auto xx:p)
        {
            int a = xx[0]+xx[1],b = xx[0]-xx[1];
            x.extract(a),y.extract(b);
             int tmp = max((*x.rbegin()-*x.begin()),(*y.rbegin()-*y.begin()));
             res=min(res,tmp);
            x.insert(a),y.insert(b);
        }
        return res;
    }
};