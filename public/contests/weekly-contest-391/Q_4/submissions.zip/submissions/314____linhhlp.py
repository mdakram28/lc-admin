class Solution:
    def minimumDistance(self, A: List[List[int]]) -> int:
        res = []
        n = len(A)
        sum = []
        diff = []
        for i in range(n):
            sum.append((A[i][0] + A[i][1], i))
            diff.append((A[i][0] - A[i][1], i))
        sum.sort()
        diff.sort()
        
        for i in range(n):
            if sum[-1][1] == i:
                maxsum = sum[-2][0]
            else:
                maxsum = sum[-1][0]
            
            if sum[0][1] == i:
                minsum = sum[1][0]
            else:
                minsum = sum[0][0]
                
            if diff[-1][1] == i:
                maxdiff = diff[-2][0]
            else:
                maxdiff = diff[-1][0]
            
            if diff[0][1] == i:
                mindiff = diff[1][0]
            else:
                mindiff = diff[0][0]
                
                
            res.append(max(maxsum - minsum, maxdiff - mindiff))

        return min(res)