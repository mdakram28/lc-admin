class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        _, a = max((x + y, i) for i, (x, y) in enumerate(points))
        _, b = max((-x + y, i) for i, (x, y) in enumerate(points))
        _, c = max((x - y, i) for i, (x, y) in enumerate(points))
        _, d = max((-x - y, i) for i, (x, y) in enumerate(points))
        al = points[:a] + points[a + 1:]
        bl = points[:b] + points[b + 1:]
        cl = points[:c] + points[c + 1:]
        dl = points[:d] + points[d + 1:]
        return min(maxDis(al), maxDis(bl), maxDis(cl), maxDis(dl))
        
    
def maxDis(points):
    _, a = max((x + y, i) for i, (x, y) in enumerate(points))
    _, b = max((-x + y, i) for i, (x, y) in enumerate(points))
    _, c = max((x - y, i) for i, (x, y) in enumerate(points))
    _, d = max((-x - y, i) for i, (x, y) in enumerate(points))
    ends = [a, b, c, d]
    res = 0
    for i in range(4):
        for j in range(1, 4):
            res = max(res, abs(points[ends[i]][0] - points[ends[j]][0]) + abs(points[ends[i]][1] - points[ends[j]][1]))
    return res
        
  