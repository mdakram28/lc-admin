class Solution {
    public int minimumDistance(int[][] points) {
        int n=points.length;
        int one[][]=new int[n][2];
        int second[][]=new int[n][2];
        for(int i=0;i<n;i++)
        {
          one[i][1]=i;
          one[i][0]=(points[i][0]+points[i][1]);
          second[i][1]=i;
          second[i][0]=(points[i][0]-points[i][1]); 
        }
        Arrays.sort(one,(a,b)->{
            if(a[0]==b[0])
                return a[1]-b[1];
            return a[0]-b[0];
        });
        Arrays.sort(second,(a,b)->{
            if(a[0]==b[0])
                return a[1]-b[1];
            return a[0]-b[0];
        });
        Map<Integer,Integer>map1=new HashMap<>();
        Map<Integer,Integer>map2=new HashMap<>();
        for(int i=0;i<n;i++)
        {
            map1.put(one[i][1],i);
            map2.put(second[i][1],i);
        }
        // for(int i=0;i<n;i++)
        // {
        //     System.out.println(one[i][0]+" "+one[i][1]);
        // }
        // for(int i=0;i<n;i++)
        // {
        //     System.out.println(second[i][0]+" "+second[i][1]);
        // }
        int ans=Integer.MAX_VALUE;
        for(int i=0;i<n;i++)
        {
            int ans1=getAns(one,n,map1.get(i));
            int ans2=getAns(second,n,map2.get(i));
            ans=Math.min(ans,Math.max(ans1,ans2));
        }
        return ans;
    }
    int getAns(int one[][], int n, int pos)
    {
        if(pos!=0 && pos!=n-1)
            return one[n-1][0]-one[0][0];
        else if(pos==0)
             return one[n-1][0]-one[1][0];
        return one[n-2][0]-one[0][0];
    }
}