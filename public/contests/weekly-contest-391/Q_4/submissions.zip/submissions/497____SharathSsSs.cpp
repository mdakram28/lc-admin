class Solution {
public:
    int minimumDistance(vector<vector<int>>& a) {
        //3,10  4,4  5,15  10,2
        //13 8 20 12
        //-7 0 -10 8
        int n = a.size();
        vector<pair<int,pair<int,int>>>pq1;
        vector<pair<int,pair<int,int>>>pq2;
        for(int i = 0; i<n; i++){
            pq1.push_back({a[i][0] + a[i][1],{a[i][0], a[i][1]}});
            pq2.push_back({a[i][0] - a[i][1],{a[i][0], a[i][1]}});
        }
        // cout<<"YES"<<endl;
        sort(pq1.begin(), pq1.end());
        sort(pq2.begin(), pq2.end());
        int max1x,max2x,max1y,max2y;
        // cout<<"YES"<<endl;
        if(pq1.back().first - pq1.front().first >= pq2.back().first - pq2.front().first){
            max1x = pq1.back().second.first;
            max2x = pq1.front().second.first;
            max1y = pq1.back().second.second;
            max2y = pq1.front().second.second;
        }
        else{
            max1x = pq2.back().second.first;
            max2x = pq2.front().second.first;
            max1y = pq2.back().second.second;
            max2y = pq2.front().second.second;
        }
        // cout<<"YES"<<endl;
        int mini = 1e9;
        //case1
        vector<pair<int,int>>tempa;
        int cnt = 0;
        for(int i = 0; i<n; i++){
            if(a[i][0] == max1x && a[i][1] == max1y && cnt == 0){
                cnt++;
                continue;
            }
            tempa.push_back({a[i][0], a[i][1]});
        }
        vector<pair<int,pair<int,int>>>pq11;
        vector<pair<int,pair<int,int>>>pq21;
        for(int i = 0; i<n-1; i++){
            pq11.push_back({tempa[i].first + tempa[i].second,{tempa[i].first, tempa[i].second}});
            pq21.push_back({tempa[i].first - tempa[i].second,{tempa[i].first, tempa[i].second}});
        }
        sort(pq11.begin(), pq11.end());
        sort(pq21.begin(), pq21.end());
        mini = min(mini, max(pq11.back().first - pq11.front().first, pq21.back().first - pq21.front().first));
        //case2
        cnt = 0;
        tempa.clear();
        for(int i = 0; i<n; i++){
            if(a[i][0] == max2x && a[i][1] == max2y && cnt == 0){
                cnt++;
                continue;
            }
            tempa.push_back({a[i][0], a[i][1]});
        }
        vector<pair<int,pair<int,int>>>pq12;
        vector<pair<int,pair<int,int>>>pq22;
        for(int i = 0; i<n-1; i++){
            pq12.push_back({tempa[i].first + tempa[i].second,{tempa[i].first, tempa[i].second}});
            pq22.push_back({tempa[i].first - tempa[i].second,{tempa[i].first, tempa[i].second}});
        }
        sort(pq12.begin(), pq12.end());
        sort(pq22.begin(), pq22.end());
        mini = min(mini, max(pq12.back().first - pq12.front().first, pq22.back().first - pq22.front().first));
        
        return mini;
    }
};