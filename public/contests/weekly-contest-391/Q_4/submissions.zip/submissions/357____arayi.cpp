#define fr first
#define sc second
class Solution {
   public:
    int mxdist(vector<vector<int>>& points, int i1) {
        vector<pair<int, int>> sum, df;
        int n = points.size();
        for (int i = 0; i < points.size(); ++i) {
            if (i == i1) {
                n--;
                continue;
            }
            auto& p = points[i];
            sum.push_back({p[0] + p[1], i});
            df.push_back({p[0] - p[1], i});
        }
        sort(sum.begin(), sum.end());
        sort(df.begin(), df.end());
        return max(sum[n - 1].fr - sum[0].fr, df[n - 1].fr - df[0].fr);
    }
    int minimumDistance(vector<vector<int>>& points) {
        vector<pair<int, int>> sum, df;
        int n = points.size();
        for (int i = 0; i < points.size(); ++i) {
            auto& p = points[i];
            sum.push_back({p[0] + p[1], i});
            df.push_back({p[0] - p[1], i});
        }
        sort(sum.begin(), sum.end());
        sort(df.begin(), df.end());
        if ((sum[n - 1].fr - sum[0].fr) > (df[n - 1].fr - df[0].fr)) {
            return min(mxdist(points, sum[n - 1].sc), mxdist(points, sum[0].sc));
        }
        return min(mxdist(points, df[n-1].sc), mxdist(points, df[0].sc));
    }
};