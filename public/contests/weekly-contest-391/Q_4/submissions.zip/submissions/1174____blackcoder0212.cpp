class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n=points.size();
        multiset<int> s1,s2;
        int ans=INT_MAX;
 
        for (int i = 0; i < n; i++) {
        s1.insert(points[i][0] + points[i][1]);            
        s2.insert(points[i][0] - points[i][1]);
    }
 
        for(int i=0;i<n;i++)
        {
          int x=points[i][0] + points[i][1];
          int y=points[i][0] - points[i][1];
          s1.erase(s1.find(x));
            s2.erase(s2.find(y));
            int t1=*--s1.end();
            int t2=*s1.begin();
            int t3=*--s2.end();
            int t4=*s2.begin();
            int t=max(t1-t2,t3-t4);
            ans=min(ans,t);
            s1.insert(x);
            s2.insert(y);
        }
        
        return ans;
        
    }
};