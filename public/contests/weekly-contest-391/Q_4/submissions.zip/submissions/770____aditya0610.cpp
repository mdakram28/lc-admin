class Solution {
public:
    
    int minimumDistance(vector<vector<int>>& v) {
        vector<int> a,b;
        multiset<int> m1,m2;
        for(int i = 0;i < v.size();i++){
            int x = v[i][0];
            int y = v[i][1];
            a.push_back(x + y);
            b.push_back(x - y);
            m1.insert(x + y);
            m2.insert(x - y);
        }
        vector<int> ans;
        for(int i = 0;i < v.size();i++){
            m1.erase(m1.find(a[i]));
            m2.erase(m2.find(b[i]));
            int a1 = *m1.rbegin();
            int a2 = *m1.begin();
            int b1 = *m2.rbegin();
            int b2 = *m2.begin();
            
            ans.push_back(max(abs(a1 - a2),abs(b1-b2)));
            m1.insert(a[i]);
            m2.insert(b[i]);
        }
        int fans = ans[0];
        for(int i = 0;i < ans.size();i++){
            fans = min(fans,ans[i]);
            cout << ans[i] << endl;
        }
        
        return fans;
        
    }
};