class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        int n = p.size();
        vector<int> s(n), d(n);
        for(int i = 0; i < n; i++){
            s[i] = p[i][0] + p[i][1];
            d[i] = p[i][0] - p[i][1];
        }
        
        sort(s.begin(), s.end());
        sort(d.begin(), d.end());
        
        int mini = INT_MAX;
        
        for(int i = 0; i < n; i++){
            int l1 = 0, l2 = 0, r1 = n-1, r2 = n-1;
            
            if(s[l1] == p[i][0] + p[i][1]) l1++;
            
            if(s[r1] == p[i][0] + p[i][1]) r1--;
            
            if(d[l2] == p[i][0] - p[i][1]) l2++;
            
            if(d[r2] == p[i][0] - p[i][1]) r2--;
            
            mini = min(mini, max( s[r1]-s[l1], d[r2]-d[l2] ));
        }
        
        return mini;
    }
};