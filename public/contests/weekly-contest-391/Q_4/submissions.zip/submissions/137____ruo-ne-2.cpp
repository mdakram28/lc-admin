class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<vector<pair<int, int>>> dis(4, vector<pair<int, int>>());
        for (int i = 0; i < n; i++) {
            dis[0].emplace_back(make_pair(points[i][0] + points[i][1], i));
            dis[1].emplace_back(make_pair(-points[i][0] + points[i][1], i));
            dis[2].emplace_back(make_pair(points[i][0] - points[i][1], i));
            dis[3].emplace_back(make_pair(-points[i][0] - points[i][1], i));
        }
        for (int i = 0; i < 4; i++) {
            sort(dis[i].begin(), dis[i].end());
        }
        int j = 0;
        for (int i = 1; i < 4; i++) {
            if (dis[i].back().first - dis[i][0].first > dis[j].back().first - dis[j][0].first) {
                j = i;
            }
        }
        int remove1 = dis[j].back().second, remove2 = dis[j][0].second;
        
        int ans1 = 0;
        for (int i = 0; i < 4; i++) {
            int start = 0, end = n - 1;
            if (dis[i][0].second == remove1) start++;
            if (dis[i].back().second == remove1) end--;
            ans1 = max(ans1, dis[i][end].first - dis[i][start].first);
        }
        int ans2 = 0;
        for (int i = 0; i < 4; i++) {
            int start = 0, end = n - 1;
            if (dis[i][0].second == remove2) start++;
            if (dis[i].back().second == remove2) end--;
            ans2 = max(ans2, dis[i][end].first - dis[i][start].first);
        }
        return min(ans1, ans2);
    }
};