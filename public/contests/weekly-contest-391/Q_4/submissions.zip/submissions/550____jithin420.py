class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def calc(arr):
            # print(arr)
            psum = [(i, x + y) for i, (x, y) in enumerate(arr)]
            dsum = [(i, x - y) for i, (x, y) in enumerate(arr)]
            psum.sort(key=lambda x: x[1])
            dsum.sort(key=lambda x: x[1])
            # print(psum, dsum)
            return psum, dsum

        psum, dsum = calc(points)
        sumdiff = psum[-1][1] - psum[0][1]
        diffdiff = dsum[-1][1] - dsum[0][1]
        # print(sumdiff, diffdiff)
        if sumdiff > diffdiff:
            idxs = [psum[-1][0], psum[0][0]]
        else:
            idxs = [dsum[-1][0], dsum[0][0]]

        ans = float('inf')
        for i in idxs:
            p, d = calc(points[:i] + points[i + 1:])
            sd = p[-1][1] - p[0][1]
            dd = d[-1][1] - d[0][1]
            ans = min(ans, max(sd, dd))
        return ans