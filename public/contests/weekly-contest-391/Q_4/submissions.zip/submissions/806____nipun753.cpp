class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        
        int n = points.size();
        multiset < int > sum;
        multiset < int > diff;
        for (int i = 0  ; i < points.size(); i++){
            sum.insert(points[i][0] + points[i][1]);
            diff.insert(points[i][1] - points[i][0]);
        }
        int ans = INT_MAX;
        
        for (int i = 0 ;i < n ; i++){
            sum.erase(sum.find(points[i][0] + points[i][1]));
            diff.erase(diff.find(points[i][1] - points[i][0]));
            
            auto x = (*sum.begin());
            auto y = (*sum.rbegin());
            auto u = (*diff.begin());
            auto v = (*diff.rbegin());
            ans =min(ans , max(y - x , v - u));
            sum.insert(points[i][0] + points[i][1]);
            diff.insert(points[i][1] - points[i][0]);
        }
        return ans;
    }
};