class Solution {
public:
    int solve(vector<vector<int>>& points,int idx){
         vector<vector<int>> poss1;vector<vector<int>> poss2;
        for(int i=0;i<points.size();i++){
            
            if(idx!=i){
            poss1.push_back({points[i][0]+points[i][1],i});
            poss2.push_back({points[i][0]-points[i][1],i});
        }}
        sort(poss1.begin(),poss1.end());
        sort(poss2.begin(),poss2.end());
        return max(poss1[poss1.size()-1][0]-poss1[0][0],poss2[poss2.size()-1][0]-poss2[0][0]);
    }
    int minimumDistance(vector<vector<int>>& points) {
        vector<vector<int>> poss1(points.size());vector<vector<int>> poss2(points.size());
        for(int i=0;i<points.size();i++){
            poss1[i]={points[i][0]+points[i][1],i};
            poss2[i]={points[i][0]-points[i][1],i};
        }
        sort(poss1.begin(),poss1.end());
        sort(poss2.begin(),poss2.end());
        if(poss1[poss1.size()-1][0]-poss1[0][0]>poss2[poss2.size()-1][0]-poss2[0][0]){
            return min(solve(points,poss1[0][1]),solve(points,poss1[poss1.size()-1][1]));
        }
        else{
            return min(solve(points,poss2[0][1]),solve(points,poss2[poss2.size()-1][1]));
        }
        // return -1;
    }
};