class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        N = len(points)
        
        def solve(pp):
            V = [0 for i in range(len(pp))]
            V1 = [0 for i in range(len(pp))]
            for i in range(len(pp)):
                V[i] = (pp[i][0] + pp[i][1], i)
                V1[i] = (pp[i][0] - pp[i][1], i)

            V.sort()
            V1.sort()
        
            a, b = V1[-1][1], V1[0][1]
            res = V1[-1][0] - V1[0][0]
            if V[-1][0]-V[0][0] > res:
                a, b = V[-1][1], V[0][1]
                res = V[-1][0] - V[0][0]
            
            return res, a, b
        
        res, a, b = solve(points)
        res1, _, _ = solve([p for i,p in enumerate(points) if i!=a])
        res2, _, _ = solve([p for i,p in enumerate(points) if i!=b])
        
        return min(res1, res2)
