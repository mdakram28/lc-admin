class Solution {
public:
    
    static bool f1(vector<int>&a,vector<int>&b){
        int s1=a[0]+a[1],s2=b[0]+b[1];
        return s1<s2;
    }
    static bool f2(vector<int>&a,vector<int>&b){
        int s1=a[1]-a[0],s2=b[1]-b[0];
        return s1<s2;
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        int ans=INT_MAX;
        int n=points.size();
        vector<vector<int>> copy1=points,copy2=points;
        sort(copy1.begin(),copy1.end(),f1);
        sort(copy2.begin(),copy2.end(),f2);
        int remov[4][2];
        remov[0][0]=copy1[0][0],remov[0][1]=copy1[0][1];
        remov[1][0]=copy1[n-1][0],remov[1][1]=copy1[n-1][1];
        remov[2][0]=copy2[0][0],remov[2][1]=copy2[0][1];
        remov[3][0]=copy2[n-1][0],remov[3][1]=copy2[n-1][1];
        
        int x=remov[0][0],y=remov[0][1];
        int head=0,end=n-1;
        if(copy2[0][0]==x&&copy2[0][1]==y)head++;
        else if(copy2[n-1][0]==x&&copy2[n-1][1]==y)end--;
        int min=abs(copy1[n-1][0]-copy1[1][0])+abs(copy1[n-1][1]-copy1[1][1]);
        min=fmax(min,abs(copy2[end][0]-copy2[head][0])+abs(copy2[end][1]-copy2[head][1]));
        ans=fmin(ans,min);
        
        x=remov[1][0],y=remov[1][1];
        head=0,end=n-1;
        if(copy2[0][0]==x&&copy2[0][1]==y)head++;
        else if(copy2[n-1][0]==x&&copy2[n-1][1]==y)end--;
        min=abs(copy1[n-2][0]-copy1[0][0])+abs(copy1[n-2][1]-copy1[0][1]);
        min=fmax(min,abs(copy2[end][0]-copy2[head][0])+abs(copy2[end][1]-copy2[head][1]));
        ans=fmin(ans,min);
        
        x=remov[2][0],y=remov[2][1];
        head=0,end=n-1;
        if(copy1[0][0]==x&&copy1[0][1]==y)head++;
        else if(copy1[n-1][0]==x&&copy1[n-1][1]==y)end--;
        min=abs(copy2[n-1][0]-copy2[1][0])+abs(copy2[n-1][1]-copy2[1][1]);
        min=fmax(min,abs(copy1[end][0]-copy1[head][0])+abs(copy1[end][1]-copy1[head][1]));
        ans=fmin(ans,min);
        
        x=remov[3][0],y=remov[3][1];
        head=0,end=n-1;
        if(copy1[0][0]==x&&copy1[0][1]==y)head++;
        else if(copy1[n-1][0]==x&&copy1[n-1][1]==y)end--;
        min=abs(copy2[n-2][0]-copy2[0][0])+abs(copy2[n-2][1]-copy2[0][1]);
        min=fmax(min,abs(copy1[end][0]-copy1[head][0])+abs(copy1[end][1]-copy1[head][1]));
        ans=fmin(ans,min);
        
        return ans;
    }
};