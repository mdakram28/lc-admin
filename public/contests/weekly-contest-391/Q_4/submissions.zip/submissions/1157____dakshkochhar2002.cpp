#define ff first
#define ss second
class Solution {
public:
    pair<int,pair<int,int>> mx_dist(vector<vector<int>>& points){
        int n = points.size();
        vector<pair<int,int>> sum, diff;
        for(int i=0; i<points.size(); i+=1){
            sum.push_back({points[i][0]+points[i][1], i});
            diff.push_back({points[i][0]-points[i][1], i});
        }
        sort(sum.begin(), sum.end());
        sort(diff.begin(), diff.end());
        pair<int,int> mx_sum = sum[n-1], mn_sum = sum[0], mx_dif = diff[n-1], mn_dif = diff[0];
        int dif1 = mx_sum.ff - mn_sum.ff, dif2 = mx_dif.ff - mn_dif.ff;
        if(dif1 > dif2){
            return {dif1, {mx_sum.ss, mn_sum.ss}};
        }else{
            return {dif2, {mx_dif.ss, mn_dif.ss}};
        }
    }
    int minimumDistance(vector<vector<int>>& points) {
        pair<int,pair<int,int>> it = mx_dist(points);
        int dif = it.ff, i = it.ss.ff, j = it.ss.ss;
        vector<vector<int>> p1, p2;
        for(int k=0; k<points.size(); k+=1){
            if(k==i) continue;
            p1.push_back(points[k]);
        }
        pair<int,pair<int,int>> it1 = mx_dist(p1);
        for(int k=0; k<points.size(); k+=1){
            if(k==j) continue;
            p2.push_back(points[k]);
        }
        pair<int,pair<int,int>> it2 = mx_dist(p2);
        int dif1 = it1.ff, dif2 = it2.ff;
        int ans = min(dif1, dif2);
        return ans;
    }
};