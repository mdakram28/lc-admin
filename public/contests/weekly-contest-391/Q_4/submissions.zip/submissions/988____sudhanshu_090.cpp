class Solution {
public:
    int findfor(vector<vector<int>> &points, int to_avoid, int n){
        vector<int> v1,v2;
        for (int i{};i<n;i++){
            if(i == to_avoid) continue;
            
            auto x = points[i];
            int a = x[0] + x[1];
            int b = x[0] - x[1];
            v1.push_back(a);
            v2.push_back(b);
        }
        sort(v1.begin(), v1.end());        
        sort(v2.begin(), v2.end());
        
        int a = v1.back() - v1.front();
        int b = v2.back() - v2.front();
        
        return max(a, b);
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<vector<int>> diff;   //{(x-y) , x, y}
        vector<vector<int>> sum;    //{(x+y) , x, y}
        
        for (int i{};i<n;i++){
            diff.push_back({points[i][0]-points[i][1] , i});
            sum.push_back({points[i][0]+points[i][1] , i});
        }
        
        sort(diff.begin(),diff.end());
        sort(sum.begin(),sum.end());
        
        int d1 = diff[n-1][0] - diff[0][0];
        int d2 = sum[n-1][0] - sum[0][0];
        
        int ans = 1e9;
        if(d1 >= d2){
            int x1 = findfor(points, diff[n-1][1], n);
            int x2 = findfor(points, diff[0][1], n);
            ans = min(x1,x2);
        }
        else{
            int x1 = findfor(points, sum[n-1][1], n);
            int x2 = findfor(points, sum[0][1], n);
            ans = min(x1,x2);
        }
        return ans;
    }
};