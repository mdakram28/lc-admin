class Solution {
public:
    
    vector<int> findM(vector<vector<int>>& points){
        int n = points.size();
        
        int maxSum, minSum, maxDiff, minDiff;
        
        minSum = maxSum = points[0][0] + points[0][1];
        minDiff = maxDiff = points[0][0] - points[0][1];
        int id1, id2, id3, id4;
        id1 = id2 = id3 = id4 = 0;
        
        for(int i = 1; i < n; i++){
            int curSum = points[i][0] + points[i][1]; // Calculate current sum correctly
            int curDiff = points[i][0] - points[i][1]; // Calculate current difference correctly
            
            if(curSum > maxSum){
                maxSum = curSum;
                id1 = i;
            }
            if(curSum < minSum){
                minSum = curSum;
                id2 = i;
            }
            if(curDiff < minDiff){
                minDiff = curDiff;
                id3 = i;
            }
            if(curDiff > maxDiff){
                maxDiff = curDiff;
                id4 = i;
            }
        }
        
        vector<int> temp;
        if (maxSum - minSum > maxDiff - minDiff) {
            temp.push_back(maxSum - minSum);
            temp.push_back(id1);
            temp.push_back(id2);
            return temp;
        } else {
            temp.push_back(maxDiff - minDiff);
            temp.push_back(id3);
            temp.push_back(id4);
            return temp;
        }
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        vector<vector<int>> temp = points;
        vector<int> ans1 = findM(temp);
        
        // Make a copy of temp before erasing
        vector<vector<int>> temp_copy = temp;
        temp_copy.erase(temp_copy.begin() + ans1[1]);
        
        // Find the second answer after erasing
        vector<int> ans2 = findM(temp_copy);
        
        // Restore temp to its original state
        temp = points;
        
        // Erase using ans2[1]
        temp.erase(temp.begin() + ans1[2]);
        
        // Find the third answer after erasing
        vector<int> ans3 = findM(temp);
        
        return min(ans2[0], ans3[0]);
    }
};
