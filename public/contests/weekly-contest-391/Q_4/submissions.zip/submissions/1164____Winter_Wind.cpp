int manathan( int x1 , int x2 , int y1 , int y2 )
{
    int a = abs(x1-x2);
    int b = abs(y1-y2);
    return a + b;
}

int a,b,c,d;
int func(  int index , vector<vector<int>> &p )
{

int n = p.size();    
int mx1 = 0 ;    
    
int high = index == n - 1 ? p[n-2][0] + p[n-2][1] : p[n-1][0]+p[n-1][1];
int h_ind = index == n - 1 ? n - 2 : n - 1 ;
        
for( int i = n - 2 ; i >= 0 ; i-- )
{
    if( i == index )
    continue;
    
    int val = manathan( p[i][0] , p[h_ind][0] , p[i][1] , p[h_ind][1] );
    if( val > mx1 )
    {
              mx1 = val;
              a = i;
              b = h_ind;
    }
          
    int chk = p[i][0] + p[i][1];
    if( chk > high )
    {
              high = chk;
              h_ind = i;
    }
}
    
    int mx2 = 0;
    high = index ? -1*p[0][0]+p[0][1] : -1*p[1][0]+p[1][1];
    h_ind = index ? 0 : 1 ;  
        
    for( int i = 1 ; i < n ; i++ )
      {
          if( i == index )
          continue;
          
          int val = manathan( p[i][0] , p[h_ind][0] , p[i][1] , p[h_ind][1] );

          if( val > mx2 )
          {
              mx2 = val;
              c = i ; 
              d = h_ind;
          }   
        
          int chk = -1*p[i][0] + p[i][1];
          if( chk > high )
          {
              high = chk;
              h_ind = i;
          }
      }
   //cout<<mx1<<" "<<mx2<<endl;
    return max(mx1,mx2);
}

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) 
    {
      sort(points.begin(),points.end());  
      func( -1 , points);
      int A = a , B = b , C = c , D = d;  
      int ans = min( func(A,points) , min(func(B,points) , min( func(C,points), func( D , points) ) ) );
      return ans;  
    }
};