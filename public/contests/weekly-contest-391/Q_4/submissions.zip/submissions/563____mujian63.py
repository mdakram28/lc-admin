class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        ans = [[x[0],x[1],x[0] -0 + x[1] - 0,x[0]+10**8+1 - x[1],10**8+1-x[0] + x[1], 10**8+1 - x[0] + 10**8+1 - x[1]]  for x in points]
        sorted_0 = sorted(ans,key = lambda x:x[2])
        sorted_1 = sorted(ans,key = lambda x:x[3])
        sorted_2 = sorted(ans,key = lambda x:x[4])
        sorted_3 = sorted(ans,key = lambda x:x[5])
        
        sorted_list = [sorted_0,sorted_1,sorted_2,sorted_3]
        cur_max_dis = -1
        remove_p = set()
        for i in range(4):
            p0 = sorted_list[i][0]
            p1 = sorted_list[i][-1]
            
            cur_dis = abs(p0[0] - p1[0]) + abs(p0[1] - p1[1])
            if cur_dis >cur_max_dis:
                remove_p = set()
                remove_p.add((p0[0],p0[1]))
                remove_p.add((p1[0],p1[1]))
                cur_max_dis = cur_dis
            elif cur_dis == cur_max_dis:
                remove_p.add((p0[0],p0[1]))
                remove_p.add((p1[0],p1[1]))
            else:
                continue
        #print(remove_p,len(sorted_list))
        
        
        min_dis = 10**8*2+1
        for p_remove in list(remove_p):
            cur_max_dis = -1
            for l in sorted_list:
                #print(l)
                i,j = 0,len(l)-1
                if l[i][0] == p_remove[0] and l[i][1] == p_remove[1]:
                    i += 1
                elif l[j][0] == p_remove[0] and l[j][1] == p_remove[1]:
                    j -= 1
                    
                p0 = l[i]
                p1 = l[j]
                
                cur_dis = abs(p0[0] - p1[0]) + abs(p0[1] - p1[1])
                if cur_dis>cur_max_dis:
                    #print(p_remove,l[i],l[j])
                    cur_max_dis = cur_dis
            
            if cur_max_dis<min_dis:
                min_dis = cur_max_dis
                
                    
        return min_dis        
            
        