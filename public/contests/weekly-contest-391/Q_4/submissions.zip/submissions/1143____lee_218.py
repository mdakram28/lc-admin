class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        n = len(points)

        res=[]
        for p, q in [[1, 1], [1, -1], [-1, 1], [-1, -1]]:
            res+=[[]]

            for i in range(n):
                res[-1]+=[ (p * points[i][0] + q * points[i][1],i) ]

            res[-1] =sorted(res[-1])


        stack=set()
        for i in res:

            stack|={i[0][1],i[-1][1]}


        ans=float('inf')
        for remove in stack:
                cur=0
                for i in range(4):

                    x=[res[i][0],res[i][1],res[i][-1],res[i][-2]]
                    x=sorted([i for i in x if remove !=i[1]])
                    cur=max(cur,x[-1][0]-x[0][0])
                ans=min(ans,cur)
        return ans