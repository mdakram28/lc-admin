class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def func(a,b,idx):
            a1=a.copy()
            b1=b.copy()
            for i,k in enumerate(a1):
                if k[1]==idx:
                    # a1.remove(i)
                    del a1[i]
            for i,k in enumerate(b1):
                if k[1]==idx:
                    # b1.remove(i)
                    del b1[i]
            return max(a1[-1][0]-a1[0][0],b1[-1][0]-b1[0][0])
                
        a=[]# sums
        b=[]# diffs
        for idx,k in enumerate(points):
            i,j=k
            a.append((i+j,idx))
            b.append((i-j,idx))
        a.sort()
        b.sort()
        print(a,b)
        return min(func(a,b,a[0][1]),func(a,b,a[-1][1]),func(a,b,b[0][1]),func(a,b,b[-1][1]))
        # return min(a[-1]-a[1],b[-1]-b[1])
        # return min(max(a[-1]-a[1],b[-1]-b[0]),max(a[-1]-a[0],b[-1]-b[1]),max(a[-2]-a[0],))
        