from typing import List

class Solution:
    def minimumDistance(self, A: List[List[int]]) -> int:
        N = len(A)
        V = [0] * N
        V1 = [0] * N
        for i in range(N):
            V[i] = A[i][0] + A[i][1]
            V1[i] = A[i][0] - A[i][1]

        V.sort()
        V1.sort()
        mini = 1e9
        
        for x, y in A:
            p, q = x + y, x - y
            a = V1[-1] - V1[1] if (q == V1[0]) else (V1[-2] - V1[0] if q == V1[-1] else V1[-1] - V1[0])
            if p == V[0]: 
                mini = min(mini, max(V[-1] - V[1], a))
            elif p == V[-1]: 
                mini = min(mini, max(V[-2] - V[0], a))
            else:
                mini = min(mini, max(V[-1] - V[0], a))
            
        return mini