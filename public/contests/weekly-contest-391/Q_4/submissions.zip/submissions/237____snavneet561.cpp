class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<vector<int>> v;
        for(auto it: points){
            int x=it[0], y=it[1];
            v.push_back({x+y, x-y});
        }
        int n=v.size();
        multiset<pair<int, int>> l1, l2, r1, r2;
        for(int i=1; i<n; i++){
            int x=v[i][0], y=v[i][1];
            r1.insert({x, y});
            r2.insert({y, x});
        }
        int x1=(*r1.begin()).first, y1=(*r2.begin()).first;
        int x2=(*r1.rbegin()).first, y2=(*r2.rbegin()).first;
        int res=max(abs(x1-x2), abs(y1-y2));
        for(int i=1; i<n; i++){
            int x=v[i][0], y=v[i][1];
            r1.erase(r1.find({x, y}));
            r2.erase(r2.find({y, x}));
            x=v[i-1][0], y=v[i-1][1];
            r1.insert({x, y});
            r2.insert({y, x});
            int x1=(*r1.begin()).first, y1=(*r2.begin()).first;
            int x2=(*r1.rbegin()).first, y2=(*r2.rbegin()).first;
            res=min(res, max(abs(x1-x2), abs(y1-y2)));
        }
        return res;
    }
};