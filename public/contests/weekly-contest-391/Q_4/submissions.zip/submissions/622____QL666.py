class Solution:
    def maxDistance(self, points):
        n = len(points)
        p = [[None] * n for _ in range(4)]
        for i in range(n):
            p[0][i] = (points[i][0] + points[i][1], i)
            p[1][i] = (-points[i][0] + points[i][1], i)
            p[2][i] = (points[i][0] - points[i][1], i)
            p[3][i] = (-points[i][0] - points[i][1], i)
        
        for i in range(4):
            p[i].sort()


        ans = 0
        max_index = (-1, -1)
        for i in range(4):
            if p[i][n - 1][0] - p[i][0][0] > ans:
                max_index = (p[i][n - 1][1], p[i][0][1])
            ans = max(ans, p[i][n - 1][0] - p[i][0][0])
        return ans, max_index
            
    def minimumDistance(self, points: List[List[int]]) -> int:
        _, max_index = self.maxDistance(points)
        index1, index2 = max_index
        ans1, _ = self.maxDistance(points[: index1] + points[index1 + 1: ])
        ans2, _ = self.maxDistance(points[: index2] + points[index2 + 1: ])
        return min(ans1, ans2)