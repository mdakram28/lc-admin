typedef pair<int,int> pi;
class Solution {
public:
    set<int> helper(vector<vector<int>> &nums, int n){
        vector<pi> v1, v2;
        for(int i=0;i<n;i++){
            v1.push_back(make_pair(nums[i][0]+nums[i][1],i));
            v2.push_back(make_pair(nums[i][0]-nums[i][1],i));
        }
        sort(v1.begin(), v1.end());
        sort(v2.begin(), v2.end());
        set<int> s;
        s.insert(v1.front().second);
        s.insert(v1.back().second);
        s.insert(v2.front().second);
        s.insert(v2.back().second);
        return s;
    }
    
    int helper2(vector<vector<int>> &nums, int n){
        vector<int> v1, v2;
        for(int i=0;i<n;i++){
            v1.push_back(nums[i][0]+nums[i][1]);
            v2.push_back(nums[i][0]-nums[i][1]);
        }
        sort(v1.begin(), v1.end());
        sort(v2.begin(), v2.end());
        return max(v1.back()-v1.front(), v2.back()-v2.front());
    }
    
    int minimumDistance(vector<vector<int>>& nums) {
        sort(nums.begin(), nums.end());
        int n =nums.size();
        set<int> s = helper(nums, n);
        // for(int i:s) cout<<i<<" ";
        // cout<<"\n";
        int maxi = INT_MAX;
        for(int i:s){
            vector<vector<int>> v;
            for(int j=0;j<n;j++){
                if(j==i) continue;
                v.push_back(nums[j]);
            }
            int temp = helper2(v, n-1);
            // cout<<i<<" "<<temp<<"\n";
            maxi = min(maxi, temp);
        }
        // cout<<"\n";
        return maxi;
    }
};