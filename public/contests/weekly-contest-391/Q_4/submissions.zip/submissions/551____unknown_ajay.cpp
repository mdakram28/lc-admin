
/*
 
 File   : Leetcode.cpp
 -------------------
 |   Hello         |
 |   DSA !         |
 -------------------
 
 */

#define mii map<int,int>
#define vi vector<int>
#define vs vector<string>
#define vb vector<bool>
#define pii pair<int,int>
#define endl "\n"
#define intmax INT_MAX
#define intmin INT_MIN
#define need_for_speed ios_base::sync_with_stdio(false); cin.tie(NULL);
#define ff(i,a,b) for(int i=a;i<b;i++)
#define rfor(i,a,b) for(int i=a;i>=b;i--)
#define all(x) x.begin(),x.end()
#define pt(x) { cout<<x<<"\n"; }
#define fs first.second
#define ss second.second
#define countofSet(x) __builtin_popcount(x)
#define pb push_back
#define fir first
#define sec second
#define sqrt(x) sqrtl(x)
#define pii pair<int,int>

int please(vector<pii>& nums)
{
    int N = nums.size();
    int abb, fk, ok, bbye;
 
    abb = fk = nums[0].first + nums[0].second;
    ok = bbye = nums[0].first - nums[0].second;
    for (int i = 1; i < N; i++) {
        int sum = nums[i].first + nums[i].second;
        int diff = nums[i].first - nums[i].second;
        if (sum < abb)
        {
            abb = sum;
        }
        else if (sum > fk)
        {
            fk = sum;
        }
        if (diff < ok)
        {
            ok = diff;
        }
        else if (diff > bbye)
        {
            bbye = diff;
        }
    }
 
    int ret = max(fk - abb, bbye - ok);

    return ret;
}

pii gfPLA(vector<pii >& nums)
{
    int N = nums.size();
    vector<pii> op1(N), op2(N);
 
    for (int i = 0; i < N; i++)
    {
        op1[i] = {nums[i].first + nums[i].second,i};
        op2[i] = {nums[i].first - nums[i].second,i};
    }
 
    sort(all(op1));
    sort(all(op2));

    int ret = op1.back().first - op1.front().first;
    int a = op1.back().second , b = op1.front().second;
    
    int two = op2.back().first - op2.front().first;
    if(two > ret)
    {
        ret = two;
        a = op2.front().second;
        b = op2.back().second;
    }
 
    return {a,b};
}

class Solution {
public:
    int minimumDistance(vector<vector<int>>& nums)
    {
        
        int n = (int)nums.size();
        vector<pii> okl; for(auto i:nums) okl.push_back({i[0],i[1]});
        pii p = gfPLA(okl);
        
        vector<pii> F,S;
        for(int i=0;i<n;i++)
        {
            if(i!=p.first)
            {
                F.push_back({nums[i][0],nums[i][1]});
            }
        }
        for(int i=0;i<n;i++)
        {
            if(i!=p.second)
            {
                S.push_back({nums[i][0],nums[i][1]});
            }
        }
        
        int ans = please(F);
        ans = min( ans , please(S) );
        return ans;
    }
};