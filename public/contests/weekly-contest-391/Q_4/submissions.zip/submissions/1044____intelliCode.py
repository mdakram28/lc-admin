class Solution:
    def minimumDistance(self, P: List[List[int]]) -> int:
        lP = len(P)
        xSum,ySum = sum(x for x,_ in P),sum(y for _,y in P)
        cen = (xSum/lP,ySum/lP)
        
        def dist(p1,p2):
            (x,y),(X,Y) = p1,p2
            return abs(x-X) + abs(y-Y)
        
        cntr = Counter([tuple(p) for p in P])
        if min(cntr.values())>1:
            return max(dist(p1,p2) for p1,p2 in combinations(cntr, 2)) if len(cntr)>1 else 0
        
        sortedP = sorted(cntr, key=lambda p: dist(p, cen))
        
        dictMax = defaultdict(set)
        # listK = sorted(cntr)
        for p1,p2 in combinations(sortedP[-20:], 2):
            dictMax[dist(p1,p2)].add((p1,p2))
        
        sortedK = sorted(dictMax)
        retV = sortedK.pop()
        setPairs = dictMax[retV]
        setP = reduce(lambda a,b: a&b, [set(p) for p in setPairs])
        if not setP:        return retV
        if all(cntr[p]>1 for p in setP):      return retV
        setPRemove = set(p for p in setP if cntr[p]==1)
        
        while setPRemove and sortedK:
            retV = sortedK.pop()
            setPairs = dictMax[retV]
            setP = reduce(lambda a,b: a&b, [set(p) for p in setPairs])
            setPRemove &= setP

        return retV
            