class Solution {
public:
    int ignore(vector<vector<int>> &d1, vector<vector<int>> &d2, int idx){
        int d1h = d1.size() - 1, d1l = 0;
        int d2h = d2.size() - 1, d2l = 0;
        if(d1[d1h][1] == idx) d1h--;
        else if(d1[d1l][1] == idx) d1l++;
        if(d2[d2h][1] == idx) d2h--;
        else if(d2[d2l][1] == idx) d2l++;
        return max(d1[d1h][0] - d1[d1l][0], d2[d2h][0] - d2[d2l][0]);
    }
    int minimumDistance(vector<vector<int>>& points) {
        const int n = points.size();
        vector<vector<int>> d1, d2;
        for(int i=0; i<n; i++){
            d1.push_back({(points[i][0] + points[i][1]), i});
            d2.push_back({(points[i][0] - points[i][1]), i});
        }
        sort(d1.begin(), d1.end());
        sort(d2.begin(), d2.end());
        // for(int i=0; i<n; i++) cout << i << ' ' << d1[i][0] << ',' << d1[i][1] << endl;
        // for(int i=0; i<n; i++) cout << i << ' ' << d2[i][0] << ',' << d2[i][1] << endl;
        int ans = ignore(d1, d2, -1);
        for(int i=0; i<n; i++){
            ans = min(ans, ignore(d1, d2, i));
            // cout << i << ' ' << ignore(d1, d2, i) << endl;
        }
        return ans;
    }
};