class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
           vector<int>b, c;
    int n = points.size();
    multiset<int>s1, s2;
    for (auto x : points) {
        b.push_back(x[0] - x[1]);
        s1.insert(x[0] - x[1]);
        c.push_back(x[0] + x[1]);
        s2.insert(x[0] + x[1]);
    }
    sort(b.begin(), b.end());
    sort(c.begin(), c.end());
    int ans = max(b.back() - b[0], c.back() - c[0]);
    for (auto x : points) {
        int t1 = x[0] - x[1];
        int t2 = x[0] + x[1];
        s1.erase(s1.find(t1));
        s2.erase(s2.find(t2));
        ans = min(ans, max(*prev(s1.end()) - *s1.begin(), *prev(s2.end()) - *s2.begin())); 
        s1.insert(t1);
        s2.insert(t2);
    }
    return ans;
    }
};