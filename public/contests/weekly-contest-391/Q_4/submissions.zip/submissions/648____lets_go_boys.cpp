class Solution {
public:
    
    int minimumDistance(vector<vector<int>>& A) {
        
        int ans=INT_MAX;
        
        multiset<int> V, V1;
     
        for (int i = 0; i < A.size(); i++) {
            V.insert(A[i][0] + A[i][1]);
            V1.insert(A[i][0] - A[i][1]);
        }
        
        for (int i = 0; i < A.size(); i++) 
        {
            V.erase(V.find(A[i][0] + A[i][1]));
            V1.erase(V1.find(A[i][0] - A[i][1]));
       
           int mx= max(*V.rbegin() - *V.begin(), *V1.rbegin() - *V1.begin());
            V.insert(A[i][0] + A[i][1]);
            V1.insert(A[i][0] - A[i][1]);
           ans=min(ans,mx);
        }
        return ans;
    }
};