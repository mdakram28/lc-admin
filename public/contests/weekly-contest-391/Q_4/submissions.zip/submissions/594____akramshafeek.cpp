class Solution {
public:    
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
            
        vector<pair<int,int>> sum(n);
        vector<pair<int,int>> diff(n);
        
        for(int i = 0 ; i < points.size() ; i++) {
            sum[i] = {points[i][0] + points[i][1], i};
            diff[i] = {points[i][0] - points[i][1], i};
        }
        
        sort(sum.begin(), sum.end());
        sort(diff.begin(), diff.end());
        
        // for(auto i: sum)
        //     cout << i.first << ":" << i.second << " ";
        // cout << endl;
        // for(auto i: diff)
        //     cout << i.first << ":" << i.second << " ";
        // cout << endl;
        // cout << "MAX dist: " << max(sum[n - 1].first - sum[0].first, diff[n - 1].first - diff[0].first) << endl;
        
        // int ans1 = max(sum[n - 1].first - sum[1].first, diff[n - 1].first - diff[1].first);
        // int ans2 = max(sum[n - 2].first - sum[0].first, diff[n - 2].first - diff[0].first);
        int ans = INT_MAX;
        
        for(int i = 0 ; i < n ; i++) {
            
            int left = 0;
            int right = n - 1;
            
            while(sum[left].second == i) left++;
            while(sum[right].second == i) right--;
            
            int sumVal = sum[right].first - sum[left].first;
            
            left = 0;
            right = n - 1;
            
            while(diff[left].second == i) left++;
            while(diff[right].second == i) right--;
            
            int diffVal = diff[right].first - diff[left].first;
            
            ans = min(ans, max(sumVal, diffVal));
        }
                
        return ans;
    }
};