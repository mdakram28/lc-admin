def MaxDist(a):
    n = len(a)
    v = [0 for i in range(n)]
    v1 = [0 for i in range(n)]
    for i in range(n):
        v[i] = (a[i][0] + a[i][1],i)
        v1[i] = (a[i][0] - a[i][1],i)
    v.sort()
    v1.sort()
    maximum ,i,j= max((v[-1][0] - v[0][0], v[0][1],v[-1][1]), (v1[-1][0] - v1[0][0],v1[-1][1],v1[0][1]))
    return maximum,i,j
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        maxdist,i,j = MaxDist(points)
        print(maxdist,i,j)
        i,j = min(i,j),max(i,j)
        a,b = points[i],points[j]
        points.pop(j)
        points.pop(i)
        best = 100000000000000000000000000000000000000000000000
        for c in [a,b]:
            c1,_,__ = MaxDist(points + [c])
            best = min(c1,best)
        return best