#define sz(a) (int)a.size()
#define ALL(v) v.begin(), v.end()
#define ALLR(v) v.rbegin(), v.rend()
#define ll long long
#define pb push_back
#define forr(i, a, b) for(int i = a; i < b; i++)
#define dorr(i, a, b) for(int i = a; i >= b; i--)
#define ld long double
#define vt vector
#include<fstream>
#define fi first
#define se second
#define pll pair<ll, ll>
#define pii pair<int, int>
#define mpp make_pair
const int inf = 1e9;
class Solution {
public:
    vt<pii>v;
    int minimumDistance(vector<vector<int>>& a) {
        multiset<int>mx, my;
        for(auto i: a){
            int px = i[0], py = i[1];
            v.pb(mpp(px + py, px - py));
        }
        for(auto i: v){
            mx.insert(i.fi); my.insert(i.se);
        }
        int ans = inf;
        for(auto i: v){
            mx.erase(mx.find(i.fi)); my.erase(my.find(i.se));
            ans = min(ans, max(*mx.rbegin() - *mx.begin(), *my.rbegin() - *my.begin()));
            mx.insert(i.fi); my.insert(i.se);
        }
        return(ans);
    }
};