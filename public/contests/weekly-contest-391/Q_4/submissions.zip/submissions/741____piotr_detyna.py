class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        points_sum = sorted([point[0]+point[1] for point in points])
        points_diff = sorted([point[0]-point[1] for point in points])
        res = float('inf')
        for point in points:
            
            point_sum = point[0] + point[1]
            point_diff = point[0] - point[1]
            
            max_sum = points_sum[-1]
            if max_sum == point_sum:
                max_sum = points_sum[-2]
                
            max_diff = points_diff[-1]
            if max_diff == point_diff:
                max_diff = points_diff[-2]

            min_sum = points_sum[0]
            if min_sum == point_sum:
                min_sum = points_sum[1]
                
            min_diff = points_diff[0]
            if min_diff == point_diff:
                min_diff = points_diff[1]
        
            dist = max(max_sum - min_sum, max_diff - min_diff)
            
            print(dist)
            res = min(dist, res)
        return res