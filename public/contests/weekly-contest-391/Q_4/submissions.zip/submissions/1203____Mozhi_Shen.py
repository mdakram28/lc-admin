class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def max_distance(points):
            pb = -float("infinity")
            ps = float("infinity")
            mb = -float("infinity")
            ms = float("infinity")
            pbh = 0
            psh = 0
            mbh = 0
            msh =0
            
            for idx, [x, y] in enumerate(points):
                a = x + y
                b = x - y
                if a > pb:
                    pb = a
                    pbh = idx
                if a < ps:
                    ps = a
                    psh = idx
                if b > mb:
                    mb = b
                    mbh = idx
                if b < ms:
                    ms = b
                    msh = idx
            # print(pbh,psh,mbh,msh)
            if pb - ps > mb - ms:
                return pb - ps, pbh, psh
            else:
                return mb - ms, mbh, msh
        
        a,b,c = max_distance(points)
        f = points.copy()
        f.pop(b)
        x = max_distance(f)
        d = points.copy()
        d.pop(c)
        y = max_distance(d)
        return min(x[0],y[0])
        return 11