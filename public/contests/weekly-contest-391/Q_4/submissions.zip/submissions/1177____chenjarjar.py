def f(a,b):
    return abs(a[0]-b[0])+abs(a[1]-b[1])
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        mm = set()
        m = set()
        for a,b in points:
            if (a,b) not in mm:
                mm.add((a,b))
            else:
                m.add((a,b))

        points.sort(key=lambda x: x[0]+x[1])
        t = []
        t += [points[0],points[1],points[-2],points[-1]]
        points.sort(key=lambda x: x[0]-x[1])
        t += [points[0],points[1],points[-2],points[-1]]
        ans = inf
        for z in t:
            cur = 0
            for x in t:
                if (z[0],z[1]) not in m and x == z:
                    continue
                for y in t:
                    if x == y or (z[0],z[1]) not in m and y == z:
                        continue
                    cur = max(cur,f(x,y))
            ans = min(ans,cur)
        return ans