class Solution {
  // x,y >= 0, no need to care about this
  // Manhattan dist
  
  // have to remove one point, cannot skip
  
  // possible min of max
  // find the max dist node and remove?
  
  
  // for original arr
  // we have max dist pair. If there are more than one max dist pair, then we cannot change the result
  // there are 1e5 points, cannot brute force
  
  // abs(x1 - x2) + abs(y1 - y2)
  // 
  
  // compute max
  // sort points by x
  // only keep two value for each x, minY and maxY and their count
  // two pointer
  // 
  public int minimumDistance(int[][] points) {
    int n = points.length;
    
    int[] tmp = maxDist(points, -1);
    // System.out.println(Arrays.toString(tmp));
    // if (tmp[1] > 1) return tmp[0]; // cannot decrease
    
    
    
    return Math.min(maxDist(points, tmp[2])[0], maxDist(points, tmp[3])[0]);
  }
  
  // https://www.geeksforgeeks.org/maximum-manhattan-distance-between-a-distinct-pair-from-n-coordinates/
  // 0 - maxDist, 1 - cnt, 2 - idx1, 3 - idx2
  private int[] maxDist(int[][] points, int skip) {
    int n = points.length;
    
    int minSum = Integer.MAX_VALUE, minSumCnt = 0, minSumIdx = -1;
    int maxSum = Integer.MIN_VALUE, maxSumCnt = 0, maxSumIdx = -1;
    int minDiff = Integer.MAX_VALUE, minDiffCnt = 0, minDiffIdx = -1;
    int maxDiff = Integer.MIN_VALUE, maxDiffCnt = 0, maxDiffIdx = -1;
    
    for (int i = 0; i < n; i++) if (i != skip) {
      int sum = points[i][0] + points[i][1];
      int diff = points[i][0] - points[i][1];
      
      if (sum < minSum) {
        minSum = sum;
        minSumCnt = 0;
        minSumIdx = i;
      }
      if (sum == minSum) minSumCnt++;
      if (sum > maxSum) {
        maxSum= sum;
        maxSumCnt = 0;
        maxSumIdx = i;
      }
      if (sum == maxSum) maxSumCnt++;
      
      if (diff < minDiff) {
        minDiff = diff;
        minDiffCnt = 0;
        minDiffIdx = i;
      }
      if (diff == minDiff) minDiffCnt++;
      if (diff > maxDiff) {
        maxDiff= diff;
        maxDiffCnt = 0;
        maxDiffIdx = i;
      }
      if (diff == maxDiff) maxDiffCnt++;
    }
    
    int dist = Math.max(maxSum - minSum, maxDiff - minDiff);
    int cnt = 1, l, r;
    if (dist == maxSum - minSum) {
      cnt = maxSumCnt * minSumCnt;
      l = minSumIdx;
      r = maxSumIdx;
    }
    else {
      cnt = maxDiffCnt * minDiffCnt;
      l = minDiffIdx;
      r = maxDiffIdx;
    }
    return new int[]{dist, cnt, l, r};
  }
}