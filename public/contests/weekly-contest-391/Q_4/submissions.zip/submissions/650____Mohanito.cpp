class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<pair<int, int>> xplusy;
        vector<pair<int, int>> xminusy;
        for (int i = 0; i < points.size(); i++) {
            int x = points[i][0], y = points[i][1];
            xplusy.push_back(make_pair(x + y, i));
            xminusy.push_back(make_pair(x - y, i));
        }
        // the max distance is max(Xj + Yj) - min(Xi + Yi)
        // Or max (Xj - Yj) - min (Xi - Yi)
        sort(xplusy.begin(), xplusy.end());
        sort(xminusy.begin(), xminusy.end());
        int n = xplusy.size();
        int maxplus, minplus, maxminus, minminus, idx;
        int ans = INT_MAX;
        // remove max x+y
        idx = xplusy[n - 1].second;
        maxplus = xplusy[n - 1].second == idx ? xplusy[n - 2].first : xplusy[n - 1].first;
        minplus = xplusy[0].second == idx ? xplusy[1].first : xplusy[0].first;
        maxminus = xminusy[n - 1].second == idx ? xminusy[n - 2].first : xminusy[n - 1].first;
        minminus = xminusy[0].second == idx ? xminusy[1].first : xminusy[0].first;
        ans = min(ans, max(maxplus - minplus, maxminus - minminus));
        
        // remove min x+y
        idx = xplusy[0].second;
        maxplus = xplusy[n - 1].second == idx ? xplusy[n - 2].first : xplusy[n - 1].first;
        minplus = xplusy[0].second == idx ? xplusy[1].first : xplusy[0].first;
        maxminus = xminusy[n - 1].second == idx ? xminusy[n - 2].first : xminusy[n - 1].first;
        minminus = xminusy[0].second == idx ? xminusy[1].first : xminusy[0].first;
        ans = min(ans, max(maxplus - minplus, maxminus - minminus));
        
        // remove max x-y
        idx = xminusy[n - 1].second;
        maxplus = xplusy[n - 1].second == idx ? xplusy[n - 2].first : xplusy[n - 1].first;
        minplus = xplusy[0].second == idx ? xplusy[1].first : xplusy[0].first;
        maxminus = xminusy[n - 1].second == idx ? xminusy[n - 2].first : xminusy[n - 1].first;
        minminus = xminusy[0].second == idx ? xminusy[1].first : xminusy[0].first;
        ans = min(ans, max(maxplus - minplus, maxminus - minminus));
        
        // remove min x-y
        idx = xminusy[0].second;
        maxplus = xplusy[n - 1].second == idx ? xplusy[n - 2].first : xplusy[n - 1].first;
        minplus = xplusy[0].second == idx ? xplusy[1].first : xplusy[0].first;
        maxminus = xminusy[n - 1].second == idx ? xminusy[n - 2].first : xminusy[n - 1].first;
        minminus = xminusy[0].second == idx ? xminusy[1].first : xminusy[0].first;
        ans = min(ans, max(maxplus - minplus, maxminus - minminus));
        
        return ans;
    }
};