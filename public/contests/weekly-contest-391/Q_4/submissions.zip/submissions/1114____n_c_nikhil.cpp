class Solution {
public:
 int calculate(vector<pair<int,int>> &v1,vector<pair<int,int>> &v,int i){
     int ret1=0;
     if(v1.back().second==i){
         ret1+=v1[v1.size()-2].first;
     }else{
         ret1+=v1.back().first;
     }
     // cout<<ret1<<" ";
     if(v1.front().second==i){
         ret1-=v1[1].first;
     }else{
         ret1-=v1.front().first;
     }
     // cout<<ret1<<" ";
     int ret2=0;
     if(v.back().second==i){
         ret2+=v[v.size()-2].first;
     }else{
         ret2+=v.back().first;
     }
     // cout<<ret2<<" ";
     if(v.front().second==i){
         ret2-=v[1].first;
     }else{
         ret2-=v.front().first;
     }
     // cout<<ret2<<"\n";
     return max(ret1,ret2);
 }
    int minimumDistance(vector<vector<int>>& num) {
        int n=num.size();
        vector<pair<int,int>> v(n),v1(n);
        for(int i=0;i<num.size();i++){
            v[i].first=num[i][0]+num[i][1];
            v[i].second=i;
            v1[i].first=num[i][0]-num[i][1];
            v1[i].second=i;
        }
        sort(v1.begin(),v1.end());
        sort(v.begin(),v.end());
        pair<int,int> p1=v1.front();
        int ans=INT_MAX;
        //change back from this 
        //V.back() - V.front(), V1.back() - V1.front()
      for(int i=0;i<n;i++){
          ans=min(ans,calculate(v1,v,i));
      }
             return ans;
    }
};