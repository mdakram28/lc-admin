from sortedcontainers import SortedList

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        a = SortedList()
        b = SortedList()
        for x, y in points:
            a.add(x - y)
            b.add(x + y)
        ans = max(a[-1] - a[0], b[-1] - b[0])
        for x, y in points:
            a.remove(x - y)
            b.remove(x + y)
            ans = min(ans, max(a[-1] - a[0], b[-1] - b[0]))
            a.add(x - y)
            b.add(x + y)
        return ans