class Solution {
public:
    int minimumDistance(vector<vector<int>>& pts) {
        vector<pair<int, int>> sum;
        vector<pair<int, int>> diff;
        int n = (int) pts.size();

        for (int i = 0; i < n; i++) {
            int x = pts[i][0];
            int y = pts[i][1];
            sum.push_back({x + y, i});
            diff.push_back({x - y, i});
        }

        sort(begin(sum), end(sum));
        sort(begin(diff), end(diff));

        int ans = INT_MAX;
        for (int i = 0; i < n; i++) {
            int x = pts[i][0];
            int y = pts[i][1];
            
            int sum_min = (sum[0].second == i ? sum[1].first : sum[0].first);
            int sum_max = (sum[n - 1].second == i ? sum[n - 2].first : sum[n - 1].first);

            int diff_min = (diff[0].second == i ? diff[1].first : diff[0].first);
            int diff_max = (diff[n - 1].second == i ? diff[n - 2].first : diff[n - 1].first);

            ans = min(ans, max(diff_max - diff_min, sum_max - sum_min));
        }
        return ans;
    }
};