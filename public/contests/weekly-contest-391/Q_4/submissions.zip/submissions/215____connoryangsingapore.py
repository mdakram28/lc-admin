def find(points, skip=-1):
    maxp = maxm = float('-inf')
    minp = minm = float('inf')

    for cur in range(len(points)):
        if cur==skip: continue
        x, y = points[cur]
        if x + y > maxp:
            maxp = x + y
            maxp_point = cur
        if x + y < minp:
            minp = x + y
            minp_point = cur
        if x - y > maxm:
            maxm = x - y
            maxm_point = cur
        if x - y < minm:
            minm = x - y
            minm_point = cur

    distance = max(maxp - minp, maxm - minm)
    if distance == maxp - minp:
        return maxp_point, minp_point, distance
    else:
        return maxm_point, minm_point, distance
    
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        p1, p2, d = find(points)
        _, _2, ans1 = find(points, p1)
        _, _2, ans2 = find(points, p2)
        return min(ans1, ans2)


        