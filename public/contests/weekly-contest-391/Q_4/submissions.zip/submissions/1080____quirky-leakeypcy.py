class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        ans=0
        re_i1=0
        re_i2=0
        for k in range(4):
            r=-1e10
            l=1e10;
            i1=0
            i2=0
            for i in range(len(points)):
                ps=0
                if ((k&1)==1):
                    ps+=points[i][0]
                else:
                    ps-=points[i][0]
                if ((k&2)==0):
                    ps+=points[i][1]
                else:
                    ps-=points[i][1]
                if (ps>r):
                    r=ps
                    i1=i
                if (ps<l):
                    l=ps
                    i2=i
                '''
                if (ps>r):
                    l=r
                    i2=i1
                    r=ps
                    i1=i
                elif (ps>l):
                    l=ps
                    i2=i
                '''
            if (r-l>ans):
                #print(l,r)
                ans=r-l
                re_i2=i2
                re_i1=i1
        #print(ans)
        ans1=0
        ans2=0
        #print(re_i1,re_i2)
        for k in range(4):
            r=-1e10
            l=1e10;
            for i in range(len(points)):
                if (i==re_i1):
                    continue;
                ps=0
                if ((k&1)==1):
                    ps+=points[i][0]
                else:
                    ps-=points[i][0]
                if ((k&2)==0):
                    ps+=points[i][1]
                else:
                    ps-=points[i][1]
                if (ps>r):
                    r=ps
                if (ps<l):
                    l=ps
            if (r-l>ans1):
                ans1=r-l
        for k in range(4):
            r=-1e10
            l=1e10;
            for i in range(len(points)):
                if (i==re_i2):
                    continue;
                ps=0
                if ((k&1)==1):
                    ps+=points[i][0]
                else:
                    ps-=points[i][0]
                if ((k&2)==0):
                    ps+=points[i][1]
                else:
                    ps-=points[i][1]
                if (ps>r):
                    r=ps
                if (ps<l):
                    l=ps
            if (r-l>ans2):
                ans2=r-l
        return min(ans1,ans2)
                    
            