class Solution {
public:
    using ll = long long;
    using pii = pair<ll, ll>;
    int minimumDistance(vector<vector<int>>& points) {
        int n = (int)points.size();
        vector<ll> a(n), b(n);
        
        for (int i = 0 ;i < n ;i++) {
            const auto u = points[i];
            ll x = u[0], y = u[1];
            a[i] = x + y;
            b[i] = x - y;
        }
        sort(a.begin(), a.end());
        sort(b.begin(), b.end());
        
        ll ans = max(a[n - 1] - a[0], b[n - 1] - b[0]);
        for (int i = 0; i < n; i++) {
            const auto u = points[i];
            ll x = u[0], y = u[1];
            ll av_1 = (x + y == a.back() ? a[n - 2] : a[n - 1]);
            ll av_0 = (x + y == a[0] ? a[1] : a[0]);
            
            ll bv_1 = (x - y == b.back() ? b[n - 2] : b[n - 1]);
            ll bv_0 = (x - y == b[0] ? b[1] : b[0]);
            
            ll h = max(av_1 - av_0, bv_1 - bv_0);
            ans = min(ans, h);
        }
        return ans;
    }
};