#include<algorithm>
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int sum[points.size()], diff[points.size()];
        for(int i = 0; i < points.size(); ++i){
            sum[i] = points[i][0] + points[i][1];
            diff[i] = points[i][0] - points[i][1];
        }
        
        sort(sum, sum + points.size());
        sort(diff, diff + points.size());
        int result = max(sum[points.size()-1] - sum[0], diff[points.size()-1] - diff[0]);
        int s1, s2, d1, d2, temp, s, d;
        for(int i = 0 ; i < points.size() ; ++i){
            s = points[i][0] + points[i][1];
            d = points[i][0] - points[i][1];
            s1 = sum[0];
            s2 = sum[points.size()-1];
            d1 = diff[0];
            d2 = diff[points.size()-1];
            if(s == sum[0]){
                s1 = sum[1];
            }
            if(s == sum[points.size()-1]){
                s2 = sum[points.size()-2];
            }
            if(d == diff[0]){
                d1 = diff[1];
            }
            if(d == diff[points.size()-1]){
                d2 = diff[points.size()-2];
            }
            temp = max(s2-s1, d2-d1);
            result = min(temp, result);
            // cout<<result<<","<<temp<<endl;
        }
        return result;
    }
};