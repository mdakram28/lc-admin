class Solution {
public:
int minimumDistance(vector<vector<int>>& points) {
    int n = points.size();
    vector<vector<int>> xAddy(n, vector<int>(2, 0));
    vector<vector<int>> ySubx(n, vector<int>(2, 0));

    for (int i = 0; i < n; i++)
    {
        xAddy[i] = {points[i][0] + points[i][1], i};
        ySubx[i] = {points[i][1] - points[i][0], i};
    }

    sort(xAddy.begin(), xAddy.end());
    sort(ySubx.begin(), ySubx.end());
    int ans = 1e8*2;
    for (int i = 0; i < n; i++) {
        int maxD = 0;
        if (xAddy[0][1] == i) 
            maxD = max(maxD, abs(xAddy[1][0] - xAddy[n - 1][0]));
        else if (xAddy[n-1][1] == i)
            maxD = max(maxD, abs(xAddy[0][0] - xAddy[n - 2][0]));
        else
            maxD = max(maxD, abs(xAddy[0][0] - xAddy[n - 1][0]));

        if (ySubx[0][1] == i) 
            maxD = max(maxD, abs(ySubx[1][0] - ySubx[n - 1][0]));
        else if (ySubx[n-1][1] == i)
            maxD = max(maxD, abs(ySubx[0][0] - ySubx[n - 2][0]));
        else
            maxD = max(maxD, abs(ySubx[0][0] - ySubx[n - 1][0]));

        ans = min(ans, maxD);
    }
    return ans;
}
};