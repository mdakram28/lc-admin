class Solution:
    def minimumDistance(self, A: List[List[int]]) -> int:
        # List to store maximum and
        # minimum of all the four forms
        ls = [[x+y, x-y] for x, y in A]
        # Sorting both the vectors
        x = sorted(ls)
        y = sorted(ls, key=lambda x: x[1])
        x1, x2 = x[:-1], x[1:]
        y1, y2 = y[:-1], y[1:]
        def maxDist(A):
            sums = [x for x, _ in A]
            diff = [y for _, y in A]
            sums.sort()
            diff.sort()
            return max(sums[-1] - sums[0], diff[-1] - diff[0])
        return min(maxDist(x1), maxDist(x2), maxDist(y1), maxDist(y2))