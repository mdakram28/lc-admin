class Solution {
public:
    int minimumDistance(vector<vector<int>>& point) {
        int n=point.size();
        vector<pair<int,int>> A;
        for(int i=0;i<n;i++){
            A.push_back({point[i][0],point[i][1]});
        }
        vector<vector<int>> pre(n,vector<int>(4));
        vector<vector<int>> suf(n,vector<int>(4));
        int minsum, maxsum, mindiff, maxdiff;
        minsum = maxsum = A[0].first + A[0].second;
        mindiff = maxdiff = A[0].first - A[0].second;
        pre[0][0]=maxsum,pre[0][1]=minsum;
        pre[0][2]=maxdiff,pre[0][3]=mindiff;
        
        for(int i=1;i<n;i++){
            int sum = A[i].first + A[i].second;
            int diff = A[i].first - A[i].second;
            if (sum < minsum)
                minsum = sum;
            else if (sum > maxsum)
                maxsum = sum;
            if (diff < mindiff)
                mindiff = diff;
            else if (diff > maxdiff)
                maxdiff = diff;
            pre[i][0]=maxsum,pre[i][1]=minsum;
            pre[i][2]=maxdiff,pre[i][3]=mindiff;
            //cout<<max(maxsum - minsum, maxdiff - mindiff)<<" ";
        }
        minsum = maxsum = A[n-1].first + A[n-1].second;
        mindiff = maxdiff = A[n-1].first - A[n-1].second;
        suf[n-1][0]=maxsum,suf[n-1][1]=minsum;
        suf[n-1][2]=maxdiff,suf[n-1][3]=mindiff;
        for(int i=n-2;i>=0;i--){
            int sum = A[i].first + A[i].second;
            int diff = A[i].first - A[i].second;
            if (sum < minsum)
                minsum = sum;
            else if (sum > maxsum)
                maxsum = sum;
            if (diff < mindiff)
                mindiff = diff;
            else if (diff > maxdiff)
                maxdiff = diff;
            suf[i][0]=maxsum,suf[i][1]=minsum;
            suf[i][2]=maxdiff,suf[i][3]=mindiff;
        }
        int ans=2e8+1;
        for(int i=0;i<n;i++){
            if(i==0){
                int  maximum=max(suf[1][0] - suf[1][1], suf[1][2] - suf[1][3]);
                ans=min(ans,maximum);
            }else if(i==(n-1)){
                int  maximum=max(pre[n-2][0] - pre[n-2][1], pre[n-2][2] - pre[n-2][3]);
                ans=min(ans,maximum);
            }else{
                int mxs=max(pre[i-1][0],suf[i+1][0]);
                int mns=min(pre[i-1][1],suf[i+1][1]);
                int mxd=max(pre[i-1][2],suf[i+1][2]);
                int mnd=min(pre[i-1][3],suf[i+1][3]);
                
                ans=min(ans,max(mxs-mns,mxd-mnd));
            }
        }
    
        return ans;
    }
};