int ZMax[100020][2];
int ZMin[100020][2];
int WMin[100020][2];
int WMax[100020][2];
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        for(int i=0;i<n;++i){
            ZMax[i][0] = ZMin[i][0] = points[i][0] - points[i][1];
            WMax[i][0] = WMin[i][0] = points[i][0] + points[i][1];
            if(i){
                ZMax[i][0] = max(ZMax[i][0], ZMax[i-1][0]);
                ZMin[i][0] = min(ZMin[i][0], ZMin[i-1][0]);
                WMax[i][0] = max(WMax[i][0], WMax[i-1][0]);
                WMin[i][0] = min(WMin[i][0], WMin[i-1][0]);
            }
            
        }
        
        for(int i=n-1;i>=0;--i){
            ZMax[i][1] = ZMin[i][1] = points[i][0] - points[i][1];
            WMax[i][1] = WMin[i][1] = points[i][0] + points[i][1];
            if(i < n-1){
                ZMax[i][1] = max(ZMax[i][1], ZMax[i+1][1]);
                ZMin[i][1] = min(ZMin[i][1], ZMin[i+1][1]);
                WMax[i][1] = max(WMax[i][1], WMax[i+1][1]);
                WMin[i][1] = min(WMin[i][1], WMin[i+1][1]);
            }            
        }
        
        int ans = 0;
        for(int i=0;i<n;++i){
            if(i == 0){
                ans = max(ZMax[1][1] - ZMin[1][1], WMax[1][1] - WMin[1][1]); 
            }else if(i < n-1){
                int z_min = min(ZMin[i-1][0], ZMin[i+1][1]);
                int z_max = max(ZMax[i-1][0], ZMax[i+1][1]);
                int w_min = min(WMin[i-1][0], WMin[i+1][1]);
                int w_max = max(WMax[i-1][0], WMax[i+1][1]);
                ans = min(ans, max(z_max - z_min, w_max - w_min));
            }else{
                ans = min(ans, max(ZMax[i-1][0] - ZMin[i-1][0], WMax[i-1][0] - WMin[i-1][0]));
            }
         //   printf("now: %d %d\n",i,ans);
        }
        return ans;
    }
};