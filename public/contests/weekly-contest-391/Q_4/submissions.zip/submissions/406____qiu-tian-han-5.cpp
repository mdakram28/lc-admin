class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        multiset<pair<int, int>> p[4];
        int tot = 0;
        for (auto t : points) {
            int x = t[0], y = t[1];
            p[0].insert({x + y, tot});
            p[1].insert({x - y, tot});
            p[2].insert({-x + y, tot});
            p[3].insert({-x - y, tot});
            tot++;
        }
        int mx = 0;
        for (int i = 0; i < 4; i++) {
            mx = max(mx, p[i].rbegin()->first - p[i].begin()->first);
        }
        int ans = mx;
        for (int i = 0; i < 4; i++) {
            int id = p[i].begin()->second;
            int x = points[id][0], y = points[id][1];
            if (p[0].count({x + y, id})) p[0].extract({x + y, id});
            if (p[1].count({-x - y, id})) p[1].extract({x - y, id});
            if (p[2].count({-x + y, id})) p[2].extract({-x + y, id});
            if (p[3].count({-x - y, id})) p[3].extract({-x - y, id});
            int cur = 0;
            for (int i = 0; i < 4; i++) {
                cur = max(cur, p[i].rbegin()->first - p[i].begin()->first);
            }
            p[0].insert({points[id][0] + points[id][1], id});
            p[1].insert({points[id][0] - points[id][1], id});
            p[2].insert({-points[id][0] + points[id][1], id});
            p[3].insert({-points[id][0] - points[id][1], id});
            ans = min(ans, cur);
        }
        for (int i = 0; i < 4; i++) {
            int id = p[i].rbegin()->second;
            p[0].erase({points[id][0] + points[id][1], id});
            p[1].erase({points[id][0] - points[id][1], id});
            p[2].erase({-points[id][0] + points[id][1], id});
            p[3].erase({-points[id][0] - points[id][1], id});
            int cur = 0;
            for (int i = 0; i < 4; i++) {
                cur = max(cur, p[i].rbegin()->first - p[i].begin()->first);
            }
            p[0].insert({points[id][0] + points[id][1], id});
            p[1].insert({points[id][0] - points[id][1], id});
            p[2].insert({-points[id][0] + points[id][1], id});
            p[3].insert({-points[id][0] - points[id][1], id});
            ans = min(cur, ans);
        }
        return ans;
    }
};