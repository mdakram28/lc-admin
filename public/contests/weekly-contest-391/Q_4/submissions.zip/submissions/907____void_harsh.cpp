class Solution {
public:
    int minimumDistance(vector<vector<int>>& A) {
        
        int N = A.size();
    multiset<int> m1, m2;

    for (int i = 0; i < N; i++) {
        int x1 = A[i][0] + A[i][1];
        int x2 = A[i][0] - A[i][1];
        m1.insert(x1);
        m2.insert(x2);
    }

    int mini = INT_MAX;

    for (int i = 0; i < N; i++) {
        int x1 = A[i][0] + A[i][1];
        int x2 = A[i][0] - A[i][1];

        auto it = m1.find(x1);
        m1.erase(it);

        it = m2.find(x2);
        m2.erase(it);

        auto it1 = m1.end();
        auto it2 = m2.end();
        it1--;
        it2--;
int val=max(*it1 - *m1.begin(),*it2 - *m2.begin());
        
        mini = min(mini, val);
       
        m1.insert(x1);
        m2.insert(x2);
    }

    return mini;
    }
};