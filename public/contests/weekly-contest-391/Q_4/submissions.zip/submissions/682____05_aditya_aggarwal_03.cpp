class Solution {
public:
    vector<int> MaxDist(vector<vector<int>>& A, int N)
{
    vector<pair<int, int>> V(N), V1(N);

    for (int i = 0; i < N; i++) {
        V[i] = {A[i][0] + A[i][1], i};
        V1[i] = {A[i][0] - A[i][1], i};
    }

    sort(V.begin(), V.end());
    sort(V1.begin(), V1.end());

    int maxDiff = V.back().first - V.front().first;
    int maxDiff1 = V1.back().first - V1.front().first;

    int maximum;
    int ind1;
        int ind2;
    if (maxDiff > maxDiff1){
        maximum = maxDiff;
        ind1 = V.back().second;
        ind2 = V.front().second;
    }
    else{
        ind1 = V1.back().second;
        ind2 = V1.front().second;
        maximum = maxDiff1;
    }
    return {maximum,ind1,ind2};
}

    int minimumDistance(vector<vector<int>>& points) {
        vector<int> p = MaxDist(points,points.size());
        vector<vector<int>> v1;
        vector<vector<int>> v2;
        
        for(int i = 0;i < points.size();i++){
            if(i != p[1]) v1.push_back(points[i]);
            if(i != p[2]) v2.push_back(points[i]);
        }
        
        vector<int> s1 = MaxDist(v1,v1.size());
        vector<int> s2 = MaxDist(v2,v2.size());
        
        int ans = min(s1[0],s2[0]);
        
        return ans;
        
    }
};