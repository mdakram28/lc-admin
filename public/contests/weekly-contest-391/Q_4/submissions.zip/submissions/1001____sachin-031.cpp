class Solution {
public:
    vector<int> MaxDist(vector< vector<int>>& A, int N)
{
    vector<pair<int,int>> V(N), V1(N);
 
    for (int i = 0; i < N; i++) {
        V[i] = {A[i][0] + A[i][1],i};
        V1[i] = {A[i][0] - A[i][1],i};
    }

    sort(V.begin(), V.end());
    sort(V1.begin(), V1.end());
    vector<int>ans(3);
    if(V.back().first - V.front().first>=V1.back().first - V1.front().first){
        ans[0]=V.back().first - V.front().first;
        ans[1]=V.back().second;
        ans[2]=V.front().second;
    }
    else{
        ans[0]=V1.back().first - V1.front().first;
        ans[1]=V1.back().second;
        ans[2]=V1.front().second;
    }
    return ans;
}
    int minimumDistance(vector<vector<int>>& points) {
        vector<int>k=MaxDist(points,points.size());
        vector<vector<int>>v1,v2;
        for(int i=0;i<points.size();i++){
            if(i!=k[1])v1.push_back(points[i]);
            if(i!=k[2])v2.push_back(points[i]);
        }
        vector<int>i=MaxDist(v1,v1.size());
        vector<int>j=MaxDist(v2,v2.size());
        return min(i[0],j[0]);
        
    }
};