const double eps = 1e-6;
#define ll long long
typedef long double ld;
#define pb push_back // for vector
#define pi pair 
// #define mp make_pair
#define all(a) a.begin(), a.end()
#define rep(i, a, b) for (ll i = a; i < b; i++)
#define ff first
#define ss second
#define vt vector
#define vi vt<ll>
#define ub upper_bound
#define lb lower_bound
#define repr(i, n, a) for (ll i = n; i >= a; i--)
#define dq deque
#define inset(a, st) st.find(a) != st.end()
#define issub(a, b) b.find(a) != string::npos // check if a is substr of b
#define len(a) (ll)a.size()
const ld PI = 2 * acos(0.0);
const ll mod = 1e9+7;
const ll mod2 = 998244353;
const ll nax = 2e5 + 5;
class Solution {
public:
    int n1 =  0 , n2 = 0, n3 = 0 , n4 = 0;
    bool t = false;
    bool f = false;
    int MaxDist(vector<pair<int, int> >& A, int N)
    {
    
    int minsum, maxsum, mindiff, maxdiff;
    
    minsum = maxsum = A[0].first + A[0].second;
    mindiff = maxdiff = A[0].first - A[0].second;
    for (int i = 1; i < N; i++) {
        int sum = A[i].first + A[i].second;
        int diff = A[i].first - A[i].second;
        if (sum < minsum){
            minsum = sum; if(!t){n1 = i;}}
        else if (sum > maxsum){
            maxsum = sum; if(!t){n2 = i;}}
        if (diff < mindiff){
            mindiff = diff;if(!t) {n3 = i;}}
        else if (diff > maxdiff){
            maxdiff = diff; if(!t){n4 = i;}}
    }
 
    if(maxsum - minsum <  maxdiff - mindiff){
        f = 1;
    }
    ll sol = max(maxsum - minsum ,  maxdiff - mindiff);
        return sol;
}
    
    int minimumDistance(vector<vector<int>>& points) {
        f = false;
        vt<pi<int,int>>ps;
        int sol = INT_MAX;
        rep(i  , 0 , points.size()){
            pi<int,int>p = {points[i][0] , points[i][1]};
            ps.push_back(p);
        }
        MaxDist(ps , ps.size());
       t = 1;
            vt<pi<int,int>>temp;
            rep(i , 0 , ps.size()){
                if(i == n1){
                    continue;
                }
                temp.push_back(ps[i]);
            }
            sol = min(sol, MaxDist(temp, temp.size()));
            
            vt<pi<int,int>>temp2;
            rep(i , 0 , ps.size()){
                if(i == n2){
                    continue;
                }
                temp2.push_back(ps[i]);
            }
            sol = min(sol, MaxDist(temp2, temp2.size()));
      
              vt<pi<int,int>>temp3;
            rep(i , 0 , ps.size()){
                if(i == n3){
                    continue;
                }
                temp3.push_back(ps[i]);
            }
            sol = min(sol, MaxDist(temp3, temp3.size()));
            
            vt<pi<int,int>>temp4;
            rep(i , 0 , ps.size()){
                if(i == n4){
                    continue;
                }
                temp4.push_back(ps[i]);
            }
      
            sol = min(sol, MaxDist(temp4, temp4.size()));
        
        return sol;
    }
};