import bisect
import math
import heapq
import array
from functools import cache
import itertools
import re
import os
from collections import deque, Counter, defaultdict
import sys

inf = float("inf")
sys.setrecursionlimit(100000)
List = list
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def check(val):
            pass
        #     max_plus, min_plus, max_sub, min_sub = 0, inf, 0, inf
        #     second_max_plus, second_min_plus, second_max_sub, second_min_sub = 0, inf, 0, inf
        #     deleted = False
        #     for x, y in points:
        #         if x + y > max_plus:
        #             max_plus, second_max_plus = x + y, max_plus
        #         elif x + y > second_max_plus:
        #             second_max_plus = x + y
        #         if x + y < min_plus:
        #             min_plus, second_min_plus = x + y, min_plus
        #         elif x + y < second_min_plus:
        #             second_min_plus = x + y
        #         if x - y > max_sub:
        #             max_sub, second_max_sub = x + y, max_sub
        #         elif x - y > second_max_sub:
        #             second_max_sub = x + y
        #         if x - y < min_sub:
        #             min_sub, second_min_sub = x - y, min_sub
        #         elif x - y < second_min_sub:
        #             second_min_sub = x - y
        #         if max(new_max_plus - new_min_plus, new_max_sub - new_min_sub) > val:
        #             if deleted:
        #                 return False
        #             else:
        #                 deleted = True
        #         else:
        #             max_plus = new_max_plus
        #             min_plus = new_min_plus
        #             max_sub = new_max_sub
        #             min_sub = new_min_sub
        #     return True
        # left, right = 0, 2 * 10**8
        # while left < right:
        #     mid = (left + right) // 2
        #     if check(mid):right = mid
        #     else:left = mid + 1
        # return mid
        n = len(points)
        plus = sorted([[points[i][0] + points[i][1], i] for i in range(n)])
        sub = sorted([[points[i][0] - points[i][1], i] for i in range(n)])
        res = inf
        smax = n - 1 if sub[-1][1] != plus[-1][1] else n - 2
        smin = 0 if sub[0][1] != plus[-1][1] else 1
        res = min(max(plus[-2][0] - plus[0][0], sub[smax][0] - sub[smin][0]), res)
        
        smax = n - 1 if sub[-1][1] != plus[0][1] else n - 2
        smin = 0 if sub[0][1] != plus[0][1] else 1
        res = min(max(plus[-1][0] - plus[1][0], sub[smax][0] - sub[smin][0]), res)
        
        pmax = n - 1 if sub[-1][1] != plus[-1][1] else n - 2
        pmin = 0 if sub[-1][1] != plus[0][1] else 1
        res = min(max(plus[pmax][0] - plus[pmin][0], sub[-2][0] - sub[0][0]), res)
        
        pmax = n - 1 if plus[-1][1] != sub[0][1] else n - 2
        pmin = 0 if plus[0][1] != sub[0][1] else 1
        res = min(max(plus[pmax][0] - plus[pmin][0], sub[-1][0] - sub[1][0]), res)
        return res
s = Solution()
print(s.minimumDistance([[3,2],[3,9],[7,10],[4,4],[8,10],[2,7]]))