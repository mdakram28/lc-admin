class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<pair<int,int>> val(n);
        vector<int> sum,diff;
        for(int i = 0;i<n;i++){
            val[i] = {points[i][0] + points[i][1],points[i][0] - points[i][1]};
            sum.push_back(val[i].first);
            diff.push_back(val[i].second);
        }
        
        sort(sum.begin(),sum.end());
        sort(diff.begin(),diff.end());
        
        vector<int> ff;
        for(int i =0;i<n;i++){
            int a = 0,b = n-1,ans;
            int aval = val[i].first;
            
            if(aval == sum[a]){
                a++;
            }
            else if(aval == sum[b]){
                b--;
            }
            
            ans = sum[b] - sum[a];
            
            a = 0,b = n-1;
            aval = val[i].second;
            
            if(aval == diff[a]){
                a++;
            }
            else if(aval == diff[b]){
                b--;
            }
            
            ans = max(ans,diff[b] - diff[a]);
            ff.push_back(ans);
        }
        
        sort(ff.begin(),ff.end());
        return ff[0];
                                 
    }
};