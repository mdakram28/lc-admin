typedef long long ll ; 
class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        multiset<ll> ms1,ms2 ; 
       
        
        for(auto & i : p)
            ms1.insert(i[0] + i[1]) , ms2.insert(i[0]-i[1]);
        ll ans = 1e9 ; 
        for(auto & i : p)
        {
            ll sum = i[0] + i[1];
            ms1.erase(ms1.find(sum));
            ll diff = i[0] - i[1];
            ms2.erase(ms2.find(diff));
            ll tans = max(*ms1.rbegin()-*ms1.begin() , *ms2.rbegin()-*ms2.begin());
            ms1.insert(sum);
            ms2.insert(diff);
            ans = min(ans,tans);
            
        }
        return ans ; 
    }
};