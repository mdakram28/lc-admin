class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        multiset<int> v1, v2;
        int ss, sd;
        for(int i = 0; i < n; i++){
            ss = points[i][0] + points[i][1];
            sd = points[i][0] - points[i][1];
            v1.insert(ss);
            v2.insert(sd);
        }
        int ans = max(*(--v1.end()) - *(v1.begin()), *(--v2.end()) - *(v2.begin()));
        for(int i = 0; i < n; i++){
            ss = points[i][0] + points[i][1];
            sd = points[i][0] - points[i][1];
            v1.erase(v1.find(ss));
            v2.erase(v2.find(sd));
            ans = min(ans, max(*(--v1.end()) - *(v1.begin()), *(--v2.end()) - *(v2.begin())));
            v1.insert(ss);
            v2.insert(sd);
        }
        
        return ans;
    }
};