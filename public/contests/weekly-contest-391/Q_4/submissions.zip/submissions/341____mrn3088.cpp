class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<pair<int, int>> A, B, C, D;
        int n = points.size();
        for (int i = 0; i < points.size(); i++) {
            A.emplace_back(points[i][0] - points[i][1], i);
            B.emplace_back(points[i][0] + points[i][1], i);
            C.emplace_back(- points[i][0] + points[i][1], i);
            D.emplace_back(- points[i][0] - points[i][1], i);
        }
        sort(A.begin(), A.end());
        sort(B.begin(), B.end());
        sort(C.begin(), C.end());
        sort(D.begin(), D.end());
        unordered_map<int, vector<int>> mp;
        for (int i = 0; i < A.size(); i++) {
            mp[A[i].second].push_back(i);
        }
        for (int i = 0; i < B.size(); i++) {
            mp[B[i].second].push_back(i);
        }
        for (int i = 0; i < C.size(); i++) {
            mp[C[i].second].push_back(i);
        }
        for (int i = 0; i < D.size(); i++) {
            mp[D[i].second].push_back(i);
        }
        int res = INT_MAX;
        for (int i = 0; i < points.size(); i++) {
            // remove i
            auto removed_index = mp[i];
            int A_max = removed_index[0] == n - 1 ? A[n - 2].first : A[n - 1].first;
            int B_max = removed_index[1] == n - 1 ? B[n - 2].first : B[n - 1].first;
            int C_max = removed_index[2] == n - 1 ? C[n - 2].first : C[n - 1].first;
            int D_max = removed_index[3] == n - 1 ? D[n - 2].first : D[n - 1].first;
            int A_min = removed_index[0] == 0 ? A[1].first : A[0].first;
            int B_min = removed_index[1] == 0 ? B[1].first : B[0].first;
            int C_min = removed_index[2] == 0 ? C[1].first : C[0].first;
            int D_min = removed_index[3] == 0 ? D[1].first : D[0].first;
            int tmp_res = max(A_max - A_min, B_max - B_min);
            tmp_res = max(tmp_res, C_max - C_min);
            tmp_res = max(tmp_res, D_max - D_min);
            res = min(res, tmp_res);
        }
        return res;
    }
};