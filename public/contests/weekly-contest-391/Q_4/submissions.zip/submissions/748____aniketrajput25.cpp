class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
         int result=INT_MAX;
        map<int,int>mm,pp;
        for(auto x:points)
        {
            mm[x[0]+x[1]]++;
            pp[x[0]-x[1]]++;
        }
        for(auto x:points)
        {
            int xx=x[0]+x[1];
            int yy=x[0]-x[1];
            mm[xx]--;
            pp[yy]--;
            if(mm[xx]==0)
              mm.erase(xx);
            
            if(pp[yy]==0)
                pp.erase(yy);
            
            auto a=mm.rbegin();
            auto b=mm.begin();
            auto c=pp.rbegin();
            auto d=pp.begin();
              
            int mx1=a->first,mn1=b->first, mx2=c->first, mn2=d->first;
            
            int temp=max(mx1-mn1,mx2-mn2);
            result=min(temp,result);
            mm[xx]++;
            pp[yy]++;
        }
        return result;
    }
};