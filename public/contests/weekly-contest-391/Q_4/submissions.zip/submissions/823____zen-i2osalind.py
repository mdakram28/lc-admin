from cmath import inf
from typing import List

from sortedcontainers import SortedList


class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        t1, t2 = SortedList(), SortedList()
        for x,y in points:
            t1.add(x+y)
            t2.add(x-y)

        ans = inf
        for x, y in points:
            t1.remove(x+y)
            t2.remove(x-y)
            ans = min(ans, max(t1[-1]-t1[0], t2[-1]-t2[0]))
            t1.add(x+y)
            t2.add(x-y)

        return ans

