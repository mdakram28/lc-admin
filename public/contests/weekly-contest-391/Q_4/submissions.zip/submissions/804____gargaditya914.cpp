class Solution {
public:
    int minimumDistance(vector<vector<int>>& v) {
        vector<pair<int,int>>sum,diff;
        int n=v.size();
        for(int i=0;i<n;i++)
        {
            sum.push_back({v[i][0]+v[i][1],i});
            diff.push_back({v[i][0]-v[i][1],i});
        }
        sort(sum.begin(),sum.end());
        sort(diff.begin(),diff.end());
        int ans=INT_MAX;
        int temp;
        temp=sum[n-2].first-sum[0].first;
        if(sum[n-1].second==diff[n-1].second)
            temp=max(temp,diff[n-2].first-diff[0].first);
        else if(sum[n-1].second==diff[0].second)
            temp=max(temp,diff[n-1].first-diff[1].first);
        else 
            temp=max(temp,diff[n-1].first-diff[0].first);
        ans=min(ans,temp);
        temp=sum[n-1].first-sum[1].first;
        if(sum[0].second==diff[0].second)
            temp=max(temp,diff[n-1].first-diff[1].first);
        else if(sum[0].second==diff[n-1].second)
            temp=max(temp,diff[n-2].first-diff[0].first);
        else 
            temp=max(temp,diff[n-1].first-diff[0].first);
        ans=min(ans,temp);
        temp=diff[n-2].first-diff[0].first;
        if(diff[n-1].second==sum[n-1].second)
            temp=max(temp,sum[n-2].first-sum[0].first);
        else if(diff[n-1].second==sum[0].second)
            temp=max(temp,sum[n-1].first-sum[1].first);
        else
            temp=max(temp,sum[n-1].first-sum[0].first);
        ans=min(ans,temp);
        temp=diff[n-1].first-diff[1].first;
        if(diff[0].second==sum[0].second)
            temp=max(temp,sum[n-1].first-sum[1].first);
        else if(diff[0].second==sum[n-1].second)
            temp=max(temp,sum[n-2].first-sum[0].first);
        else
            temp=max(temp,sum[n-1].first-sum[0].first);
        ans=min(ans,temp);
        return ans;
        // return min(max(abs(sum[n-2]-sum[0]),abs(diff[n-2]-diff[0])),max(abs(sum[n-1]-sum[1]),abs(diff[n-1]-diff[1])));
    }
};