class Solution {
public:
    int minimumDistance(vector<vector<int>>& A) {
        int N = A.size();
        int n = N;
        map<int, int> V, V1;
 
        for (int i = 0; i < N; i++) {
            V[A[i][0] + A[i][1]]++;
            V1[A[i][0] - A[i][1]]++;
        }

        int minmax = INT_MAX;
        
        //if (V1.size() <= 2) return 0;
       // cout << *V.begin() << " " << *prev(V.end()) << endl;
        for (int i = 0; i < N; i++) {
            int tmp1 = A[i][0] + A[i][1];
            int tmp2 = A[i][0] - A[i][1];
            
            V[tmp1]--;
            V1[tmp2]--;
            
            if (V[tmp1] == 0) V.erase(tmp1);
            if (V1[tmp2] == 0) V1.erase(tmp2);
            
            int maximum = max(prev(V.end())->first-V.begin()->first,prev(V1.end())->first-V1.begin()->first);
            //cout << maximum << endl;
            minmax = min(minmax, maximum);
            
            V[tmp1]++;
            V1[tmp2]++;
        }
        
        return minmax;
    }
};