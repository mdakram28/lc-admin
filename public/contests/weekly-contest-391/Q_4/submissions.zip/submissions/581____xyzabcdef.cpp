class Solution {
public:
    int minimumDistance(vector<vector<int>>& pts) {
        multiset<int>sum, diff;
        for(auto i: pts){
            int x = i[0], y = i[1];
            sum.insert(x+y);
            diff.insert(x-y);
        }
        int ans = 1'000'000'008;
        for(auto i: pts){
            int x = i[0], y = i[1];
            sum.erase(sum.lower_bound(x+y));
            diff.erase(diff.lower_bound(x-y));
            int mx1 = *sum.rbegin() - *sum.begin();
            int mx2 = *diff.rbegin() - *diff.begin();
            ans = min(ans, max(mx1, mx2));
            sum.insert(x+y);
            diff.insert(x-y);
        }
        return ans;
    }
};