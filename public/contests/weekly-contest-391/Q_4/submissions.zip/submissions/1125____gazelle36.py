class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        dist = []
        n = len(points)
        for p in points:
            dist.append([p[0]+p[1], p[0]+10**8-p[1], 10**8-p[0]+p[1], 2*10**8-p[0]-p[1]])
        # print(len(dist), len(dist[0]))
        max4 = [-1, -1, -1, -1]
        max4_idx = [set(), set(), set(), set()]
        min4 = [2*10**8, 2*10**8, 2*10**8, 2*10**8]
        min4_idx = [set(), set(), set(), set()]
        for k in range(4):
            for i in range(n):
                if dist[i][k] > max4[k]:
                    max4[k] = dist[i][k]
                    max4_idx[k] = set([i])
                elif dist[i][k] == max4[k]:
                    max4_idx[k].add(i)
                if dist[i][k] < min4[k]:
                    min4[k] = dist[i][k]
                    min4_idx[k] = set([i])
                elif dist[i][k] == min4[k]:
                    min4_idx[k].add(i)
        diff4 = [max4[k]-min4[k] for k in range(4)]
        def check(delete: int):
            max4 = [-1, -1, -1, -1]
            max4_idx = [set(), set(), set(), set()]
            min4 = [2*10**8, 2*10**8, 2*10**8, 2*10**8]
            min4_idx = [set(), set(), set(), set()]
            for k in range(4):
                for i in range(n):
                    if dist[i][k] > max4[k] and i != delete:
                        max4[k] = dist[i][k]
                        max4_idx[k] = set([i])
                    elif dist[i][k] == max4[k] and i != delete:
                        max4_idx[k].add(i)
                    if dist[i][k] < min4[k] and i != delete:
                        min4[k] = dist[i][k]
                        min4_idx[k] = set([i])
                    elif dist[i][k] == min4[k] and i != delete:
                        min4_idx[k].add(i)
            diff4 = [max4[k]-min4[k] for k in range(4)]
            # print("check: ", delete, diff4, max4, min4)
            return max(diff4)
        # print(max4_idx)
        # print(min4_idx)
        s = set()
        for st in max4_idx:
            s.update(st)
        for st in min4_idx:
            s.update(st)
        # print(s)
        ans = 2*10**8
        for t in s:
            ans = min(ans, check(t))
        return ans
        
        
        