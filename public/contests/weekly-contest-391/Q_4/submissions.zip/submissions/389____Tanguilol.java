class Solution {
    
    private static class Point {
        
        int x;
        int y;
        
        public Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
        
        public String toString() {
            return "[" + x + ", " + y + "]";
        }
        
        public boolean equals(Object obj) {
            Point other = (Point) obj;
            return x == other.x && y == other.y;
        }
    }
    
    private static class WeightedPoint implements Comparable<WeightedPoint> {
        
        int w;
        Point p;
        
        public WeightedPoint(int w, Point p) {
            this.w = w;
            this.p = p;
        }
        
        public int compareTo(WeightedPoint wp) {
            return Integer.compare(w, wp.w);
        }
        
        public String toString() {
            return "[" + w + ", " + p + "]";
        }
        
    }
    
    public int minimumDistance(int[][] points) {
        List<WeightedPoint> d1 = new ArrayList<>();
        List<WeightedPoint> d2 = new ArrayList<>();
        
        for (int i = 0; i < points.length; i++) {
            int x = points[i][0];
            int y = points[i][1];
            
            Point p = new Point(x, y);
            
            d1.add(new WeightedPoint(x + y, p));
            d2.add(new WeightedPoint(x - y, p));
        }
        
        Collections.sort(d1);
        Collections.sort(d2);
        
        //System.out.println(d1);
        //System.out.println(d2);
        
        return Math.min(
            Math.min(calc(d1, d2, d1.get(0).p), calc(d1, d2, d1.get(d1.size() - 1).p)),
            Math.min(calc(d1, d2, d2.get(0).p), calc(d1, d2, d2.get(d2.size() - 1).p))
        );
    }
    
    private int calc(List<WeightedPoint> d1, List<WeightedPoint> d2, Point remove) {
        return Math.max(calc(d1, remove), calc(d2, remove));
    }
    
    private int calc(List<WeightedPoint> wp, Point remove) {
        if (wp.get(0).p.equals(remove)) {
            return wp.get(wp.size() - 1).w - wp.get(1).w;
        } else if (wp.get(wp.size() - 1).p.equals(remove)) {
            return wp.get(wp.size() - 2).w - wp.get(0).w;
        } else {
            return wp.get(wp.size() - 1).w - wp.get(0).w;
        }
    }
    
}