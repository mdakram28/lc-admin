class Solution {
public:
    
    // int maxXplusY = INT_MIN;
    // int minXplusY = INT_MAX;
    // int maxXminusY = INT_MIN;
    // int minXminusY = INT_MAX;

//     for (const auto& [x, y] : points) {
//         maxXplusY = std::max(maxXplusY, x + y);
//         minXplusY = std::min(minXplusY, x + y);
//         maxXminusY = std::max(maxXminusY, x - y);
//         minXminusY = std::min(minXminusY, x - y);
//     }

//     return std::max(maxXplusY - minXplusY, maxXminusY - minXminusY);
    int minimumDistance(vector<vector<int>>& points) {
        long long ans = INT_MAX;
        multiset<long long>xpy;
         multiset<long long , greater<long long>>rxpy;
         multiset<long long>xmy;
         multiset<long long,greater<long long>>rxmy;
        for(int i =0; i < points.size();i++){
            int val = points[i][0] + points[i][1];
            int val2 = points[i][0] - points[i][1];
            xpy.insert(val);
            rxpy.insert(val);
            xmy.insert(val2);
            rxmy.insert(val2);
        }
        for(int i =0; i < points.size();i++){
            int val = points[i][0] + points[i][1];
            int val2 = points[i][0] - points[i][1];
            auto itr = xpy.find(val);
            xpy.erase(itr);
                        auto itr1 = rxpy.find(val);
            rxpy.erase(itr1);
                        auto itr2 = xmy.find(val2);
            xmy.erase(itr2);
                        auto itr3 = rxmy.find(val2);
            rxmy.erase(itr3);
            itr = xpy.begin();
            itr1 = rxpy.begin();
            itr2 = xmy.begin();
            itr3 = rxmy.begin();
            ans = min(ans, max(*itr1 - *itr,*itr3- *itr2));
            xpy.insert(val);
            rxpy.insert(val);
            xmy.insert(val2);
            rxmy.insert(val2);
            
        }
        return ans;
    }
};