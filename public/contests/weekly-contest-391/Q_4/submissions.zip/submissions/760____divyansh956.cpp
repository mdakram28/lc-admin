class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> sum, diff;
        for (auto x : points) {
            sum.insert(x[0] + x[1]);
            diff.insert(x[0] - x[1]);
        }

        int ans = 1e9;
        for (auto x : points) {
            sum.erase(sum.find(x[0] + x[1]));
            diff.erase(diff.find(x[0] - x[1]));
            int mx = max(*sum.rbegin() - *sum.begin(),
                         *diff.rbegin() - *diff.begin());
            ans = min(ans, mx);
            sum.insert(x[0] + x[1]);
            diff.insert(x[0] - x[1]);
        }
        return ans;
    }
};