struct Node {
    int val;
    int idx;
};

bool cmp(const Node &node1, const Node &node2) {
    if (node1.val != node2.val) return node1.val < node2.val;
    return node1.idx < node2.idx;
}

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<Node> S, D;
        int cnt = 0;
        for (vector<int> v: points) {
            Node node;
            node.val = v[0] + v[1];
            node.idx = cnt;
            S.push_back(node);
            node.val = v[0] - v[1];
            D.push_back(node);
            cnt++;
        }
        sort(S.begin(), S.end(), cmp);
        sort(D.begin(), D.end(), cmp);
        int res = 1e9;
        set<int> st;
        for (int i = 0; i < 2; i++) {
            st.insert(S[i].idx);
            st.insert(S[S.size() - i - 1].idx);
            st.insert(D[i].idx);
            st.insert(D[D.size() - i - 1].idx);
        }
        
        for (int x: st) {
            int start, end;
            start = 0;
            end = S.size() - 1;
            if (S[start].idx == x) start++;
            if (S[end].idx == x) end--;
            int can = S[end].val - S[start].val;
            
            start = 0;
            end = D.size() - 1;
            if (D[start].idx == x) start++;
            if (D[end].idx == x) end--;
            int can2 = D[end].val - D[start].val;
            
            can = max(can, can2);
            res = min(res, can);
        }
        return res;
        
    }
};