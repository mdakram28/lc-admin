class Solution {
    public int minimumDistance(int[][] points) {
        int min = Integer.MAX_VALUE / 2;
        int n = points.length;
        int[][] arr = new int[n][4];
        int[] max = new int[4];
        Arrays.fill(max, Integer.MIN_VALUE / 2);
        for (int i = 0; i < n; i++) {
            int[] point = points[i];
            arr[i][0] = point[0] + point[1];
            arr[i][1] = point[0] - point[1];
            arr[i][2] = -point[0] - point[1];
            arr[i][3] = -point[0] + point[1];
            for (int j = 0; j < 4; j++) {
                max[j] = Math.max(max[j], arr[i][j]);
            }
        }
        int[] cnt = new int[4];
        int[] index = new int[4];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < 4; j++) {
                if (arr[i][j] == max[j]) {
                    cnt[j]++;
                    index[j] = i;
                }
            }
        }
        min = getMax(points, -1);
        for (int i = 0; i < 4; i++) {
            if (cnt[i] == 1) {
                min = Math.min(min, getMax(points, index[i]));
            }
        }
        return min;
    }

    private int getMax(int[][] points, int v) {
        int[] p;
        if (v == 0) {
            p = points[1];
        } else {
            p = points[0];
        }
        int a = p[0] + p[1];
        int b = p[0] - p[1];
        int c = -p[0] - p[1];
        int d = -p[0] + p[1];
        for (int i = 0; i < points.length; i++) {
            if (i == v) {
                continue;
            }
            int[] point = points[i];
            a = Math.max(a, point[0] + point[1]);
            b = Math.max(b, point[0] - point[1]);
            c = Math.max(c, -point[0] - point[1]);
            d = Math.max(d, -point[0] + point[1]);
        }
        return Math.max(a + c, b + d);
    }
}