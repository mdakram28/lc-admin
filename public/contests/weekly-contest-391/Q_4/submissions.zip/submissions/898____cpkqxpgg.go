func minimumDistance(points [][]int) int {
    n:=len(points)
    min1:=0
    max1:=0
    maxval1:=points[0][0]+points[0][1]
    minval1:=points[0][0]+points[0][1]
    min2:=0
    max2:=0
    maxval2:=points[0][0]-points[0][1]
    minval2:=points[0][0]-points[0][1]
    for i:=1;i<n;i++{
        val1:=points[i][0]+points[i][1]
        if val1>maxval1{
            maxval1=val1
            max1=i
        }
        if val1<minval1{
            minval1=val1
            min1=i
        }
        val2:=points[i][0]-points[i][1]
        if val2>maxval2{
            maxval2=val2
            max2=i
        }
        if val2<minval2{
            minval2=val2
            min2=i
        }
    }
    res:=calc(points,min1)
    res=min(res,calc(points,max1))
    res=min(res,calc(points,min2))
    res=min(res,calc(points,max2))
    return res
}

func max(a,b int)int{
    if a<b{
        return b
    }
    return a
}
func min(a,b int)int{
    if a<b{
        return a
    }
    return b
}

func calc(points [][]int,index int)int{
    n:=len(points)
    maxval1:=points[0][0]+points[0][1]
    minval1:=points[0][0]+points[0][1]
    maxval2:=points[0][0]-points[0][1]
    minval2:=points[0][0]-points[0][1]
    if index==0{
        maxval1=points[1][0]+points[1][1]
        minval1=points[1][0]+points[1][1]
        maxval2=points[1][0]-points[1][1]
        minval2=points[1][0]-points[1][1]
    }
    for i:=1;i<n;i++{
        if i==index{
            continue
        }
        val1:=points[i][0]+points[i][1]
        if val1>maxval1{
            maxval1=val1
        }
        if val1<minval1{
            minval1=val1
        }
        val2:=points[i][0]-points[i][1]
        if val2>maxval2{
            maxval2=val2
        }
        if val2<minval2{
            minval2=val2
        }
    }
    return max(maxval1-minval1,maxval2-minval2)
}