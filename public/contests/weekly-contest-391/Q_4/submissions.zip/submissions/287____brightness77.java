class Solution {
    public int minimumDistance(int[][] points) {
        int n = points.length;
        
        List<int[]> sumList = new ArrayList<>();
        List<int[]> diffList = new ArrayList<>();
        
        for(int i = 0; i < n; ++i){
            sumList.add(new int[]{points[i][0] + points[i][1], i});
            diffList.add(new int[]{points[i][0] - points[i][1], i});
        }
        
        Collections.sort(sumList, (a, b) -> Integer.compare(a[0], b[0]));
        Collections.sort(diffList, (a, b) -> Integer.compare(a[0], b[0]));
        
        int result = Integer.MAX_VALUE;
        
        for(int i = 0; i < n; ++i){
            int[] curMaxSum = sumList.get(n - 1)[1] == i ? sumList.get(n - 2) : sumList.get(n - 1);
            int[] curMinSum = sumList.get(0)[1] == i ? sumList.get(1) : sumList.get(0);
            
            int[] curMaxDiff = diffList.get(n - 1)[1] == i ? diffList.get(n - 2) : diffList.get(n - 1);
            int[] curMinDiff = diffList.get(0)[1] == i ? diffList.get(1) : diffList.get(0);
            
            int curRes = Math.max(curMaxSum[0] - curMinSum[0], curMaxDiff[0] - curMinDiff[0]);
            // System.out.println(i + ":" + curMaxSum[0] + "/" + curMinSum[0] + ", " + curMaxDiff[0] + "/" + curMinDiff[0]);
            
            result = Math.min(result, curRes);
        }
        
        return result;
        
    }
    
}