class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        from sortedcontainers import SortedList
        
        plus = SortedList()
        minus = SortedList()
        
        for x,y in points:
            plus.add(x+y)
            minus.add(x-y)
        
        res = math.inf
        
        for x,y in points:
            plus.remove(x+y)
            minus.remove(x-y)
            res = min(res, max(plus[-1]-plus[0], minus[-1]-minus[0]))
            plus.add(x+y)
            minus.add(x-y)
        return res
        