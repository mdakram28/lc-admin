class Solution {
public:
    pair<int,pair<int,int>> worstDistance (vector<vector<int>> points) {
        vector<pair<int,int>> v1, v2;
        for (int i = 0; i < points.size(); i++) {
            v1.emplace_back(points[i][0] + points[i][1], i);
            v2.emplace_back(points[i][0] - points[i][1], i);
        }
        sort(v1.begin(), v1.end());
        sort(v2.begin(), v2.end());
        auto p1 = make_pair(v1.back().first - v1[0].first, make_pair(v1.back().second, v1[0].second));
        auto p2 = make_pair(v2.back().first - v2[0].first, make_pair(v2.back().second, v2[0].second));
        return max(p1, p2);
    }
    int minimumDistance(vector<vector<int>>& points) {
        pair<int,pair<int,int>> p = worstDistance(points);
        vector<int> rem = {p.second.first, p.second.second};
        int ans = INT_MAX;
        for (int x: rem) {
            vector<vector<int>> v;
            for (int i = 0; i < points.size(); i++) {
                if (i == x) continue;
                v.push_back(points[i]);
            }
            ans = min(ans, worstDistance(v).first);
        }
        return ans;
    }
};