class SegmentTree:
    # efficient iterative version, implemented by LeonDong1993 (LeonDong1993@gmail.com)
    # adapted from https://codeforces.com/blog/entry/18051
    # support single update and query such as range max, min, sum, gcd, max with count, etc.
    def __init__(self, n, merge, default = 0):
        self.n = n
        self.tree = [default] * (n<<1)
        self.merge = merge
        self.default = default

    def query(self, l, r, default = None):
        # on a close interval [l,r], 0-indexed
        l += self.n
        r += self.n
        ans = default if default is not None else self.default

        while l <= r:
            if l & 1:
                ans = self.merge(ans, self.tree[l])
                l += 1
            if not r & 1:
                ans = self.merge(ans, self.tree[r])
                r -= 1
            l >>= 1
            r >>= 1
        return ans

    def update(self, i, v):
        # update arr[i] to v, 0-indexed
        i += self.n
        self.tree[i] = v # or self.merge(self.tree[i], v)
        while i > 1:
            i >>= 1
            self.tree[i] = self.merge(self.tree[i<<1], self.tree[i<<1 | 1])

    def build(self, arr):
        assert(len(arr) == self.n), 'Size Mismatch!'

        for i in range(self.n):
            self.tree[i + self.n] = arr[i]

        for i in range(n-1,0,-1):
            self.tree[i] = self.merge(self.tree[i<<1], self.tree[i<<1 | 1])
        return self

push = heapq.heappush

pop = heapq.heappop

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        
        def get_max_dist_pair():
            low = []
            high = []
            pts = sorted(points)
            # if y2 > y1 then save x1 + y1, want x2+y2 - minimum
            # if y2 < y1 then save x1- y1, want x2-y2 - minimum
            
            dist = -1
            ans = None
            for i,(x,y) in enumerate(pts):
                if len(low):
                    v, j = low[0]
                    cur = x+y - v
                    if cur > dist:
                        dist = cur
                        ans = (i,j)
                
                if len(high):
                    v,j = high[0]
                    cur = x-y-v
                    if cur > dist:
                        dist = cur
                        ans = (i,j)
                        
                push(low, (x+y ,i))
                push(high, (x-y, i))
                        
            
            return ans, dist
        
        # get dist info
        points.sort()
        (i,j), _ = get_max_dist_pair()
        pi, pj = points[i], points[j]
        
        # try first way
        points[i] = pj
        _, ans1 = get_max_dist_pair()
        
        # try another way
        points[i] = pi
        points[j] = pi
        _, ans2 = get_max_dist_pair()
        
        return min(ans1,ans2)
        
                    
                
            
            
            
            
            
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
    