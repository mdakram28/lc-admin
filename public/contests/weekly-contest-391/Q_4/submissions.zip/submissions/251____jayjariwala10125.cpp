class Solution {
public:
struct data_struct{
    multiset<int>m;
    data_struct(){
    }
    void insert(int x){
        m.insert(x);
    }
    void remove(int x){
        m.erase(m.find(x));
    }
    void erase(int x){
        m.erase(x);
    }
    bool count(int x){
        return m.count(x);
    }
    int size(){
        return m.size();
    }
    int lower_bound(int x){
        auto it =  m.lower_bound(x);
        if(it==m.end()){
            return -1;
        }
        else{
            return *it;
        }
    }
    auto upper_bound(int x){
        auto it =  m.upper_bound(x);
        if(it==m.end()){
            return -1;
        }
        else{
            return *it;
        }
    }
    int max(){
        return *(--m.end());
    }
    int min(){
        return *(m.begin());
    }
};
    int minimumDistance(vector<vector<int>>& v) {
        data_struct d1;
        data_struct d2;
        int ans = INT_MAX;
        for(auto &i:v){
            d1.insert(i[0]+i[1]);
            d2.insert(i[0]-i[1]);
        }
        for(auto &i:v){
            int sum = i[0]+i[1];
            int diff = i[0]-i[1];
            d1.remove(sum);
            d2.remove(diff);
            int mx1 = d1.max();
            int mn1 = d1.min();
            int mx2 = d2.max();
            int mn2 = d2.min();
            int mx = max(mx2-mn2,mx1-mn1);
            ans=min(ans,mx);
            d1.insert(sum);
            d2.insert(diff);
        }
        return ans;
    }
};