class Solution {
public:
	struct node
	{
		pair<int,int> p;
		pair<int,int> q;
	};
	
	node mx[4],mn[4];

    int minimumDistance(vector<vector<int>>& points) {
		int n=points.size();
		memset(mx,-0x3f,sizeof mx);
		memset(mn,0x3f,sizeof mn);
		
		for(int st=0;st<4;st++){
			for(int i=0;i<n;i++){
				int now=0;
				for(int j=0;j<2;j++){
					if(st&(1<<j)) now-=points[i][j];
					else now+=points[i][j];
				}
				if(now>mx[st].p.first){
					mx[st].q=mx[st].p;
					mx[st].p={now,i};
				}
				else if(now>mx[st].q.first){
					mx[st].q={now,i};
				}

				if(now<mn[st].p.first){
					mn[st].q=mn[st].p;
					mn[st].p={now,i};
				}
				else if(now<mn[st].q.first){
					mn[st].q={now,i};
				}
			}
		}

		int ans=2e9;
		for(int i=0;i<n;i++){
			int mxx=0;
			for(int st=0;st<4;st++){
				priority_queue <int> tmp;
				if(mx[st].p.second!=i && mn[st].p.second!=i) tmp.push(mx[st].p.first-mn[st].p.first);
				if(mx[st].p.second!=i && mn[st].q.second!=i) tmp.push(mx[st].p.first-mn[st].q.first);
				if(mx[st].q.second!=i && mn[st].p.second!=i) tmp.push(mx[st].q.first-mn[st].p.first);
				if(mx[st].q.second!=i && mn[st].q.second!=i) tmp.push(mx[st].q.first-mn[st].q.first);
				mxx=max(mxx,tmp.top());
			}

			ans=min(ans,mxx);
		}
		return ans;
	}
};