class Solution {
    
    class P {
        int r, c;
        P(int r, int c) {
            this.r = r;
            this.c = c;
        }
    }
    
    public int minimumDistance(int[][] points) {
        int smxi = 0;
        int smni = 0;
        int dmxi = 0;
        int dmni = 0;
        
        ArrayList<P> pts = new ArrayList<P>();
        for (int[] point : points) {
            pts.add(new P(point[0], point[1]));
        }
        
        for (int i = 0; i < pts.size(); i++) {
            if (pts.get(i).r + pts.get(i).c > pts.get(smxi).r + pts.get(smxi).c) {
                smxi = i;
            }
            
            if (pts.get(i).r + pts.get(i).c < pts.get(smni).r + pts.get(smni).c) {
                smni = i;
            }
            
            if (pts.get(i).r - pts.get(i).c > pts.get(dmxi).r - pts.get(dmxi).c) {
                dmxi = i;
            }
            
            if (pts.get(i).r - pts.get(i).c < pts.get(dmni).r - pts.get(dmni).c) {
                dmni = i;
            }
            
        }
        
        
        int a = solve(exclude(pts, smxi));
        int b = solve(exclude(pts, smni));
        int c = solve(exclude(pts, dmxi));
        int d = solve(exclude(pts, dmni));
        
        return min(a, b, c, d);
    }
    
    public int min(int a, int b, int c, int d) {
        int A = Math.min(a, b);
        int C = Math.min(c, d);
        return Math.min(A, C);
    }
    
    public ArrayList<P> exclude(ArrayList<P> points, int t) {
        ArrayList<P> newList = new ArrayList<P>();
        for (int i = 0; i < points.size(); i++) {
            if (i == t) continue;
            newList.add(new P(points.get(i).r, points.get(i).c));
        }
        return newList;
    }
    
    public int solve(ArrayList<P> points) {
        ArrayList<Integer> sums = new ArrayList<Integer>();
        ArrayList<Integer> diff = new ArrayList<Integer>();
        for (P p : points) {
            sums.add(p.r + p.c);
            diff.add(p.r - p.c);
        }
        
        Collections.sort(sums);
        Collections.sort(diff);
        
        return Math.max(sums.get(sums.size()-1) - sums.get(0), diff.get(diff.size()-1) - diff.get(0));
    }
}