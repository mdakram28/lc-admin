import java.util.*;
import java.util.stream.*;

public class Solution {
    private long f(List<long[]> A, long N) {
        long[] init = A.get(0);
        long minSum = init[0] + init[1], maxSum = minSum;
        long minDiff = init[0] - init[1], maxDiff = minDiff;

        for (long[] a : A) {
            long sum = a[0] + a[1], diff = a[0] - a[1];
            minSum = Math.min(minSum, sum);
            maxSum = Math.max(maxSum, sum);
            minDiff = Math.min(minDiff, diff);
            maxDiff = Math.max(maxDiff, diff);
        }

        return Math.max(maxSum - minSum, maxDiff - minDiff);
    }
    
    public int minimumDistance(int[][] points) {
        List<long[]> A = Stream.of(points).map(p -> new long[] {p[0], p[1]}).collect(Collectors.toList());
        
        long minSum = A.get(0)[0] + A.get(0)[1], maxSum = minSum;
        long minDiff = A.get(0)[0] - A.get(0)[1], maxDiff = minDiff;
        int[] indices = new int[4];

        for (int i = 1; i < A.size(); i++) {
            long[] a = A.get(i);
            long sum = a[0] + a[1], diff = a[0] - a[1];

            if (sum < minSum) {
                minSum = sum;
                indices[0] = i;
            } 
            else if (sum > maxSum) {
                maxSum = sum;
                indices[1] = i;
            }

            if (diff < minDiff) {
                minDiff = diff;
                indices[2] = i;
            } 
            else if (diff > maxDiff) {
                maxDiff = diff;
                indices[3] = i;
            }
        } 
        
        long ans = Long.MAX_VALUE;

        for (int t : indices) {
            ArrayList<long[]> curr = new ArrayList<long[]>(A);
            curr.remove(t);
            ans = Math.min(ans, f(curr, curr.size()));
        }
        
        return (int) ans;
    }
}
