class Solution {
//     public int minimumDistance(int[][] points) {

//     }
    public int minimumDistance(int[][] points) {
        Arrays.sort(points, (a,b)->a[0]-b[0]);

        int minA = Integer.MAX_VALUE/10;
        int minB = Integer.MAX_VALUE/10;
        int ans = 0;
        int loc = 0;
        int n = points.length;
        for (int i = 0; i < n; i++) {
            int[] p = points[i];
            int f = Integer.MIN_VALUE/10;
            f = Math.max(f, p[0]+p[1] - minA);
            f = Math.max(f, p[0]-p[1] - minB);

            if(ans<f){
                loc = i;
                ans = f;
            }
            minA = Math.min(p[0]+p[1],minA);
            minB = Math.min(p[0]-p[1],minB);
        }


        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int[] p = points[i];
            if(Math.abs(p[0]-points[loc][0]) + Math.abs(p[1]-points[loc][1])  == ans){
                list.add(i);
            }
        }



        minA = Integer.MAX_VALUE/10;
        minB = Integer.MAX_VALUE/10;
        ans = 0;
        for (int i = 0; i < n; i++) {
            if(i== loc) continue;
            int[] p = points[i];
            int f = Integer.MIN_VALUE/10;
            f = Math.max(f, p[0]+p[1] - minA);
            f = Math.max(f, p[0]-p[1] - minB);

            ans = Math.max(f, ans);
            minA = Math.min(p[0]+p[1],minA);
            minB = Math.min(p[0]-p[1],minB);
        }
        
        if(list.size() ==1){
            loc = list.get(0);
            minA = Integer.MAX_VALUE/10;
            minB = Integer.MAX_VALUE/10;
            int res  = 0;
            for (int i = 0; i < n; i++) {
                if(i== loc) continue;
                int[] p = points[i];
                int f = Integer.MIN_VALUE/10;
                f = Math.max(f, p[0]+p[1] - minA);
                f = Math.max(f, p[0]-p[1] - minB);

                res = Math.max(f, res);
                minA = Math.min(p[0]+p[1],minA);
                minB = Math.min(p[0]-p[1],minB);
            }
            ans = Math.min(res ,ans);
            
        }



        return ans;
    }


}