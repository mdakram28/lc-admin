#define ll long long
class Solution {
public:
    int dist(vector<int> &a, vector<int> &b){
        return abs(a[0]-b[0])+abs(a[1]-b[1]);
    }
    vector<int> get_max(vector<vector<int>> points){
        // sort(points.begin(),points.end());
        int a = 0, b = 0;
        int maxd = -1;
        int ld = -1, rd = -1;
        
        for(int i = 1;i<points.size();i++){
            int x = points[i][0], y = points[i][1];
            int d = dist(points[i],points[a]);
            if(d> maxd){
                maxd = d;
                ld = a, rd = i;
            }
            d = dist(points[i],points[b]);
            if(d> maxd){
                maxd = d;
                ld = b, rd = i;
            }
            
            if(y>points[a][1]){
                int dy = y-points[a][1];
                int dx = x-points[a][0];
                if(dy>dx){
                    a = i;
                }
            }
            if(y<points[b][1]){
                int dy = points[b][1] - y;
                int dx = x-points[b][0];
                if(dy>dx){
                    b = i;
                }
            }
            // cout<<a<<" "<<b<<endl;
        }
        return {maxd,ld,rd};
    }
    int minimumDistance(vector<vector<int>>& points) {
        sort(points.begin(),points.end());
        int n = points.size();
        auto vv = get_max(points);
        int ans = vv[0], ld = vv[1], rd = vv[2];
        // cout<<ld<<" -> "<<rd<<endl;
        vector<vector<int>> v = points;
        v.erase(v.begin()+ld);
        ans = min(ans,get_max(v)[0]);
        v = points;
        v.erase(v.begin()+rd);
        ans = min(ans,get_max(v)[0]);
        return ans;
    }
};