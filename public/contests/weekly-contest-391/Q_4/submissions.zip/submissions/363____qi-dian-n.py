

def MaxDist(A, N):

    # List to store maximum and
    # minimum of all the four forms
    V0 = [[0, -1] for i in range(N)]
    V1 = [[0, -1] for i in range(N)]

    for i in range(N):
        V0[i] = A[i][0] + A[i][1], i
        V1[i] = A[i][0] - A[i][1], i

    # Sorting both the vectors
    V0.sort()
    V1.sort()

    maximum = max(V0[-1][0] - V0[0][0], V1[-1][0] - V1[0][0])

    return maximum, V0[0][1], V0[-1][1], V1[0][1], V1[-1][1]


class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        mx, a, b, c, d = MaxDist(points, n)
        mx1 = MaxDist(points[:a] + points[a + 1 :], n - 1)[0]
        mx2 = MaxDist(points[:b] + points[b + 1 :], n - 1)[0]
        mx3 = MaxDist(points[:c] + points[c + 1 :], n - 1)[0]
        mx4 = MaxDist(points[:d] + points[d + 1 :], n - 1)[0]
        return min(mx, mx1, mx2, mx3, mx4)