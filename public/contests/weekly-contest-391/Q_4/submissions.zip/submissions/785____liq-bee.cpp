class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        std::sort(points.begin(), points.end(), 
                  [](vector<int> &a, vector<int> &b)->bool {
                     return a[0] < b[0] || a[0] == b[0] && a[1] < b[1]; 
                  });
        auto mm = [&points](int del)->vector<int> {
            int hi = -1;
            int lo = -1;
            vector<int> ret(2, -1);
            int dis = -1;
            // printf("%d\n", del);
            for (int i = 0; i < points.size(); i++) {
                // printf("%d %d %d\n", i, lo, hi);
                if (i == del) {
                    continue;
                }
                int ha = 0;
                int hb = 0;
                int d = 0;
                if (hi != -1) {
                    ha = points[i][0] - points[hi][0];
                    hb = points[i][1] - points[hi][1];
                    d = std::abs(ha) + std::abs(hb);
                    if (dis < d) {
                        ret[0] = hi;
                        ret[1] = i;
                        dis = d;
                    }
                }
                
                if (lo != -1) {
                    ha = points[i][0] - points[lo][0];
                    hb = points[i][1] - points[lo][1];
                    d = std::abs(ha) + std::abs(hb);
                    if (dis < d) {
                        ret[0] = lo;
                        ret[1] = i;
                        dis = d;
                    }
                }
                
                if (hi == -1 || points[i][0] - points[hi][0] < points[i][1] - points[hi][1]) {
                    hi = i;
                }
                if (lo == -1 || points[i][0] - points[lo][0] < points[lo][1] - points[i][1]) {
                    lo = i;
                }
            }
            return ret;
        };
        
        vector<int> v = mm(-1);
        vector<int> vv = mm(v[0]);
        int dis0 = std::abs(points[vv[0]][0] - points[vv[1]][0]) + std::abs(points[vv[0]][1] - points[vv[1]][1]);
        
        vv = mm(v[1]);
        int dis1 = std::abs(points[vv[0]][0] - points[vv[1]][0]) + std::abs(points[vv[0]][1] - points[vv[1]][1]);
        
        int ret = std::min(dis0, dis1);
        
        return ret;
    }
};