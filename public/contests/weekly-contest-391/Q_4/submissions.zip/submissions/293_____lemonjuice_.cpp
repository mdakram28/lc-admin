class Solution {
public:

    int MaxDist(vector<pair<int, int> >& A, int N)
{
    // Vectors to store maximum and
    // minimum of all the four forms
    vector<int> V(N), V1(N);
 
    for (int i = 0; i < N; i++) {
        V[i] = A[i].first + A[i].second;
        V1[i] = A[i].first - A[i].second;
    }
 
    // Sorting both the vectors
    sort(V.begin(), V.end());
    sort(V1.begin(), V1.end());
 
    int maximum
        = max(V.back() - V.front(), V1.back() - V1.front());
 
    return maximum;
}

    int minimumDistance(vector<vector<int>>& points) {
        vector <pair<int,int>> v1,v2;
        int n=points.size();
        for(int i=0;i<n;i++){
            v1.push_back({points[i][0]+points[i][1],i});
            v2.push_back({points[i][0]-points[i][1],i});
        }
        sort(v1.begin(),v1.end());
        sort(v2.begin(),v2.end());
        pair <int,int> op1={v1.back().second,v1.front().second};
        if(v2.back().first-v2.front().first>v1.back().first-v1.front().first){
            op1={v2.back().second,v2.front().second};
        }
        vector <pair<int,int>> x1,x2;
        for(int i=0;i<n;i++){
            if(i==op1.first){
                continue;
            }
            x1.push_back({points[i][0],points[i][1]});
        }
        for(int i=0;i<n;i++){
            if(i==op1.second){
                continue;
            }
            x2.push_back({points[i][0],points[i][1]});
        }
        return min(MaxDist(x1,n-1),MaxDist(x2,n-1));
    }
};