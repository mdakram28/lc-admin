#define INF 0x3f3f3f3f

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        int a, b;
        int mx = -INF;
        vector<priority_queue<pair<int, int>>> pq(4);
        pq[0].push({-points[0][0] - points[0][1], 0});
        pq[1].push({points[0][0] - points[0][1], 0});
        pq[2].push({-points[0][0] + points[0][1], 0});
        pq[3].push({points[0][0] + points[0][1], 0});
        for(int i = 1; i < n; i ++) {
            int x = points[i][0], y = points[i][1];
            if(x + y + pq[0].top().first > mx) {
                mx = x + y + pq[0].top().first;
                a = pq[0].top().second, b = i;
            }
            if(-x + y + pq[1].top().first > mx) {
                mx = -x + y + pq[1].top().first;
                a = pq[1].top().second, b = i;
            }
            if(x - y + pq[2].top().first > mx) {
                mx = x - y + pq[2].top().first;
                a = pq[2].top().second, b = i;
            }
            if(-x - y + pq[3].top().first > mx) {
                mx = -x - y + pq[3].top().first;
                a = pq[3].top().second, b = i;
            }
            pq[0].push({-x - y, i});
            pq[1].push({x - y, i});
            pq[2].push({-x + y, i});
            pq[3].push({x + y, i});
        }
        return min(cal(points, a), cal(points, b));
    }
    
    int cal(vector<vector<int>>& points, int remove) {
        int res = -INF;
        int n = points.size();
        vector<priority_queue<int>> pq(4);
        for(int i = 0; i < n; i ++) {
            if(i == remove) continue;
            int x = points[i][0], y = points[i][1];
            if(!pq[0].empty()) {
                res = max(res, x + y + pq[0].top());
                res = max(res, -x + y + pq[1].top());
                res = max(res, x - y + pq[2].top());
                res = max(res, -x - y + pq[3].top());
            }
            pq[0].push({-x - y});
            pq[1].push({x - y});
            pq[2].push({-x + y});
            pq[3].push({x + y});
        }
        return res;
    }
};