class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        # from sortedcontainers import SortedList
        points.sort()
        def find_max_dist(points_selected):
            # # northwest - southeast
            # explored = SortedList()
            # for idx, (x, y) in enumerate(points_selected):
            #     pass
            res, n = 0, len(points_selected)
            idx_small, idx_large = -1, -1
            for p, q in [[1, 1], [1, -1], [-1, 1], [-1, -1]]:
                smallest = p * points_selected[0][0] + q * points_selected[0][1]
                idx1 = 0
                for i in range(1, n):
                    cur = p * points_selected[i][0] + q * points_selected[i][1]
                    if cur - smallest > res:
                        res = max(res, cur - smallest)
                        idx_small, idx_large = idx1, i
                    if cur < smallest:
                        idx1 = i
                        smallest = cur
            return res, idx_small, idx_large # dist, idx1, idx2
        
        _, idx1, idx2 = find_max_dist(points)
        d1, _, _ = find_max_dist(points[:idx1] + points[(idx1+1):])
        d2, _, _ = find_max_dist(points[:idx2] + points[(idx2+1):])
        return min(d1, d2)
        