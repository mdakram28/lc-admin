import heapq

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        """
        1. mahatten-distance = |x_i - x_j| + |y_i - y_j|
        2. |x_i - x_j| + |y_i - y_j| = max(
            (x_i - x_j) + (y_i - y_j), => (x_i + y_i) - (x_j + y_j)
            (x_i - x_j) + (y_j - y_i), => (x_i - y_i) - (x_j - y_j)
            (x_j - x_i) + (y_i - y_j), => (x_j - y_j) - (x_i - y_i)
            (x_j - x_i) + (y_j - y_i), => (x_j + y_j) - (x_i + y_i)
        ).
        3. |x_i - x_j| + |y_i - y_j| = max(
            sum(i) - sum(j),
            diff(i) - diff(j),
            diff(j) - diff(i),
            sum(j) - sum(i),
        )
        """
        max_s, min_s = list(), list()
        max_d, min_d = list(), list()
        for _, (x, y) in enumerate(points):
            s = x + y
            d = x - y
            
            heapq.heappush(max_s, -s)
            heapq.heappush(min_s, s)
            heapq.heappush(max_d, -d)
            heapq.heappush(min_d, d)

        ret = float("+inf")
        for _, (x, y) in enumerate(points):
            s = x + y
            d = x - y
            
            f1, f2, f3, f4 = False, False, False, False
            if -s == max_s[0]:
                heapq.heappop(max_s)
                f1 = True
            if s == min_s[0]:
                heapq.heappop(min_s)
                f2 = True
            if -d == max_d[0]:
                heapq.heappop(max_d)
                f3 = True
            if d == min_d[0]:
                heapq.heappop(min_d)
                f4 = True
                
            ret = min(
                ret,
                max(
                    -max_s[0] - min_s[0],
                    -max_d[0] - min_d[0]
                )
            )
            
            if f1:
                heapq.heappush(max_s, -s)
            if f2:
                heapq.heappush(min_s, s)
            if f3:
                heapq.heappush(max_d, -d)
            if f4:
                heapq.heappush(min_d, d)
            
        return ret