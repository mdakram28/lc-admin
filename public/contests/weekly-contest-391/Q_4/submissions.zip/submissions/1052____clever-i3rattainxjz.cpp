class Solution {
public:
    static bool cmp(pair<int, int>& a, pair<int, int>& b) {
        if (a.first < b.first)
            return true;
        return false;
    }
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<pair<int, int>> record1(n), record2(n);
        for (int i = 0; i < n; ++i) {
            record1[i] = { points[i][0] + points[i][1],i };
            record2[i] = { points[i][0] - points[i][1],i };
        }
        sort(record1.begin(), record1.end(), cmp);
        sort(record2.begin(), record2.end(), cmp);
        int dist1 = record1[n - 1].first - record1[0].first, dist2 = record2[n - 1].first - record2[0].first;
        int tmp = INT32_MAX;
        if (dist1 > dist2) {
            if (record1[0].second == record2[0].second)
                tmp = min(tmp, max(record1[n - 1].first - record1[1].first, record2[n - 1].first - record2[1].first));
            else if (record1[0].second == record2[n - 1].second)
                tmp = min(tmp, max(record1[n - 1].first - record1[1].first, record2[n - 2].first - record2[0].first));
            else
                tmp = min(tmp, max(record1[n - 1].first - record1[1].first, record2[n - 1].first - record2[0].first));
            if (record1[n - 1].second == record2[0].second)
                tmp = min(tmp, max(record1[n - 2].first - record1[0].first, record2[n - 1].first - record2[1].first));
            else if (record1[n - 1].second == record2[n - 1].second)
                tmp = min(tmp, max(record1[n - 2].first - record1[0].first, record2[n - 2].first - record2[0].first));
            else
                tmp = min(tmp, max(record1[n - 2].first - record1[0].first, record2[n - 1].first - record2[0].first));
        }
        else {
            if (record2[0].second == record1[0].second)
                tmp = min(tmp, max(record2[n - 1].first - record2[1].first, record1[n - 1].first - record1[1].first));
            else if (record2[0].second == record1[n - 1].second)
                tmp = min(tmp, max(record2[n - 1].first - record2[1].first, record1[n - 2].first - record1[0].first));
            else
                tmp = min(tmp, max(record2[n - 1].first - record2[1].first, record1[n - 1].first - record1[0].first));
            if (record2[n - 1].second == record1[0].second)
                tmp = min(tmp, max(record2[n - 2].first - record2[0].first, record1[n - 1].first - record1[1].first));
            else if (record2[n - 1].second == record1[n - 1].second)
                tmp = min(tmp, max(record2[n - 2].first - record2[0].first, record1[n - 2].first - record1[0].first));
            else
                tmp = min(tmp, max(record2[n - 2].first - record2[0].first, record1[n - 1].first - record1[0].first));
        }
        return tmp;
    }
};