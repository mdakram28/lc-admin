from sortedcontainers import SortedList

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        s, d = SortedList(), SortedList()
        for p in points:
            s.add(p[0] + p[1])
            d.add(p[0] - p[1])
        ans = sys.maxsize
        for p in points:
            tot, diff = p[0] + p[1], p[0] - p[1]
            s.discard(tot)
            d.discard(diff)
            ans = min(ans, max(s[-1] - s[0], d[-1] - d[0]))
            s.add(tot)
            d.add(diff)
        return ans