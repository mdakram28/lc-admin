class Solution {
public:
    int findMax(vector< vector<int> > points, int ind){
        int n = points.size();
        vector<int> add;
        vector<int> sub;
        for(int i=0;i<n;i++){
            if(ind!=i){
                add.push_back(points[i][0]+points[i][1]);
                sub.push_back(points[i][0]-points[i][1]);
            }
        }
        sort(add.begin(), add.end());
        sort(sub.begin(), sub.end());
        int maxi = max(add.back()-add.front(), sub.back()- sub.front());
        return maxi;
    }
    int minimumDistance(vector<vector<int>>& points) {
        int N = points.size();
        
        vector< pair<int, int> > v(N), v1(N);
 
        for (int i = 0; i < N; i++) {
            v[i] = {points[i][0] + points[i][1], i};
            v1[i] = {points[i][0] - points[i][1], i};
        }

        // Sorting both the vectors
        sort(v.begin(), v.end());
        sort(v1.begin(), v1.end());
        int mini = 0;
        if(v.back().first-v.front().first > v1.back().first-v1.front().first){
            int ind = v.back().second;
            int maxi1 = findMax(points, ind);
            ind = v.front().second;
            int maxi2 = findMax(points, ind);
            mini = min(maxi1, maxi2);
        } else{
            
            int ind = v1.back().second;
            int maxi1 = findMax(points, ind);
            ind = v1.front().second;
            int maxi2 = findMax(points, ind);
            mini = min(maxi1, maxi2);
        }
        return mini;
    }
};