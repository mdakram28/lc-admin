type ANS = [[number, number, number], [number, number, number], number];
function cla(points: [number, number][]): ANS {
  const sortAPoint: [number, number, number] = points.reduce((ans, point, idx) => ans[0] + ans[1] < point[0] + point[1] ? ans : [...point, idx], [...points[0], 0]); // 最左下
  const sortBPoint: [number, number, number] = points.reduce((ans, point, idx) => ans[0] - ans[1] < point[0] - point[1] ? ans : [...point, idx], [...points[0], 0]); // 最左上
  let ans: ANS = [sortAPoint, sortBPoint, Math.abs(sortAPoint[0] - sortBPoint[0]) + Math.abs(sortAPoint[1] - sortAPoint[1])];
  for (let i = 0; i < points.length; i++) {
    const point = points[i];
    if (Math.abs(sortAPoint[0] - point[0]) + Math.abs(sortAPoint[1] - point[1]) > ans[2]) {
      ans = [sortAPoint, [...point, i], Math.abs(sortAPoint[0] - point[0]) + Math.abs(sortAPoint[1] - point[1])];
    }
    if (Math.abs(sortBPoint[0] - point[0]) + Math.abs(sortBPoint[1] - point[1]) > ans[2]) {
      ans = [sortBPoint, [...point, i], Math.abs(sortBPoint[0] - point[0]) + Math.abs(sortBPoint[1] - point[1])];
    }
  }
  return ans;
}
function minimumDistance(points: [number, number][]): number {
  const [pointA, pointB] = cla(points);

  return Math.min(cla(points.filter((_, idx) => idx !== pointA[2]))[2], cla(points.filter((_, idx) => idx !== pointB[2]))[2])
};