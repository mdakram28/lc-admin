class Solution {
public:
    int minimumDistance(vector<vector<int>>& A) {
        int minsum, maxsum, mindiff, maxdiff,mis,mas,mid,mad;
        int N=A.size(); 
        minsum = maxsum = A[0][0] + A[0][1];
        mindiff = maxdiff = A[0][0] - A[0][1];
        vector<array<int,4>>ps(N+1,{int(-1e8),int(1e8),int(-1e8),int(1e8)});
        vector<array<int,4>>ss(N+1,{int(-1e8),int(1e8),int(-1e8),int(1e8)});
        ps[0]={maxsum, minsum, maxdiff, mindiff};

        for (int i = 1; i < N; i++) {
            int sum = A[i][0] + A[i][1];
            int diff = A[i][0] - A[i][1];

            if (sum < minsum)
                minsum = sum;
            else if (sum > maxsum)
                maxsum = sum;
            if (diff < mindiff)
                mindiff = diff;
            else if (diff > maxdiff)
                maxdiff = diff;
            ps[i]={maxsum, minsum, maxdiff, mindiff};
        }
        minsum=maxsum=A[N-1][0]+A[N-1][1];
        mindiff=maxdiff=A[N-1][0]-A[N-1][1];
        ss[N-1]={maxsum, minsum, maxdiff, mindiff};
        for(int i=N-2;i>=0;i--){
            int sum = A[i][0] + A[i][1];
            int diff = A[i][0] - A[i][1];
            if (sum < minsum)
                minsum = sum;
            else if (sum > maxsum)
                maxsum = sum;
            if (diff < mindiff)
                mindiff = diff;
            else if (diff > maxdiff)
                maxdiff = diff;
            ss[i]={maxsum, minsum, maxdiff, mindiff};
        }
        int ans=3e8;
        for(int i=0;i<N;i++){
            int mas=-2e8;
            int mis=2e8;
            int mad=-2e8;
            int mid=2e8;
            if(i>0){
                mas=max(mas, ps[i-1][0]);
                mis=min(mis, ps[i-1][1]);
                mad=max(mad, ps[i-1][2]);
                mid=min(mid, ps[i-1][3]);
            }
            if(i<N){
                mas=max(mas, ss[i+1][0]);
                mis=min(mis, ss[i+1][1]);
                mad=max(mad, ss[i+1][2]);
                mid=min(mid, ss[i+1][3]);
            }
            ans=min(ans,max(mas-mis,mad-mid));
        }

        return ans;
    }
};