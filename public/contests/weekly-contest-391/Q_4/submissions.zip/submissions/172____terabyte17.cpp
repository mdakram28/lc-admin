class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset<int> zz, zo, oz, oo;
        int high = 100000001;
        int n = points.size();
        int ans = INT_MAX;
        for(int i=0;i<n;i++)
        {
            zz.insert(points[i][0]+points[i][1]);
            zo.insert(points[i][0]+high-points[i][1]);
            oz.insert(high-points[i][0] + points[i][1]);
            oo.insert(high-points[i][0]+high-points[i][1]);
        }
        for(int i=0;i<n;i++)
        {
            int curr = 0;
            zz.erase(zz.find(points[i][0]+points[i][1]));
            zo.erase(zo.find(points[i][0]+high-points[i][1]));
            oz.erase(oz.find(high-points[i][0] + points[i][1]));
            oo.erase(oo.find(high-points[i][0]+high-points[i][1]));
            curr = max(curr, *(zz.rbegin()) - *(zz.begin()));
            curr = max(curr, *(zo.rbegin()) - *(zo.begin()));
            curr = max(curr, *(oz.rbegin()) - *(oz.begin()));
            curr = max(curr, *(oo.rbegin()) - *(oo.begin()));
            ans = min(ans, curr);
            zz.insert(points[i][0]+points[i][1]);
            zo.insert(points[i][0]+high-points[i][1]);
            oz.insert(high-points[i][0] + points[i][1]);
            oo.insert(high-points[i][0]+high-points[i][1]);
        }
        return ans;
    }
};