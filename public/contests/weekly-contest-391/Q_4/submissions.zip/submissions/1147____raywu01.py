class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        max_dist, p1, p2 = find_max_dist(points)
        
        points_1 = [p for p in points]
        points_1.remove(p1)
        max_dist_1, _, _ = find_max_dist(points_1)
        
        points_2 = [p for p in points]
        points_2.remove(p2)
        max_dist_2, _, _ = find_max_dist(points_2)
        return min(max_dist_1, max_dist_2)
        
        

def find_max_dist(points):
    p1, p2 = mmax(points, key=lambda x: x[0] - x[1]), mmin(points, key=lambda x: x[0] - x[1])
    d1 = dist(p1, p2)

    p3, p4 = mmax(points, key=lambda x: x[0] + x[1]), mmin(points, key=lambda x: x[0] + x[1])
    d2 = dist(p3, p4)
    
    if d1 > d2:
        return d1, p1, p2
    
    return d2, p3, p4
        
        
def mmax(points, key):
    max_score = -float('inf')
    ret = None
    for p in points:
        s = key(p)
        if s > max_score:
            ret = p
            max_score = s
    return ret
        
def mmin(points, key):
    min_score = float('inf')
    ret = None
    for p in points:
        s = key(p)
        if s < min_score:
            ret = p
            min_score = s
    return ret  
        
def dist(p1, p2):
    x1, y1 = p1
    x2, y2 = p2
    return abs(x1 - x2) + abs(y1 - y2)