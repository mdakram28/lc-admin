class Solution {
public:
    typedef long long ll;
    int minimumDistance(vector<vector<int>>& points) {
        auto x = helper(points);
        reverse(points.begin(), points.end());
        auto y = helper(points);
        return min(x, y);
    }
    int helper(vector<vector<int>>& points) {
        ll a1 = -1e9;
        ll b1 = -1e9;
        ll a2 = 1e9;
        ll b2 = 1e9;
        int n = points.size();
        int k = -1;
        ll ans = -1;
        for(int i = 0;i< n;i++){
            ll x = points[i][0];
            ll y = points[i][1];
            a1 = max(a1,x + y), a2 = min(a2,x + y);
            b1 = max(b1,x - y), b2 = min(b2,x - y);
            auto t = max(a1-a2,b1-b2);
            if (t > ans) {
                ans = t;
                k = i;
            }
        }
        a1 = -1e9;
        b1 = -1e9;
        a2 = 1e9;
        b2 = 1e9;
        for(int i = 0;i< n;i++){
            if (i == k) {
                continue;
            }
            ll x = points[i][0];
            ll y = points[i][1];
            a1 = max(a1,x + y), a2 = min(a2,x + y);
            b1 = max(b1,x - y), b2 = min(b2,x - y);
        }
        ans = 0;
        ans = max(a1-a2,b1-b2);
        
        return ans;
    }
};