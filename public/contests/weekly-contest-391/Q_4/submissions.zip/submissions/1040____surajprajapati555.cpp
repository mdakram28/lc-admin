class Solution {
public:
    
    int minimumDistance(vector<vector<int>>&points) {
       
        int ans=INT_MAX; 
       
        map<int,int> mp1, mp2;
       
        for (int i = 0; i <points.size(); i++) {
            mp1[points[i][0] +points[i][1]]++;
            mp2[points[i][0] -points[i][1]]++;
       
        }
        for (int i = 0; i <points.size(); i++) 
        {
            if (--mp1[points[i][0] +points[i][1]]==0)
            {
                mp1.erase(points[i][0] +points[i][1]);
            }

            if (--mp2[points[i][0] -points[i][1]] == 0)
            {
                mp2.erase(points[i][0] -points[i][1]);
            }

            ans = min(ans, max(mp1.rbegin()->first - mp1.begin()->first, mp2.rbegin()->first - mp2.begin()->first));
           
            mp1[points[i][0] +points[i][1]]++;
           
            mp2[points[i][0] -points[i][1]]++;
        }
        return ans;
    }
};