



class Solution {
public:
    int minimumDistance(vector<vector<int>>& A) {
        int N=A.size();
        vector<pair<int,int>> V(N), V1(N);
        for (int i = 0; i < N; i++) {
            V[i] = {A[i][0] + A[i][1],i};
            V1[i] ={A[i][0] - A[i][1],i};
        }

        // Sorting both the vectors
        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());
        int ans=INT_MAX;
        for(int i=0;i<N;i++){
            int f=V1[0].first,l=V1.back().first;
            if(V[i].second==V1[0].second) f=V1[1].first;
            if(V[i].second==V1.back().second) l=V1[N-2].first;
            int temp=V.back().first-V[0].first;
            if(i==0) temp=V.back().first-V[1].first;
            if(i==(N-1)) temp=V[N-2].first-V[0].first;
            ans=min(ans,max(l-f,temp));
        }

       return ans;
    }
};