class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        set<pair<int, int>> s;
        for(auto &point: points){
            int x = point[0], y = point[1];
            point[0] = x + y;
            point[1] = x - y;
            s.emplace(point[0], point[1]);
        }
        vector<int> x, y;
        for(auto &point: points){
            x.push_back(point[0]);
            y.push_back(point[1]);
        }
        sort(x.begin(), x.end());
        sort(y.begin(), y.end());
        int ans = INT_MAX;
        int n = points.size();
        ans = min(ans, max(y[n - 1] - y[0], x[n - 1] - x[1]));
        ans = min(ans, max(y[n - 1] - y[0], x[n - 2] - x[0]));
        ans = min(ans, max(x[n - 1] - x[0], y[n - 1] - y[1]));
        ans = min(ans, max(x[n - 1] - x[0], y[n - 2] - y[0]));
        if(s.count({x[0], y[0]})) ans = min(ans, max(y[n - 1] - y[1], x[n - 1] - x[1]));
        if(s.count({x[0], y[n - 1]})) ans = min(ans, max(y[n - 2] - y[0], x[n - 1] - x[1]));
        if(s.count({x[n - 1], y[0]})) ans = min(ans, max(y[n - 1] - y[1], x[n - 2] - x[0]));
        if(s.count({x[n - 1], y[n - 1]})) ans = min(ans, max(y[n - 2] - y[0], x[n - 2] - x[0]));
        return ans;
    }
};