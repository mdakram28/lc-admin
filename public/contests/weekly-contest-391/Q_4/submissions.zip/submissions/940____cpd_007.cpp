class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<int> s(n,0);
        vector<int> d(n,0);
        for(int i = 0; i<n; i++) {
            s[i] = points[i][0] + points[i][1];
            d[i] = points[i][0] - points[i][1];
        }
        sort(s.begin(), s.end());
        sort(d.begin(), d.end());
        
        int ans = INT_MAX;
        
        for(int i = 0; i<n; i++) {
            int cur = 0;
            int x = points[i][0] + points[i][1];
            int y = points[i][0] - points[i][1];
            if(s[0] == x) cur = max(cur, s[n-1] - s[1]);
            else if(s[n-1] == x) cur = max(cur, s[n-2] - s[0]);
            else cur = max(cur, s[n-1] - s[0]);
            if(d[0] == y) cur = max(cur, d[n-1] - d[1]);
            else if(d[n-1] == y) cur = max(cur, d[n-2] - d[0]);
            else cur = max(cur, d[n-1] - d[0]);
            
            ans = min(ans, cur);
        }
        return ans;
    }
};