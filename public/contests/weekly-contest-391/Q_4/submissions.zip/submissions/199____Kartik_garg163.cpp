class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {
        multiset<int> st1, st2;
        for(int i=0; i<p.size(); i++){
            st1.insert(p[i][0]+p[i][1]);
            st2.insert(p[i][0]-p[i][1]);
        }
        int ans = 1e9;
        for(int i=0; i<p.size(); i++){
            int sum = p[i][0] + p[i][1];
            int diff = p[i][0] - p[i][1];
            auto it1 = st1.find(sum);
            auto it2 = st2.find(diff);
            st1.erase(it1);
            st2.erase(it2);
            int val1 = *--st1.end() - *st1.begin();
            int val2 = *--st2.end() - *st2.begin();
            int val = max(val1,val2);
            ans = min(ans,val);
            st1.insert(sum);
            st2.insert(diff);
        }
        return ans;
    }
};