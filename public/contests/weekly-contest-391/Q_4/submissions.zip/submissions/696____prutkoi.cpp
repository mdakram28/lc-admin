class Solution {
public:
    int manhat(vector<vector<int>> &points, int to_avoid){
        set<pair<int, int>> st;
        set<pair<int, int>> st1;
        
        for(int i = 0; i < points.size(); i++){
            if(i == to_avoid) continue;
            auto x = points[i];
            int a = x[0] + x[1];
            int b = x[0] - x[1];
            st.insert({a, i});
            st1.insert({b, i});
        }
        int a = st.rbegin() -> first - st.begin() -> first;
        int b = st1.rbegin() -> first - st1.begin() -> first;
        return max(a, b);
    }
    int minimumDistance(vector<vector<int>>& points) {
        set<pair<int, int>> st;
        set<pair<int, int>> st1;
        
        for(int i = 0; i < points.size(); i++){
            auto x = points[i];
            int a = x[0] + x[1];
            int b = x[0] - x[1];
            st.insert({a, i});
            st1.insert({b, i});
        }
        int a = st.rbegin() -> first - st.begin() -> first;
        int b = st1.rbegin() -> first - st1.begin() -> first;
        int ans = 1e9;
        if(a > b){
            int rem = st.begin() -> second;
            ans = manhat(points, rem);
            rem = st.rbegin() -> second;
            ans = min(manhat(points, rem), ans);
        }
        else{
            int rem = st1.begin() -> second;
            ans = manhat(points, rem);
            rem = st1.rbegin() -> second;
            ans = min(manhat(points, rem), ans);
        }
        return ans;
    }
};