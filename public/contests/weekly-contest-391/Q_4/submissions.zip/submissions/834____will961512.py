class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        def MaxDist(A):

            minsum = maxsum = A[0][0] + A[0][1]
            mindiff = maxdiff = A[0][0] - A[0][1]
            bs, ss, bd, sd = 0, 0, 0, 0

            for i in range(1, len(A)):
                sum = A[i][0] + A[i][1]
                diff = A[i][0] - A[i][1]
                if (sum < minsum):
                    minsum = sum
                    ss = i
                elif (sum > maxsum):
                    maxsum = sum
                    bs = i
                if (diff < mindiff):
                    mindiff = diff
                    sd = i
                elif (diff > maxdiff):
                    maxdiff = diff
                    bd = i

            return [max(maxsum - minsum, maxdiff - mindiff), bs, ss, bd, sd]
        
        use = MaxDist(points)
        ans = use[0]
        for i in range(1, 5):
            tmp = points.copy()
            tmp.pop(use[i])
            ans = min(ans, MaxDist(tmp)[0])
        return ans