class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int minsum, maxsum, mindiff, maxdiff;
        vector<vector<int>> p = vector<vector<int>>(4, vector<int>(2, 0));
        int index1 = 0;
        int index2 = 0;
        int index3 = 0;
        int index4 = 0;
        minsum = maxsum = points[0][0] + points[0][1];
        mindiff = maxdiff = points[0][0] - points[0][1];
        p[0][0] = points[0][0];
        p[0][1] = points[0][1];
        p[1][0] = points[0][0];
        p[1][1] = points[0][1];
        p[2][0] = points[0][0];
        p[2][1] = points[0][1];
        p[3][0] = points[0][0];
        p[3][1] = points[0][1];
        for (int i = 1; i < points.size(); i++) {
            int sum = points[i][0] + points[i][1];
            int diff = points[i][0] - points[i][1];
            if (sum < minsum) {
                minsum = sum;
                p[0][0] = points[i][0];
                p[0][1] = points[i][1];
                index1 = i;
            }
            else if (sum > maxsum) {
                maxsum = sum;
                p[1][0] = points[i][0];
                p[1][1] = points[i][1];
                index2 = i;
            }
            if (diff < mindiff) {
                mindiff = diff;
                p[2][0] = points[i][0];
                p[2][1] = points[i][1];
                index3 = i;
            }
            else if (diff > maxdiff) {
                maxdiff = diff;
                p[3][0] = points[i][0];
                p[3][1] = points[i][1];
                index4 = i;
            }
        }
        
        int tmp = (maxsum - minsum) > (maxdiff - mindiff) ? 1: 0;
        if (tmp) {
            points.erase(points.begin() + index1);
            if (index1 < index2) {
                index2--;
            }
            points.push_back({p[0][0], p[0][1]});
        } else {
            points.erase(points.begin() + index3);
            if (index3 < index4) {
                index4--;
            }
            points.push_back({p[2][0], p[2][1]});
        }
        
        minsum = maxsum = points[0][0] + points[0][1];
        mindiff = maxdiff = points[0][0] - points[0][1];

        for (int i = 1; i < points.size() - 1; i++) {
            int sum = points[i][0] + points[i][1];
            int diff = points[i][0] - points[i][1];
            if (sum < minsum) {
                minsum = sum;
            }
            else if (sum > maxsum) {
                maxsum = sum;
            }
            if (diff < mindiff) {
                mindiff = diff;
            }
            else if (diff > maxdiff) {
                maxdiff = diff;
            }
        }
        
        int maximum1 = max(maxsum - minsum, maxdiff - mindiff);
        if (tmp) {
            points.erase(points.begin() + index2);
        } else {
            points.erase(points.begin() + index4);
        }
        
        minsum = maxsum = points[0][0] + points[0][1];
        mindiff = maxdiff = points[0][0] - points[0][1];

        for (int i = 1; i < points.size(); i++) {
            int sum = points[i][0] + points[i][1];
            int diff = points[i][0] - points[i][1];
            if (sum < minsum) {
                minsum = sum;
            }
            else if (sum > maxsum) {
                maxsum = sum;
            }
            if (diff < mindiff) {
                mindiff = diff;
            }
            else if (diff > maxdiff) {
                maxdiff = diff;
            }
        }
        
        // if ((maxsum - minsum) > (maxdiff - mindiff)) {
        //     cout << p[1][0] << p[1][1] << " " << p[0][0] << p[0][1];
        // } else {
        //     cout << p[2][0] << p[2][1] << " " << p[3][0] << p[3][1];
        // }
        int maximum2 = max(maxsum - minsum, maxdiff - mindiff);
        return min(maximum1, maximum2);
    }
};