#define ll long long int
class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        ll n=points.size();
        multiset<ll> sum,dif;
        for(ll i=0;i<n;i++){
            ll a=points[i][0];
            ll b=points[i][1];
            sum.insert(a+b);
            dif.insert(a-b);
        }
        ll ans=1e17;
        for(ll i=0;i<n;i++){
            ll a=points[i][0];
            ll b=points[i][1];
            sum.erase(sum.find(a+b));
            dif.erase(dif.find(a-b));
            ll ele1=*sum.begin();
            ll ele2=*sum.rbegin();
            ll ele3=*dif.begin();
            ll ele4=*dif.rbegin();
            ll see2=max(ele2-ele1,ele4-ele3);
            ans=min(ans,see2);
            sum.insert(a+b);
            dif.insert(a-b);
        }
        return ans;
    }
};