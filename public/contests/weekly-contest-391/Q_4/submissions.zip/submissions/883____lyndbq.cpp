#include<bits/stdc++.h>
using namespace std;

class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int mina = INT_MAX, minb = INT_MAX, maxa = INT_MIN, maxb = INT_MIN, ans = INT_MAX;
        for(auto i : points){
            mina = min(i[0]+i[1], mina);
            maxa = max(i[0]+i[1], maxa);
            minb = min(i[0]-i[1], minb);
            maxb = max(i[0]-i[1], maxb);
        }

        int mia = INT_MAX, mib = INT_MAX, maa = INT_MIN, mab = INT_MIN;
        bool ok = true;
        for(auto i : points){
            if(i[0] + i[1] == mina && ok){
                ok = false;
                continue;
            }
            mia = min(i[0]+i[1], mia);
            maa = max(i[0]+i[1], maa);
            mib = min(i[0]-i[1], mib);
            mab = max(i[0]-i[1], mab);
        }
        ans = min(ans, max(maa-mia, mab-mib));

        mia = INT_MAX, mib = INT_MAX, maa = INT_MIN, mab = INT_MIN;
        ok = true;
        for(auto i : points){
            if(i[0] + i[1] == maxa && ok){
                ok = false;
                continue;
            }
            mia = min(i[0]+i[1], mia);
            maa = max(i[0]+i[1], maa);
            mib = min(i[0]-i[1], mib);
            mab = max(i[0]-i[1], mab);
        }
        ans = min(ans, max(maa-mia, mab-mib));


        mia = INT_MAX, mib = INT_MAX, maa = INT_MIN, mab = INT_MIN;
        ok = true;
        for(auto i : points){
            if(i[0] - i[1] == minb && ok){
                ok = false;
                continue;
            }
            mia = min(i[0]+i[1], mia);
            maa = max(i[0]+i[1], maa);
            mib = min(i[0]-i[1], mib);
            mab = max(i[0]-i[1], mab);
        }
        ans = min(ans, max(maa-mia, mab-mib));

        mia = INT_MAX, mib = INT_MAX, maa = INT_MIN, mab = INT_MIN;
        ok = true;
        for(auto i : points){
            if(i[0] - i[1] == maxb && ok){
                ok = false;
                continue;
            }
            mia = min(i[0]+i[1], mia);
            maa = max(i[0]+i[1], maa);
            mib = min(i[0]-i[1], mib);
            mab = max(i[0]-i[1], mab);
        }
        ans = min(ans, max(maa-mia, mab-mib));

        return ans;
    }
};