static constexpr int MAXN = 200005;
typedef long long ll;
typedef pair<int, int> pii;
static constexpr int INF = 0x3f3f3f3f;
class Solution {
    public:
    int ans = INF;
    int n;
    inline void del(vector<vector<int>>& points, int x)
    {
        vector<pii> v1;
        vector<pii> v2;
        for (int i = 0; i < n; i ++)
        {
            if (i == x) continue ;
            v1.push_back({points[i][0] + points[i][1], i});
            v2.push_back({points[i][0] - points[i][1], i});
        }
        sort(v1.begin(), v1.end());
        sort(v2.begin(), v2.end());
        ans = min(ans, max(v1[n - 2].first - v1[0].first, v2[n - 2].first - v2[0].first));
    }

    int minimumDistance(vector<vector<int>>& points) {
        vector<pii> v1;
        vector<pii> v2;
        n = points.size();
        for (int i = 0; i < n; i ++)
        {
            v1.push_back({points[i][0] + points[i][1], i});
            v2.push_back({points[i][0] - points[i][1], i});
        }
        sort(v1.begin(), v1.end());
        sort(v2.begin(), v2.end());
        del(points, v1[0].second);
        del(points, v1[n - 1].second);
        del(points, v2[0].second);
        del(points, v2[n - 1].second);
        return ans;
    }
};