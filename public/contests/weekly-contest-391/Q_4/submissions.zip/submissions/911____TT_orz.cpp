// --start--
#define fi first
#define se second
using pii = std::pair<int, int>;
using pll = std::pair<long long, long long>;
using pci = std::pair<char, int>;
using i64 = signed long long;
const int mod = 1e9 + 7;
const int inf = 0x3f3f3f3f; // 10^9级别的
const i64 dinf = 0x3f3f3f3f3f3f3f3f; //4.62*10^18级别的



class Solution {
 public:
	int minimumDistance(vector<vector<int>>& a) {
		vector<pii> b;
		vector<pii> c;
		int n = a.size();
		for (int i = 0; i < n; i++) { //存坐标
			b.push_back({a[i][0] - a[i][1], i});
			c.push_back({a[i][0] + a[i][1], i});
		}
		sort(b.begin(), b.end());
		sort(c.begin(), c.end());
		auto get=[&](int id){
				int x=0,y=0;

				if(b[0].se==id)  x=max(x,b[n-1].fi-b[1].fi);
				else if(b[n-1].se==id)  x=max(x,b[n-2].fi-b[0].fi);
            else x=max(x,b[n-1].fi-b[0].fi);
				if(c[0].se==id)  y=max(y,c[n-1].fi-c[1].fi);
				else if(c[n-1].se==id)  y=max(y,c[n-2].fi-c[0].fi);
                else y=max(y,c[n-1].fi-c[0].fi);
				 // cout<<x<<" "<<" "<<y<<endl;
                return max(x,y);
		};
		int res=inf;
        // cout<<c[n-1].se<<endl;
		res=min(res,get(b[n-1].se));
		res=min(res,get(b[0].se));
		res=min(res,get(c[n-1].se));
		res=min(res,get(c[0].se));
		return res;
	}
};