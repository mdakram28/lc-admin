class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        bis=[]
        dirs = [(1,1),(1,-1),(-1,1),(-1,-1)]
        for d in dirs:
            dx,dy=d
            a=[]
            i=-1
            for x,y in points:
                i += 1
                v=x*dx+y*dy
                a.append((v,i))
                a.sort(reverse=True)
                a=a[:2]
            bis.append(a)
        ans = inf
        for i in range(4):
            ti = bis[i][0][1]
            md=0
            md = max(md, abs(bis[i^1][1 if ti==bis[i^1][0][1] else 0][0]+bis[~(i^1)][1 if ti==bis[~(i^1)][0][1] else 0][0]))
            md = max(md, abs(bis[i][1][0]+bis[~i][1 if ti==bis[~i][0][1] else 0][0]))
            ans = min(ans,md)
        # print(bis)
        return ans