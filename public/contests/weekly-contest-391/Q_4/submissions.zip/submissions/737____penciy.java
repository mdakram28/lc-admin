public class Solution {
    public int minimumDistance(int[][] points) {
        Arrays.sort(points, (o1, o2) -> o1[0] - o2[0]);
        PriorityQueue<int[]> pq1 = new PriorityQueue<>((o1, o2) -> o1[0] - o2[0]);
        PriorityQueue<int[]> pq2 = new PriorityQueue<>((o1, o2) -> o1[0] - o2[0]);
        pq1.offer(new int[]{points[0][0]+points[0][1], 0});
        pq2.offer(new int[]{points[0][0]-points[0][1], 0});
        int maxDist = Integer.MIN_VALUE;
        int[] maxIds = new int[2];
        for(int i = 1;i < points.length;++i){
            int[] point = points[i];
            int x = point[0], y = point[1];
            int dist1 = (x+y) - pq1.peek()[0];
            int dist2 = (x-y) - pq2.peek()[0];
            if(dist1 > maxDist || dist2 > maxDist){
                maxDist = Math.max(dist1, dist2);
                maxIds[0] = dist1 > dist2 ? pq1.peek()[1] : pq2.peek()[1];
                maxIds[1] = i;
            }
            pq1.offer(new int[]{x+y, i});
            pq2.offer(new int[]{x-y, i});
        }
        int maxDist1 = Integer.MIN_VALUE;
        pq1 = new PriorityQueue<>((o1, o2) -> o1[0] - o2[0]);
        pq2 = new PriorityQueue<>((o1, o2) -> o1[0] - o2[0]);
        for(int i = 0;i < points.length;++i){
            if(i == maxIds[0]) continue;
            int[] point = points[i];
            int x = point[0], y = point[1];
            if(!pq1.isEmpty()) {
                int dist1 = (x + y) - pq1.peek()[0];
                int dist2 = (x - y) - pq2.peek()[0];
                if (dist1 > maxDist1 || dist2 > maxDist1) {
                    maxDist1 = Math.max(dist1, dist2);
                }
            }
            pq1.offer(new int[]{x+y, i});
            pq2.offer(new int[]{x-y, i});
        }
        int maxDist2 = Integer.MIN_VALUE;
        pq1 = new PriorityQueue<>((o1, o2) -> o1[0] - o2[0]);
        pq2 = new PriorityQueue<>((o1, o2) -> o1[0] - o2[0]);
        for(int i = 0;i < points.length;++i){
            if(i == maxIds[1]) continue;
            int[] point = points[i];
            int x = point[0], y = point[1];
            if(!pq1.isEmpty()) {
                int dist1 = (x + y) - pq1.peek()[0];
                int dist2 = (x - y) - pq2.peek()[0];
                if (dist1 > maxDist2 || dist2 > maxDist2) {
                    maxDist2 = Math.max(dist1, dist2);
                }
            }
            pq1.offer(new int[]{x+y, i});
            pq2.offer(new int[]{x-y, i});
        }
        return Math.min(maxDist1, maxDist2);
    }
}