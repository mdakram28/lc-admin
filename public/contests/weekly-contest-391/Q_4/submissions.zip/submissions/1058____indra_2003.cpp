class Solution {
public:
    static bool comp(vector<int> &a, vector<int> &b){
        if(a[0] == b[0]) return a[1] < b[1];
        return a[0] < b[0];
    }
    int minimumDistance(vector<vector<int>>& a) {
        int n = a.size();
        vector<pair<int, int>> sum(n), diff(n);
        for(int i=0;i<n;i++){
            sum[i] = {a[i][0] + a[i][1], i};
            diff[i] = {a[i][0] - a[i][1], i};
        }
        sort(sum.begin(), sum.end(), greater<pair<int, int>>());
        int idx1 = sum[0].second, idx2 = sum[n-1].second;
        sort(diff.begin(), diff.end());
        int ind1 = diff[0].second, ind2 = diff[n-1].second;
        // for(auto it: diff) cout << it.first << " ";
        // cout << endl;
        vector<int> v(n);
        for(int i=0;i<n;i++){
            if(i == idx1){
                // cout << "first" << i << endl;
                v[i] = sum[1].first - sum[n-1].first;
            }
            else if(i == idx2){
                // cout << "second" << i << endl;
                v[i] = sum[0].first - sum[n-2].first;
            }
            else{
                // cout << "third" << i << endl;
                v[i] = sum[0].first - sum[n-1].first;
            }
        }
        for(int i=0;i<n;i++){
            if(i == ind1){
                v[i] = max(v[i], abs(diff[1].first - diff[n-1].first));
            }
            else if(i == ind2){
                v[i] = max(v[i], abs(diff[0].first - diff[n-2].first));
            }
            else{
                v[i] = max(v[i], abs(diff[0].first - diff[n-1].first));
            }
        }
        // for(auto it: v) cout << it << " ";
        // cout << endl;
        int ans = *min_element(v.begin(), v.end());
        return ans;
    }
};