class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        map<int,int> mp1,mp2;
        for(auto&it:points){
            mp1[it[0]+it[1]]++;
            mp2[it[0]-it[1]]++;
        }
        int ans=INT_MAX;
        for(auto&it:points){
            int a=it[0]+it[1];
            int b=it[0]-it[1];
            mp1[a]--;mp2[b]--;
            if(mp1[a]==0)
            mp1.erase(a);
            if(mp2[b]==0)
            mp2.erase(b);
            ans=min(ans,max(mp1.rbegin()->first-mp1.begin()->first,mp2.rbegin()->first-mp2.begin()->first));
            mp1[a]++;mp2[b]++;
            
            
        }
    return ans;
    }
};