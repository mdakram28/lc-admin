class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        # minimize max(|xi-xj|+|yi-yj|) -> max(|xi+yi-xj-yj|,|xi-yi-xj+yj|)
        points = [(a+b,a-b) for a,b in points]
        maxL = [None]*len(points)
        minL = [None]*len(points)
        maxL[0] = points[0]
        minL[0] = points[0]
        for i in range(1,len(points)):
            a,b = maxL[i-1]
            c,d = points[i]
            maxL[i] = (a if a >= c else c, b if b >= d else d)
            a,b = minL[i-1]
            minL[i] = (a if a <= c else c, b if b <= d else d)
        maxR = [None]*len(points)
        minR = [None]*len(points)
        maxR[-1] = points[-1]
        minR[-1] = points[-1]
        for i in range(len(points)-2,-1,-1):
            a,b = maxR[i+1]
            c,d = points[i]
            maxR[i] = (a if a >= c else c, b if b >= d else d)
            a,b = minR[i+1]
            minR[i] = (a if a <= c else c, b if b <= d else d)
        ans = None
        for i in range(len(points)):
            max_ = maxR[i+1][0] if i==0 else maxL[i-1][0] if i==len(points)-1 else maxL[i-1][0] if maxL[i-1][0] >= maxR[i+1][0] else maxR[i+1][0]
            min_ = minR[i+1][0] if i==0 else minL[i-1][0] if i==len(points)-1 else minL[i-1][0] if minL[i-1][0] <= minR[i+1][0] else minR[i+1][0]
            resa = max_-min_
            max_ = maxR[i+1][1] if i==0 else maxL[i-1][1] if i==len(points)-1 else maxL[i-1][1] if maxL[i-1][1] >= maxR[i+1][1] else maxR[i+1][1]
            min_ = minR[i+1][1] if i==0 else minL[i-1][1] if i==len(points)-1 else minL[i-1][1] if minL[i-1][1] <= minR[i+1][1] else minR[i+1][1]
            resb = max_-min_
            res = resa if resa >= resb else resb
            ans = ans if ans is not None and ans <= res else res
        return ans
            