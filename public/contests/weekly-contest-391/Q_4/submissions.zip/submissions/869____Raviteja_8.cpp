class Solution {
public:
    
    int minimumDistance(vector<vector<int>>& pts) {
        int N = pts.size();
        vector<pair<int,int>> v(N), v1(N);
        
        for (int i = 0; i < N; i++) {
            v[i].first = pts[i][0] + pts[i][1];
            v[i].second = i;
            v1[i].first = pts[i][0] - pts[i][1];
            v1[i].second = i;
        }

        // Sorting both the vectors
        sort(v.begin(), v.end());
        sort(v1.begin(), v1.end());
     
        int ans =  max(v.back().first-v[0].first , v1.back().first-v1[0].first);
        map<int,int> mp,mp1;
        for(int i=0;i<N;i++){
            mp[v[i].second] = i;
            mp1[v1[i].second] = i;
        }
        for(int i=0;i<N;i++){
            int x=v.back().first,y=v[0].first,p=v1.back().first,q=v1[0].first;
            if(mp[i]==N-1){
                x = v[N-2].first;
            }
            if(mp[i]==0){
                y = v[1].first;
            }
            if(mp1[i]==N-1){
                p = v1[N-2].first;
            }
            if(mp1[i]==0){
                q = v1[1].first;
            }
            ans = min(ans,max(x-y,p-q));
        }
        return ans;
    }
};