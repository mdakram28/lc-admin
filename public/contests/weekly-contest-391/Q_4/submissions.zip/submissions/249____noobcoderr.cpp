class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        int res = INT_MAX;
        int minDiff, maxDiff, minSum, maxSum;
        minDiff = minSum = INT_MAX;
        maxDiff = maxSum = INT_MIN;
        priority_queue<int> maxSumQ, maxDiffQ;
        priority_queue<int, vector<int>, greater<int>> minSumQ, minDiffQ;
        for(vector<int>& p : points){
            int sum = p[0] + p[1];
            int diff = p[0] - p[1];
            maxSumQ.push(sum);
            minSumQ.push(sum);
            maxDiffQ.push(diff);
            minDiffQ.push(diff);
        }
        for(vector<int>& p : points){
            int sum = p[0] + p[1];
            int diff = p[0] - p[1];
            vector<int> v(4, INT_MAX);
            if(sum == minSumQ.top()){
                v[0] = sum;
                minSumQ.pop();
            }
            if(sum == maxSumQ.top()){
                v[1] = sum;
                maxSumQ.pop();
            }
            if(diff == minDiffQ.top()){
                v[2] = diff;
                minDiffQ.pop();
            }
            if(diff == maxDiffQ.top()){
                v[3] = diff;
                maxDiffQ.pop();
            }
            //    int maximum = max(maxsum - minsum, maxdiff - mindiff);

            res = min(res, max(maxSumQ.top() - minSumQ.top(), maxDiffQ.top() - minDiffQ.top()));
            if(v[0] != INT_MAX){
                minSumQ.push(sum);
            }
            if(v[1] != INT_MAX){
                maxSumQ.push(sum);
            }
            if(v[2] != INT_MAX){
                minDiffQ.push(diff);
            }
            if(v[3] != INT_MAX){
                maxDiffQ.push(diff);
            }
            
        }
        return res;
        
    }
};