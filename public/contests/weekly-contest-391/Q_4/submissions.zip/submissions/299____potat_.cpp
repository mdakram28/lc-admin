class Solution {
public:
    int MaxDist(vector<vector<int> >& A, int N)
    {
        // Vectors to store maximum and
        // minimum of all the four forms
        vector<pair<int, int>> V(N), V1(N);

        for (int i = 0; i < N; i++) {
            V[i].first = A[i][0] + A[i][1];
            V1[i].first = A[i][0] - A[i][1];
            V[i].second = i;
            V1[i].second = i;
        }

        // Sorting both the vectors
        sort(V.begin(), V.end());
        sort(V1.begin(), V1.end());
        
        vector<int> a;
        a.push_back((int) V[0].second);
        a.push_back((int) V1[0].second);
        a.push_back((V.back()).second);
        a.push_back((V1.back()).second);
        
        int ans = 1e9;
        
        for(int i = 0; i < a.size(); i++)
        {
            vector<int> newv, newv1;
            
            for(int j = 0; j < V.size(); j++)
            {
                if(V[j].second != a[i])
                    newv.push_back(V[j].first);
                if(V1[j].second != a[i])
                    newv1.push_back(V1[j].first);
            }
            
            ans = min(ans, max(newv.back() - newv.front(), newv1.back() - newv1.front()));
            
        }

        return ans;
    }
    
    int minimumDistance(vector<vector<int>>& points) {
        return MaxDist(points, points.size());
    }
};