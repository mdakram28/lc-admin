class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        multiset <int> ms1,ms2;
        for(auto &point:points) {
            int x=point[0],y=point[1];
            ms1.insert(x+y);
            ms2.insert(x-y);
        }
        int res=INT_MAX;
        for(auto &point:points) {
            int x=point[0],y=point[1];
            ms1.erase(ms1.find(x+y));
            ms2.erase(ms2.find(x-y));
            auto l1=*ms1.begin();
            auto r1=*ms1.rbegin();
            auto l2=*ms2.begin();
            auto r2=*ms2.rbegin();
            res=min(res,max(r1-l1,r2-l2));
            ms1.insert(x+y);
            ms2.insert(x-y);
        }
        return res;
    }
};