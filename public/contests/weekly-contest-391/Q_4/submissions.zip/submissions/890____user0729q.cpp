class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        vector<pair<int,int>> s;
        vector<pair<int,int>> d;
        int i = 0;
        for(vector<int> pp : points)
        {
           s.push_back(make_pair(pp[0]+pp[1],i));
            d.push_back(make_pair(pp[0]-pp[1],i));
            i++;
        }
        sort(s.begin(),s.end());
        sort(d.begin(),d.end());
        int n = s.size();
        int ans = s[n-1].first - s[0].first;
        int l = s[0].second;
        int r = s[n-1].second;
        
        if(d[n-1].first - d[0].first > ans)
        {
            ans = d[n-1].first - d[0].first;
            l = d[0].second;
            r = d[n-1].second;
        }
        // cout<<ans<<" "<<l<<" "<<r<<"\n";
        s.clear();
        d.clear();
        
        for(int i = 0;i<n;i++)
        {
            if(i ==l)continue;
            s.push_back(make_pair(points[i][0]+points[i][1],i));
            d.push_back(make_pair(points[i][0]-points[i][1],i));
        }
        sort(s.begin(),s.end());
        sort(d.begin(),d.end());
        ans = min(ans,max(s[n-2].first - s[0].first,d[n-2].first - d[0].first ));
        // cout<<ans<<"\n";
        s.clear();
        d.clear();
        
        for(int i = 0;i<n;i++)
        {
            if(i ==r)continue;
            s.push_back(make_pair(points[i][0]+points[i][1],i));
            d.push_back(make_pair(points[i][0]-points[i][1],i));
        }
        sort(s.begin(),s.end());
        sort(d.begin(),d.end());
        ans = min(ans,max(s[n-2].first - s[0].first,d[n-2].first - d[0].first ));
        // cout<<max(s[n-1].first - s[0].first,d[n-1].first - d[0].first )<<"\n";
        return ans;
    }
};