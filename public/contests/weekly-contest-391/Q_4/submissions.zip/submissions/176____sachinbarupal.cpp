class Solution {
public:
    int minimumDistance(vector<vector<int>>& p) {

        int n = p.size();
        vector<int> s, d;
        s.push_back(p[0][0] + p[0][1]);
        d.push_back(p[0][0] - p[0][1]);
        for(int i=1; i<n; i++) {
            int sum = p[i][0] + p[i][1];
            int diff = p[i][0] - p[i][1];
            
            s.push_back(sum);
            d.push_back(diff);
        }
        
        sort(s.begin(),s.end());
        sort(d.begin(),d.end());
        
        int ans = max(s[n-1] - s[0], d[n-1] - d[0]);
        
        for(int i=0; i<n; ++i){
            int sum = p[i][0] + p[i][1];
            int diff = p[i][0] - p[i][1];
            int maxiS = s[n-1], miniS = s[0];
            int maxiD = d[n-1], miniD = d[0];
            if(sum == s[0]){
                miniS = s[1];
            }else if(sum == s[n-1]){
                maxiS = s[n-2];
            }
            
            if(diff == d[0]){
                miniD = d[1];
            }else if(diff == d[n-1]){
                maxiD = d[n-2];
            }
            
            ans = min(ans, max(maxiS - miniS,maxiD - miniD));
            
            
        }
        
        return ans;
    }
};