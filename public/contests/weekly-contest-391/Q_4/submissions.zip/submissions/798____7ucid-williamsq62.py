from sortedcontainers import *
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        res = inf
        t1 = SortedList()
        t2 = SortedList()
        find = dict()
        n = len(points)
        for i, (x, y) in enumerate(points):
            find[i] = []
            find[i].append(x - y)
            find[i].append(x + y)
            t1.add(x - y)
            t2.add(x + y)
        for i in range(n):
            a, b = find[i]
            t1.discard(a)
            t2.discard(b)
            res = min(res, max(t1[-1] - t1[0], t2[-1] - t2[0]))
            t1.add(a)
            t2.add(b)
        return res