class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        pos = []
        neg = []
        for i,(a,b) in enumerate(points):
            pos.append((a+b, i))
            neg.append((a-b, i))
        pos.sort()
        neg.sort()
        print(pos)
        print(neg)
        res = max(pos[-1][0]-pos[0][0], neg[-1][0]-neg[0][0])
        if pos[-1][1] == neg[-1][1]:
            res = min(res, max(pos[-2][0]-pos[0][0], neg[-2][0]-neg[0][0]))
        elif pos[-1][1] == neg[0][1]:
            res = min(res, max(pos[-2][0]-pos[0][0], neg[-1][0]-neg[1][0]))
        else:
            res = min(res, max(pos[-2][0]-pos[0][0], neg[-1][0]-neg[0][0]))
        if pos[0][1] == neg[-1][1]:
            res = min(res, max(pos[-1][0]-pos[1][0], neg[-2][0]-neg[0][0]))
        elif pos[0][1] == neg[0][1]:
            res = min(res, max(pos[-1][0]-pos[1][0], neg[-1][0]-neg[1][0]))
        else:
            res = min(res, max(pos[-1][0]-pos[1][0], neg[-1][0]-neg[0][0]))
        res = min(res, max(pos[-1][0]-pos[0][0], neg[-2][0]-neg[0][0]))
        res = min(res, max(pos[-1][0]-pos[0][0], neg[-1][0]-neg[1][0]))
        return res