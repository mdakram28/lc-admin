from sortedcontainers import SortedList
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:

        x=SortedList()
        y=SortedList()
        n=len(points)
        ans=10**18
        for i in range(n):
            a,b=points[i][0],points[i][1]
            x.add(a+b)
            y.add(a-b)
        for i in range(n):
            a,b=points[i][0],points[i][1]
            x.remove(a+b)
            y.remove(a-b)
            p,q=0,len(x)-1
            minx,maxx=x[0],x[q]
            miny,maxy=y[0],y[q]
            x.add(a+b)
            y.add(a-b)
            ans=min(ans,max(maxx-minx,maxy-miny))
        return ans

      
   