class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        map<int, set<int>> x_plus_y_to_index;
        map<int, set<int>> x_minus_y_to_index;
        for (int i = 0; i < points.size(); i++) {
            int x_plus_y = points[i][0] + points[i][1];
            int x_minus_y = points[i][0] - points[i][1];
            x_plus_y_to_index[x_plus_y].insert(i);
            x_minus_y_to_index[x_minus_y].insert(i);
        }
        
        int res = INT_MAX;
        for (int i = 0; i < points.size(); i++) {
            int x_plus_y = points[i][0] + points[i][1];
            int x_minus_y = points[i][0] - points[i][1];
            x_plus_y_to_index[x_plus_y].erase(i);
            x_minus_y_to_index[x_minus_y].erase(i);
            if (x_plus_y_to_index[x_plus_y].empty()) x_plus_y_to_index.erase(x_plus_y);
            if (x_minus_y_to_index[x_minus_y].empty()) x_minus_y_to_index.erase(x_minus_y);
            int feasible1 = abs(x_plus_y_to_index.rbegin()->first - x_plus_y_to_index.begin()->first);
            int feasible2 = abs(x_minus_y_to_index.begin()->first - x_minus_y_to_index.rbegin()->first);
            res = min(res, max(feasible1, feasible2));
            x_plus_y_to_index[x_plus_y].insert(i);
            x_minus_y_to_index[x_minus_y].insert(i);
        }
        return res;
    }
};