class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        n = len(points)
        sum_val = []
        diff_val = []
        for i, (x, y) in enumerate(points):
            sum_val.append((x + y, i))
            diff_val.append((x - y, i))
        
        sum_val.sort()
        diff_val.sort()
        
        ans = float('inf')
        for i in range(n):
            # Sum
            if sum_val[0][1] == i:
                max_sum = sum_val[-1][0] - sum_val[1][0]
            elif sum_val[-1][1] == i:
                max_sum = sum_val[-2][0] - sum_val[0][0]
            else:
                max_sum = sum_val[-1][0] - sum_val[0][0]
            
            # Diff
            if diff_val[0][1] == i:
                max_diff = diff_val[-1][0] - diff_val[1][0]
            elif diff_val[-1][1] == i:
                max_diff = diff_val[-2][0] - diff_val[0][0]
            else:
                max_diff = diff_val[-1][0] - diff_val[0][0]
            
            ans = min(ans, max(max_sum, max_diff))
        
        return ans