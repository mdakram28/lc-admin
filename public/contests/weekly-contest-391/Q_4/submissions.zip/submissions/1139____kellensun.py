from sortedcontainers import SortedList

def dist(x,y):
    return abs(x[0]-y[0]) + abs(x[1]-y[1])

class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        sums = SortedList([])
        diff = SortedList([])
        for i in points:
            sums.add(i[0] + i[1])
            diff.add(i[0] - i[1])
        best = float('inf')
        for i in points:
            sums.remove(i[0] + i[1])
            diff.remove(i[0] - i[1])
            best = min(best, max(sums[-1] - sums[0], diff[-1] - diff[0]))
            sums.add(i[0] + i[1])
            diff.add(i[0] - i[1])
        return best
        