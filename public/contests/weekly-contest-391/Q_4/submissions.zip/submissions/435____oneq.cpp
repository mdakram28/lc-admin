#include <bits/stdc++.h>
using namespace std;
class Solution
{
public:
    int minimumDistance(vector<vector<int>> &points)
    {
        multiset<int> adds, subs;
        for (auto v : points)
        {
            int x = v[0], y = v[1];
            adds.insert(x + y);
            subs.insert(x - y);
        }
        int ans=1e9;
        for (auto v : points)
        {
            int x = v[0], y = v[1];
            adds.extract(x + y);
            subs.extract(x - y);
            int mxa=*adds.rbegin();
            int mia=*adds.begin();
            int mxs=*subs.rbegin();
            int mis=*subs.begin();
            int t=0;
            t=max(t,mxa-mia);
            t=max(t,mxs-mis);
            ans=min(t,ans);
            adds.insert(x+y);
            subs.insert(x-y);
        }
        return ans;
    }
};