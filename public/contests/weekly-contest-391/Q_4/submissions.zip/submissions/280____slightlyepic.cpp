class Solution {
public:
    int minimumDistance(vector<vector<int>>& points) {
        const int n = points.size();
        
        vector<tuple<int, int, int, int>> sfx(n + 1);
        sfx[n] = { INT_MAX, INT_MIN, INT_MAX, INT_MIN };
        
        int minS = points[n - 1][0] + points[n - 1][1];
        int maxS = points[n - 1][0] + points[n - 1][1];
        int minD = points[n - 1][0] - points[n - 1][1];
        int maxD = points[n - 1][0] - points[n - 1][1];

        int i;
        for(i = n - 1; i >= 0; i--) {
            auto& p = points[i];
            int s = p[0] + p[1];
            int d = p[0] - p[1];
            minS = min(minS, s);
            maxS = max(maxS, s);
            minD = min(minD, d);
            maxD = max(maxD, d);
            
            sfx[i] = { minS, maxS, minD, maxD };
        }
        
        minS = INT_MAX;
        maxS = INT_MIN;
        minD = INT_MAX;
        maxD = INT_MIN;
        
        int ans = 1e9;
        for(i = 0; i < n; i++) {
            auto& p = points[i];
            int s = p[0] + p[1];
            int d = p[0] - p[1];
            
            auto [sMinS, sMaxS, sMinD, sMaxD] = sfx[i + 1];
            int dist = max(
                max(maxS, sMaxS) - min(minS, sMinS),
                max(maxD, sMaxD) - min(minD, sMinD)
            );
            ans = min(ans, dist);
            
            minS = min(minS, s);
            maxS = max(maxS, s);
            minD = min(minD, d);
            maxD = max(maxD, d);
        }
        
        return ans;
    }
};