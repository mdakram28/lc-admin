from sortedcontainers import SortedList
class Solution:
    def minimumDistance(self, points: List[List[int]]) -> int:
        output = float("inf")
        nums1 = SortedList()
        nums2 = SortedList()
        for x, y in points:
            nums1.add(x + y)
            nums2.add(x - y)
        for i, (x, y) in enumerate(points):
            nums1.remove(x + y)
            nums2.remove(x - y)
            output = min(output, max(nums1[-1] - nums1[0], nums2[-1] - nums2[0]))
            nums1.add(x + y)
            nums2.add(x - y)
        return output