
type ptr struct {
	idx, val int
}

func minimumDistance(points [][]int) (ans int) {

	d := make([][]ptr, 4)
	for i := range d {
		d[i] = make([]ptr, len(points))
		for j, p := range points {
			switch i {
			case 0:
				d[i][j] = ptr{j, p[0] - p[1]}
			case 1:
				d[i][j] = ptr{j, p[0] + p[1]}
			case 2:
				d[i][j] = ptr{j, -p[0] - p[1]}
			case 3:
				d[i][j] = ptr{j, p[1] - p[0]}
			}
		}
	}
	sort.Slice(d[0], func(i, j int) bool { return d[0][i].val < d[0][j].val })
	sort.Slice(d[1], func(i, j int) bool { return d[1][i].val < d[1][j].val })
	sort.Slice(d[2], func(i, j int) bool { return d[2][i].val < d[2][j].val })
	sort.Slice(d[3], func(i, j int) bool { return d[3][i].val < d[3][j].val })

	ans = 1e9 + 7
	n := len(points)
	for _, rm := range []int{d[0][0].idx, d[0][n-1].idx, d[1][0].idx, d[1][n-1].idx, d[2][0].idx, d[2][n-1].idx, d[3][0].idx, d[3][n-1].idx} {
		// 如果移除了rm，求最远距离
		ans = min(ans, maxDis(rm, n, d))
	}
	return
}
func maxDis(rm int, size int, d[][]ptr) int {
	ret := 0
    for i:=0;i<4;i++ {
        if d[i][size-1].idx == rm {
            ret = max(ret, d[i][size-2].val-d[i][0].val)
        } else if d[i][0].idx == rm {
            ret = max(ret, d[i][size-1].val-d[i][1].val)
        } else {
            ret = max(ret, d[i][size-1].val-d[i][0].val)
        }
    }
	 
	return ret
}