class Solution {
public:
    int minimumDistance(vector<vector<int>>& w) {
        vector<multiset<int>>g(4);
        vector<int>res;
        for(int i = 1; i<w.size(); i++){
            for(int j=0; j<4; j++){
                int s = 0;
                for(int k=0; k<2; k++){
                    if(j>>k&1)s += w[i][k];
                    else s-=w[i][k];
                }
                g[j].insert(s);
            }
        }
        int res1 = 0;
        for(int i=0; i<4; i++){
            int cur = (*g[i].rbegin())-(*g[i].begin());
            if(cur>res1)res1 = cur;
        }
        res.push_back(res1);
        
        for(int i=0; i<w.size(); i++){
            //插入第i个，删除第i+1
             for(int j=0; j<4; j++){
                int s = 0;
                for(int k=0; k<2; k++){
                    if(j>>k&1)s += w[i][k];
                    else s-=w[i][k];
                }
                g[j].insert(s);
            }
            if(i+1<w.size()){
                for(int j=0; j<4; j++){
                    int s = 0;
                    for(int k=0; k<2; k++){
                        if(j>>k&1)s += w[i+1][k];
                        else s-=w[i+1][k];
                    }
                    g[j].extract(s);
                }
            }
            int res1 = 0;
            for(int r=0; r<4; r++){
                int cur = (*g[r].rbegin())-(*g[r].begin());
                if(cur>res1)res1 = cur;
            }
            res.push_back(res1);
            
        }
        return *min_element(res.begin(), res.end());
        
    }
};