class Solution {
public:
    typedef pair<int, int> pii;
    int minimumDistance(vector<vector<int>>& points) {
        int n = points.size();
        vector<pii> a, b;
        for(int i = 0; i < n; i ++) {
            a.push_back({points[i][0] + points[i][1], i});
            b.push_back({points[i][0] - points[i][1], i});
        }
        sort(a.begin(), a.end());
        sort(b.begin(), b.end());
        
        set<int> st; 
        st.insert(a[0].second); st.insert(a.back().second);
        st.insert(b[0].second); st.insert(b.back().second);
        auto check = [&](int x) -> int {
            int res = 0;
            vector<int> a, b;
            for(int i = 0; i < n; i ++) {
                if(i == x) continue;
                    a.push_back(points[i][0] + points[i][1]);
                    b.push_back(points[i][0] - points[i][1]);
                
            }
            sort(a.begin(), a.end());
                sort(b.begin(), b.end());
                res = max(res, max(a.back() - a[0], b.back() - b[0]));
            return res;
        };
        int ans = 2e8 + 10;
        for(int t : st) {
            ans = min(ans, check(t));
        }
        return ans;
    }
};